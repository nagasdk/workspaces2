/*
 * Copyright 2010-2013, Sikuli.org
 * Released under the MIT License.
 *
 * modified RaiMan 2013
 */
package org.sikuli.ide;

public interface NativeLayer {
   public void initApp();
   public void initIDE(SikuliIDE ide);
}

