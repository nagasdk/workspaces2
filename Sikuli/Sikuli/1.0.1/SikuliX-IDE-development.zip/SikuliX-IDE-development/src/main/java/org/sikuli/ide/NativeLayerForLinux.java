/*
 * Copyright 2010-2013, Sikuli.org
 * Released under the MIT License.
 *
 * modified RaiMan 2013
 */
package org.sikuli.ide;

public class NativeLayerForLinux implements NativeLayer {

  @Override
  public void initApp() {
  }

  @Override
  public void initIDE(SikuliIDE ide) {
  }
}
