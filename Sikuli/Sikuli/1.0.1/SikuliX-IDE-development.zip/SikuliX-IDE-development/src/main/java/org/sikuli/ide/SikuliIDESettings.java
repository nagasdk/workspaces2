/*
 * Copyright 2010-2013, Sikuli.org
 * Released under the MIT License.
 *
 * modified RaiMan 2013
 */
package org.sikuli.ide;

import org.sikuli.script.Settings;

public class SikuliIDESettings {

	public static final String SikuliVersion = Settings.SikuliVersionIDE;
}
