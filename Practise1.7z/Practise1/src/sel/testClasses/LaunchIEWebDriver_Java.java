
package sel.testClasses;
import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;

import java.io.*;
import java.sql.Driver;

public class LaunchIEWebDriver_Java {

	
	public static void main(String args[]){
		WebDriver d1;
     WebDriverInstantiate i1 = new WebDriverInstantiate();
    
     d1=WebDriverInstantiate.getIEDriver();
      
     WebDriver d11 = WebDriverInstantiate.getFFDriver();
	 //d1.get("www.google.co.in");	
		
	}
}
