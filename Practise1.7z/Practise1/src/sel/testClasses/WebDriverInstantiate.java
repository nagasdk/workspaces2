
package sel.testClasses;
import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

import java.io.*;
import java.sql.Driver;

public class WebDriverInstantiate {

	private static WebDriver driver ;
	
	WebDriverInstantiate(){
		//driver = new InternetExplorerDriver();		
		System.out.println("hello");
	}
	
	
	public static WebDriver getIEDriver(){
		driver = new InternetExplorerDriver();
		return driver;
	}

	
	public static WebDriver getFFDriver(){
		driver = new FirefoxDriver();
		return driver;
	}
	
	public static WebDriver getDriver(String drvName){
		
		driver = new FirefoxDriver();
		return driver;
	}	
	
}
