package core.classes;

import static practise.players.TeamIndia.*;
import practise.players.TeamIndia;


public class IndianTeam implements TeamIndia{

	@Override
	public String getOpeners() {
		String Openers;
		Openers ="OPENER1: "+OPENER1 + "\n" + "OPENER2: " + OPENER2; 
		return Openers;
	}

	public String getBowlers() {
		String Bowlers;
		Bowlers = "BOWLER1:"+PLAYER6DOWN+"\t"+" BOWLER2: "+PLAYER7DOWN+"\t"+" BOWLER3: "+PLAYER8DOWN+"\t"+" BOWLER4: "+PLAYER9DOWN;
		return Bowlers;
	}

	public String getAllrounders() {
		String AllRounders;
		AllRounders="Allrounder1: "+PLAYER2DOWN+"\t"+" Allrounder2: "+PLAYER3DOWN+"\t"+" Allrounder3: "+PLAYER5DOWN;   
		return AllRounders;
	}

	
}
