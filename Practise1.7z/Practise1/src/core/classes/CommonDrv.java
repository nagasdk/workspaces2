package core.classes;

public class CommonDrv {

	public static void main(String args[]) {
	
		CommonDrv c1 = new CommonDrv(); 
		System.out.println("Helo");
		c1.CommonDrv1();
	}
	


	public  CommonDrv()
	{
		System.out.println("Name: "+CommonDrv.class.getName());
		System.out.println("CanonicalName: " + CommonDrv.class.getCanonicalName());
		System.out.println("SimpleName: " + CommonDrv.class.getSimpleName());
		
		System.out.println("toString: " + CommonDrv.class.toString());
		
	}

	public  void CommonDrv1()
	{
		System.out.println("Name: "+CommonDrv.class.getName());
		System.out.println("CanonicalName: " + CommonDrv.class.getCanonicalName());
		System.out.println("SimpleName: " + CommonDrv.class.getSimpleName());
		
		System.out.println("toString: " + CommonDrv.class.toString());
		
	}

	
	
}
