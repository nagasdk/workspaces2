package core.classes;

import static practise.players.TeamIndia.*;

public class DisplayIndianPlayersName_Order  {

	/**
	 * This is a Sample Program
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub		
		System.out.println("In the Class" + DisplayIndianPlayersName_Order.class.getSimpleName());
		
		//StringConstants i1 = null ;
		System.out.print("Player1: " + OPENER1);System.out.print(", Player2: " + OPENER2);
		System.out.print(", PLAYER1DOWN: " + PLAYER1DOWN);System.out.print(", PLAYER2DOWN: " + PLAYER2DOWN);System.out.print(", PLAYER3DOWN: " + PLAYER3DOWN);System.out.print(", PLAYER4DOWN: " + PLAYER4DOWN);System.out.print(", PLAYER5DOWN: " + PLAYER5DOWN);System.out.print(", PLAYER6DOWN: " + PLAYER6DOWN);System.out.print(", PLAYER7DOWN: " + PLAYER7DOWN);System.out.print(", PLAYER8DOWN: " + PLAYER8DOWN);System.out.print(", PLAYER9DOWN: " + PLAYER9DOWN);
		
		System.out.println("\n**** DISPLAY ONLY OPENERS");
		IndianTeam IT1= new IndianTeam();
		System.out.println(IT1.getOpeners());
		
		System.out.println("\n**** DISPLAY ONLY BOWLERS");
		System.out.println(IT1.getBowlers());

		System.out.println("\n**** DISPLAY ONLY ALLROUNDERS");
		System.out.println(IT1.getAllrounders());

		
		
	}
}
