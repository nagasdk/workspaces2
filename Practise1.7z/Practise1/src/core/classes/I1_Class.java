package core.classes;
import practise.players.I1_sample;


public class I1_Class implements I1_sample{

	/**
	 * @param args
	 */

		

	@Override
	public String PlayerInfo(String s1, String s2, String s3) {
		// TODO Auto-generated method stub
		return s1+s2+s3;
	}

	@Override
	public String PlayerInfo(String s1, String s2) {
		// TODO Auto-generated method stub
		return s1+s2;
	}
		

	

}
