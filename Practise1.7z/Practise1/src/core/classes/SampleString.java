package core.classes;


public class SampleString {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		stringOps s1= new stringOps();
		System.out.println(s1.get_StringConcat("NAGA","RAJU"));
		System.out.println(s1.get_StringReverse("NAGARAJU"));	
		
	}

}
