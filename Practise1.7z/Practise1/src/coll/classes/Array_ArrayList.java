package coll.classes;

import java.util.ArrayList;
import java.util.Iterator;

public class Array_ArrayList {
	public static void main(String[] args){
		
		 Display_ArrValues();
		
		Display_ArrayList();
	
	}

	
	
	
	

	public static void  Display_ArrValues(){
			int arr[];
			
			arr= new int[10];
			
			for(int i=0; i<10;i++)
				arr[i]=i;
			
			System.out.println("***Displaying Array values***");
				for(int i=0; i<10;i++)
					System.out.println("arr values: "+arr[i]);
	 }

	
	/* 		ARRAY LIST is a dynamic array, we can add n no entries
	 		Entries can be of duplicate values also
	
	 */

	public static void Display_ArrayList(){
		ArrayList<String> s1 = new ArrayList<>();
		
		s1.add("hello");
		s1.add(0, "AWelcome");
		s1.add(1, "TO ");
		s1.add(2, "INDIA ");
		s1.add(3, "HYDERABAD");
		s1.add(3, "HYDERABAD");
		
		System.out.println("\n ***Displaying ArrayLIST values*** ");
		Iterator<String> i1= s1.iterator();
			while(i1.hasNext()){
				System.out.println(i1.next());
			}
		
	}
	
}


