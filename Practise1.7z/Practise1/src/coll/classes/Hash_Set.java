package coll.classes;
import java.util.HashSet;


public class Hash_Set {

	/**
	 * @param args
	 * HashSet - is a collection of set of elements(integers,string,obects)
	 * 
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<Integer> phonenos = new HashSet<>();
		phonenos.add(1);
		phonenos.add(2);
		phonenos.add(3);
		phonenos.add(4);
		System.out.println("**** HASHSET **** "+"\n"+phonenos);		
		phonenos.remove(4);
		System.out.println("removing the 4 from set and displaying the other values : "+ phonenos);
		phonenos.add(1);
		phonenos.add(2);
		phonenos.add(3);
		phonenos.add(4);
		System.out.println(phonenos);
		
		
		// IGNORES MULTIPLE VALUES AND DISPLAYS ONLY UNIQUE VALUES
	}

}
