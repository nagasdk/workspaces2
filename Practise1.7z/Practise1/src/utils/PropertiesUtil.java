package utils;

//Import required classes
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

/**
 * This class has methods to read or write from .properties file
 * @author Nagaraju Kura
 *
 */
public class PropertiesUtil {
	
	/**
	 * Path of .properties file
	 */
	private String propertiesFilePath;

	/**
	 * Constructor which takes .properties file path as input
	 * @param propertiesFilePath
	 */
	public PropertiesUtil(String propertiesFilePath) {
		this.propertiesFilePath = propertiesFilePath;
	}
	
	/**
	 * This method is used to write a map of values into
	 * .properties file
	 * @param map
	 */
	public void write(Map<String, String> map) {

		Properties prop = new Properties();

			/*	 try {
						FileInputStream in = new FileInputStream(propertiesFilePath);
						prop.load(in);
						in.close();
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}*/
		
		try {
			//Iterate the HashMap
			for (Entry<String, String> entry : map.entrySet()) {
				//set the properties value
				prop.setProperty(entry.getKey().toString(), entry.getValue().toString());
			}

			
			//save properties to required folder
			prop.store(new FileOutputStream(propertiesFilePath), null);
			
			//System.out.println(map);
			System.out.println("successfully written to properties file");

		} catch (IOException ex) {			
			ex.printStackTrace(); //Print the stack trace
		}
	}

	/**
	 * This method reads the key from .properties file and returns it's value
	 * @author Nagaraju_Kura
	 * @param key
	 * @return value
	 */
	public String read(String key) {

		Properties prop = new Properties();

		try {
			//load a properties file
			prop.load(new FileInputStream(propertiesFilePath));


		}
		catch (IOException ex) {
			ex.printStackTrace();
		}
		
		//get the property value and return it
		return prop.getProperty(key).toString();

	}

	
	/**
	 * This method updates the Value related to a key
	 * @param keyName
	 * @param keyValue
	 * @return void - No Return Type
	 * @throws FileNotFoundException 
	 */
	public void updateKeyValue(String keyName,String keyValue) throws FileNotFoundException{
		 Properties props = new Properties();
		 FileOutputStream  fos = null;
		 
		 try {
			FileInputStream in = new FileInputStream(propertiesFilePath);
			props.load(in);
			in.close();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		 
		 
		 //File f2= new File(propertiesFilePath);	//pims_variables.PimsRes_File);
		try {
			fos = new FileOutputStream(propertiesFilePath);
			props.setProperty(keyName, keyValue);
			props.store(fos, null);
			fos.close();
		}  catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
}



