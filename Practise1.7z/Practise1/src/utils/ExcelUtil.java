package utils;

//import required classes
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Set;

import practise.constants.GenericConstants;

/* JARS REQUIRED  FOR EXCEL OPERATIONS */
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



/**
 * Util class for read/write properties from excel sheet file
 * @author Nagaraju Kura
 *
 */
public class ExcelUtil {
	
	/**
	 * This method reads value of the property in excel sheet based on the pageName and
	 * controlName given
	 * @param pageName
	 * @param controlName
	 * @return String
	 */
	public static String readProps( String pageName, String controlName) {

		//value of the cell that is read
		String value="";
		try
		{
			FileInputStream file = new FileInputStream(GenericConstants.WORKBOOK_PATH);
            System.out.println("Excel File Path" + GenericConstants.WORKBOOK_PATH); 
			//Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);

			//Get desired sheet from the workbook using pageName
			XSSFSheet sheet = workbook.getSheet(pageName);

			/* Fetch the row number which contains the controlName */
			int rowNumber = 0;			
			for (Row row : sheet) {
				for (Cell cell : row) {
					if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
						if (cell.getRichStringCellValue().getString().trim().equals(controlName)) {
							rowNumber = row.getRowNum();  
							break;
						}
					}
				}
			} 

			/* Get the row, it's 2nd column(i.e. column B) value */
			XSSFRow row = sheet.getRow(rowNumber);
			XSSFCell cell = row.getCell(1);
			value = cell.getStringCellValue().trim().toString();		   


			//close the file
			file.close();			

		} 
		catch (Exception e) 
		{
			//Print the exception
			e.printStackTrace();
		}

		return value;
	}

	/**
	 * This method writes a map of values into an excel sheet with
	 * pageName and data given as inputs
	 * @param pageName
	 * @param data
	 */
	public static void writeProps(String pageName, Map<String, Object[]> data) {         
		
		//WorkBook path
		String propertiesWorkBookPath = GenericConstants.WORKBOOK_PATH1; 										// "src/ocpe/aut/fwk/resources/properties.xlsx";
		
		//Blank workbook         
		XSSFWorkbook workbook = new XSSFWorkbook();                    
		//Create a blank sheet         
		XSSFSheet sheet = workbook.createSheet(pageName);                   

		//Iterate over data and write to sheet         
		Set<String> keyset = data.keySet();         
		int rownum = 0;         
		for (String key : keyset) {             
			Row row = sheet.createRow(rownum++);             
			Object [] objArr = data.get(key);             
			int cellnum = 0;             
			for (Object obj : objArr)   {                
				Cell cell = row.createCell(cellnum++);                
				if(obj instanceof String)                     
					cell.setCellValue((String)obj);                 
				else if(obj instanceof Integer)                     
					cell.setCellValue((Integer)obj);             
			}         
		}         
		try        
		{            
			//Write the workbook in file system             
			FileOutputStream out = new FileOutputStream(new File(propertiesWorkBookPath));            
			workbook.write(out);             
			out.close();             
			System.out.println("properties.xlsx written successfully on disk.");         
		}          
		catch (Exception e)  {  
			//Print the exception
			e.printStackTrace();         
		}    
	}




	/**
	 * This method reads value of the property in excel sheet based on the pageName and
	 * controlName given
	 * @param Page Name
	 * @param Control or Field Name
	 * @param Locator Type
	 * @return String
	 */
	public static String readProps( String SheetName, String ControlName, String LocatorType ) {

		//value of the cell that is read
		String value="";
		try
		{
			FileInputStream file = new FileInputStream(GenericConstants.WORKBOOK_PATH);
            System.out.println("Excel File Path : " + GenericConstants.WORKBOOK_PATH); 
			//Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);

			//Get desired sheet from the workbook using pageName
			XSSFSheet sheet = workbook.getSheet(SheetName);

			/* Fetch the row number which contains the controlName */
			int rowNumber = 0;			
			for (Row row : sheet) {
				for (Cell cell : row) {
					if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
						/*if (cell.getRichStringCellValue().getString().trim().equals(controlName)) {
							rowNumber = row.getRowNum();  
							break;
						}*/
						if(row.getCell(0).getStringCellValue().trim().equals(ControlName) && (row.getCell(1).getStringCellValue().trim().equals(LocatorType)) ){
							System.out.println("match found for the Control Name");
							rowNumber = row.getRowNum();
							break;
							
							
						}
					}
				}
			} 

			/* Get the row, it's 2nd column(i.e. column B) value */
			XSSFRow row = sheet.getRow(rowNumber);
			XSSFCell cell = row.getCell(2);
			value = cell.getStringCellValue().trim().toString();		   


			//close the file
			file.close();			

		} 
		catch (Exception e) 
		{
			//Print the exception
			e.printStackTrace();
		}

		return value;
	}

















}
