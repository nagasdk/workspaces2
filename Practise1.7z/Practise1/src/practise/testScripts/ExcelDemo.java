package practise.testScripts;


import java.util.Map;
import java.util.TreeMap;
import org.junit.BeforeClass;
import org.junit.Test;
import practise.constants.GenericConstants;
import utils.ExcelUtil;


public class ExcelDemo {

	
	@BeforeClass
	public static void oneTimeSetUp() {
			
	
	}
	
	

	
	@Test
	public void test() {		
		
		System.out.println("** DEMO OF Excel Util Class ** ");
	
		//Read_Excel();
		
		 Write_Excel();		
	}
	
	
	public static void Read_Excel(){
		//String xpathExpression = ExcelUtil.readProps(GenericConstants.LoginPage, GenericConstants.USER_TEXTBOX);
		
		String xpathExpression = ExcelUtil.readProps(GenericConstants.LoginPage, GenericConstants.PWD_TEXTBOX,GenericConstants.LOC_ID);
		System.out.println(xpathExpression);					
		
	}
	
	
	public  static void Write_Excel(){
		Map<String, Object[]> data = new TreeMap<String, Object[]>();         
		data.put("1", new Object[] {"txtUserName",GenericConstants.LOC_XPATH, "//*[span()='hello']"});   
		data.put("2", new Object[] {"txtPwdName",GenericConstants.LOC_ID, "gbqfsa"});
		data.put("3", new Object[] {"submitbutton",GenericConstants.LOC_XPATH, "//*[span()='hellosubmit']"});
		data.put("4", new Object[] {"checklogoimage",GenericConstants.LOC_XPATH, "//*[@id='gbqfbb']"});
		ExcelUtil.writeProps(GenericConstants.WriteDataPage, data);
	}
	
	
	
}
