package practise.testScripts;



/*import org.junit.Test;
import org.junit.BeforeClass;*/

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.TreeMap;

import practise.constants.GenericConstants;
import utils.PropertiesUtil;



public class PropsDemo {
	
	private static PropertiesUtil props = new PropertiesUtil(GenericConstants.PROPS_FILE);
	
	public static void main (String[] args){
			
		
		// Read_Properties();
		
		
		//Write_Properties();
		
		 Modify_KeyValue();
		
	}
	
	
	
	
	public static void Read_Properties(){
		String sVal = props.read("Office2"); 		System.out.println(sVal);
		
	}
	
	
	public static void Write_Properties(){
		
		HashMap<String, String> map = new HashMap<String,String>();
				map.put("Office1", "Infy1");
				map.put("Office2", "Infy2");
				map.put("Office3", "Infy3");
				map.put("Office4", "Infy4");
				map.put("Office5", "Infy5");		
				map.put("Office6", "Infy6");
		
		props.write(map);
		
	}
	
	
	public static void Modify_KeyValue(){
		System.out.println("Before Modification - KEYVALUE is:  " + props.read("Office2") );
		
		try {
		props.updateKeyValue("Office2", "Amazon");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		System.out.println("After Modification - KEYVALUE is:  " + props.read("Office2") );
		
		
	}
	
	
/*	private static PropertiesUtil props ;
	
	@BeforeClass
    public static void initiliaxation(){
		props = new PropertiesUtil("src/resources/practise1.properties");
	}
	
	

	
	@Test
	public void test() {
		System.out.println(props.read("surname"));		
		
	}
*/
}
