package practise.testScripts;


import org.junit.BeforeClass;
import org.junit.Test;

import utils.PropertiesUtil;



public class PropsReadsdemo {

	private static PropertiesUtil propsRW;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// one-time initialization code   
		System.out.println("@BeforeClass - oneTimeSetUp");
			propsRW = new PropertiesUtil("src/resources/practise1.properties");

		/* Get valid username from properties file ex: rg@gmail.com*/
		String userName = propsRW.read("surname").trim();
		System.out.println(userName);
		}


	@Test
	public void test_A_1() {
		//Refer admin.properties file
		propsRW = new PropertiesUtil("src/resources/practise1.properties");

		//Get the user management side menu label from properties file
		String prop_userMgmt = propsRW.read("name");
		System.out.println(prop_userMgmt);

	}


	
	}
