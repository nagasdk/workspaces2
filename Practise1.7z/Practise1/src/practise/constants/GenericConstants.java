package practise.constants;


public class GenericConstants {
	
	public static final String WORKBOOK_PATH = "src/resources/OR.xlsx";
	public static final String WORKBOOK_PATH1 = "src/resources/OR1.xlsx";
	public static String txtUserName="username";
	public static String txtPassWord="password";
	
	public static String LoginPage="Login";
	public static String WriteDataPage="WriteData";
	
	public static String USER_TEXTBOX="txtUserName";
	public static String PWD_TEXTBOX="txtPwdName";
	
	// ***** VARIOUS LOCATION IDENTIFIERS
	public static String LOC_XPATH="xpath";
	public static String LOC_linkname="linkname";
	public static String LOC_ID="id";
	public static String LOC_css="css";
	
	//	** properties Files Constants
	
	public static final String PROPS_FILE= "src/resources/practise1.properties";
}
