package practise.players;

public interface TeamIndia {

	
	public static final String OPENER1="SACHIN TENDULKAR";
	public static final String OPENER2="S DHAWAN";
	public static final String PLAYER1DOWN="VIRAT KOHLI";
	public static final String PLAYER2DOWN="YUVARAJ SINGH";
	public static final String PLAYER3DOWN="SURESH RAINA";
	public static final String PLAYER4DOWN="M S Dhoni";
	public static final String PLAYER5DOWN="R JADEJA";
	public static final String PLAYER6DOWN="R ASHWIN";
	public static final String PLAYER7DOWN="B KUMAR";
	public static final String PLAYER8DOWN="U YADAV";
	public static final String PLAYER9DOWN="I SHARMA";
	
	public String getOpeners();
	
}
