

package withproxy;

import static org.junit.Assert.*;
import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.TakesScreenshot;


public class TakeScreenshot_FireFoxProxy {

	
	private static  int s=100;
	private static String FIREFOX_FILE="D:/Program Files/Mozilla Firefox/firefox.exe";
	private static FirefoxProfile ffProfile ;
	private static DesiredCapabilities dc = null;
	private static FirefoxBinary ffBinary ;
	private static Proxy proxy = null;
	private static WebDriver driver;
	
	@BeforeClass
	public static void BeforeClass(){
		System.out.println("Setting,Initializing up the necessary browser related informations");
			
		ffBinary = new FirefoxBinary(new File(FIREFOX_FILE));
		
		ffProfile = new ProfilesIni().getProfile("default");
		ffProfile.setPreference("network.proxy.type", 2);
		
		proxy= new Proxy();
		proxy.setProxyAutoconfigUrl("http://infypacsrv/pearl.pac");
		 
		dc= new DesiredCapabilities();
		dc.setCapability(CapabilityType.PROXY, proxy);
			
		driver = new FirefoxDriver(ffBinary, ffProfile, dc );
		
	}
	
	
	@Test
	public void test1() throws InterruptedException {
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to("http://google.com"); Thread.sleep(3000);
		driver.navigate().refresh();
		driver.getTitle();
		driver.getWindowHandle();   //A TargetLocator which can be used to select a frame or window
		driver.getWindowHandles(); //retrieves all open window handles
		driver.switchTo().activeElement(); //switches to active webelement
		driver.switchTo().defaultContent(); //selects the first frame or to the prev frame
		driver.switchTo().frame(1);
		driver.switchTo().frame("iframe");
		// driver.switchTo().frame(WebElement sEle);
		
		driver.getCurrentUrl();
		WebDriverWait wait = new WebDriverWait(driver, 3000);
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("hello")));
		
		WebElement myDynamicElement = (new WebDriverWait(driver, 10))
		.until(ExpectedConditions.presenceOfElementLocated(By.id("myDynamicElement")));
		
	}
	
	@Test
	public void test() throws InterruptedException, Exception{
		System.out.println("launch the Browser now");		
		driver.navigate().to("http://google.com");
		//driver.get("http://google.com");
		Thread.sleep(2000);
		driver.navigate().refresh();
		Thread.sleep(2000);		
		driver.manage().window().maximize();
		
		if (driver.getTitle().contains("Google")){
			System.out.println("Google Page is Loaded Sucesfully");
			
			File sFile= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(sFile, new File("D:/OCPE_Workspace/Practise1/src/selenium/withproxy/LoginGoogle_FireFox_Proxy.jpeg"));
			
			if (Elementexists(driver))
				System.out.println("Element Found");
			else
				System.out.println("Element Not Found");
		}
				
		else
			System.out.println("Google Page is not Loaded Sucessfully");	
		
	}

	
	
	@AfterClass
	public  static void dismantle(){
		driver.close();
		driver.quit();
	}
		

	boolean Elementexists(WebDriver d){		
		if(d.findElement(By.xpath("//*[@id='gs_tti0']/div/*[@id='gbqfq']")).isDisplayed()){
			d.findElement(By.xpath("//*[@id='gs_tti0']/div/*[@id='gbqfq']")).sendKeys("HELLO WELCOME TO SELENIUM");
			return true;
		}
		else
			return false;		
	}
	
	
}
