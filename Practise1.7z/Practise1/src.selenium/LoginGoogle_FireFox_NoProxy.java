import static org.junit.Assert.*;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.OutputType;

public class LoginGoogle_FireFox_NoProxy {

	  private static WebDriver driver;
	  private static String baseUrl="http://google.com";
	  private static File pathToFirefoxBinary;  
	 @BeforeClass
	  public static void setUp() throws Exception {
		pathToFirefoxBinary = new File("D:/Program Files/Mozilla Firefox/firefox.exe");
		ProfilesIni profile = new ProfilesIni();
		FirefoxProfile ffprofile = profile.getProfile("default");
		ffprofile.setPreference("network.proxy.type", 0);	//Direct connection, no proxy

		 driver = new FirefoxDriver(ffprofile);
	    // TVM URL
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  }



	@Test
	public void LoginGoogle() throws InterruptedException {
		System.out.println(baseUrl);
		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		WebElement sEle=driver.findElement(By.xpath("//input[@id='gs_htif0']"));
		if(sEle.isEnabled())
			System.out.println("enabled");
		else
			System.out.println("not enabled");
		// Thread.sleep(3000);
		//isElementLoaded(By.xpath("//*[@id='signIn']"));
		
		
		if(isElementLoaded(By.xpath("//input[@id='gs_htif0']"))) 	
			System.out.println("Text box Button Loaded");
		else 
			System.out.println("Text box Button Not Loaded");			
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	    //driver.quit();

	}
	
	
	  private boolean isElementLoaded(By by) throws InterruptedException {
		  int iCnt=0;
		  boolean sVal=false;
		  WebElement sEle=driver.findElement(by);
		   
				do {
					
					Thread.sleep(2000);
					iCnt=iCnt+2;
					if(sEle.isEnabled()){
						sVal= true;
						break;						
					}
				    	  	
				} while (iCnt<=30);	  
		      return sVal;
		  }
	
	  
	  
	  private boolean isElementPresent(By by) {
		    try {
		      driver.findElement(by);
		      return true;
		    } catch (NoSuchElementException e) {
		    	System.out.println("Exception not found");
		      return false;
		    }
		  }
	
}
