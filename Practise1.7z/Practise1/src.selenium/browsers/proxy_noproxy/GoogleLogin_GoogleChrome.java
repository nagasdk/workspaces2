package browsers.proxy_noproxy;
import static org.junit.Assert.*;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverBackedSelenium;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;


public class GoogleLogin_GoogleChrome {

	  private static WebDriver driver;
	  private static String baseUrl="http://google.com";
	  private static File pathToFirefoxBinary;  
	  private static WebDriverBackedSelenium selenium;
	 @BeforeClass
	  public static void setUp() throws Exception {
		pathToFirefoxBinary = new File("C:/Program Files/Google/Chrome/Application/chrome.exe");
/*		ProfilesIni profile = new ProfilesIni();
		FirefoxProfile ffprofile = profile.getProfile("default");
		ffprofile.setPreference("network.proxy.type", 0);
*/
		//System.setProperty("webdriver.chrome.driver", "C:/Program Files/Google/Chrome/Application/chrome.exe");
		System.setProperty("webdriver.chrome.driver","D:\\Softwares\\chromedriver.exe");
		 driver = new ChromeDriver();
		 
		 selenium= new WebDriverBackedSelenium(driver, baseUrl);
		 
	    // TVM URL
	    //driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
	    selenium.wait(5);
	  }



	@Test
	public void LoginGoogle() throws InterruptedException {
		System.out.println(baseUrl);
		//driver.get(baseUrl);
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		selenium.open(baseUrl);
		if(selenium.isElementPresent("//input[@id='gs_htif0']"))System.out.println("Text box avail");
		else { System.out.println("Text box not a avail");
		}
		
		
		
		
		/*WebElement sEle=driver.findElement(By.xpath("//input[@id='gs_htif0']"));
		if(sEle.isEnabled())
			System.out.println("enabled");
		else
			System.out.println("not enabled");*/
		// Thread.sleep(3000);
		//isElementLoaded(By.xpath("//*[@id='signIn']"));
		
		/*
		if(isElementLoaded(By.xpath("//input[@id='gs_htif0']"))) 	
			System.out.println("Text box Button Loaded");
		else 
			System.out.println("Text box Button Not Loaded");*/			
	  }
   

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	    //driver.quit();

	}
	
	
	  private boolean isElementLoaded(By by) throws InterruptedException {
		  int iCnt=0;
		  boolean sVal=false;
		  WebElement sEle=driver.findElement(by);
		   
				do {
					
					Thread.sleep(2000);
					iCnt=iCnt+2;
					if(sEle.isEnabled()){
						sVal= true;
						break;						
					}
				    	  	
				} while (iCnt<=30);	  
		      return sVal;
		  }
	
	  
	  
	  private boolean isElementPresent(By by) {
		    try {
		      driver.findElement(by);
		      return true;
		    } catch (NoSuchElementException e) {
		    	System.out.println("Exception not found");
		      return false;
		    }
		  }
	
}
