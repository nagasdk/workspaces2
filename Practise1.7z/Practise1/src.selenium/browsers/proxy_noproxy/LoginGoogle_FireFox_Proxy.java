package browsers.proxy_noproxy;
import static org.junit.Assert.*;

import java.io.File;
import java.util.concurrent.TimeUnit;


import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;


public class LoginGoogle_FireFox_Proxy {

	  private static WebDriver driver;
	  private static String baseUrl="http://google.com";
	  private static File pathToFirefoxBinary;  
	 
	static DesiredCapabilities cap = null; 

	  
	  @BeforeClass
	  public static void setUp() throws Exception {
		pathToFirefoxBinary = new File("D:/Program Files/Mozilla Firefox/firefox.exe");
		
		
		FirefoxBinary ffBinary = new FirefoxBinary(pathToFirefoxBinary);
		ProfilesIni profile = new ProfilesIni();		   		   
		FirefoxProfile ffprofile = profile.getProfile("default");	//InfyProxy_Extranet
		ffprofile.setPreference("network.proxy.type", 2); // Proxy auto-configuration (PAC)
		
		
		
		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();		  		  
		proxy.setProxyAutoconfigUrl("http://infypacsrv/pearl.pac");	//http://10.219.3.170/PRAKRITI.pac
		
		/*proxy.setSocksUsername("nagaraju_kura");
		proxy.setSocksPassword("Sch00l@r7");*/		
		cap = new DesiredCapabilities();		  
		cap.setCapability(CapabilityType.PROXY, proxy);	




		//Util classes that reads the excel sheet and properties files
		driver = new FirefoxDriver(ffBinary,ffprofile,cap);
		
		
		
		/*ProfilesIni profile = new ProfilesIni();
		FirefoxProfile ffprofile = profile.getProfile("default");
		ffprofile.setPreference("network.proxy.type", 0);
		 driver = new FirefoxDriver(ffprofile);*/

		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	  }



	@Test
	public void LoginGoogle() throws InterruptedException {
		System.out.println(baseUrl);
		driver.get(baseUrl); System.out.println("Waiting for 5 seconds explicitly");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.navigate().refresh();
		Thread.sleep(3000);
		driver.navigate().refresh();
		Thread.sleep(3000);
		
		if(driver.getTitle().contentEquals("Google"))
			System.out.println("Google page is Loaded");	
		else
			{ 
			System.out.println("Google page is not yet Loaded");
			//driver.close();
			//System.exit(0);
			}
		
		//WebElement sEle=driver.findElement(By.xpath("//input[@type='submit'AND @value='Google Search']"));
		//if(driver.findElement(By.xpath("//input[@type='submit'AND @value='Google Search']")).isDisplayed())
		if(driver.findElement(By.xpath("//input[@name='btnK']")).isDisplayed())			
			System.out.println("enabled");
		else
			System.out.println("not enabled");
		// Thread.sleep(3000);
		//isElementLoaded(By.xpath("//*[@id='signIn']"));
		
		System.out.println("Fetching the name attribute from html structure" + driver.findElement(By.xpath("//input[@value='Google Search']")).getAttribute("name"));
		/*if(isElementLoaded(By.xpath("//input[@id='gs_htif0']"))) 	
			System.out.println("Text box Button Loaded");
		else 
			System.out.println("Text box Button Not Loaded");*/
		
		
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	    //driver.quit();

	}
	
	
	  private boolean isElementLoaded(By by) throws InterruptedException {
		  int iCnt=0;
		  boolean sVal=false;
		  WebElement sEle=driver.findElement(by);
		   
				do {
					
					Thread.sleep(2000);
					iCnt=iCnt+2;
					if(sEle.isEnabled()){
						sVal= true;
						break;						
					}
				    	  	
				} while (iCnt<=30);	  
		      return sVal;
		  }
	
	  
	  
	  private boolean isElementPresent(By by) {
		    try {
		      driver.findElement(by);
		      return true;
		    } catch (NoSuchElementException e) {
		    	System.out.println("Exception not found");
		      return false;
		    }
		  }
	
}
