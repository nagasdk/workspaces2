package browsers.proxy_noproxy;
import static org.junit.Assert.*;

import java.io.File;
import java.util.concurrent.TimeUnit;


import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.OutputType;

public class GETCSSVALUE {

	  private static WebDriver driver;
	  private static String baseUrl="https://in.yahoo.com/?p=us";	//"http://google.com";
	  private static File pathToFirefoxBinary;  
	 @BeforeClass
	  public static void setUp() throws Exception {
		pathToFirefoxBinary = new File("D:/Program Files/Mozilla Firefox/firefox.exe");
		ProfilesIni profile = new ProfilesIni();
		//FirefoxProfile ffprofile = profile.getProfile(new File("C:/Users/nagaraju_kura/AppData/Roaming/Mozilla/Firefox/Profiles/8c10dre2.default"));
		FirefoxProfile ffprofile = new FirefoxProfile(new File("C:/Users/nagaraju_kura/AppData/Roaming/Mozilla/Firefox/Profiles/8c10dre2.default"));
		ffprofile.setPreference("network.proxy.type", 0);	//Direct connection, no proxy
		
		ffprofile.addExtension(new File("C:/Users/nagaraju_kura/AppData/Roaming/Mozilla/Firefox/Profiles/8c10dre2.default/extensions/FireXPath@pierre.tholence.com.xpi"));
		ffprofile.addExtension(new File("C:/Users/nagaraju_kura/AppData/Roaming/Mozilla/Firefox/Profiles/8c10dre2.default/extensions/firebug@software.joehewitt.com.xpi"));

		 driver = new FirefoxDriver(ffprofile);
	    // TVM URL
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  }



	@Test
	public void LoginGoogle() throws InterruptedException {
		System.out.println(baseUrl);
		driver.get(baseUrl);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		WebElement sEle=driver.findElement(By.xpath(".//*[@id='search-submit']")); //gs_htif0
		
		
		System.out.println("border bottom color:"+ sEle.getCssValue("border-bottom-color"));		
		String rgb[] = sEle.getCssValue("border-bottom-color").replaceAll("(rgba)|(rgb)|(\\()|(\\s)|(\\))","").split(",");
		String hex = String.format("#%s%s%s", toBrowserHexValue(Integer.parseInt(rgb[0])), toBrowserHexValue(Integer.parseInt(rgb[1])), toBrowserHexValue(Integer.parseInt(rgb[2])));
		System.out.println("Converted hexa decimal format"+hex);
		
		WebElement sEle1=driver.findElement(By.xpath(".//*[@id='search-submit']/parent::*"));
		System.out.println("background color"+sEle1.getCssValue("background-color"));
		String rgb1[] = sEle1.getCssValue("background-color").replaceAll("(rgba)|(rgb)|(\\()|(\\s)|(\\))","").split(",");
		String hex1 = String.format("#%s%s%s", toBrowserHexValue(Integer.parseInt(rgb1[0])), toBrowserHexValue(Integer.parseInt(rgb1[1])), toBrowserHexValue(Integer.parseInt(rgb1[2])));
		System.out.println("Converted hexa decimal format"+ hex1);
		
		System.out.println("box-shadow:"+sEle1.getCssValue("box-radius"));
		System.out.println("box-shadow:"+sEle1.getCssValue("box-shadow"));
		System.out.println("background:"+sEle1.getCssValue("background"));
		System.out.println("border:"+sEle1.getCssValue("border"));
		
		
	}

	private static String toBrowserHexValue(int number) {
        StringBuilder builder = new StringBuilder(Integer.toHexString(number & 0xff));
        while (builder.length() < 2) {
            builder.append("0");
        }
        return builder.toString().toUpperCase();
    }		

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
	    //driver.quit();

	}
	

	
	
	
	
	
	
}
