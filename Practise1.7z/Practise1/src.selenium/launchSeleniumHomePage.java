import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;




public class launchSeleniumHomePage {

	
	public launchSeleniumHomePage() {
		System.out.print("\nDefault Constructor Launched");
	}
	
	
	@BeforeClass
	public  static void oneTimeSetUp(){
		System.out.print("In the BeforeClass() method");		
	}

	@Before
	public void beforeTest(){
		System.out.print("\nIn the Before() test method >>");
	}

	@After
	public void afterTest(){
		System.out.print("In the After() test method");
	}
	
	@Test
	public void test1(){
		System.out.print("In the test1 method >>");	
	}
	
	@Test
	public void test2(){
		System.out.print("In the test2 method >>");	
	}
	
	@AfterClass
	public static void oneTimeCloseUp(){
		System.out.print("\nIn the After Class method");
	}
	
}
