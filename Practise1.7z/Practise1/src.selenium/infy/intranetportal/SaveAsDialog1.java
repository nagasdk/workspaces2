package infy.intranetportal;


import java.io.File;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class SaveAsDialog1 {

	private static WebDriver driver;
	private static FirefoxBinary ffBinary ;
	private static FirefoxProfile ffProfile;
	private static DesiredCapabilities cap;
	
	
	@BeforeClass
	public static void initilaize(){
		ffBinary = new FirefoxBinary(new File("D:/Program Files/Mozilla Firefox/firefox.exe")); 
				
		ffProfile = new ProfilesIni().getProfile("default");
		
		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
		proxy.setProxyAutoconfigUrl("http://infypacsrv/pearl.pac");
		cap = new DesiredCapabilities();
		cap.setCapability(CapabilityType.PROXY, proxy);
		
		driver =new FirefoxDriver(ffBinary, ffProfile,cap);			

	}
	
	@Test
	public void test1() throws InterruptedException{
		Thread.sleep(5000);
		//driver.get("http://iscls2apps/EDSPlus/aspx/Personal/EDSPlusQualification.aspx");
		driver.get("https://iscls2apps/EDSPlus/aspx/Personal/EDSPlusQualification.aspx");		Thread.sleep(10000);
	    driver.findElement(By.id("hypl_14_4")).click();											Thread.sleep(5000);	
		//driver.findElement(By.xpath("//td[text()='PUC  ']/preceding-sibling::td[a[contains(text(),'Degree')]]")).click();	Thread.sleep(2000);
		driver.findElement(By.xpath("//table[@id='EDOCMyDocket1_dgrdEmpDocs']/tbody/tr[2]/td[2]/a")).click(); Thread.sleep(2000);
		
	}
	
	
	

}
