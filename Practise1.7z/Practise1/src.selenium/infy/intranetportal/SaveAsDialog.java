package infy.intranetportal;

import static org.junit.Assert.*;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;

import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;


public class SaveAsDialog {

       private static WebDriver driver;
       private static FirefoxBinary ffBinary ;
       private static FirefoxProfile ffProfile;
       private static DesiredCapabilities cap;
       
       
       @BeforeClass
       public static void initilaize() throws InterruptedException{
     

       }

       @Test
       public void test() throws InterruptedException, AWTException{
           ffBinary = new FirefoxBinary(new File("D:/Program Files/Mozilla Firefox/firefox.exe")); 
           
           ffProfile = new ProfilesIni().getProfile("default");
           
           org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
           proxy.setProxyAutoconfigUrl("http://infypacsrv/pearl.pac");
           cap = new DesiredCapabilities();
           cap.setCapability(CapabilityType.PROXY, proxy);
           
           driver =new FirefoxDriver(ffBinary, ffProfile,cap);
           driver.get("http://iscls2apps/EDOC/aspx/EDOCEmpDocStatus.aspx");
           Thread.sleep(5000);
           System.out.println("Page has got navigated to " + driver.getTitle());
           driver.findElement(By.xpath("//a[text()='View/Update Employee Docket']")).click();
           Thread.sleep(2000);
           
           driver.findElement(By.xpath("//td[text()='PUC  ']/preceding-sibling::td[a[contains(text(),'Degree')]]")).click();
   		  Thread.sleep(2000);     
   		  
   		  //Runtime.getRuntime().exec("");
   		  Robot robot = new Robot();
   		  robot.keyPress(KeyEvent.VK_ENTER);
   		  robot.keyPress(KeyEvent.VK_ALT);
   		  robot.keyPress(KeyEvent.VK_S);
   		  robot.keyRelease(KeyEvent.VK_ALT);
   		  Thread.sleep(3000);
   		  
   		  robot.keyPress(KeyEvent.VK_C);
   		  robot.keyPress(KeyEvent.VK_COLON);
   		  robot.keyPress(KeyEvent.VK_BACK_SLASH);
   		  robot.keyPress(KeyEvent.VK_1);
   		  robot.keyPress(KeyEvent.VK_PERIOD);
   		  robot.keyPress(KeyEvent.VK_T);
   		  robot.keyPress(KeyEvent.VK_I);
   		  robot.keyPress(KeyEvent.VK_F);
   		  robot.keyPress(KeyEvent.VK_F);
   		  robot.keyPress(KeyEvent.VK_F);
   		  
   		  Thread.sleep(5000);
   		  
   		  robot.keyPress(KeyEvent.VK_ALT);
  		  robot.keyPress(KeyEvent.VK_S);
  		  robot.keyRelease(KeyEvent.VK_ALT);

  		  
  		  driver.findElement(By.linkText("hello")).click();
       }

}

		

