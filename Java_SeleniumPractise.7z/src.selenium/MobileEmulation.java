import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;


public class MobileEmulation {

	
	public static void main(String args[]){
		
	WebDriver driver =null;	
	String baseUrl="http://www.google.com/mobile/";
	
	
	System.setProperty("webdriver.chrome.driver","D:/Softwares/Chromedriver/2.14/chromedriver.exe");

	Map<String, String> mobileEmulation = new HashMap<String, String>();
	
	mobileEmulation.put("deviceName", "Samsung Galaxy Tab");
//	mobileEmulation.put("deviceName", "Samsung Galaxy S4");
//	mobileEmulation.put("deviceName", "Apple iPhone 6");
	

	Map<String, Object> chromeOptions = new HashMap<String, Object>();
	chromeOptions.put("mobileEmulation", mobileEmulation);
	DesiredCapabilities capabilities = DesiredCapabilities.chrome();
	capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
	driver = new ChromeDriver(capabilities);


	//driver =new ChromeDriver();
	
	driver.get(baseUrl);
	
	try {
		Thread.sleep(5000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println(driver.getCurrentUrl());
	System.out.println(driver.getTitle());
	WebElement sEle = driver.findElement(By.xpath("//a[@data-g-action='Maia: Header']/img"));
	System.out.println(sEle.getText());		
	if(sEle.getText().trim().startsWith("Google")){
			//equalsIgnoreCase("Google") ){
			System.out.println("Google image was  found");
			//sEle.click();
			WebElement sEle1 = driver.findElement(By.xpath(".//*[@class='button' and @id='home-feature-start-button']"));
			System.out.println(sEle1.getText());
			
			System.out.println(sEle1.isDisplayed());
			System.out.println(sEle1.isEnabled());
			sEle1.click();
			
/*			if (sEle1.isDisplayed() && sEle1.isEnabled()){
				System.out.println("Start Now Button is Displayed and Enabled");
				sEle1.click();
						try {
							Thread.sleep(3000);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}

			}else{
				System.out.println("Start Now Button might not be Displayed nor Enabled");
			}*/
			
	}else{
		System.out.println("Google image was  not found");	
	}
	
	
	
	
	
	}
}
