import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;


public class LaunchChrome_ChromeOptions_DesiredCapabilities1 {

	public static void main(String args[]){
		
		System.setProperty("webdriver.chrome.driver","D:/Softwares/Chromedriver/2.14/chromedriver.exe");
		//String baseUrl="http://www.google.com/mobile/";
		String baseUrl="https://m.youtube.com/";
		
		
		Map<String,Object> deviceMetrics = new HashMap<String, Object>();
		deviceMetrics.put("width", 375);
		deviceMetrics.put("height", 667);
		deviceMetrics.put("pixelRatio", 3.0);
		
		Map<String, Object> mobileEmulation = new HashMap<String, Object>();
		mobileEmulation.put("deviceMetrics", deviceMetrics);
		mobileEmulation.put("userAgent", "Mozilla/5.0 (Linux; Android 4.2.1; en-us; Nexus 5 Build/JOP40D) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.166 Mobile Safari/535.19");
		
		/*Map<String, Object> deviceOptions = new HashMap<String, Object>();
		deviceOptions.put("mobileEmulation", mobileEmulation);*/
		
		
		List<String> s1= new ArrayList<String>();
		
		s1.add("load-extension=C:/Users/nagaraju_kura/AppData/Local/Google/Chrome/User Data - Copy/Default/Extensions/eemkmiehbcigiognajmhgfgglomdbddc/1.1.0_0");
		s1.add("load-extensions=C:/Users/nagaraju_kura/AppData/Local/Google/Chrome/User Data - Copy/Default/Extensions/ggmdpepbjljkkkdaklfihhngmmgmpggp/1.4_0");
		System.out.println(s1.size());
		//options.addArguments("load-extensions=C:/Users/nagaraju_kura/AppData/Local/Google/Chrome/User Data - Copy/Default/Extensions/ggmdpepbjljkkkdaklfihhngmmgmpggp/1.4_0";
		//options.addArguments("load-extension=C:/Users/nagaraju_kura/AppData/Local/Google/Chrome/User Data - Copy/Default/Extensions/eemkmiehbcigiognajmhgfgglomdbddc/1.1.0_0");
		
		ChromeOptions options = new ChromeOptions();		
		options.addArguments("user-data-dir=C:/Users/nagaraju_kura/AppData/Local/Google/Chrome/User Data - Copy");
		
		
		
		
		//options.setExperimentalOption("mobileEmulation", mobileEmulation);
		
		//DesiredCapabilities capabilities = new DesiredCapabilities();
		//capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		//capabilities.setCapability(ChromeOptions.CAPABILITY, deviceOptions);
		//ChromeDriver driver = new ChromeDriver(capabilities);
		ChromeDriver driver = new ChromeDriver(options);
		//driver.manage().window().setSize(new Dimension(500, 700));
		//driver.manage().window().setPosition(new Point(250,0));
		
		driver.get(baseUrl);
		
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		driver.quit();
		
		}
	
}
//options.addExtensions(new File("C:/Users/nagaraju_kura/AppData/Local/Google/Chrome/User Data/Default/Extensions/ggmdpepbjljkkkdaklfihhngmmgmpggp/1.4_0.crx"));
//options.addExtensions(new File("D:/Softwares/Chromedriver/extensions/ggmdpepbjljkkkdaklfihhngmmgmpggp/1.4_0.crx"));
