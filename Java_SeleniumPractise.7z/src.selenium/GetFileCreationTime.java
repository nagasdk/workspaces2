

	import java.io.IOException;
	import java.nio.file.Files;
	import java.nio.file.Path;
	import java.nio.file.Paths;
	import java.nio.file.attribute.FileTime;
	import static java.nio.file.LinkOption.NOFOLLOW_LINKS;
	public class GetFileCreationTime {
	    public static void main(String[] args) throws Exception {
	        /* Step  -1: Access the file in Path object */
	        Path path = Paths.get("D:/OLB", "OLB1.txt");
	        /* Get System time to set against created timestamp */
	        long time = System.currentTimeMillis();
	        /* Get FileTime value */
	        FileTime fileTime = FileTime.fromMillis(time);
	        /* Change Created Time Stamp */
	        Files.setAttribute(path, "basic:creationTime", fileTime, NOFOLLOW_LINKS);                               
	    }
	}

