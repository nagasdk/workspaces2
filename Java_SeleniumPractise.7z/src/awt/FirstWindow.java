package awt;


/**Most graphics comes from "swing" package in system library*/
import java.awt.BorderLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
 
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
 
 
public class FirstWindow extends JFrame{
    private static final long serialVersionUID = 1L;
 
    public FirstWindow() { /**Constructor*/
         
        //Setting title of window:
        super("Your computer has a virus"); /**"super" refers to superclass == class you are extending == JFrame */
     
         setVisible(true);

        //Setting default window size:
        setSize(600,400); /**Width x Height (px)*/
         
         
        //Setting default on how you close the window:  
        setDefaultCloseOperation(EXIT_ON_CLOSE); /**Exit application*/
        /** 
         * "setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);"
         *      Can't close program when trying to exit; Most of time, don't want to do this
         * */
         
         
        //Creating the panels:
        JPanel p = new JPanel(); 
        JPanel p2 = new JPanel(); /**Default constructor*/
        JPanel p3 = new JPanel(new GridBagLayout()); /**Want certain layout in panel; now have access to GridBagConstraints*/
         
         
        //Creating buttons & adding it to the panel:
        JButton b1 = new JButton("Button 1"); 
        JButton b2 = new JButton("Button 2"); 
         
            //Adding action for "Button 1":
        b1.addActionListener(new ActionListener() { /**Added "ears" to button; so can "listen" for something to do*/
             
            @Override
            public void actionPerformed(ActionEvent e) { /**Method when listen to action -> what action want to perform?*/
                // TODO Auto-generated method stub
                JOptionPane.showMessageDialog(null, "Good job kid, you harvested your corn"); /**Creates a JOptionPane (THINK: pop-up window)*/
            }
        }); /**End ActionListener*/
         
            //Adding buttons to the panel:
        p.add(b1); 
        p.add(b2);
         
         
        //Creating checkboxes & adding it to the panel:
        JCheckBox cb1 = new JCheckBox("Do you LOVE bacon?");
        JCheckBox cb2 = new JCheckBox("Do you LOVE cheese?");
         
        p2.add(cb1);
        p2.add(cb2);
         
         
        //Creating label, text area, text field * & adding it to the panel: 
        JLabel label = new JLabel("This is a label"); 
        JTextArea ta = new JTextArea("This is a text area"); 
        JTextField textField = new JTextField("text field"); 
     
            //Spacing: Grid Bag Layout
        GridBagConstraints gbc = new GridBagConstraints(); /**For organization in grid system*/
        gbc.insets = new Insets(15,15,15,15); /**4 parameters: top, bottom, left, right (px)*/
         
            //Positioning & adding items in panel
        gbc.gridx = 0; 
        gbc.gridy = 0; 
        p3.add(label, gbc); /**2nd parameter -> use grid system*/
         
        gbc.gridx = 0; 
        gbc.gridy = 1; 
        p3.add(ta, gbc);
         
        gbc.gridx = 1; 
        gbc.gridy = 2;
        p3.add(textField, gbc);
	    //myFrame.setVisible(true);
    
         
        //Adding the panels to the JFrame & specifying its location:
        /**Refers to JFrame which we extend to from this class*/
        add(p, BorderLayout.SOUTH); /**Second parameter specifies the location of where to add the panel to the window; else overwrites & don't see all the panels*/
        add(p3, BorderLayout.CENTER);
        add(p2, BorderLayout.NORTH);
         
    }
    public static void main(String args[]){
    	FirstWindow f1 = new FirstWindow(); 
    }
}