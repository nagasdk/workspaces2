package awt;

import java.applet.Applet;
import java.awt.Button;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionListenerDemo extends Applet implements ActionListener{

	Label ageLabel;
	TextField AgeTxtFld;
	Button ClickMe;
	Label ResultLabel;

	public void init(){
		ageLabel = new Label("Enter Your Age");
		AgeTxtFld = new TextField(5);
		AgeTxtFld.setText("-20");
		ClickMe = new Button("Calculate Eligibility");
		ClickMe.addActionListener(this);
		
		ResultLabel= new Label("");
		
		add(ageLabel);
		add(AgeTxtFld);
		add(ClickMe);
		add(ResultLabel);
	}
	
	public void run(){
		

		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String AgeValue=AgeTxtFld.getText();
		int result= Integer.parseInt(AgeValue);
		//		System.out.println(result);
		if (result >18) {
			ResultLabel.setText("You are invited as you are an adult");
		}else{
			ResultLabel.setText("You  are not invited as you are a kid");
		}
		
		
	}

	
	
}
