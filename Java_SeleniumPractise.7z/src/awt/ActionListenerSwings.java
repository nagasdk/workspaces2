package awt;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.*;

import javax.swing.*;
import javax.swing.event.*;


public class ActionListenerSwings implements ActionListener {

	public  void  Action_Listener_Swings() {
        JFrame myFrame;		
		JLabel ageLabel = new JLabel("Enter Your Age");;
		final JTextField AgeTxtFld =  new JTextField(5);
		JButton ClickMe = new JButton("Calculate Eligibility");
		final JLabel ResultLabel = new JLabel("");

	    final JCheckBox checkboxAll = new JCheckBox("Upload-All Results");
	    checkboxAll.setSelected(true);
	    final JCheckBox checkboxPass = new JCheckBox("Upload-Passed Results");
	    checkboxPass.setSelected(false);
		
		
		    myFrame = new JFrame("Age Calculator");
		    myFrame.setVisible(true);
		    myFrame.setSize(500, 500);
		    myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		    myFrame.setLayout(new FlowLayout());
		    
		    
		    myFrame.add(ageLabel);
		    myFrame.add(AgeTxtFld);
		    myFrame.add(ClickMe);
		    myFrame.add(ResultLabel);
		    myFrame.add(checkboxPass);
		    myFrame.add(checkboxAll);
		    
		    String message = "Are you sure you want to Upload only All Results ?";
		    Object[] params = {message, checkboxAll,checkboxPass};
		    int n = JOptionPane.showConfirmDialog(myFrame, params, "Upload Results", javax.swing.JOptionPane.YES_NO_OPTION);
		    System.out.println(n);
		    
		    System.out.println("checkboxAll:" + checkboxAll.isSelected());
		    System.out.println("checkboxPass:" + checkboxPass.isSelected());

		    
		    
		    checkboxPass.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					if(checkboxPass.isSelected()){
						checkboxAll.setSelected(false);
					}else{
						checkboxAll.setSelected(true);	
					}	
				    System.out.println("checkboxAll:" + checkboxAll.isSelected());
				    System.out.println("checkboxPass:" + checkboxPass.isSelected());				
				}
		    });

		    
		    
		    checkboxAll.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					if(checkboxAll.isSelected() ){
						checkboxPass.setSelected(false);
					}else{
						checkboxPass.setSelected(true);	
					}
				    System.out.println("checkboxAll:" + checkboxAll.isSelected());
				    System.out.println("checkboxPass:" + checkboxPass.isSelected());					
				}				    				    
		    });

		    
		    
/*		    JRadioButton radioAll_Passed = new JRadioButton();
		    radioAll_Passed.
*/		    		
		    		
			ClickMe.addActionListener(new ActionListener(){
				@Override
				public void actionPerformed(ActionEvent e) {
					String AgeValue=AgeTxtFld.getText();
					int result= Integer.parseInt(AgeValue);
					//		System.out.println(result);
					if (result >18) {
						ResultLabel.setText("You are invited because >> you are ADULT, your age >20");
					}else{
						ResultLabel.setText("You  are not invited because >> you are a KID, your age <20");
					}
					
				}
						
			});
 
			
		
			AgeTxtFld.addActionListener(new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					AgeTxtFld.setText("");
					
				}
			});
	
	
		
		
	}
	
	
	public static void main(String args[]){
		
		ActionListenerSwings s1 = new ActionListenerSwings();
		s1.Action_Listener_Swings();
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}
	
}
