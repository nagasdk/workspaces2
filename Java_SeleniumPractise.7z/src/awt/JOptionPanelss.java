package awt;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.*;


import javax.swing.event.*;
class JOptionPanelss{
	

private static Object DEFAULT_OPTION=0;
private static Object PLAIN_MESSAGE= "hello";

public static void main(String[] args) {

	String tcupload="";
	//String[] options = new String[] {"Upload All TestCases", "Upload Passed TestCases", "Maybe", "Cancel"};
	String[] options = new String[] {"Upload All TestCases", "Upload Passed TestCases"};
    int response = JOptionPane.showOptionDialog(null, "Click on any one of the button", "Upload Test Cases",JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE,null, options, options[1]);
    //int response = JOptionPane.showOptionDialog(null, "Click on any one of the button", "Upload Test Cases",JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,null, options, options[1]);
    System.out.println(response);
    if (response==1){
    	tcupload="passedtestcases";
    }else if (response==0){
    	tcupload="alltestcases";
    }else{
    	JOptionPane.showMessageDialog(null, "Click on \n 'Upload All TestCases' button \n           OR         \n 'Upload Passed TestCases' button ");
    	return;
    }
	
	JOptionPane.showMessageDialog(null, tcupload);
	
//Object[] options1 = {"Yes, please","No, thanks","No eggs, no ham!"};
//int n = JOptionPane.showOptionDialog(null,"Would you like some green eggs to go with that ham?","A Silly Question",javax.swing.JOptionPane.YES_NO_CANCEL_OPTION,javax.swing.JOptionPane.QUESTION_MESSAGE,null,options1,options1[2]);
//    // Where response == 0 for Yes, 1 for No, 2 for Maybe and -1 or 3 for Escape/Cancel.
//System.out.println(n);
}


}