package awt;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.*;

import javax.swing.*;
import javax.swing.event.*;


public class ActionListener_JPanelOptions  {
    public static String uploadtc="";
    
	public  void  Action_Listener_Swings() {
        final JFrame myFrame;
  
        myFrame = new JFrame("Upload TCS");
	    myFrame.setVisible(true);
	    myFrame.setSize(500, 500);
	    myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    myFrame.setLayout(new FlowLayout());        

        JPanel myPanel = new JPanel(new FlowLayout());
		myFrame.add(myPanel);
        
	    final JCheckBox checkboxAll = new JCheckBox("Upload-All Results");
	    checkboxAll.setSelected(true);
	    final JCheckBox checkboxPass = new JCheckBox("Upload-Passed Results");
	    checkboxPass.setSelected(false);	    
	    JButton ButtonOK = new JButton("OK");
	    
	    ButtonOK.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {	
					if(checkboxAll.isSelected())uploadtc = "alltestcases";
					else uploadtc = "passedtestcases";
					myFrame.dispose();
			}	    	
	    });
	    
	    ButtonOK.addMouseListener(new MouseAdapter() {
	    	public void mouseReleased(MouseEvent arg0) {
	    	    System.out.println("Upload :" + uploadtc); 
	    	}		
	    });
	    	    
		myPanel.add(checkboxPass);
		myPanel.add(checkboxAll);
		myPanel.add(ButtonOK);    
		    
		    checkboxPass.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					if(checkboxPass.isSelected()){
						checkboxAll.setSelected(false);
					}else{
						checkboxAll.setSelected(true);	
					}	
				    System.out.println("checkboxAll:" + checkboxAll.isSelected());
				    System.out.println("checkboxPass:" + checkboxPass.isSelected());				
				}
		    });

		    		    
		    checkboxAll.addActionListener(new ActionListener(){
				public void actionPerformed(ActionEvent e) {
					if(checkboxAll.isSelected() ){
						checkboxPass.setSelected(false);
					}else{
						checkboxPass.setSelected(true);	
					}
				    System.out.println("checkboxAll:" + checkboxAll.isSelected());
				    System.out.println("checkboxPass:" + checkboxPass.isSelected());					
				}				    				    
		    });
	}
	
	
	public static void main(String args[]){
		
		ActionListener_JPanelOptions s1 = new ActionListener_JPanelOptions();
		s1.Action_Listener_Swings();
	}


	
}
