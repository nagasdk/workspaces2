package awt;

public class TestFrameCheckBox {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		ActionListener_JPanelOptions s1 = new ActionListener_JPanelOptions();
		if (3>2)
			s1.Action_Listener_Swings();
		else
			System.out.println("failed");

	}

}
