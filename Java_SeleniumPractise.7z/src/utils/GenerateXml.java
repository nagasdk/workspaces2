package utils;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import constants.GenericConstants;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 * This class generates Verification point xml file
 * @author Devalanka_Pavani
 *
 */
public class GenerateXml  {

	/**
	 * This method generates an Xml with the list of
	 * elements passed as parameters
	 * @param testScriptName
	 * @param fileName
	 * @param listOfElements
	 * @param totalTestCases
	 * @param totalVerificationPoints
	 * @param pass
	 * @param fail
	 * @param notRun
	 * 
	 */
	public void generateVPXml(String testScriptName, String fileName, List<LogXMLResult> listOfElements,
			int totalTestCases, int totalVerificationPoints, int pass, int fail, int notRun) {

		File file = new File(fileName);
		CreateXML_Root rootVO = new CreateXML_Root();
		rootVO.setTestScriptName(testScriptName);
		rootVO.setElementVO(listOfElements);
		rootVO.setTotalTestCases(totalTestCases);
		rootVO.setTotalVerificationPoints(totalVerificationPoints);
		rootVO.setPassed(pass);
		rootVO.setFailed(fail);
		rootVO.setNotRun(notRun);

		try {

			JAXBContext jaxbContext = JAXBContext.newInstance(CreateXML_Root.class);


			Marshaller marshaller = jaxbContext.createMarshaller();

			// Format the output XML
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

			marshaller.marshal(rootVO, file);

			//print the output on the console
			//marshaller.marshal(rootVO, System.out);

		} catch (JAXBException e) {
			e.printStackTrace();
		}

	}

	/**
	 * This method sets the child nodes values of <verificationPoint>
	 * tag while generating XML
	 * @param testCaseId
	 * @param VPName
	 * @param VPResult
	 * @param VPStatus
	 * @return LogXMLResult
	 */
	public LogXMLResult logVerificationPoint(String testCaseId, String VPName,
			String VPResult, String VPStatus) {
		LogXMLResult logResult = new LogXMLResult();
		logResult.setTestCaseId(testCaseId);
		logResult.setVPName(VPName);
		logResult.setVPResult(VPResult);
		logResult.setVPStatus(VPStatus);

		return logResult;
	}

	/**
	 * This method is used to create a new XML file in the
	 * given path with the given script name. xmlFilePath variable
	 * will be like 
	 * D:\OCPE_AutomationReports\17Oct2013_1021\DetailedReports\xml\data.xml
	 * @param scriptName
	 */
	public void createVPXML(String scriptName) {
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder;
		try {
			documentBuilder = documentBuilderFactory.newDocumentBuilder();

			Document document = documentBuilder.newDocument();
			Element rootElement = document.createElement(GenericConstants.ELE_VERIFICATIONPOINTS);
			document.appendChild(rootElement);

			DOMSource source = new DOMSource(document);
			Element root = document.getDocumentElement();

			// Verification point element and it's child node TestScriptName
			Element testScriptName = document.createElement(GenericConstants.ELE_TESTSCRIPTNAME);
			testScriptName.appendChild(
					document.createTextNode(scriptName));
			rootElement.appendChild(testScriptName);

			root.appendChild(testScriptName);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer;
			transformer = transformerFactory.newTransformer();

			StreamResult result = new StreamResult(GenericConstants.XML_FILEPATH);
			transformer.transform(source, result);


		} catch (ParserConfigurationException e) {

			e.printStackTrace();
		} catch (TransformerConfigurationException e) {

			e.printStackTrace();
		} catch (TransformerException e) {

			e.printStackTrace();
		}
	}


	/**
	 * This method is used to append <verificationPoint> child node to
	 * the root node <VerificationPoints> 
	 * @param testCaseId
	 * @param vpName
	 * @param vpResult
	 * @param status
	 */
	public void logVP(String testCaseId,
			String vpName, String vpResult, String status) {
		//Maintain passCount and failCount
		if(status.equalsIgnoreCase(GenericConstants.vPass)) {
			GenericConstants.passCount ++;
		} else {
			GenericConstants.failCount ++;
		}
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document;
			document = documentBuilder.parse(GenericConstants.XML_FILEPATH);

			Element root = document.getDocumentElement();

			// Root Element
			Element rootElement = document.getDocumentElement();

			// Verification point element and it's child nodes
			Element vp = document.createElement(GenericConstants.ELE_VERIFICATIONPOINT);
			rootElement.appendChild(vp);

			Element testCaseIdElement = document.createElement(GenericConstants.ELE_TESTCASEID);
			testCaseIdElement.appendChild(document.createTextNode(testCaseId));
			vp.appendChild(testCaseIdElement);

			Element vpNameElement = document.createElement(GenericConstants.ELE_VPNAME);
			vpNameElement.appendChild(document.createTextNode(vpName));
			vp.appendChild(vpNameElement);

			Element vpResultElement = document.createElement(GenericConstants.ELE_VPRESULT);
			vpResultElement.appendChild(document.createTextNode(vpResult));
			vp.appendChild(vpResultElement);

			Element vpStatusElement = document.createElement(GenericConstants.ELE_VPSTATUS);
			vpStatusElement.appendChild(document.createTextNode(status));
			vp.appendChild(vpStatusElement);

			root.appendChild(vp);


			DOMSource source = new DOMSource(document);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			StreamResult result = new StreamResult(GenericConstants.XML_FILEPATH);
			transformer.transform(source, result);
		} catch (ParserConfigurationException e) {

			e.printStackTrace();
		} catch (SAXException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}	catch (TransformerConfigurationException e) {

			e.printStackTrace();
		} catch (TransformerException e) {

			e.printStackTrace();
		}
	}

	/**
	 * This method is used to add pass, fail, not run counts to XML file
	 * <Header> tag
	 */
	public void logHeaderReportCounts() {
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document;
			document = documentBuilder.parse(GenericConstants.XML_FILEPATH);

			Element root = document.getDocumentElement();

			// Root Element
			Element rootElement = document.getDocumentElement();

			Element header = document.createElement(GenericConstants.ELE_HEADERSECTION);
			rootElement.appendChild(header);

			//Get the properties file to fetch total VPs and TCs
			PropertiesUtil propertiesUtil = new PropertiesUtil(GenericConstants.PROPERTIES_FILEPATH); 

			// Total no.of Verification points element
			Element totalVPs = document.createElement(GenericConstants.HEADER_ELE_TOTALVPS);
			totalVPs.appendChild(
					document.createTextNode(propertiesUtil.read(GenericConstants.TOTAL_VERIFICATION_POINTS)));
			header.appendChild(totalVPs);



			// Total no.of test cases  element
			Element totalTCs = document.createElement(GenericConstants.HEADER_ELE_TOTALTCS);
			totalTCs.appendChild(
					document.createTextNode(propertiesUtil.read(GenericConstants.TOTAL_TESTCASES)));
			header.appendChild(totalTCs);



			//  Passed element
			Element passCount = document.createElement(GenericConstants.HEADER_ELE_PASSED);
			passCount.appendChild(
					document.createTextNode(Integer.toString(GenericConstants.passCount)));
			header.appendChild(passCount);



			//  Failed element
			Element failCount = document.createElement(GenericConstants.HEADER_ELE_FAILED);
			failCount.appendChild(
					document.createTextNode(Integer.toString(GenericConstants.failCount)));
			header.appendChild(failCount);


			//  Failed element
			Element notRunCount = document.createElement(GenericConstants.HEADER_ELE_NOTRUN);
			notRunCount.appendChild(
					document.createTextNode(Integer.toString(GenericConstants.notRunCount)));
			header.appendChild(notRunCount);

			root.appendChild(header);

			DOMSource source = new DOMSource(document);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			StreamResult result = new StreamResult(GenericConstants.XML_FILEPATH);
			transformer.transform(source, result);
		} catch (ParserConfigurationException e) {

			e.printStackTrace();
		} catch (SAXException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}	catch (TransformerConfigurationException e) {

			e.printStackTrace();
		} catch (TransformerException e) {

			e.printStackTrace();
		}
	}

	/**
	 * This method is used to create a new summary report XML file in the
	 * given path with the given name. xmlFilePath variable
	 * will be like 
	 * D:\OCPE_AutomationReports\17Oct2013_1021\DetailedReports\xml\SummaryReport.xml 
	 */
	public void createSummaryXML() {
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
		DocumentBuilder documentBuilder;
		try {
			documentBuilder = documentBuilderFactory.newDocumentBuilder();

			Document document = documentBuilder.newDocument();
			Element rootElement = document.createElement(GenericConstants.ELE_SUMMARYREPORT);
			document.appendChild(rootElement);
			
			Element reportNameElement = document.createElement(GenericConstants.ELE_REPORTNAME);
			reportNameElement.appendChild(document.createTextNode(GenericConstants.SUMMARY_REPORT_NAME));
			rootElement.appendChild(reportNameElement);
			

			DOMSource source = new DOMSource(document);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer;
			transformer = transformerFactory.newTransformer();

			StreamResult result = new StreamResult(GenericConstants.SUMMARY_REPORT_XML_FILE_PATH);
			transformer.transform(source, result);


		} catch (ParserConfigurationException e) {

			e.printStackTrace();
		} catch (TransformerConfigurationException e) {

			e.printStackTrace();
		} catch (TransformerException e) {

			e.printStackTrace();
		}
	}


	/**
	 * This method writes the script details into SummaryReport.xml file 
	 * @param scriptName
	 * @param htmlReportPath
	 * @param pass
	 * @param fail
	 * @param notRun
	 */
	public void logScript(String scriptName, String htmlReportPath) {
		try {
			//If SummaryReport.xml does not exist, then create it
			File file = new File(GenericConstants.SUMMARY_REPORT_XML_FILE_PATH);
			if (!file.exists()) {
				createSummaryXML();
			}
			
			//Parse SummaryReport.xml
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(GenericConstants.SUMMARY_REPORT_XML_FILE_PATH);

			// Root Element
			Element rootElement = document.getDocumentElement();

			// Script element and it's child nodes
			Element script = document.createElement(GenericConstants.ELE_SCRIPT);
			rootElement.appendChild(script);

			Element scriptNameElement = document.createElement(GenericConstants.ELE_SCRIPTNAME);
			scriptNameElement.appendChild(document.createTextNode(scriptName));
			script.appendChild(scriptNameElement);
			
			Element htmlFilePathElement = document.createElement(GenericConstants.ELE_HTMLREPORTPATH);
			htmlFilePathElement.appendChild(document.createTextNode(htmlReportPath));
			script.appendChild(htmlFilePathElement);

			//Get the properties file to fetch total VPs and TCs
			PropertiesUtil propertiesUtil = new PropertiesUtil(GenericConstants.PROPERTIES_FILEPATH); 

			Element totalTCs = document.createElement(GenericConstants.HEADER_ELE_TOTALTCS);
			totalTCs.appendChild(document.createTextNode(propertiesUtil.read(GenericConstants.TOTAL_TESTCASES)));
			script.appendChild(totalTCs);

			Element totalVPs = document.createElement(GenericConstants.HEADER_ELE_TOTALVPS);
			totalVPs.appendChild(document.createTextNode(propertiesUtil.read(GenericConstants.TOTAL_VERIFICATION_POINTS)));
			script.appendChild(totalVPs);

			Element passElement = document.createElement(GenericConstants.HEADER_ELE_PASSED);
			passElement.appendChild(document.createTextNode(Integer.toString(GenericConstants.passCount)));
			script.appendChild(passElement);

			Element failElement = document.createElement(GenericConstants.HEADER_ELE_FAILED);
			failElement.appendChild(document.createTextNode(Integer.toString(GenericConstants.failCount)));
			script.appendChild(failElement);

			Element notRunElement = document.createElement(GenericConstants.HEADER_ELE_NOTRUN);
			notRunElement.appendChild(document.createTextNode(Integer.toString(GenericConstants.notRunCount)));
			script.appendChild(notRunElement);

			rootElement.appendChild(script);


			DOMSource source = new DOMSource(document);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			StreamResult result = new StreamResult(GenericConstants.SUMMARY_REPORT_XML_FILE_PATH);
			transformer.transform(source, result);
		} catch (ParserConfigurationException e) {

			e.printStackTrace();
		} catch (SAXException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}	catch (TransformerConfigurationException e) {

			e.printStackTrace();
		} catch (TransformerException e) {

			e.printStackTrace();
		}
	}

	/**
	 * This method logs total TCs, VPs, passed, failed and notRun
	 * elements in header section of SummaryReport.xml file
	 */
	public void logSummaryReportHeaderSection() {
		try {
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			Document document = documentBuilder.parse(GenericConstants.SUMMARY_REPORT_XML_FILE_PATH);
		//	Element root = document.getDocumentElement();
			// Root Element
			Element rootElement = document.getDocumentElement();

			Element header = document.createElement(GenericConstants.ELE_HEADERSECTION);
			rootElement.appendChild(header);

		
			// Total no.of test cases  element
			Element totalTCs = document.createElement(GenericConstants.HEADER_ELE_TOTALTCS);
			totalTCs.appendChild(
					document.createTextNode(getString(GenericConstants.HEADER_ELE_TOTALTCS, rootElement)));
			header.appendChild(totalTCs);

			// Total no.of Verification points element
			Element totalVPs = document.createElement(GenericConstants.HEADER_ELE_TOTALVPS);
			totalVPs.appendChild(
					document.createTextNode(getString(GenericConstants.HEADER_ELE_TOTALVPS, rootElement)));
			header.appendChild(totalVPs);


			//  Passed element
			Element passCount = document.createElement(GenericConstants.HEADER_ELE_PASSED);
			passCount.appendChild(
					document.createTextNode(getString(GenericConstants.HEADER_ELE_PASSED, rootElement)));
			header.appendChild(passCount);



			//  Failed element
			Element failCount = document.createElement(GenericConstants.HEADER_ELE_FAILED);
			failCount.appendChild(
					document.createTextNode(getString(GenericConstants.HEADER_ELE_FAILED, rootElement)));
			header.appendChild(failCount);


			//  Failed element
			Element notRunCount = document.createElement(GenericConstants.HEADER_ELE_NOTRUN);
			notRunCount.appendChild(
					document.createTextNode(getString(GenericConstants.HEADER_ELE_NOTRUN, rootElement)));
			header.appendChild(notRunCount);

			rootElement.appendChild(header);

			DOMSource source = new DOMSource(document);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			StreamResult result = new StreamResult(GenericConstants.SUMMARY_REPORT_XML_FILE_PATH);
			transformer.transform(source, result);
		} catch (ParserConfigurationException e) {

			e.printStackTrace();
		} catch (SAXException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}	catch (TransformerConfigurationException e) {

			e.printStackTrace();
		} catch (TransformerException e) {

			e.printStackTrace();
		}
	}

	/**
	 * This element gets the elements of tagName that is
	 * passed as parameter and  
	 * returns the count of values present
	 * in tagName. This is used calulate total TCs, VPs, passed,
	 * failed, notRun count in header of SummaryReport.xml file 
	 * @param tagName
	 * @param element
	 * @return
	 */
	private String getString(String tagName, Element element) {

		NodeList list = element.getElementsByTagName(tagName);
		int count = 0;
		for(int loopVar=0; loopVar<list.getLength();loopVar++) {
			count += Integer.parseInt(list.item(loopVar).getTextContent().trim().toString());
		}		

		return Integer.toString(count);
	}

}