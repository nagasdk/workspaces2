package utils;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import constants.GenericConstants;

public class CommonUtils {
	/**
	 * @param args
	 */

	public static WebDriver loginApplication() throws InterruptedException {
		WebDriver driver;
		DesiredCapabilities cap = null;
		FirefoxBinary ffBinary = null;
		FirefoxProfile ffprofile = null;
		PropertiesUtil propsRW = null;
		// ExcelUtil xlRW = new ExcelUtil();

		File pathToFirefoxBinary = new File(
				GenericConstants.PATH_TO_FIREFOX_BINARY);
		ffBinary = new FirefoxBinary(pathToFirefoxBinary);
		ProfilesIni profile = new ProfilesIni();
		ffprofile = profile
				.getProfile(GenericConstants.FIREFOX_PROFILE_DEFAULT);

		if (GenericConstants.PRIVATE_NETWORK.equals(GenericConstants.TRUE)) {
			org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
			proxy.setProxyAutoconfigUrl(GenericConstants.PROXY_URL);
			cap = new DesiredCapabilities();
			cap.setCapability(CapabilityType.PROXY, proxy);
			driver = new FirefoxDriver(ffBinary, ffprofile, cap);
		} else {
			ffprofile.setPreference("network.proxy.type", 0);
			driver = new FirefoxDriver(ffprofile);
		}

		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(GenericConstants.APPLICATION_URL);

		propsRW = new PropertiesUtil(GenericConstants.LOGIN_PROPSFILE);
		System.out.println("GenericConstants.LOGIN_PAGE"
				+ GenericConstants.LOGIN_PAGE);
		System.out.println("GenericConstants.VALID_USERNAME"
				+ GenericConstants.VALID_USERNAME);
		String xpathExpression = ExcelUtil.readProps(
				GenericConstants.LOGIN_PAGE, GenericConstants.VALID_USERNAME);
		driver.findElement(By.xpath(xpathExpression)).clear();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(
				propsRW.read(GenericConstants.VALID_USERNAME));
		xpathExpression = ExcelUtil.readProps(GenericConstants.LOGIN_PAGE,
				GenericConstants.VALID_PASSWORD);
		driver.findElement(By.xpath(xpathExpression)).clear();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(
				propsRW.read(GenericConstants.VALID_PASSWORD));

		xpathExpression = ExcelUtil.readProps(GenericConstants.LOGIN_PAGE,
				GenericConstants.SIGN_IN);
		driver.findElement(By.xpath(xpathExpression)).click();
		//Thread.sleep(5000);
		System.out
				.println("Entered Valid Username and Password, Clicked on Login Button");
		return driver;
	}

	public static Boolean waitForAnobject(WebDriver AppDriver, int waitTime,
			String objXPath) throws InterruptedException {
		Boolean sFlag = false;
		for (int iCnt = 1; iCnt <= waitTime; iCnt++) {
			if (AppDriver.findElement(By.xpath(objXPath)).isDisplayed()) {
				System.out.println("object found finally Waited for Seconds " + iCnt);
				sFlag = true;
				break;
			}
			Thread.sleep(1000);System.out.println("Waited >>"+iCnt+ "Seconds");
		}
		return sFlag;

	}

}
