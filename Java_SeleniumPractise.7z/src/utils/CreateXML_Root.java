package utils;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * This is the class from which verification points XML file is generated
 * @author Devalanka_Pavani
 *
 */
@XmlRootElement(name="VerificationPoints")
public class CreateXML_Root {

	
	/**
	 * list of <verificationPoint> tags in xml
	 */
	List<LogXMLResult> lstElementVO = new ArrayList<LogXMLResult>();

	public List<LogXMLResult> getElementVO() {
		return lstElementVO;
	}
	
	@XmlElement (name="verificationPoint")
	public void setElementVO(List<LogXMLResult> elementVO) {
		this.lstElementVO = elementVO;
	}
	
	/**
	 * <TotalTestCases> tag in xml
	 */
	int totalTestCases = 0;
	
	/**
	 * <TotalVerificationPoints> tag in xml
	 */
	int totalVerificationPoints = 0;
	
	/**
	 * No.of test cases passed
	 * <Passed> tag in xml
	 */
	int passed = 0;
	
	/**
	 * No.of test cases passed
	 * <Failed> tag in xml
	 */
	int failed = 0;
	
	/**
	 * No.of test cases which does not run
	 * <NotRun> tag in xml
	 */
	int notRun = 0;

	public int getTotalTestCases() {
		return totalTestCases;
	}

	@XmlElement (name="TotalTestCases")
	public void setTotalTestCases(int totalTestCases) {
		this.totalTestCases = totalTestCases;
	}

	public int getTotalVerificationPoints() {
		return totalVerificationPoints;
	}

	@XmlElement (name="TotalVerificationPoints")
	public void setTotalVerificationPoints(int totalVerificationPoints) {
		this.totalVerificationPoints = totalVerificationPoints;
	}

	public int getPassed() {
		return passed;
	}

	@XmlElement (name="Passed")
	public void setPassed(int passed) {
		this.passed = passed;
	}

	public int getFailed() {
		return failed;
	}

	@XmlElement (name="Failed")
	public void setFailed(int failed) {
		this.failed = failed;
	}

	public int getNotRun() {
		return notRun;
	}

	@XmlElement (name="NotRun")
	public void setNotRun(int notRun) {
		this.notRun = notRun;
	}

	/**
	 * Test script name
	 */
	String testScriptName;
	
	public String getTestScriptName() {
		return testScriptName;
	}

	@XmlElement (name="TestScriptName")
	public void setTestScriptName(String testScriptName) {
		this.testScriptName = testScriptName;
	}
	
	
}
