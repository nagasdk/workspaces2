//package com.sel.test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

public class Test123 {
  @Test
  public void f() {
	  System.out.println("Test in verified");
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("Beofer methid");
	  System.out.println("Beofer methid");

  }

}
 