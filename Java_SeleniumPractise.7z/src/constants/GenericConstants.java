package constants;

public class GenericConstants {
	
	public static String txtUserName="username";
	public static String txtPassWord="password";

	public static String PATH_TO_FIREFOX_BINARY = "D:/Program Files/Mozilla Firefox/firefox.exe";
	public static String FIREFOX_PROFILE_DEFAULT="default";
	
	public static String PRIVATE_NETWORK="FALSE";
	
	public static String PROXY_URL="";
	public static String APPLICATION_URL="https://accounts.google.com/ServiceLogin?service=mail&continue=https://mail.google.com/mail/&hl=en";

	public static String ddMMMYYYY_HHmm = "ddMMMyyyy_HHmm";
	public static String REPORTS_DIRECTORYPATH = "D:\\OCPE_AutomationReports";
	public static String DETAILED_REPORTS = "DetailedReports";		
	public static String RESOURCES_FOLDERPATH = "src/resources/"; 
	public static String DETAILED_REPORT_XSL = "DetailedReportXSL.xsl";
	public static String SUMMARY_REPORT_XSL = "src/ocpe/aut/fwk/resources/SummaryReportXSL.xsl";
	
	
	public static String LOGIN_PROPSFILE="src/resources/login.properties";
	public static String OBJECT_REPOSITORY= "src/resources/ObjectRepository.xlsx";
	
	
	
	public static String LOGIN_PAGE = "LoginPage";
	
	public static String VALID_USERNAME = "Username";
	public static String VALID_PASSWORD = "Password";
	public static String SIGN_IN = "SignIn";
	public static String LOGIN_MESSAGE = "LoginMessage";

	
	
	public static String CurrentPROPERTIES_FILEPATH ="";
	
	
	//THIS SECTION CONTAINS passCount, failCount and notRunCount
	public static int passCount= 0,failCount = 0, notRunCount = 0;
		
    //THIS variable will change dynamically according to the script
	public static String PROPERTIES_FILEPATH="";  
	public static String TOTAL_VERIFICATION_POINTS = "totalVerificationPoints";
	public static String TOTAL_TESTCASES = "totalTestCases";


	//XML Generation Constants
	public static String XML_FILEPATH="";		 // This variable gets initialized/uninitialized dynamically by the TestScript which uses this, Every new script should have mechanism to handle this	
	public static String ELE_VERIFICATIONPOINTS = "VerificationPoints";
	public static String ELE_VERIFICATIONPOINT = "verificationPoint";
	public static String ELE_TESTCASEID = "TestCaseId";	
	public static String ELE_VPNAME = "VPName";
	public static String ELE_VPRESULT = "VPResult";
	public static String ELE_VPSTATUS = "VPStatus";
	public static String ELE_TESTSCRIPTNAME = "TestScriptName";
	public static String HEADER_ELE_TOTALVPS = "TotalVerificationPoints";
	public static String HEADER_ELE_TOTALTCS = "TotalTestCases";
	public static String HEADER_ELE_PASSED ="Passed";
	public static String HEADER_ELE_FAILED ="Failed";
	public static String HEADER_ELE_NOTRUN ="NotRun";
	public static String ELE_HEADERSECTION = "Header";
	
	
	//THIS SECTION HAS FOLDER CREATION CONSTANTS
	public static String SUMMARY_REPORT_FOLDER = "D:/OCPE_AutomationReports/19Dec2013_1540";	
	public static String DETAIL_REPORT_FOLDER = "D:/OCPE_AutomationReports/19Dec2013_1540/DetailedReports";		
	public static String XML_FOLDERPATH = "D:/OCPE_AutomationReports/19Dec2013_1540/DetailedReports/xml"; 
	public static String SUMMARY_REPORT_XML_FILE_PATH = "D:/OCPE_AutomationReports/19Dec2013_1540/DetailedReports/xml/SummaryReport.xml"; 

	/* 	public static String SUMMARY_REPORT_FOLDER = "";	
	public static String DETAIL_REPORT_FOLDER = "";		
	public static String XML_FOLDER = ""; 
	public static String SUMMARY_REPORT_XML_FILE_PATH = "";
*/	

	
	// THIS SECTION HAS THE DEFINITION OF CONSTANTS BEING USED FOR SUMMARY XML REPORT GENERATION
	public static String SUMMARY_REPORT = "SummaryReport";	
	public static String SUMMARY_REPORT_NAME = "OCPE Regression Testing Report";
	public static String ELE_SUMMARYREPORT = "SummaryReport";
	public static String ELE_SCRIPT = "Script";
	public static String ELE_REPORTNAME = "ReportName";
	public static String ELE_SCRIPTNAME = "ScriptName";
	public static String ELE_HTMLREPORTPATH = "HtmlReportPath";
	
//  Extensions
	public static String FORWARD_SLASH = "/"; 
	public static String DOT_XML=".xml";
	public static String DOT_HTML = ".html";
	public static String XML = "xml";

	
	public static String vPass = "Pass";
	public static String vFail = "Fail";

	
	//MISC Constants
	public static String SPACE = " ";
	public static String READONLY = "readonly";
	public static String TRUE="TRUE";
	public static String FALSE="FALSE";
	
	public static String INPUT = "input";
	public static String CHECKED = "checked";
	public static String ID = "id";
	public static String OPTION = "option";
	public static String TYPE = "type";
	public static String CHECKBOX = "checkbox";
	public static String CLASS = "class";
	public static String TR = "tr";
	public static String TD = "td";
	public static String SRC = "src";
	public static String QUESTION_MARK = "?";	
	public static String ASCENDING = "ascending";
	public static String DESCENDING = "descending";	

	
	
}
