package gmail;

//package ocpe.aut.fwk.testScripts;

import static org.junit.Assert.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.xpath.operations.Bool;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebDriverBackedSelenium;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.reporters.ExitCodeListener;

import utils.CommonUtils;
import utils.ExcelUtil;
import utils.GenerateHTML;
import utils.GenerateXml;
import utils.PropertiesUtil;

import constants.GenericConstants;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Gmail_Login {
	private static StringBuffer verificationErrors = new StringBuffer();
	//private static ExcelUtil excelRW;
	private static PropertiesUtil propsRW;
	private static GenerateXml generateXML;
	private static GenerateHTML generateHReport;
	private static CommonUtils commonUtil;
	//	private static String pageName = AppConstants.LOGIN_PAGE;
	int sleepInterval = 3000;	// Sleep interval in milliseconds, 2000 milliseconds, i.e. 2seconds

	public static WebDriver driver;
	
	
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// one-time initialization code   
		System.out.println("@BeforeClass - oneTimeSetUp");	
		generateXML = new GenerateXml();		
		generateHReport = new GenerateHTML();		
		//excelRW = new ExcelUtil(); 
		commonUtil = new CommonUtils();

		//Change the xml file path according to name of the script
		//AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER+AppConstants.FORWARD_SLASH+AdminConstants.ADMIN+AppConstants.DOT_XML;
		GenericConstants.XML_FILEPATH = GenericConstants.XML_FOLDERPATH+GenericConstants.FORWARD_SLASH+"GMAIL_LOGIN"+GenericConstants.DOT_XML;
		GenericConstants.CurrentPROPERTIES_FILEPATH = GenericConstants.LOGIN_PROPSFILE;		

		//Sheet Name of excel from where the xpath values are fetched
		//	pageName = AdminConstants.ADMIN_PAGE;

		//Create a new XML file
		//generateXML.createVPXML(AdminConstants.ADMIN_SCRIPT_NAME);

		driver=CommonUtils.loginApplication();

	}

	@Test
	public void test() throws InterruptedException{
		propsRW =new PropertiesUtil(GenericConstants.LOGIN_PROPSFILE);	
		String xpathExpression=ExcelUtil.readProps(GenericConstants.LOGIN_PAGE, GenericConstants.LOGIN_MESSAGE);
		if(CommonUtils.waitForAnobject(driver,15,xpathExpression) == true)
		{
			String wlcmMessage=driver.findElement(By.xpath(xpathExpression)).getText();
			System.out.println("runtime value"+wlcmMessage);
			String expVal=propsRW.read(GenericConstants.LOGIN_MESSAGE);
			System.out.println("expVal value"+expVal);
			if(wlcmMessage.contains(expVal))	
				System.out.println("Login Succesful");
			else	
				System.out.println("Login is UnSuccesful");
		}
		else
		{
			System.out.println("Even after 15 seconds the page was not loaded on time");
		}
		
	}

	
//	@AfterClass
//	public static void tearDownAfterClass() throws Exception {
//
///*		
//		AppConstants.notRunCount = 	 Integer.parseInt(propsRW.read(AppConstants.TOTAL_VERIFICATION_POINTS).trim())-AppConstants.passCount-AppConstants.failCount;		
//
//		//log header report counts in XML file
//		generateXML.logHeaderReportCounts();
//		//Generate html report using xml created in test method
//		//Report should be according to test case name, ex: data.html
//		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH+AppConstants.DETAILED_REPORT_XSL;
//		String outputHTML = AppConstants.DETAIL_REPORT_FOLDER+AppConstants.FORWARD_SLASH+AdminConstants.ADMIN+AppConstants.DOT_HTML;
//		generateHReport.generateHTML(AppConstants.XML_FILE_PATH, inputXSL, outputHTML);
//
//		System.out.println("Successfully generated the report");
//
//		//log script in summary report xml file
//		generateXML.logScript(AdminConstants.ADMIN_SCRIPT_NAME, outputHTML);
//
//		//Reset xml & properties files path to ""	
//		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
//		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;
//
//		//Set pass, fail and notrun count to zero
//		AppConstants.passCount= 0;
//		AppConstants.failCount = 0;
//		AppConstants.notRunCount = 0;
//*/
//		//Close the browser
//		// driver.quit();
//		/*		String verificationErrorString = verificationErrors.toString();
//				if (!"".equals(verificationErrorString)) {
//					fail(verificationErrorString);
//				}
//		*/
//	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}



		
	

}


