import java.util.HashMap;
import java.util.HashSet;


public class Hash_Map {

	/**
	 * @param args
	 * HashSet - is a collection of set of elements(integers,string,obects)
	 * 
	 * HashMap - is a collection of Key Value Pairs
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		HashSet<Integer> phonenos = new HashSet<>();
		phonenos.add(1111);
		phonenos.add(2222);
		phonenos.add(3333);phonenos.add(4444);phonenos.add(3333);
		phonenos.add(4444);// IGNORES MULTIPLE VALUES AND DISPLAYS ONLY UNIQUE VALUES
		System.out.println("\n PRINT THE HASH SET VALUES");
		System.out.println(phonenos);
		
		HashMap<String,Integer> dir= new HashMap<String,Integer>();
		dir.put("KURA1", 632831);dir.put("KURA2", 632832);
		dir.put("KURA3", 632833);dir.put("KURA4", 632834);
		dir.put("KURA3", 632834);dir.put("KURA5", 632835);
		System.out.println("\n PRINT THE HASH MAP VALUES");
		System.out.println(dir);
		
		
		HashMap<String,HashSet<Integer>> dir1= new HashMap<String,HashSet<Integer>>();
		HashSet<Integer> h1= new HashSet<>();h1.add(123);h1.add(234);h1.add(345);
		HashSet<Integer> h2= new HashSet<>();h2.add(123);h2.add(234);h2.add(345);
		dir1.put("KURA1", h1);dir1.put("KURA2", h2);
		System.out.println("\n PRINT THE HASH MAP VALUES");
		System.out.println(dir1);
		
		
		
		
		
		
		
	}

}
