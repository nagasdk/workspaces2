package interfaces;

public interface I1_sample {
	
	
	public String PlayerInfo(String s1, String s2,String s3);

	public String PlayerInfo(String s1, String s2);

	
}
