
public class stringOps {
	
		String revstr="";					
		String concat="";

		
		
		public String get_StringReverse(String s){			
			for(int i=s.length()-1;i>=0;i--)
			revstr=revstr+s.charAt(i);
			return revstr;		
		}

		public String get_StringConcat(String s1,String s2){
			return s1.concat(s2); 		
		}


}
