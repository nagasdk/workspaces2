
public class interface_instantiate {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
	I1_Class i1= new I1_Class();
	String s = i1.PlayerInfo("HELLO", "WORLD");
	System.out.println("String Value" + s);
	}
	

}
