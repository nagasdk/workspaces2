package ocpe.aut.fwk.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;

import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.constants.CatalogConstants;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


/**
 * Common util methods are present in this class
 * @author Devalanka_Pavani
 *
 */
public class CommonUtil {
	
	private HBaseUtil hbaseUtil=new HBaseUtil();
	private PropertiesUtil props=new PropertiesUtil(CatalogConstants.CATALOG_PROPERTIES);

	/**
	 * This method fetches the particular column data on the screen.
	 * Provide table WebElement and position of the column (in the table) from where 
	 * data needs to be fetched
	 * @param table
	 * @param columnPosition
	 * @return
	 */
	public List<String> getColumnContents(WebElement table, int columnPosition) {

		List<String> dataList = new ArrayList<String>();
		//Get the rows of the table
		List<WebElement> rows = table.findElements(By.tagName(AppConstants.TR));
		for (WebElement row : rows) {
			//Get the columns for a particular row
			List<WebElement> columns = row.findElements(By.tagName(AppConstants.TD));

			//Add the data in the required column in the list
			dataList.add(columns.get(columnPosition).getText().trim());			
		}
		
		//return the list
		return dataList;
	}

	/**
	 * This method is used to check whether a list is properly sorted in
	 * ascending / descending order
	 * @param actualList
	 * @param sortOrder
	 * @return
	 */
	public boolean checkSorting(List<String> actualList, String sortOrder) {
		/* Create a sorted list with actual list */
		List<String> sortedList = new ArrayList<String>(actualList);

		/* Check the sort order (whether it is ascending or desecending) and sort the
		 * list accordingly*/
		if(sortOrder.equals(AppConstants.ASCENDING)) {
			Collections.sort(sortedList);
		} else {
			// create comparator for reverse order i.e. descending order
			Comparator<String> comparator = Collections.reverseOrder(); 
			// sort the list
			Collections.sort(sortedList, comparator); 
		}

		boolean sortSuccess = false;
		//Compare actual and sorted lists and return true or false
		if(actualList.equals(sortedList)) {
			sortSuccess = true;
		} 

		return sortSuccess;		
	}
	
	class Product
	{
		
		private String productId;
		private float rating;
	
		 
		 public String getProductId() {
			return productId;
		}
		public void setProductId(String productId) {
			this.productId = productId;
		}
		public float getRating() {
			return rating;
		}
		public void setRating(float rating) {
			this.rating = rating;
		}		 
		 
	}
	/**
	 * This method is used to get the recommendations from the hbase for the specified column family
	 * sort them and get the product names for the first 20 products after sorting them on count
	 * @param columnFamilyName
	 * @return LinkedHashMap<String,String>
	 */	
	
	@SuppressWarnings("unchecked")
	
	public LinkedHashMap<String,String> getProductNames(String ColumnFamilyName)
	{
		
		PropertiesUtil propsRW=new PropertiesUtil(CatalogConstants.CATALOG_PROPERTIES);
		
		LinkedHashMap<String, Object> expectedMap=new LinkedHashMap<String, Object>();
		
		expectedMap=hbaseUtil.getLatestRowKeyDetailsInsertionOrder(CatalogConstants.PRODUCTINSIGHT, ColumnFamilyName, propsRW.read(CatalogConstants.VALIDPRODUCTID), 1);
	
		List<Product> productsList=new ArrayList<Product>();
		
		for(Entry<String,Object> e:expectedMap.entrySet())
		{
			Product product=new Product();
			product.setProductId(e.getKey());
			product.setRating(Float.valueOf(e.getValue().toString()));
			productsList.add(product);
			
			
		}

		int topRatedListSize = productsList.size();

		if( topRatedListSize > 1 ){
		
			Collections.sort( productsList, new RatingComparator( false ) ); //sorting in descending order

		}

			return getSortedProductNames(productsList);
	}
		
	/**
	 * This method is used to get the recommendations from the hbase for the specified column family
	 * sort them and get the product names for the first 20 products after sorting them on count and comparing the category codes
	 * @param columnFamilyName
	 * @return LinkedHashMap<String,String>
	 */	
	public LinkedHashMap<String,String> getProductNamesbyCategory(String ColumnFamilyName)
	{
		
		PropertiesUtil propsRW=new PropertiesUtil(CatalogConstants.CATALOG_PROPERTIES);
		
		LinkedHashMap<String, Object> expectedMap=new LinkedHashMap<String, Object>();
		
		expectedMap=hbaseUtil.getLatestRowKeyDetailsInsertionOrder(CatalogConstants.PRODUCTINSIGHT, ColumnFamilyName, propsRW.read(CatalogConstants.VALIDPRODUCTID), 1);
	
		List<Product> productsList=new ArrayList<Product>();
		
				
		for(Entry<String,Object> e:expectedMap.entrySet())
		{
			Product product=new Product();
			String vertical=hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, e.getKey(), CatalogConstants.VERTICALCODE, CatalogConstants.MAXVERSIONS);
			String category=hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, e.getKey(), CatalogConstants.CATEGORYCODE, CatalogConstants.MAXVERSIONS);
			String subCategory=hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, e.getKey(), CatalogConstants.SUBCATEGORYCODE, CatalogConstants.MAXVERSIONS);
			
			if( vertical != null && !vertical.isEmpty() && !CatalogConstants.NEWLINE_SPCLChar.equalsIgnoreCase( vertical )
					&& category != null && !category.isEmpty() && !CatalogConstants.NEWLINE_SPCLChar.equalsIgnoreCase(category )
					&& subCategory != null && !subCategory.isEmpty() && !CatalogConstants.NEWLINE_SPCLChar.equalsIgnoreCase( subCategory) )
				{
		
				product.setProductId(e.getKey());
				product.setRating(Float.valueOf(e.getValue().toString()));
				productsList.add(product);
			
				}
		}

		int topRatedListSize = productsList.size();

		if( topRatedListSize > 1 ){
		
			Collections.sort( productsList, new RatingComparator( false ) ); //sorting in descending order

		}

		
		return getSortedProductNames(getProductListByCategory(props.read(CatalogConstants.VALIDPRODUCTID),productsList));

	
	}
	/**
	 * This method is used to get the recommendations from the hbase for the specified column family
	 * sort them and get the product names for the first 20 products after sorting
	 * @param columnFamilyName
	 * @return LinkedHashMap<String,String>
	 */
	
	private LinkedHashMap<String,String> getSortedProductNames(List<Product> productsList)	
	{
		LinkedHashMap<String, String> productNames=new LinkedHashMap<String,String>();
		
		List<Product> subList=new ArrayList<Product>();
	
		if(productsList.size()>=20)
		{
			subList=productsList.subList(0, 20); //getting only first 20 product names if there are more than 20 products
		}	
	

		if(subList.size()!=0)
		{
		for(Product p:subList) //getting product names for first 20 products
			{
				String productName=hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS,p.getProductId(), CatalogConstants.PRODUCT_NAME, 1);
				productNames.put(p.getProductId(),productName);
				
			}
		}
		
		
		else
		{
		for(Product p:productsList)
		{
			String productName=hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS,p.getProductId(), CatalogConstants.PRODUCT_NAME, 1);
			productNames.put(p.getProductId(),productName);
			
		}
	}
		
		return productNames;
	
	}
	
	/**
	 * This method is used to get the recommendations from the hbase for the specified column family
	 * sort them and get the product names for comparing the category codes
	 * @param columnFamilyName
	 * @return List<Product>
	 */
	
	public List<Product> getProductListByCategory(String validrowkey,List<Product> productsList)	
	{
		
		List<Product> newList=new LinkedList<Product>();
		System.out.println("hbase util"+hbaseUtil+"---"+validrowkey);
		String actualCategoryCode=hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, validrowkey, CatalogConstants.CATEGORYCODE, CatalogConstants.MAXVERSIONS);
	
		for(Product p:productsList)
		{
			String categoryCode=hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, p.getProductId(), CatalogConstants.CATEGORYCODE, CatalogConstants.MAXVERSIONS);;
			if(categoryCode.equalsIgnoreCase(actualCategoryCode))
			{
				newList.add(p);
			}
		
		}
		
		return newList;
		
	}
	
	public static void main(String s[])
	{
		CommonUtil c=new CommonUtil();
		c.getProductNamesbyCategory(CatalogConstants.ALSOVIEWEDFAMILY);
	}
	
}
