/**
 * 
 */
package ocpe.aut.fwk.util;

import java.io.File;
import java.util.concurrent.TimeUnit;

import ocpe.aut.fwk.constants.AppConstants;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * @author arindam_r
 * 
 */
public enum DriverFactory {

	FIREFOX {
		@Override
		public WebDriver get() {
			File pathToFirefoxBinary = new File(
					AppConstants.PATH_TO_FIREFOX_BINARY);
			FirefoxBinary ffBinary = new FirefoxBinary(pathToFirefoxBinary);
			ProfilesIni profile = new ProfilesIni();
			FirefoxProfile ffprofile = profile
					.getProfile(AppConstants.FIREFOX_PROFILE_DEFAULT);
			ffprofile.setEnableNativeEvents(true);
			org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
			proxy.setProxyAutoconfigUrl(AppConstants.PROXY_URL);
			DesiredCapabilities cap = new DesiredCapabilities();
			cap.setCapability(CapabilityType.PROXY, proxy);
			FirefoxDriver driver = new FirefoxDriver(ffBinary, ffprofile, cap);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			driver.manage().window().maximize();
			return driver;
		}
	},
	CHROME {
		@Override
		public WebDriver get() {
			throw new UnsupportedOperationException(
					"We'll think about this later!");
		}
	},
	IE {
		@Override
		public WebDriver get() {
			throw new UnsupportedOperationException(
					"We'll think about this later!");
		}
	},
	HTMLUNIT {
		@Override
		public WebDriver get() {
			throw new UnsupportedOperationException(
					"We'll think about this later!");
		}
	};

	public abstract WebDriver get();
}
