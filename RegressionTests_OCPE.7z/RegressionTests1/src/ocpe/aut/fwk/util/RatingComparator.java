package ocpe.aut.fwk.util;

import java.io.Serializable;
import java.util.Comparator;

import ocpe.aut.fwk.util.CommonUtil.Product;


/**
 * Class Description: � Comparator class for comparing two products based on
 * their rating fields
 * 
 * @since: 05/24/2011
 * @author: Infosys
 */

public class RatingComparator implements Comparator,Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private boolean ascending = true;

    public RatingComparator(boolean ascending) {
	this.ascending = ascending;
    }
    @Override
    public int compare(Object product1, Object product2) {

	// parameter are of type Object, so we have to downcast it to product
	// objects

    	double product1Count = ((Product) product1).getRating();

    	double product2Count = ((Product) product2).getRating();

	if (Math.abs(product1Count - product2Count) < .0000001) { //product1Count == product2Count) {
															 // For Sonar fix<Dodgy - Test for floating point equality>
	    return 0;
	}

	if (ascending) {
	    return (product1Count > product2Count) ? 1 : -1;
	} else {
	    return (product1Count > product2Count) ? -1 : 1;
	}

    }
}



