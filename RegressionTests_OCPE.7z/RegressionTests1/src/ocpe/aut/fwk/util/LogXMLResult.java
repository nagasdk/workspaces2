package ocpe.aut.fwk.util;

import javax.xml.bind.annotation.XmlElement;

 
/**
 * This is the class for <verificationPoint> tag in xml
 * All the child nodes in this tag are the properties in this file 
 * @author Devalanka_Pavani
 *
 */
public class LogXMLResult {
 
	
	/**
	 * <testCaseId> tag in xml
	 */
	String testCaseId;
	
	/**
	 * <vPName> tag in xml
	 */
	String VPName;
	
	/**
	 * <vPResult> tag in xml
	 */
	String VPResult;
	
	/**
	 * <vPStatus> tag in xml
	 */
	String VPStatus;	
	
	public String getTestCaseId() {
		return testCaseId;
	}

	@XmlElement(name="testCaseId")
	public void setTestCaseId(String testCaseId) {
		this.testCaseId = testCaseId;
	}

	public String getVPName() {
		return VPName;
	}

	@XmlElement(name="vPName")
	public void setVPName(String vPName) {
		VPName = vPName;
	}

	public String getVPResult() {
		return VPResult;
	}

	@XmlElement(name="vPResult")
	public void setVPResult(String vPResult) {
		VPResult = vPResult;
	}

	public String getVPStatus() {
		return VPStatus;
	}

	@XmlElement(name="vPStatus")
	public void setVPStatus(String vPStatus) {
		VPStatus = vPStatus;
	}
	 
	/*@XmlAttribute
	public void setId(int id) {
		this.id = id;
	}*/
 
}