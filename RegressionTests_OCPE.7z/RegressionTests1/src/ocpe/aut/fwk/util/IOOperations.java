package ocpe.aut.fwk.util;

import java.io.File;

import ocpe.aut.fwk.constants.AppConstants;

/**
 * This class is used for I/O operations
 * like creating a folder, deleting a folder etc 
 * @author Devalanka_Pavani
 *
 */
public class IOOperations {

	/**
	 * This method is used to create a directory
	 * @param folderName
	 * @return String
	 */
	public String createTimeStampFolder(String folderName ) { 

		//Create a reports directory (i.e. folder) in the path D:\\Reports if it does not exist
		String reportsFolder = AppConstants.REPORTS_DIRECTORY_PATH;
		File reportsDirectory = new File(reportsFolder);
		
		if(reportsDirectory.exists()){
			System.out.println(AppConstants.REPORTS_DIRECTORY_PATH+
					" folder is created");
		}else{
			System.out.println("Reports directory created");
			reportsDirectory.mkdir();
		}
		
		//Create a directory (i.e. folder) with filderName under reports directory
		String folderPath = AppConstants.REPORTS_DIRECTORY_PATH+
				AppConstants.FORWARD_SLASH+folderName;
		File directory = new File(folderPath);		

		/*If the directory (i.i. folder) already exists, no need to create a new directory (i.e. folder)
		 * otherwise a new directory (i.e. folder) is created
		 * */
		if(directory.exists()){
			System.out.println("A folder with name "+folderName+" is already exist in the path "
					+AppConstants.REPORTS_DIRECTORY_PATH);
		}else{
			System.out.println("Directory created");
			directory.mkdir();
		}
		return folderPath;
	}
	
	/**
	 * This method is used to delete a directory
	 * @param folderPath
	 * @return deleted
	 */
	public boolean deleteFolder(String folderPath ) { 
		boolean deleted=false;

		File directory = new File(folderPath);		

		/*If the directory (i.i. folder) already exists, no need to create a new directory (i.e. folder)
		 * otherwise a new directory (i.e. folder) is created
		 * */
		if(directory.exists()){
			deleted = directory.delete();
			System.out.println(folderPath+" deleted");
		}else{
			System.out.println("If directory does not exists, then no need of delete");
		}
		return deleted;
	}
}
