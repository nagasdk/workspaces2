package ocpe.aut.fwk.util;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import ocpe.aut.fwk.constants.AppConstants;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.FilterList;
import org.apache.hadoop.hbase.filter.RowFilter;
import org.apache.hadoop.hbase.util.Bytes;

/**
 * This class is contains util methods that are used to retrieve data 
 * from HBase
 * @author Devalanka_Pavani
 *
 */
public class HBaseUtil {


	/**
	 * This method returns the HBase configuration 
	 * @return
	 */
	public Configuration getConfig() {

		Configuration config = HBaseConfiguration.create();
		config.clear();
		config.set(AppConstants.ZOOKEEPER_QUORUM, AppConstants.ZOOKEEPER_QUORUM_VALUE);
		config.set(AppConstants.ZOOKEEPER_CLIENT_PORT,AppConstants.ZOOKEEPER_CLIENT_PORT_VALUE);
		config.set(AppConstants.HBASE_MASTER, AppConstants.HBASE_MASTER);		

		return config;
	}

	/**
	 * This method returns key value pair of qualifiers for
	 * a given table, column family, row key and maxVersions 
	 * @param tableName
	 * @param colFamily
	 * @param rowKey
	 * @param maxVersions
	 * @return keyValue
	 */
	public HashMap<String, Object> getLatestRowKeyDetails 
	(String tableName, String colFamily, String rowKey, int maxVersions) {

		//Local variables declaration
		ResultScanner resultScanner = null; 
		Result result = null;		
		HashMap<String, Object> keyValue = new HashMap<String, Object>();

		//Get the HBase configuration
		Configuration config = getConfig();

		try {
			//Check HBase availability
			HBaseAdmin.checkHBaseAvailable(config);

			HTable table = new HTable(config, tableName);
			
			Get get=new Get(Bytes.toBytes(rowKey));
			get.addFamily(Bytes.toBytes(colFamily));
			Scan scan = new Scan(get);
			//scan.addFamily(Bytes.toBytes(colFamily));

			scan.setMaxVersions(maxVersions); // set max version to 1 means scan for col family of latest timestamp
			resultScanner = table.getScanner(scan);	
			result=resultScanner.next();
		

//			while((result=resultScanner.next())!=null){
//				//Get the row key
//				String key=Bytes.toString(result.getRow());

				//If row key equals to given row key
				//if(rowKey.equals(key)) {
					//Get the qualifiers list of row
					List<KeyValue> list=result.list();
					for(KeyValue kv:list){	
					keyValue.put(Bytes.toString(kv.getQualifier()), Bytes.toString(kv.getValue()));	
				}

			//}

		} catch (IOException ioException) {
			ioException.printStackTrace();
		}

		return keyValue;
	}

	/**
	 * This method returns key value pair of qualifiers for
	 * a given table, column family, row key, qualifier
	 * and maxVersions 
	 * @param tableName
	 * @param colFamily
	 * @param rowKey
	 * @param qualifier
	 * @param maxVersions
	 * @return value
	 */
	public String  getQualifierValue (String tableName, String colFamily, String rowKey,
			String qualifier, int maxVersions) {

		//Local variables declaration
		ResultScanner resultScanner = null; 
		Result result = null;	
		String value = AppConstants.BLANK_STRING;

		//Get the HBase configuration
		Configuration config = getConfig();		

		try {
			//Check HBase availability
			HBaseAdmin.checkHBaseAvailable(config);

			HTable table = new HTable(config, tableName);
			
			Get get=new Get(Bytes.toBytes(rowKey));
			get.addColumn(Bytes.toBytes(colFamily),Bytes.toBytes(qualifier));
			Scan scan = new Scan(get);
		
			//scan.addFamily(Bytes.toBytes(colFamily));
//			scan.addColumn(Bytes.toBytes(colFamily), Bytes.toBytes(qualifier));
			scan.setMaxVersions(maxVersions);

			resultScanner = table.getScanner(scan);			
			result=resultScanner.next();

//			while((result=resultScanner.next())!=null){
//				//Get the row key
//				String key=Bytes.toString(result.getRow());
//
//				//If row key equals to given row key
//				if(rowKey.equals(key)) {	
//					//Get the qualifiers list of row
					List<KeyValue> list=result.list();
					for(KeyValue kv:list){	
//						//Check for required qualifier 
//						if(qualifier.equals(Bytes.toString(kv.getQualifier()))) {
//							//get the value of required qualifier
							value = Bytes.toString(kv.getValue());
						//break;
						}
//
//					} // for loop ends
//				} // row key if ends
//
//			} // while loop ends

		} catch (IOException ioException) {
			ioException.printStackTrace();
		}
		if(value.contains("&amp;")) {
			value = value.replace("&amp;", "&");
		}
		return value;
	}

	
	/**
	 * This method returns the rows for the
	 * given startRow, stopRow and maxVersions
	 * values along with table name, column family
	 * @param tableName
	 * @param colFamily
	 * @param startRow
	 * @param stopRow
	 * @param maxVersions
	 * @return
	 */
	public List<Result> fetchRows (String tableName, String colFamily,
			String startRow, String stopRow, int maxVersions) {

		//Local variables declaration
		ResultScanner resultScanner = null; 
		Result result = null;	

		//Get the HBase configuration
		Configuration config = getConfig();		

		List<Result> lstRows = new ArrayList<Result>();

		try {
			//Check HBase availability
			HBaseAdmin.checkHBaseAvailable(config);

			HTable table = new HTable(config, tableName);

			Scan scan = new Scan();
			scan.addFamily(Bytes.toBytes(colFamily));
			scan.setMaxVersions(maxVersions);
			
			//set startRow and stopRow values
			scan.setStartRow(Bytes.toBytes(startRow));
			scan.setStopRow(Bytes.toBytes(stopRow));

			resultScanner = table.getScanner(scan);

			while((result=resultScanner.next())!=null){
				//Add rows to a list
				lstRows.add(result);			
			} // while loop ends

		} catch (IOException ioException) {
			ioException.printStackTrace();
		}

		return lstRows;
	}
	
	/**
	 * This method returns rows based on the row filter
	 * applied to the specified table
	 * Ex: If user wants only numeric row keys, then a filter is applied
	 * to fetch rows having numeric row keys
	 * @param tableName
	 * @param colFamily
	 * @param rowFilter
	 * @param maxVersions
	 * @return
	 */
	public List<Result> rowFilter (String tableName, 
			RowFilter rowFilter, int maxVersions) {

		//Local variables declaration
		ResultScanner resultScanner = null; 
		Result result = null;	

		//Get the HBase configuration
		Configuration config = getConfig();		

		List<Result> lstRows = new ArrayList<Result>();

		try {
			//Check HBase availability
			HBaseAdmin.checkHBaseAvailable(config);

			HTable table = new HTable(config, tableName);

			Scan scan = new Scan();
			scan.setMaxVersions(maxVersions);
			
			//set row filter
			scan.setFilter(rowFilter);

			resultScanner = table.getScanner(scan);

			while((result=resultScanner.next())!=null){
				//Add rows to a list
				lstRows.add(result);			
			} // while loop ends

		} catch (IOException ioException) {
			ioException.printStackTrace();
		}

		return lstRows;
	}
	
	public List<Result> columnFilter (String tableName, 
			FilterList  filterList, int maxVersions) {

		//Local variables declaration
		ResultScanner resultScanner = null; 
		Result result = null;	

		//Get the HBase configuration
		Configuration config = getConfig();		

		List<Result> lstRows = new ArrayList<Result>();

		try {
			//Check HBase availability
			HBaseAdmin.checkHBaseAvailable(config);

			HTable table = new HTable(config, tableName);

			Scan scan = new Scan();
			scan.setMaxVersions(maxVersions);
			
			//set row filter
			scan.setFilter(filterList);

			resultScanner = table.getScanner(scan);

			while((result=resultScanner.next())!=null){
				//Add rows to a list
				lstRows.add(result);			
			} // while loop ends

		} catch (IOException ioException) {
			ioException.printStackTrace();
		}

		return lstRows;
	}
	
	/**
	 * This method returns key value pair of qualifiers for
	 * a given table, column family, row key and maxVersions 
	 * @param tableName
	 * @param colFamily
	 * @param rowKey
	 * @param maxVersions
	 * @return keyValue
	 */
	public LinkedHashMap<String, Object> getLatestRowKeyDetailsInsertionOrder 
	(String tableName, String colFamily, String rowKey, int maxVersions) {

		//Local variables declaration
		ResultScanner resultScanner = null; 
		Result result = null;		
		LinkedHashMap<String, Object> keyValue = new LinkedHashMap<String, Object>();

		//Get the HBase configuration
		Configuration config = getConfig();

		try {
			//Check HBase availability
			HBaseAdmin.checkHBaseAvailable(config);

			HTable table = new HTable(config, tableName);
			
			Get get=new Get(Bytes.toBytes(rowKey));
			get.addFamily(Bytes.toBytes(colFamily));
			Scan scan = new Scan(get);
			//scan.addFamily(Bytes.toBytes(colFamily));

			scan.setMaxVersions(maxVersions); // set max version to 1 means scan for col family of latest timestamp
			resultScanner = table.getScanner(scan);	
			result=resultScanner.next();
		

//			while((result=resultScanner.next())!=null){
//				//Get the row key
//				String key=Bytes.toString(result.getRow());

				//If row key equals to given row key
				//if(rowKey.equals(key)) {
					//Get the qualifiers list of row
					List<KeyValue> list=result.list();
					for(KeyValue kv:list){	
					keyValue.put(Bytes.toString(kv.getQualifier()), Bytes.toString(kv.getValue()));	
				}

			//}

		} catch (IOException ioException) {
			ioException.printStackTrace();
		}

		return keyValue;
	}
}
