package ocpe.aut.fwk.util;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
/**
 * This class generates HTML report from given XML and it's
 * corresponding  XSL files
 * @author Devalanka_Pavani
 *
 */
public class GenerateHTML  {  

	/**
	 * This method takes the inputs XML and XSL files and 
	 * generate a HTML report for XML
	 * @param dataXML
	 *  			XML which has actual details
	 * @param inputXSL
	 * 				XSL for above dataXML
	 * @param outputHTML
	 * 				output HTML file where it is present 
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */
	public void generateHTML(String dataXML, String inputXSL, String outputHTML)  
			throws TransformerConfigurationException,  	TransformerException  	{  

		/* Create a new instance of TransformerFactory */
		TransformerFactory factory = TransformerFactory.newInstance();  
		
		StreamSource xslStream = new StreamSource(inputXSL);  
		Transformer transformer = factory.newTransformer(xslStream);		
		StreamSource in = new StreamSource(dataXML);  
		StreamResult out = new StreamResult(outputHTML);  
		transformer.transform(in, out);  
		System.out.println("The generated HTML file is:" + outputHTML);  

	}  

} 
