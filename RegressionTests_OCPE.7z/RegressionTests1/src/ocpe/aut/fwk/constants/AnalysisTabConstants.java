package ocpe.aut.fwk.constants;

public class AnalysisTabConstants {

	
	//THIS SECTION HAS CONSTANTS FOR Analysis Tab
	public static String ANALYSIS_TAB_NAME = "Data";
	public static String ANALYSIS_OVERVIEW_TAB_NAME="Overview";
	public static String ANALYSIS_BRAND_LINK_NAME="Brand";
	//public static String TAB_DATA = "tab_data";
	public static String ANALYSIS_TAB_OVERVIEW="overviewTab";
	public static String ANALYSIS_TAB_OVERVIEW_SELECT="overviewSelect";
	public static String COLOR_ORANGE="orange";
	public static String LTR_CURRENT="current";
	public static String LTR_DISABLED="disable";
	public static String LTR_BUBBLE_CHART="bubble-chart";
	public static String LTR_TABLE_DATA="tabledata";
	public static String LTR_SEGMENT_NAME="Segment Name";
	public static String LTR_NUMBER_OF_CUSTOMER="Number Of Customers";
	public static String LTR_SVG="svg";
	public static String LTR_ANALYSISADVANCESEARCHLABEL1="AnalysisBrandAdvanceSearchLable1";
	public static String LTR_ANALYSISADVANCESEARCHLABEL2="AnalysisBrandAdvanceSearchLable2";
	public static String LTR_ANALYSISADVANCESEARCHLABEL3="AnalysisBrandAdvanceSearchLable3";
	public static String LTR_ANALYSISADVANCESEARCHLABEL4="AnalysisBrandAdvanceSearchLable4";
	public static String LTR_ANALYSISADVANCESEARCHLABEL5="AnalysisBrandAdvanceSearchLable5";
	
	
	
}
