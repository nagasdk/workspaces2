/**
 * 
 */
package ocpe.aut.fwk.constants;

/**
 * @author Abhishek_Amarnath
 *
 */
public class SocialConstants {
	//THIS SECTION HAS CONSTANTS FOR SOCIAL TAB
	public static String SOCIAL = "social";
	public static String SOCIAL_PROPERTIES= "src/ocpe/aut/fwk/resources/social.properties";
	public static String SOCIAL_TAB = "SocialTab";
	public static String SOCIAL_SCRIPT_NAME = "Social";
	
	public static String SOCIAL_TAB_NAME = "Social";
	public static String TAB_SOCIAL = "tab_social";
	public static String SEARCHSECTION_TITLE = "searchsection_title";
	public static String TITLE = "searchTitle";
	public static String SEARCH_KEYWORD_TITLE = "searchKeywordTitle";
	
	public static String MENU_DEFAULT = "menu_default";
	public static String LEFTMENUITEM_1 = "leftmenuItem1";
	public static String FACEBOOKASSOCIATION = "association";
	public static String ANCHOR_TAG = "a";
	public static String SLIDECOLOR = "slideColor";
	public static String SLIDECOLORCLASS = "activeSpan";
	public static String SEARCHTITLECLASS = "searchTitleCssClass";
	
	public static String COLOR = "color";
	public static String FONT_WEIGHT = "font_weight";
	public static String BLACK_COLOR = "blackColor";
	public static String BOLD_FONT_WEIGHT = "boldFontWeight";
	public static String GREEN_COLOR = "greenColor";
	public static String NODE_COLOR = "nodeColor";
	public static String BACKGROUND_COLOR= "background-color";
	public static String BLACK_BACKGROUND_COLOR ="blackBckGrd";
	public static String ORANGE_TEXT_COLOR = "orangeText";
	
	public static String KEYWORD_RADIO = "keywordRadio";
	public static String CATEGORY_RADIO = "categoryRadio";
	public static String SEARCH_TEXT_BOX = "searchTextBox";
	public static String GO_BUTTON = "goButton";
	
	public static String TREE_MENU = "treeMenu";
	public static String TREE_ELEMENT = "treeElement";
	public static String FB_DATA_TABLE = "fbDataTable";
	public static String FB_DATA_TABLE_COLUMNS = "fbDataTableColumns";
	public static String DATA_TABLE_NO_OF_ENTRIES = "noOfEntriesText";
	public static String DATA_TABLE_PAGINATION = "paginationButtons";
	public static String NO_OF_ENTRIES_TEXT = "showingNoOfEntriesText";
	public static String CANCEL_BTN = "cancelAssociationsBtn";
	public static String SAVE_BTN = "saveAssociationBtn";
	
	public static String CANCEL_TEXT = "Cancel";
	public static String SAVE_TEXT = "Save";
	
	public static String MENU_FACEBOOK_ASSOCIATIONS= "menu_facebook_associations";
	
	public static String VALID_KEYWORD = "validKeyword";
	public static String ALERT = "alert";
	public static String ERRORMESSAGE_BLANK_KEYWORDS = "errorMessage_blank_keywords";
	public static String ALERTBUTTON ="alertButtonClass";
	
	public static String TOOLING_TREEMENU = "tooling_treemenu";
	public static String TOOLING_RESULT = "tooling_result";
	public static String INP_FIELD_TEXT_VALIDATE = "inputFieldTextForTooling";
	public static String TOOLING_VALID_RESULT="toolingresult";
	public static String FACEBOOK_PAGE_RESULT_DIV="fbpage_result_id";


}
