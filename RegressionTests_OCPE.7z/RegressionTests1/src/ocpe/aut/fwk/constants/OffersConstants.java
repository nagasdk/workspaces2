/**
 * 
 */
package ocpe.aut.fwk.constants;

/**
 * @author karthik_chellappan
 *
 */
public class OffersConstants {
	
	public static String OFFER_PROPERTIES= "src/ocpe/aut/fwk/resources/offer.properties";
	public static String OFFER_SCRIPT_NAME = "Offer";
	public static String OFFER_TAB = "OfferTab";
	public static String OFFER_TAB_NAME = "Offers";
	public static String TAB_OFFER = "tab_offer";
	
	public static String CONFIG_PARAM = "config_param";
	public static String CONFIG_PARAM_VAL = "Configure Parameters: Suggested Items help";
	public static String MENU_REPLENISHMENT ="menu_replenishment";
	public static String SEARCH_REPLENISHMENT ="search_replenishment";
	public static String CREATE_REPLENISHMENT ="create_replenishment";
	public static String REPLENISHMENT_TABLE="replenishment_table";
	public static String REPLENISHMENT_TABLE_ITEM ="replenishment_table_item";
	public static String REPLENISHMENT_TABLE_DEFINED ="replenishment_table_defined";
	public static String REPLENISHMENT_TABLE_PURCHASE ="replenishment_table_purchase";
	public static String REPLENISHMENT_TABLE_DEVIATION ="replenishment_table_deviation";
	public static String REPLENISHMENT_TABLE_IMAGE ="replenishment_table_image";
	public static String REPLENISHMENT_TABLE_TYPE ="replenishment_table_type";
	public static String REPLENISHMENT_TABLE_DELETE ="replenishment_table_delete";
	public static String SORTING_ASC = "sorting_asc";
	public static String SORTING_DESC = "sorting_desc";
	
	public static String SEARCH_LABEL ="search_label";
	public static String SEARCH_TEXTBOX ="search_textbox";
	
	public static String SHOW_DROPDOWN_NAME ="show_dropdown_name";
	public static String SHOW_DROPDOWN ="show_dropdown";
	
	public static String SEARCH_PREVIOUS ="search_previous";
	public static String SEARCH_NEXT ="search_next";
	public static String SEARCH_ENTRIES ="search_list";
	public static String SEARCH_TEXT ="search_text";
	public static String SEARCH_RESULT_STR1 ="search_result_str1";
	public static String SEARCH_RESULT_STR2 ="search_result_str2";
	
	public static String TABLE_REPLENISHMENT="table_replenishment";
	public static String ENTRIES_LENGTH ="entries_length";
	public static String ENTRIES_INFO ="entries_info";
	
	public static String DELETE_ICON ="delete_icon";
	public static String DELETE_POPUP ="delete_popup";
	public static String OK_POPUP ="ok";
	public static String PRODUCT_ID="product_id";
	public static String DELETE_POPUP_MSG ="delete_popup_msg";
	public static String POPUP_MSG ="popup_msg";
	public static String DELETE_CONFIRM_MSG ="delete_confirm_msg";
	public static String OK_CONFIRM ="ok";
	
	public static String REPLENISHMENT_ITEMS="replenishment_items";
	public static String EDIT_REPLENISHMENT_HEADER="edit_replenishment_header";
	public static String EDIT_REPLENISHMENT_BACK_BUTTON="edit_replenishment_back_button";
	public static String EDIT_REPLENISHMENT_LABEL="edit_replenishment_label";
	public static String EDIT_REPLENISHMENT_VERTICAL="edit_replenishment_vertical";
	public static String EDIT_REPLENISHMENT_CATEGORY="edit_replenishment_category";
	public static String EDIT_REPLENISHMENT_SUBCATEGORY="edit_replenishment_subcategory";
	public static String EDIT_REPLENISHMENT_PRODUCT="edit_replenishment_product";
	public static String EDIT_REPLENISHMENT_REPEAT_HEADER="edit_replenishment_repeat_header";
	public static String EDIT_REPLENISHMENT_SYSTEM_RADIO="edit_replenishment_system_radio";
	public static String EDIT_REPLENISHMENT_USER_RADIO="edit_replenishment_user_radio";
	public static String EDIT_REPLENISHMENT_INTVL_LBL="edit_replenishment_intvl_lbl";
	public static String EDIT_REPLENISHMENT_INTVL_VAL="edit_replenishment_intvl_val";
	public static String EDIT_REPLENISHMENT_INTVL_VAL1="edit_replenishment_intvl_val1";
	public static String EDIT_REPLENISHMENT_INTVL_VAL2="edit_replenishment_intvl_val2";
	public static String EDIT_REPLENISHMENT_INTVL_VAL3="edit_replenishment_intvl_val3";
	public static String EDIT_REPLENISHMENT_INTVL_VAL4="edit_replenishment_intvl_val4";
	public static String EDIT_REPLENISHMENT_INTVL_VAL5="edit_replenishment_intvl_val5";
	public static String EDIT_REPLENISHMENT_INTVL_VAL6="edit_replenishment_intvl_val6";
	public static String EDIT_REPLENISHMENT_INTVL_DAYS="edit_replenishment_intvl_days";
	public static String EDIT_REPLENISHMENT_RECOM_LBL="edit_replenishment_recom_lbl";
	public static String EDIT_REPLENISHMENT_RECOM_VAL="edit_replenishment_recom_val";
	public static String EDIT_REPLENISHMENT_RECOM_VAL1="edit_replenishment_recom_val1";
	public static String EDIT_REPLENISHMENT_RECOM_VAL2="edit_replenishment_recom_val2";
	public static String EDIT_REPLENISHMENT_RECOM_VAL3="edit_replenishment_recom_val3";
	public static String EDIT_REPLENISHMENT_RECOM_VAL4="edit_replenishment_recom_val4";
	public static String EDIT_REPLENISHMENT_RECOM_VAL5="edit_replenishment_recom_val5";
	public static String EDIT_REPLENISHMENT_RECOM_VAL6="edit_replenishment_recom_val6";
	public static String EDIT_REPLENISHMENT_RECOM_DAYS="edit_replenishment_recom_days";
	public static String EDIT_REPLENISHMENT_DEL_BTTN="edit_replenishment_del_bttn";
	public static String EDIT_REPLENISHMENT_SAVE_BTTN="edit_replenishment_save_bttn";
	public static String EDIT_REPLENISHMENT_UPDATE_MSG="edit_replenishment_updt_msg";
	public static String REPL_TABLE_VAL="repl_table_val";

	public static String CREATE_REPLENISHMENT_LBL="create_replenishment_lbl";
	public static String CREATE_REPLENISHMENT_ITEM_LBL="create_replenishment_item_lbl";
	public static String CREATE_REPLENISHMENT_RADIO_LBL="create_replenishment_radio_lbl";
	public static String CREATE_REPLENISHMENT_PROD_LBL="create_replenishment_prod_lbl";
	public static String CREATE_REPLENISHMENT_DROPDOWN="create_replenishment_dropdown";
	public static String CREATE_REPLENISHMENT_DROPDOWN_VAL="create_replenishment_dropdown_val";
	public static String CREATE_REPLENISHMENT_DROPDOWN_INVALID_VAL="create_replenishment_dropdown_invalid_val";
	public static String CREATE_REPLENISHMENT_GO_BTTN="go_button";
	public static String CREATE_REPLENISHMENT_GO_ERR_MSG="go_err_msg";
	public static String CREATE_REPLENISHMENT_GO_ERR_INVALID_MSG="go_err_invalid_msg";
	public static String CREATE_REPLENISHMENT_PART_NO="create_replenishment_part_no";
	public static String CREATE_REPLENISHMENT_LIST="create_replenishment_list";
	public static String CREATE_REPLENISHMENT_PROD="create_replenishment_prod";
	public static String CREATE_REPLENISHMENT_SUBCAT="create_replenishment_subcat";
	public static String CREATE_REPLENISHMENT_CAT="create_replenishment_cat";
	public static String CREATE_REPLENISHMENT_VERTICAL="create_replenishment_vertical";
	public static String CREATE_REPLENISHMENT_SEARCH_LBL="create_replenishment_search_lbl";
	public static String CREATE_REPLENISHMENT_SEARCH_VAL="create_replenishment_search_val";
	public static String CREATE_REPLENISHMENT_ENTRIES_DROP="create_replenishment_entries_drop";
	public static String CREATE_REPLENISHMENT_PREV="create_replenishment_prev";
	public static String CREATE_REPLENISHMENT_NEXT="create_replenishment_next";
	public static String CREATE_REPLENISHMENT_ENTRIES_INFO="create_replenishment_entries_info";
	public static String CREATE_REPLENISHMENT_PROD_LINK="create_replenishment_prod_link";
	public static String CREATE_REPLENISHMENT_REPEAT_HEADER="create_replenishment_repeat_header";
	public static String CREATE_REPLENISHMENT_REPEAT_LBL="create_replenishment_repeat_lbl";
	public static String CREATE_REPLENISHMENT_SAVE="create_replenishment_save";
	public static String CREATE_REPLENISHMENT_CANCEL="create_replenishment_cancel";
	public static String CREATE_REPLENISHMENT_HIGHLIGHT="create_replenishment_highlight";
	public static String CREATE_REPLENISHMENT_ERR_MSG1="create_replenishment_err_msg1";
	public static String CREATE_REPLENISHMENT_ERR_MSG2="create_replenishment_err_msg2";
	public static String CREATE_REPLENISHMENT_ERR_MSG3="create_replenishment_err_msg3";
	public static String CREATE_REPLENISHMENT_ERR_MSG4="create_replenishment_err_msg4";
	public static String CREATE_REPLENISHMENT_ERR_MSG5="create_replenishment_err_msg5";
	public static String CREATE_REPLENISHMENT_SUCC_MSG="create_replenishment_succ_msg";
	public static String CREATE_REPLENISHMENT_RPT_DIV="create_replenishment_rpt_div";
	public static String CREATE_REPLENISHMENT_SEARCH_RSLT1="create_replenishment_search_rslt1";
	public static String CREATE_REPLENISHMENT_SEARCH_RSLT2="create_replenishment_search_rslt2";
	
	public static String SUGGESTED_ITEMS_LINK="suggested_items_link";
	public static String SUGGESTED_ITEMS_LBL="suggested_items_lbl";
	public static String SUGGESTED_ITEMS_UPDT="update";
	public static String SUGGESTED_ITEMS_UPDT_MSG="update_msg";

	public static String TOP_PICKS_LINK="top_picks_link";
	public static String TOP_PICKS_HDR_LBL="top_picks_hdr_lbl";
	public static String TOP_PICKS_LBL="top_picks_lbl";
	public static String TOP_PICKS_UPDT="update";
	public static String TOP_PICKS_UPDT_MSG="update_msg";
	
	public static String FREQ_BOUGHT_LINK="freq_bought_link";
	public static String FREQ_BOUGHT_HDR_LBL="freq_bought_hdr_lbl";
	public static String FREQ_BOUGHT_LBL="freq_bought_lbl";
	public static String FREQ_BOUGHT_UPDT="update";
	public static String FREQ_BOUGHT_UPDT_MSG="update_msg";
}
