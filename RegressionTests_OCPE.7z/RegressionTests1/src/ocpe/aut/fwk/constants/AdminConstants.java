package ocpe.aut.fwk.constants;

public class AdminConstants {
	//THIS SECTION HAS CONSTANTS RELATED TO ADMIN PAGE
	public static String ADMIN_PROPERTIES= "src/ocpe/aut/fwk/resources/admin.properties";
	public static String ADMIN_SCRIPT_NAME = "Admin";
	public static String ADMIN_PAGE = "AdminPage";	
	public static String BTN_ADMIN = "btnAdmin";
	public static String ADMIN = "admin";
	public static String MENU_DEFAULT = "menu_default";
	public static String MENU_USERMGMT = "menu_userMgmt";
	public static String MENU_ROLEMGMT = "menu_roleMgmt";
	public static String MENU_JOBSEARCH = "menu_jobSearch";
	
	/*Constants for User Management start here */
	public static String  HEADER_SEARCHUSER = "header_searchUser";
	public static String BTN_CREATEUSER = "btn_createUser";
	public static String BTN_GO = "btn_go";
	public static String TXTBOX_USERNAME = "txtBox_userName";
	public static String TXTBOX_FIRSTNAME = "txtBox_firstName";
	public static String TXTBOX_LASTNAME = "txtBox_lastName";
	public static String SELECT_ROLE = "select_role";
	public static String  SELECT_STATUS = "select_status";
	public static String NAME = "name";
	public static String TABLE_USER = "table_user";
	public static String TABLE_USER_HDR_1 = "table_user_header1";
	public static String TABLE_USER_HDR_2 = "table_user_header2";
	public static String TABLE_USER_HDR_3 = "table_user_header3";
	public static String TABLE_USER_HDR_4 = "table_user_header4";
	public static String TABLE_USER_HDR_5 = "table_user_header5";
	public static String TABLE_USER_HDR_6 = "table_user_header6";
	public static String TABLE_USER_HDR_7 = "table_user_header7";
	public static String TABLE_USER_HDR_8 = "table_user_header8";
	public static String BTN_DELETE = "btn_delete";
	public static String BTN_PREVIOUS = "btn_previous";
	public static String BTN_NEXT = "btn_next";
	public static String SORTING_ASC = "sorting_asc";
	public static String SORTING_DESC = "sorting_desc";
	
	public static String VALID_USERNAME = "valid_userName";
	public static String VALID_FIRSTNAME = "valid_firstName";
	public static String VALID_LASTNAME = "valid_lastName";
	public static String VALID_PRIMARYROLE = "valid_primaryRole";
	public static String VALID_STATUS = "valid_status";
	
	public static String RESULT_USERNAME = "result_userName";
	public static String RESULT_FIRSTNAME = "result_firstName";
	public static String RESULT_LASTNAME = "result_lastName";
	public static String RESULT_PRIMARYROLE = "result_primaryRole";
	public static String RESULT_STATUS = "result_status";
	
	public static String USERNAME_HYPERLINK = "username_hyperlink";
	public static String BTN_CANCEL = "btn_cancel";
	public static String POPUP_HEADER = "popup_header";
	public static String EDIT = "Edit";
	public static String ANCHOR_TAGNAME = "a";
	public static String DATA_FIRSTNAME = "data_firstname";
	public static String PAGINATION_INFO = "pagination_info";
	public static String ROWSPERPAGE_DROPDOWN = "rowsPerPage_dropdown";
	public static String ROWSPERPAGE_SELECTED = "rowsPerPage_selected";

	public static String POPUP_EDITUSER = "popup_editUser";
	public static String POPUP_USERNAME = "popup_txtBox_userName";
	public static String POPUP_FIRSTNAME = "popup_txtBox_firstName";
	public static String POPUP_LASTNAME = "popup_txtBox_lastName";
	public static String POPUP_ROLES = "popup_dropdown_roles";
	public static String POPUP_PRIMARYROLE = "popup_dropdown_primaryRole";
	public static String POPUP_STATUS = "popup_dropdown_status";
	public static String POPUP_CANCEL = "popup_btn_cancel";
	public static String POPUP_SELECTED_ROLES =  "popup_multiSelect_roles";
	
	public static String ACTIVE = "Active";
	public static String INACTIVE = "Inactive";
	
	public static String TABLE_COL_STATUS = "table_col_status";
	public static String FORM_SEARCH_USER = "form_search_user";
	public static String BTN_RESET_PWD = "btn_reset_password";
	public static String POPUP_RESETPWD = "popup_resetpassword";
	public static String POPUP_RESETPWD_OK = "popup_resetpassword_btn_ok";
	public static String POPUP_CLOSE = "popup_btn_close";
	
	public static String FORM_CREATEUSER = "form_createUser";
	public static String INVALID_USERNAME1 = "invalid_userName1";
	public static String INVALID_USERNAME2 = "invalid_userName2";
	public static String ERRMSG_CREATEUSER_UNAME = "errmsg_createUser_userName";
	public static String VALID_USERNAME1 = "valid_userName1";
	public static String BTN_CREATE = "btn_create";
	
	public static String  CREATE_USERNAME = "createpopup_txtbox_userName";
	public static String  CREATE_FIRSTNAME = "createpopup_txtbox_firstName";
	public static String  CREATE_LASTNAME = "createpopup_txtbox_lastName";
	public static String CREATE_POPUP_EMAIL = "popup_txtbox_email";
	public static String CREATE_POPUP_ROLE_ADMIN = "createpopup_role_admin";
	public static String CREATE_POPUP_BTN_OK = "createpopup_errmsg_btn_ok";
	
	public static String 	FIRST_NAME = "firstName";
	public static String LAST_NAME = "lastName";
	public static String EMAIL = "email";
	public static String CREATE_USER_SUCCESS = "createpopup_success_msg_div";
	public static String CREATE_USER_SUCCESS_MSG = "createUserSuccessMsg";
	public static String CREATE_POPUP_SUCCESSMSG_BTN_OK = "createpopup_successmsg_btn_ok";
	public static String CREATE_POPUP_BTN_CANCEL = "createpopup_btn_cancel";
	
	public static String DELETE_CONFIRM_MSG = "delete_confirmation_msg";
	public static String BTN_CANCEL_DEL_CONFIRM = "btn_cancel_delete_confirmation";
	public static String BTN_OK_DEL_CONFIRM = "btn_ok_delete_confirmation";
	public static String DEL_SUCCESS_MSG = "user_del_success_msg";
	public static String NO_DATA_MSG = "no_data_msg";
	public static String BTN_OK_DEL_SUCCESS = "btn_ok_del_success";
	public static String ADMIN_ROLE = "adminRole";
	/*Constants for User Management end here */
	
	/*Constants for Role Management start here */
	public static String SEARCH_ROLE = "search_role";
	public static String TXTBOX_ROLENAME = "txtBox_roleName";
	public static String TXTBOX_STARTDATE = "txtBox_startDate";
	public static String TXTBOX_ENDDATE = "txtBox_endDate";
	public static String BTN_CREATEROLE = "btn_createRole";
	public static String BTN_ROLE_GO = "btn_role_go";
	
	public static String TABLE_ROLE = "table_role";
	public static String TABLE_ROLE_BODY = "table_role_body";
	public static String TABLE_ROLE_HDR_1 = "table_role_header1";
	public static String TABLE_ROLE_HDR_2 = "table_role_header2";
	public static String TABLE_ROLE_HDR_3 = "table_role_header3";
	public static String TABLE_ROLE_HDR_4 = "table_role_header4";
	public static String TABLE_ROLE_BTN_PRE = "table_role_btn_previous";
	public static String TABLE_ROLE_BTN_NEXT = "table_role_btn_next";
	public static String SORTING = "sorting";

	/*Constants for Role Management end here */
	
	

	

}
