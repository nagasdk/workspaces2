package ocpe.aut.fwk.constants;

public class CatalogConstants {
	//constants for customer and catalog tabs.
		public static String CATALOG_PROPERTIES= "src/ocpe/aut/fwk/resources/catalog.properties";
		public static String CATALOG_TAB = "CatalogTab";
		public static String CATALOG_SCRIPT_NAME = "Catalog";
		public static String CATALOG = "catalog";
		public static String CATALOG_TAB_NAME = "Catalog";
		public static String TAB_CATALOG = "tab_catalog";
		public static String MENU_DEFAULT = "menu_default";
		public static String LEFTMENUITEM_1 = "leftmenuItem1";
		public static String LEFTMENUITEM_2 = "leftmenuItem2";
		public static String LEFTMENUITEM_3 = "leftmenuItem3";
		public static String SEARCHSECTION_TITLE = "searchsection_title";
		public static String TITLE = "searchTitle";
		public static String PRODUCTOVERVIEW = "productOverview";
		public static String PRODUCTANALYTICS = "productAnalytics";
		public static String PRODUCTRECOMMENDATIONS = "productRecommendations";
		public static String ANCHOR_TAG = "a";
		public static String SLIDECOLOR = "slideColor";
		public static String SLIDECOLORCLASS = "activeSpan";
		public static String HOVERCSSCLASS = "leftMenuHoverClass";
		public static String CLICKBGCSSCLASS = "BgOnClickCssClass";
		public static String SEARCHLABEL = "searchLabel";
		public static String SEARCHTEXTBOX = "searchTextBox";
		public static String GOBUTTON = "goButton";
		public static String SEARCHLABLETEXT = "productId";
		public static String SEARCHLABLETEXT_BRANDID = "brandId";
		public static String SEARCHLABLETEXT_KEYWORD = "keyword";
		public static String VALIDPRODUCTID = "validProductId";
		public static String VALIDCUSTOMERID = "validCustomerId";
		public static String INVALIDPRODUCTID = "invalidProductId";
		public static String SCREENTITLE = "screenTitle";
		public static String ERRORMESSAGE_INVALIDID = "errorMessage_invalid";
		public static String ERRORMESSAGE_BLANK = "errorMessage_blank";
		public static String ERRORMESSAGE_BLANK_KEYWORDS = "errorMessage_blank_keywords";
		public static String ERRORMESSAGE_INVALID_BRAND = "errorMessage_invalid_brand";
		public static String ERRORMESSAGE_INVALID_CUSTOMER = "errorMessage_invalid_customer";
		public static String ALERT = "alert";
		public static String ALERTBUTTON ="alertButtonClass";
		public static String SPECIALCHARACTER = "!";
		public static String ERRORMESSAGE_TEXTBOXINPUT = "errorMessage_textInput";
		public static String LABELS = "productOverViewLables";
		public static String PRODUCTOVERVIEW_VALUES = "productOverViewValues";
		public static int LABELSCOUNT = 10;
		public static String BRANDID = "brandID";
		public static String SELECTED = "selected";
		public static String DISABLED = "disabled";
		public static String CLASSATTRIBUTE = "class";
		public static String ACTIVESPAN = "leftmenu_class";
		public static String DROPDOWNATAG = "dropDownTagName";
		public static String DROPDOWNATTRIBUTE = "optionAttribute";
		public static String SEARCHLABLE_PRODUCT = "searchLabel1";
		public static String SEARCHLABLE_BRAND = "searchLabel2";
		public static String SEARCHLABLE_KEYWORDS = "searchLabel3";
		public static String VALIDBRANDID = "validBrandID";
		public static String LEFTMENUBACKGROUND = "leftmenubackground";
		public static String LEFTMENUSLIDE = "leftmenuslide";
		public static String CATALOGCUSTOMER = "catalogCustomerId";
		public static String VALUE = "value";
		public static String AGEPIECHARTTILE = "ageTitle";
		public static String GENDERPIECHARTTILE = "genderTitle";
		public static String PIECHARTTILE = "pieChartTitles";
		public static String CHARTTILECOLOR = "chartTitleColor";
		public static String PIECHARTTILEWEIGHT = "chartTitleWeight";
		public static String CHARTTITLECLASS = "chartTitleCssClass";
		public static String AGEPIECHARTLEGEND = "agePieChartLegend";
		public static String GENDERPIECHARTLEGEND = "genderPieChartLegend";
		public static String SVG = "svg";
		public static String G = "g";
		public static String AGELEGENDELEMENTS = "ageLegendElements";
		public static String GENDERLEGENDELEMENTS = "genderLegendElements";
		public static String AGEPIECHARTVALUES = "agePieChartValues";
		public static String GENDERPIECHARTVALUES = "genderPieChartValues";
		public static String CUSTOMERIDLABEL = "customerIdLabel";
		public static String PLACEHOLDER = "placeholder";
		public static String TYPE = "type";
		public static String AGECHARTHOVER = "agechartHover";
		public static String GENDERCHARTHOVER = "genderchartHover";
		public static String HOVERATTRIBUTE = "name";
		public static String AGEPIECHART = "agePieChart";
		public static String GENDERPIECHART = "genderPieChart";
		
		public static String PRODUCTRECOMMENDATIONSLIST = "productRecommendations";
		public static String SUGGESTEDITEMS = "Suggested Items";
		public static String ALSOVIEWED = "Also Viewed";
		public static String BOUGHTTOGETHER = "Bought Together Items";
		public static String SIMILARPRODUCTS = "Similar Products";
		public static String VISUALLYSIMILAR = "Visually Similar";
		public static String COMPLEMENTARYITEMS = "ComplementaryItems_header";
		public static String PRODUCTRECOMMENDATIONSTITLE =	"recommTitle";
		
		public static String BACKGROUNDCOLOR =	"background-color";
		public static String FONT_WEIGHT =	"font-weight";
		public static String COLOR =	"color";
		public static String TITLECSS ="titleCssClass";
		public static String RECOMMENDATIONELEMENTS="recommElements";
		public static String PRODUCTNAME="productName";
		public static String OPTIONSICON="optionsIcon";
		public static String STRATEGYPIECHARTTILE="strategyTitle";
		public static String STRATEGYLEGEND="strategyLegend";
		public static String STRATEGYLEGENDELEMENTS="strategyLegendElements";
		public static String USERPIECHARTTILE="userChartTitle";
		public static String USERLEGEND="userChartLegend";
		public static String USERLEGENDELEMENTS="userLegendElements";
		public static String RECOMMENDATIONSPAGE="recommendationspage";
		
		
		//hbase constants
		
		public static String PRODUCTINSIGHT = "PRODUCT_INSIGHT";
		public static String PRODUCTDETAILS = "PRODUCT_DETAILS";
		public static String CATEGORY_NAME = "CATEGORY_NAME";
		public static String AGE = "AGE";
		public static String PRODUCT_NAME = "PRODUCT_NAME";
		public static String SUB_CATEGORY_NAME = "SUB_CATEGORY_NAME";
		public static String BRAND_NAME = "BRAND_NAME";
		public static String SALE_PRICE = "SALE_PRICE";
		public static String VERTICAL_NAME = "VERTICAL_NAME";
		public static String GENDER = "GENDER";
		public static String NORM_PRICE = "NORM_PRICE_01";
		public static String VERTICALCODE = "VERTICAL";
		public static String CATEGORYCODE = "CATEGORY";
		public static String SUBCATEGORYCODE = "SUB_CATEGORY";
		public static String BRANDCODE = "BRAND_ID";
		public static String SUGGESTEDFORYOUFAMILTY = "SUGGESTED_FOR_YOU";
		public static String ALSOVIEWEDFAMILY= "ALSO_VIEWED_01";
		public static String SIMILARPRODUCTSFAMILTY = "SIMILAR_PRODUCTS_01";
		public static String BOUGHTTOGETHERFAMILY = "BOUGHT_TOGETHER_01";
		public static String VISUALLYSIMILARFAMILTY = "VISUAL_SIMILAR_ITEMS";
		public static String STRATEGY_CONFIGURATION="STRATEGY_CONFIGURATION";
		public static String PARAMETER_DETAILSFAMILY="PARAMETER_DETAILS";
		public static String ROWKEY_STRAT1006="STRAT1006";
		public static final String NEWLINE_SPCLChar="\\N";
		
		public static String OPTIONSDROPDOWN ="optionsDropDown";
		public static String TRACESECTION ="traceSection";
		public static String TRACE ="Trace";
		public static String TRACESECTIONHEADER="traceSectionHeader";
		public static String BACKBUTTON="backButtonTrace";
		public static String BACKCSS ="backbuttoncss";
		public static String BACKBUTTONCOLOR ="backButtonColor";
		public static String BACKBUTTONBGCOLOR ="backButtonbgColor";
		public static String STRATEGYCHARTHOVER ="strategyChartHover";
		public static String USERCHARTHOVER ="userChartHover";
		public static String TRACEPIECHARTITLES ="tracePieChartTitles";
		
		
		public static String DERIVEDINFO = "DERIVED_INFO";
		public static String PH_ANALYTICS = "PH_ANALYTICS";
		public static String DIMENSIONS = "dimensions";
		public static String GLOBALMAP = "globalMap";
		
		
		public static int MAXVERSIONS = 1;
}
