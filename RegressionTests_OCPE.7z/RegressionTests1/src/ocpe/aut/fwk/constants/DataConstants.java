package ocpe.aut.fwk.constants;

public class DataConstants {
	//THIS SECTION HAS CONSTANTS FOR DATA TAB
		public static String DATA_TAB_NAME = "Data";
		public static String TAB_DATA = "tab_data";
		public static String MENU_CUSTOMERS = "menu_customers";
		public static String MENU_CATALOG = "menu_catalog";
		public static String MENU_ACTIVITIES ="menu_activities";
		public static String MENU_SCRIBE ="menu_scribe";
		public static String SIDEMENU ="sidemenu";
		public static String CUSTOMERS_SECTIONS= "customers_sections";
		public static String CUSTOMER_DISTRIBUTION ="customer_distribution";
		public static String FUNNEL_ID = "funnel_id";
		public static String AREA_CHART_LEGEND = "area_chart_legend";
		public static String CHART= "chart";
		public static String PARENT_GROOVE = "parent_groove";
		public static String NEW_HEADER = "new_header";
		public static String CUSTOMER_DISTRIBUTION_XPATh ="customer_distribution_xpath";
		public static String CHANNELVIEW_LEGEND = "channelview_legend";
		public static String SIDEMENU_CATALOG ="sidemenu_catalog";
		public static String SIDEMENU_ACTIVITIES = "sidemenu_activities";
		public static String SIDEMENU_SCRIBE = "sidemenu_scribe";
		public static String GROOVE_HEADER = "groove_header";
		public static String ACTIVITY_DISTRIBUTION_CUSTOMER = "activity_dist_customer";
		public static String ACTIVITY_DISTIRBUTION_ACTIVITY = "activity_dist_activity";
		public static String FROM_DATE = "from_date";
		public static String TO_DATE = "to_date";
		public static String VALID_FROM_DATE = "valid_frmdate";
		public static String VALID_TO_DATE = "valid_todate";
		public static String GO = "submit_date";
		public static String SCRIBE_OVERVIEW_SECTIONS = "scribe_overview_sections";
		public static String TAB_CONTENT ="tab_content";
		public static String GRID_PAGE = "grid_page";
		public static String CSS_TABS ="css_tabs";
		public static String OUTLINE = "overview_tab";
		public static String SHELFWISE = "shelfwise_tab";
		public static String DEFAULT_TAB = "default_tab";
		public static String INVALID_FROM_DATE = "invalid_frmdate";
		public static String INVALID_TO_DATE = "invalid_todate";
		public static String TABLE_CONTAINER = "table_container";
		public static String AVG_ANONYMOUS = "avg_anonymous";
		public static String AVG_REGISTERED = "avg_registered";
		public static String AVERAGE_CLICKS_TABLE = "average_clicks_table";
		public static String GROOVE = "groove";
		public static String PARENT_GROOVE_INNER_DIV = "parentGrooveInnerDiv";
		public static String STRATEGY_DETAILS_HEADER = "strategy_details_header";
		public static String SFU_CHARTBOARD = "sfu_chartboard";
		public static String TP_CHARTBOARD = "tp_chartboard";
		public static String SFULink = "sfulink";
		public static String TPLink = "tplink";

}
