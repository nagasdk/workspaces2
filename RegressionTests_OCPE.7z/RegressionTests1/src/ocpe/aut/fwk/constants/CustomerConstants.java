package ocpe.aut.fwk.constants;

public class CustomerConstants {

	public static String CUSTOMER_PROPERTIES = "src/ocpe/aut/fwk/resources/customer.properties";
	public static String CUSTOMER_TAB = "CustomerTab";
	public static String CUSTOMER_SCRIPT_NAME = "Customer";
	public static String TAB_CUSTOMER = "tab_customer";
	public static String CUSTOMER_TAB_NAME = "Customer";
	public static String CUSTOMER = "customer";
	public static String SEARCH_SECTION_TITLE = "customerSearchSection_title";
	public static String MENU_DEFAULT = "menu_default";
	public static String LEFTMENUITEM_1 = "leftmenu_Item1";
	public static String LEFTMENUITEM_2 = "leftmenu_Item2";
	public static String LEFTMENUITEM_3 = "leftmenu_Item3";

	public static String LEFTMENUITEM_4 = "leftmenu_Item4";
	public static String LEFTMENUITEM_5 = "leftmenu_Item5";
	public static String LEFTMENUITEM_6 = "leftmenu_Item6";
	public static String LEFTMENUITEM_7 = "leftmenu_Item7";
	
	public static String SUMMARY = "customerSummary";
	public static String CUSTOMER_ANALYTICS = "customerAnalytics";
	public static String RECOMMENDATIONS = "customerRecommendations";
	public static String PURCHASED = "Purchased";
	public static String BROWSED = "Browsed";
	public static String EMAIL = "Email";
	public static String SOCIAL = "Social";
	
	public static String VIEWED_ONLY_PRODUCTS="viewedOnlyProducts";
	public static String PURCHASED_PRODUCTS="purchasedProducts";
	public static String  RECENT_VIEWS="recentViews";
	public static String ORDER_CONFIRMATION="orderConfirmation";
	public static String ITEM_UNAVAILABLE="itemUnavailable";
	public static String PRODUCT_RECOMMENDATION="productRecommendation";
	
	public static String ANCHOR_TAG = "a";
	
	public static String SLIDECOLOR = "slideColor";
	public static String SLIDECOLORCLASS = "activeSpan";
	
	public static String CUSTOMER_SEARCH_SECTION_TITLE="searchSection_Title";
	public static String SEARCH_TITLE="searchTitle";
	
	public static String SEARCH_LABEL="searchLabel";
	public static String SERACH_LABLE_TEXT = "customerId";
	
	public static String SEARCH_TEXT_FIELD = "searchTextField";
	public static String GO_BUTTON="goButton";
	public static String VALID_CUSTOMERID="valid_CustomerId";
	public static String INVALID_CUSTOMERID="invalid_CustomerId";
	public static String RECOMMENDATIONS_NEW="New";
	public static String TITLE_RECOMMENDATIONS_NEW="New";
	public static String CUSTOMER_NOT_FOUND_PATH="customer_Not_Found";
	public static String CUSTOMER_MANDATORY_MESSAGE="customer_Mandatory";
	public static String NULL_CUSTOMER_ID="";
	public static String CUSTOMER_MANDATORY_OK="customer_Mandatory_Ok";
	public static String CUSTOMER_INVALID_FORMAT="customerId_Invalid_Format";
	public static String CUSTOMER_INVALID_FORMAT_MESSAGE="customerId_Invalid_Format_Message";
	public static String CUSTOMER_INVALID_FORMAT_OK="customerId_Invalid_Format_Ok";
	public static String CATEGORY_ANALYTICS="Category Analytics";
	public static String BRAND_ANALYTICS="Brand Analytics";
	public static String PRICE_ANALYTICS="Price Analytics";
	public static String AGE_ANALYTICS="Age Analytics";
	public static String GENDER_ANALYTICS="Gender Analytics";
	public static String MONETARY_ANALYTICS="Monetary Analytics";
	public static String CATEGORY_ANALYTICS_ZOOM="category_Analytics_Zoom";
	public static String BRAND_ANALYTICS_ZOOM="brand_Analytics_Zoom";
	public static String ZOOM="Zoom";
	
	
	public static String CATEGORY_ANALYTICS_XPATH="category_Analytics";
	public static String BRAND_ANALYTICS_XPATH="Brand Analytics";
	public static String PRICE_ANALYTICS_XPATH="Price Analytics";
	public static String AGE_ANALYTICS_XPATH="Age Analytics";
	public static String GENDER_ANALYTICS_XPATH="Gender Analytics";
	public static String MONETARY_ANALYTICS_XPATH="Monetary Analytics";
	
	public static String ANALYTICS_CHART_TITLE_CLASS="analytics_Chart_Title_Class";
	public static String ANALYTICS_TITLE_BG_COLOR="analytics_Chart_Title_BGColor";
	public static String ANALYTICS_TITLE_FONT_COLOR="analytics_Chart_FontColor";
	public static String ANALYTICS_CHART_TITLE_FONTWEIGHT="analytics_Title_Font_Weight";
	
	
	
	public static String CATEGORY_ANALYTICS_PIECHART="category_Analytics_PieChart";
	public static String BRAND_ANALYTICS_PIECHART="brand_Analytics_PieChart";
	public static String PRICE_ANALYTICS_PIECHART="price_Analytics_PieChart";
	public static String AGE_ANALYTICS_PIECHART="age_Analytics_PieChart";
	public static String GENDER_ANALYTICS_PIECHART="gender_Analytics_PieChart";
	public static String MONETARY_ANALYTICS_PIECHART="monetary_Analytics_PieChart";

	
	public static String ANALYTICS_ZOOM="analytics_Zoom";
	public static String ZOOM1="zoom1";
	public static String ZOOM2="zoom2";
	public static String ANALYTICS_ZOOM_HEADER_XPATH="analytics_Zoom_Header";
	
	public static String CLOSE="close";
	
	public static String TOP_PICKS_RECOMMENDATIONS="top_Picks_Recommendations";
	public static String TOP_OFFERS_RECOMMENDATIONS="top_Offers_Recommendations";
	public static String NEW_ARRIVALS_FOR_YOU_RECOMMENDATIONS="new_Arrivals_For_You_Recommendations";
	public static String RECOMMENDED_BRANDS_FOR_YOU="recommended_For_You_Recommendations";
	public static String SUGGESSTED_FOR_YOU_RECOMMENDATIONS="suggessted_For_You_Recommendations";
	public static String BEST_SELLERS_RECOMMENDATIONS="best_Sellers_Recommendations";
	public static String RECOMMENDED_BRANDS_RECOMMENDATIONS="recommended_Brands_Recommendations";
	public static String BEST_SELLERS_IN_CITY_RECOMMENDATIONS="best_Sellers_In_City_Recommendations";
	public static String REPLENISHMENT_RECOMMENDATIONS="replenishment_Recommendations";

	public static String TOP_PICKS_HEADER="top_Picks_Header";
	public static String NEW_ARRIVALS_HEADER="new_Arrivals_For_You_Header";
	public static String TOP_OFFERS_HEADER="top_Offers_Header";
	public static String RECOMMENDED_FOR_YOU_HEADER="recommended_For_You_Header";
	public static String SUGGESSTED_FOR_YOU_HEADER="suggessted_For_You_Header";
	public static String BEST_SELLERS_HEADER="best_Sellers_Header";
	public static String RECOMMEDED_BRANDS_HEADER="recommended_Brands_Header";
	public static String BEST_SELLERS_IN_CITY_HEADER="best_Sellers_In_City_Header";
	public static String REPLENISHMENT_HEADER="replenishment_Header";
	public static String PURCHASED_PRODUCTS_HEADER="purchased_Products_Header";
	public static String PURCHASED_PRODUCTS_CSS="purchased_Products_CSS";

	public static String VIEWED_ONLY_LINK="viewed_Only_Link";
	public static String RECENT_VIEWS_LINK="recent_Views_Link";
	
	public static String VIEWED_ONLY_HEADER="viewed_Only_Products_Header";
	public static String RECENT_VIEWS_HEADER="recent_Views_Header";
	public static String PURCHASED_PRODUCTS_LEFT="purchased_Products_Left_Arrow";
	public static String PURCHASED_PRODUCTS_RIGHT="purchased_Products_Right_Arrow";
	public static String PURCHASED_PRODUCTS_ALL="purchased_Products_AllItems";

	public static String ORDER_CONFIRMATION_XPATH="order_Confirmation_Header";
	public static String ITEM_UNAVAILABLE_XPATH="item_Unavaialble_Header";
	public static String EMAIL_PRODUCT_RECOMMENDATION_XPATH="product_Recommendation_Header";
	public static String TAG_7="tag_7";
	public static String DISABLED="disabled";
	public static String CLASS="class";
	public static String ANA_HEADER="ana_Header";
	public static String SVG="svg";
	public static String B="b";
	public static String IFRAME="iframe";
	public static String SCROLL="scrolling";
	public static String YES="yes";
	public static String H2="h2";
	public static String LIKE="like";
	public static String QUESTIONS="Questions?";
	public static String RECOMMENDATIONS_STRING="Recommendations";
	public static String ORDER_STATUS_STRING="Your order has been confirmed.";
	public static String SUGGESTED_FOR_YOU_STRING="Suggested For You:";
	public static String ORDER_CONF_HEADER="order_Conf_Header";
	
	public static String TOP_PICKS_PRODUCT_NAMES="top_Picks_ProductNames";
	public static String TOP_PICKS_PRODUCT_IDS="top_Picks_ProductIds";

	public static String NEW_ARRIVALS_FOR_YOU_PRODUCT_NAMES="new_Arrivals_For_you_ProductNames";
	public static String NEW_ARRIVALS_FOR_YOU_PRODUCT_IDS="new_Arrivals_For_you_ProductIds";
	
	public static String USER_STRATEGIES_TABLE="USER_STRATEGIES";
	public static String STRATEGIES_CF="STRATEGIES";
	//Column Qualifier for Top Picks Recommendations Carousel
	public static String S1_CQ="S1";
	public static String S2_CQ="S2";
	public static String PRODUCT_INSIGHT_TABLE="PRODUCT_INSIGHT";
	public static String PRODUCT_DETAILS_CF="PRODUCT_DETAILS";
	public static String PRODUCT_NAME_CQ="PRODUCT_NAME";
	
	public static String CUSTOMER_INSIGHT_TABLE="CUSTOMER_INSIGHT";
	public static String DERIVED_INFO_CF="DERIVED_INFO";
	public static String PH_ANALYTICS_CQ="PH_ANALYTICS";
	
	public static String CATEGORY_ANALYTICS_LEGEND="category_Analytics_Legend";
	
	public static String CATEGORY_INSIGHT_TABLE="CATEGORY_INSIGHT";
	public static String CATEGORY_INFO_CF="CATEGORY_INFO";
	public static String DESC_CQ="desc";
	public static String SUPPLIER_CODE_MAPPING_TABLE="SUPPLIER_CODE_MAPPING";
	public static String DESCRIPTION_CF="DESCRIPTION";
	public static String BRAND_NAME_CQ="brand_name";
	
	
	public static String BRAND_ANALYTICS_LEGEND="brand_Analytics_Legend";
	public static String PRICE_ANALYTICS_LEGEND="price_Analytics_Legend";
	public static String AGE_ANALYTICS_LEGEND="age_Analytics_Legend";
	public static String GENDER_ANALYTICS_LEGEND="gender_Analytics_Legend";
	public static String MONETARY_ANALYTICS_LEGEND="monetary_Analytics_Legend";
	
	public static String RECENT_PURCHASES_PIDS="recent_Purchases_ProductIds";
}
