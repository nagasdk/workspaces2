package ocpe.aut.fwk.constants;

public interface APITabConstants {

	public static final String IFRAME_SERVICES_API = "iframe_services_api";
	public static final String IFRAME_SERVICES_HEADER_ANCHOR = "iframe_header_anchor";
	
	public static final String LINK_PRODUCTS = "link_products";
	public static final String LINK_USERS = "link_users";
	public static final String LINK_STRATEGY = "link_strategy";
	public static final String LINK_SEARCH = "link_search";
	public static final String LINK_CLUSTERS = "link_clusters";
	public static final String LINK_CONFIGURATION = "link_configuration";
	
	public static final String PRODUCTS_GET_PRODUCT_DETAILS_BUTTON = "get_productDetails_button";
	public static final String PRODUCTS_GET_PRODUCT_DETAILS_ANCHOR = "get_productDetails_anchor";
	public static final String PRODUCTS_GET_PRODUCT_DETAILS_PRODUCTID = "get_productDetails_productId";
	public static final String PRODUCTS_GET_PRODUCT_DETAILS_TRYITOUT = "get_productDetails_tryItOut";
	public static final String PRODUCTS_GET_PRODUCT_DETAILS_RESPONSE = "get_productDetails_response";

	public static final String PRODUCTS_GET_SUGGESTED_ITEMS_BUTTON = "get_suggestedItems_button";
	public static final String PRODUCTS_GET_SUGGESTED_ITEMS_ANCHOR = "get_suggestedItems_anchor";
	public static final String PRODUCTS_GET_SUGGESTED_ITEMS_PRODUCTID = "get_suggestedItems_productId";
	public static final String PRODUCTS_GET_SUGGESTED_ITEMS_USERID = "get_suggestedItems_userId";
	public static final String PRODUCTS_GET_SUGGESTED_ITEMS_MODE = "get_suggestedItems_mode";
	public static final String PRODUCTS_GET_SUGGESTED_ITEMS_LIMIT = "get_suggestedItems_limit";
	public static final String PRODUCTS_GET_SUGGESTED_ITEMS_CHANNEL = "get_suggestedItems_channel";
	public static final String PRODUCTS_GET_SUGGESTED_ITEMS_TRYITOUT = "get_suggestedItems_tryItOut";
	public static final String PRODUCTS_GET_SUGGESTED_ITEMS_RESPONSE = "get_suggestedItems_response";

	public static final String PRODUCTS_GET_PRODUCT_ANALYTICS_BUTTON = "get_productAnalytics_button";
	public static final String PRODUCTS_GET_PRODUCT_ANALYTICS_ANCHOR = "get_productAnalytics_anchor";
	public static final String PRODUCTS_GET_PRODUCT_ANALYTICS_PRODUCTID = "get_productAnalytics_productId";
	public static final String PRODUCTS_GET_PRODUCT_ANALYTICS_MODE = "get_productAnalytics_mode";
	public static final String PRODUCTS_GET_PRODUCT_ANALYTICS_TRYITOUT = "get_productAnalytics_tryItOut";
	public static final String PRODUCTS_GET_PRODUCT_ANALYTICS_RESPONSE = "get_productAnalytics_response";

	public static final String PRODUCTS_GET_PROMOTIONS_BUTTON = "get_promotions_button";
	public static final String PRODUCTS_GET_PROMOTIONS_ANCHOR = "get_promotions_anchor";
	public static final String PRODUCTS_GET_PROMOTIONS_PARTNUMBER = "get_promotions_partNumber";
	public static final String PRODUCTS_GET_PROMOTIONS_MODE = "get_promotions_mode";
	public static final String PRODUCTS_GET_PROMOTIONS_LIMIT = "get_promotions_limit";
	public static final String PRODUCTS_GET_PROMOTIONS_CHANNEL = "get_promotions_channel";
	public static final String PRODUCTS_GET_PROMOTIONS_TRYITOUT = "get_promotions_tryItOut";
	public static final String PRODUCTS_GET_PROMOTIONS_RESPONSE = "get_promotions_response";
	
	public static final String PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_BUTTON = "get_boughtTogetherItems_button";
	public static final String PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_ANCHOR = "get_boughtTogetherItems_anchor";
	public static final String PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_PRODUCTID = "get_boughtTogetherItems_productId";
	public static final String PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_MODE = "get_boughtTogetherItems_mode";
	public static final String PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_LIMIT = "get_boughtTogetherItems_limit";
	public static final String PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_CHANNEL = "get_boughtTogetherItems_channel";
	public static final String PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_TRYITOUT = "get_boughtTogetherItems_tryItOut";
	public static final String PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_RESPONSE = "get_boughtTogetherItems_response";

	public static final String PRODUCTS_GET_OPEN_COMMERCE_DATA_BUTTON = "get_openCommerceData_button";
	public static final String PRODUCTS_GET_OPEN_COMMERCE_DATA_ANCHOR = "get_openCommerceData_anchor";
	public static final String PRODUCTS_GET_OPEN_COMMERCE_DATA_QUERY = "get_openCommerceData_query";
	public static final String PRODUCTS_GET_OPEN_COMMERCE_DATA_CUSTOMERID = "get_openCommerceData_customerId";
	public static final String PRODUCTS_GET_OPEN_COMMERCE_DATA_MODE = "get_openCommerceData_mode";
	public static final String PRODUCTS_GET_OPEN_COMMERCE_DATA_LIMIT = "get_openCommerceData_limit";
	public static final String PRODUCTS_GET_OPEN_COMMERCE_DATA_CHANNEL = "get_openCommerceData_channel";
	public static final String PRODUCTS_GET_OPEN_COMMERCE_DATA_TRYITOUT = "get_openCommerceData_tryItOut";
	public static final String PRODUCTS_GET_OPEN_COMMERCE_DATA_RESPONSE = "get_openCommerceData_response";

	public static final String PRODUCTS_GET_ALSO_VIEWED_ITEMS_BUTTON = "get_alsoViewedItems_button";
	public static final String PRODUCTS_GET_ALSO_VIEWED_ITEMS_ANCHOR = "get_alsoViewedItems_anchor";
	public static final String PRODUCTS_GET_ALSO_VIEWED_ITEMS_PRODUCTID = "get_alsoViewedItems_productId";
	public static final String PRODUCTS_GET_ALSO_VIEWED_ITEMS_MODE = "get_alsoViewedItems_mode";
	public static final String PRODUCTS_GET_ALSO_VIEWED_ITEMS_LIMIT = "get_alsoViewedItems_limit";
	public static final String PRODUCTS_GET_ALSO_VIEWED_ITEMS_CHANNEL = "get_alsoViewedItems_channel";
	public static final String PRODUCTS_GET_ALSO_VIEWED_ITEMS_TRYITOUT = "get_alsoViewedItems_tryItOut";
	public static final String PRODUCTS_GET_ALSO_VIEWED_ITEMS_RESPONSE = "get_alsoViewedItems_response";

	public static final String PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_BUTTON = "get_ultimatelyBoughtItems_button";
	public static final String PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_ANCHOR = "get_ultimatelyBoughtItems_anchor";
	public static final String PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_PRODUCTID = "get_ultimatelyBoughtItems_productId";
	public static final String PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_MODE = "get_ultimatelyBoughtItems_mode";
	public static final String PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_LIMIT = "get_ultimatelyBoughtItems_limit";
	public static final String PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_CHANNEL = "get_ultimatelyBoughtItems_channel";
	public static final String PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_TRYITOUT = "get_ultimatelyBoughtItems_tryItOut";
	public static final String PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_RESPONSE = "get_ultimatelyBoughtItems_response";

	public static final String PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_BUTTON = "get_completeTheLookItems_button";
	public static final String PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_ANCHOR = "get_completeTheLookItems_anchor";
	public static final String PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_PRODUCTID = "get_completeTheLookItems_productId";
	public static final String PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_MODE = "get_completeTheLookItems_mode";
	public static final String PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_LIMIT = "get_completeTheLookItems_limit";
	public static final String PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_CHANNEL = "get_completeTheLookItems_channel";
	public static final String PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_TRYITOUT = "get_completeTheLookItems_tryItOut";
	public static final String PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_RESPONSE = "get_completeTheLookItems_response";

	public static final String PRODUCTS_GET_SIMILAR_PRODUCTS_BUTTON = "get_similarProducts_button";
	public static final String PRODUCTS_GET_SIMILAR_PRODUCTS_ANCHOR = "get_similarProducts_anchor";
	public static final String PRODUCTS_GET_SIMILAR_PRODUCTS_PRODUCTID = "get_similarProducts_productId";
	public static final String PRODUCTS_GET_SIMILAR_PRODUCTS_MODE = "get_similarProducts_mode";
	public static final String PRODUCTS_GET_SIMILAR_PRODUCTS_LIMIT = "get_similarProducts_limit";
	public static final String PRODUCTS_GET_SIMILAR_PRODUCTS_CHANNEL = "get_similarProducts_channel";
	public static final String PRODUCTS_GET_SIMILAR_PRODUCTS_TRYITOUT = "get_similarProducts_tryItOut";
	public static final String PRODUCTS_GET_SIMILAR_PRODUCTS_RESPONSE = "get_similarProducts_response";

	public static final String PRODUCTS_GET_TOP_SELLING_ITEMS_BUTTON = "get_topSellingItems_button";
	public static final String PRODUCTS_GET_TOP_SELLING_ITEMS_ANCHOR = "get_topSellingItems_anchor";
	public static final String PRODUCTS_GET_TOP_SELLING_ITEMS_PRODUCTID = "get_topSellingItems_productId";
	public static final String PRODUCTS_GET_TOP_SELLING_ITEMS_MODE = "get_topSellingItems_mode";
	public static final String PRODUCTS_GET_TOP_SELLING_ITEMS_LIMIT = "get_topSellingItems_limit";
	public static final String PRODUCTS_GET_TOP_SELLING_ITEMS_CHANNEL = "get_topSellingItems_channel";
	public static final String PRODUCTS_GET_TOP_SELLING_ITEMS_TRYITOUT = "get_topSellingItems_tryItOut";
	public static final String PRODUCTS_GET_TOP_SELLING_ITEMS_RESPONSE = "get_topSellingItems_response";
	
	public static final String HEADER_AHAM_API_EXPLORER = "AHAM API Explorer";
	
	public static final String COMMON_SERVICES_MODE = "services.mode";
	public static final String COMMON_SERVICES_LIMIT = "services.limit";
	public static final String COMMON_SERVICES_CHANNEL = "services.channel";
	
	public static final String PRODUCT_ID_VALID = "productId.valid";
	public static final String PRODUCT_ID_INVALID = "productId.invalid";
	public static final String PRODUCT_ID_VISUAL_SIMILAR_ITEMS = "productId.visualSimilarItems";
	public static final String QUERY_OPEN_COMMERCE_DATA_VALID = "query.opencommercedata";
	public static final String QUERY_OPEN_COMMERCE_DATA_INVALID = "query.opencommercedata.invalid";
	
	public static final String RESPONSE_SUGGESTED_ITEMS = "response.suggestedItems";
	public static final String RESPONSE_VISUAL_SIMILAR_ITEMS = "response.visualSimilarItems";
	public static final String RESPONSE_PROMOTIONS = "response.promotions";
	public static final String RESPONSE_BOUGHT_TOGETHER_ITEMS = "response.boughtTogetherItems";
	public static final String RESPONSE_READ_OPEN_COMMERCE_DATA = "response.readOpenCommerceData";
	public static final String RESPONSE_ALSO_VIEWED_ITEMS = "response.alsoViewedItems";
	public static final String RESPONSE_ULTIMATELY_BOUGHT_ITEMS = "response.ultimatelyBoughtItems";
	public static final String RESPONSE_COMPLETE_THE_LOOK_ITEMS = "response.completeTheLookItems";
	public static final String RESPONSE_SIMILAR_PRODUCTS = "response.similarProducts";
	public static final String RESPONSE_TOP_SELLING_ITEMS = "response.topSellingItems";

	public static final String INPUT_USERS_ID_VALID = "users.id.valid";
	public static final String INPUT_USERS_ID_INVALID = "users.id.invalid";
	public static final String INPUT_USERS_CATALOGHIERARCHY_LEVEL = "users.catalogHierarchy.level";
	public static final String INPUT_USERS_GETPROMOTIONS_TYPE = "users.getPromotions.type";
	public static final String INPUT_USERS_GETCLUSTERRECOMMENDATIONS_TYPE = "users.getClusterRecommendations.type";
	public static final String INPUT_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID = "users.insertSocialCompareProducts.compareId";
	public static final String INPUT_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERNAME = "users.postInsertSocialCompareProducts.userName";
	public static final String INPUT_USERS_GETINTENTBASEDRECOMMENDATIONS_COUNT = "users.getIntentBasedRecommendations.count";
	public static final String INPUT_USERS_GETSUGGESTEDITEMSFORYOU_PRODUCTID = "users.getSuggestedItemsForYou.productId";
	public static final String INPUT_USERS_GETSTRATEGIESFORUSERBYSHELF_STRATEGYID = "users.getStrategiesForUserByShelf.strategyId";
	public static final String INPUT_USERS_GETPURCHASEDITEMS_USERID = "users.getPurchasedItems.userId";
	public static final String INPUT_USERS_GETVIEWEDONLYITEMS_USERID = "users.getViewedOnlyItems";
	public static final String INPUT_USERS_GETVIEWEDONLYITEMS_COLUMNFAMILY = "users.getViewedOnlyItems.columnFamily";
	public static final String INPUT_USERS_GETREPLENISHMENTRECOMMENDATIONS_USERID = "users.getReplenishmentRecommendations.userId";
	public static final String INPUT_USERS_GETREPLENISHMENTRECOMMENDATIONS_MODE = "users.getReplenishmentRecommendations.mode";
	public static final String INPUT_USERS_GETFRIENDSBIRTHDAYS_USERID = "users.getFriendsBirthdays.userId";
	public static final String INPUT_USERS_POSTAHAMFACEBOOKLOGIN_USERID = "users.postAhamFacebookLogin.userId";
	public static final String INPUT_USERS_POSTAHAMFACEBOOKLOGIN_ACCESSTOKEN = "users.postAhamFacebookLogin.accessToken";
	public static final String INPUT_USERS_GETRETURNITEMS_USERID = "users.getReturnItems.userId";
	public static final String INPUT_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_INITIATORUSERID = "users.getSocialCompareConsolidatedRatings.initiatorUserId";
	public static final String INPUT_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_COMPAREID = "users.getSocialCompareConsolidatedRatings.compareId";
	public static final String INPUT_USERS_GETGUESTUSERBROWSED_USERID = "users.getGuestUserBrowsed.userId";
	public static final String INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_USERID = "users.getStrategyRecommendationsEmail.userId";
	public static final String INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_STRATEGYID = "users.getStrategyRecommendationsEmail.strategyId";
	public static final String INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_PRODUCTS = "users.getStrategyRecommendationsEmail.products";
	public static final String INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LAYOUT = "users.getStrategyRecommendationsEmail.layout";
	public static final String INPUT_USERS_GETUSERCLUSTERINFO_USERID = "users.getUserClusterInfo.userId";
	public static final String INPUT_USERS_GETBEHAVIORFORCUSTOMER360_USERID = "users.getBehaviorForCustomer360.userId";
	public static final String INPUT_USERS_GETLOCATIONFROMIP_USERIP = "users.getLocationfromIP.userIP";
	public static final String INPUT_USERS_GETLOCATIONFROMIP_USERIP_INVALID = "users.getLocationfromIP.userIP.invalid";
	public static final String INPUT_USERS_GETMYANALYTICS_USERID = "users.getMyAnalytics.userId";
	public static final String INPUT_USERS_GETTOPCATEGORIES_USERID = "users.getTopCategories.userId";

	public static final String RESPONSE_USERS_LOCATION = "response.users.location";
	public static final String RESPONSE_USERS_CATALOGHIERARCHY = "response.users.catalogHierarchy";
	public static final String RESPONSE_USERS_GETPROMOTIONS = "response.users.getPromotions";
	public static final String RESPONSE_USERS_GETCLUSTERRECOMMENDATIONS = "response.users.getClusterRecommendations";
	public static final String RESPONSE_USERS_INSERTSOCIALCOMPAREPRODUCTS = "response.users.insertSocialCompareProducts";
	public static final String RESPONSE_USERS_INSERTSOCIALCOMPARERATINGS = "response.users.insertSocialCompareRatings";
	public static final String RESPONSE_USERS_GETSOCIALCOMPAREPRODUCTS = "response.users.getSocialCompareProducts";
	public static final String RESPONSE_USERS_GETSOCIALCOMPARERATINGS = "response.users.getSocialComparerRatings";
	public static final String RESPONSE_USERS_GETUSERDETAILS = "response.users.getUserDetails";
	public static final String RESPONSE_USERS_GETSOCIALCOMPARES = "response.users.getSocialCompares";
	public static final String RESPONSE_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS = "response.users.postInsertSocialCompareProducts";
	public static final String RESPONSE_USERS_GETSTRATEGYNAMES = "response.users.getStrategyNames";
	public static final String RESPONSE_USERS_GETSTRATEGYRECOMMENDATIONS = "response.users.getStrategyRecommendations";
	public static final String RESPONSE_USERS_GETINTENTBASEDRECOMMENDATIONS = "response.users.getIntentBasedRecommendations";
	public static final String RESPONSE_USERS_GETSUGGESTEDITEMSFORYOU = "response.users.getSuggestedItemsForYou";
	public static final String RESPONSE_USERS_GETSTRATEGIESFORUSERBYSHELF = "response.users.getStrategiesForUserByShelf";
	public static final String RESPONSE_USERS_GETPURCHASEDITEMS = "response.users.getPurchasedItems";
	public static final String RESPONSE_USERS_GETVIEWEDONLYITEMS = "response.users.getViewedOnlyItems";
	public static final String RESPONSE_USERS_GETREPLENISHMENTRECOMMENDATIONS = "response.users.getReplenishmentRecommendations";
	public static final String RESPONSE_USERS_GETFRIENDSBIRTHDAYS = "response.users.getFriendsBirthdays";
	public static final String RESPONSE_USERS_POSTAHAMFACEBOOKLOGIN = "response.users.postAhamFacebookLogin";
	public static final String RESPONSE_USERS_GETRETURNITEMS = "response.users.getReturnItems";
	public static final String RESPONSE_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS = "response.users.getSocialCompareConsolidatedRatings";
	public static final String RESPONSE_USERS_GETGUESTUSERBROWSED = "response.users.getGuestUserBrowsed";
	public static final String RESPONSE_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL = "response.users.getStrategyRecommendationsEmail";
	public static final String RESPONSE_USERS_GETUSERCLUSTERINFO = "response.users.getUserClusterInfo";
	public static final String RESPONSE_USERS_GETBEHAVIORFORCUSTOMER360 = "response.users.getBehaviorForCustomer360";
	public static final String RESPONSE_USERS_GETLOCATIONFROMIP = "response.users.getLocationfromIP";
	public static final String RESPONSE_USERS_GETTOPVIEWEDCATEGORIES = "response.users.getTopViewedCategories";
	public static final String RESPONSE_USERS_GETTOPVIEWEDSOURCES = "response.users.getTopViewedSources";
	public static final String RESPONSE_USERS_GETMYANALYTICS = "response.users.getMyAnalytics";
	public static final String RESPONSE_USERS_GETTOPCATEGORIES = "response.users.getTopCategories";
	
	public static final String INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS = "strategy.insertAlgorithmParameters.parameters";
	public static final String INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS_INVALID = "strategy.insertAlgorithmParameters.parameters.invalid";
	public static final String INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME = "strategy.insertAlgorithmParameters.algorithmName";
	public static final String INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME_INVALID = "strategy.insertAlgorithmParameters.algorithmName.invalid";
	public static final String INPUT_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME = "strategy.fetchAlgorithmParameters.algorithmName";
	public static final String INPUT_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME_INVALID = "strategy.fetchAlgorithmParameters.algorithmName.invalid";
	public static final String INPUT_STRATEGY_GETTRACEANALYTICS_PRODUCT_ID = "strategy.getTraceAnalytics.productId";
	public static final String INPUT_STRATEGY_GETTRACEANALYTICS_PRODUCT_ID_INVALID = "strategy.getTraceAnalytics.productId.invalid";
	public static final String INPUT_STRATEGY_GETTRACEANALYTICS_ALGONAME = "strategy.getTraceAnalytics.algoName";
	public static final String INPUT_STRATEGY_GETTRACEANALYTICS_ALGONAME_INVALID = "strategy.getTraceAnalytics.algoName.invalid";
	public static final String INPUT_STRATEGY_GETTRACEANALYTICS_MODE = "strategy.getTraceAnalytics.mode";
	public static final String INPUT_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME = "strategy.getStrategyAnalytics.algoName";
	public static final String INPUT_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME_INVALID = "strategy.getStrategyAnalytics.algoName.invalid";
	public static final String INPUT_STRATEGY_GETSTRATEGYANALYTICS_MODE = "strategy.getStrategyAnalytics.mode";
	public static final String INPUT_STRATEGY_GETSUMMARY_TYPE = "strategy.getSummary.type";
	public static final String INPUT_STRATEGY_GETSUMMARY_TYPE_INVALID = "strategy.getSummary.type.invalid";
	
	public static final String RESPONSE_STRATEGY_INSERTALGORITHMPARAMETERS = "response.strategy.insertAlgorithmParameters";
	public static final String RESPONSE_STRATEGY_FETCHALGORITHMPARAMETERS = "response.strategy.fetchAlgorithmParameters";
	public static final String RESPONSE_STRATEGY_GETTRACEANALYTICS = "response.strategy.getTraceAnalytics";
	public static final String RESPONSE_STRATEGY_GETSTRATEGYANALYTICS = "response.strategy.getStrategyAnalytics";
	public static final String RESPONSE_STRATEGY_GETSUMMARY = "response.strategy.getSummary";
	
	public static final String INPUT_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY = "search.getSearchedAndUltimatelyBought.searchKey";
	public static final String INPUT_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY_INVALID = "search.getSearchedAndUltimatelyBought.searchKey.invalid";
	
	public static final String RESPONSE_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT = "response.search.getSearchedAndUltimatelyBought";
	
	public static final String USERS_GET_USERS_GETLOCATION_BUTTON = "get_users_getLocation_button";
	public static final String USERS_GET_USERS_GETLOCATION_ANCHOR = "get_users_getLocation_anchor";
	public static final String USERS_GET_USERS_GETLOCATION_USERID = "get_users_getLocation_userId";
	public static final String USERS_GET_USERS_GETLOCATION_TRYITOUT = "get_users_getLocation_tryItOut";
	public static final String USERS_GET_USERS_GETLOCATION_RESPONSE = "get_users_getLocation_response";
	
	public static final String USERS_GET_USERS_GETHIERARCHY_BUTTON = "get_users_getHierarchy_button";
	public static final String USERS_GET_USERS_GETHIERARCHY_ANCHOR = "get_users_getHierarchy_anchor";
	public static final String USERS_GET_USERS_GETHIERARCHY_LEVEL = "get_users_getHierarchy_level";
	public static final String USERS_GET_USERS_GETHIERARCHY_USERID = "get_users_getHierarchy_userId";
	public static final String USERS_GET_USERS_GETHIERARCHY_MODE = "get_users_getHierarchy_mode";
	public static final String USERS_GET_USERS_GETHIERARCHY_TRYITOUT = "get_users_getHierarchy_tryItOut";
	public static final String USERS_GET_USERS_GETHIERARCHY_RESPONSE = "get_users_getHierarchy_response";
	
	public static final String USERS_POST_USERS_GETPROMOTIONS_BUTTON = "post_users_getPromotions_button";
	public static final String USERS_POST_USERS_GETPROMOTIONS_ANCHOR = "post_users_getPromotions_anchor";
	public static final String USERS_POST_USERS_GETPROMOTIONS_TYPE = "post_users_getPromotions_type";
	public static final String USERS_POST_USERS_GETPROMOTIONS_USERID = "post_users_getPromotions_userId";
	public static final String USERS_POST_USERS_GETPROMOTIONS_MODE = "post_users_getPromotions_mode";
	public static final String USERS_POST_USERS_GETPROMOTIONS_TRYITOUT = "post_users_getPromotions_tryItOut";
	public static final String USERS_POST_USERS_GETPROMOTIONS_RESPONSE = "post_users_getPromotions_response";
	
	public static final String USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_BUTTON = "get_users_getClusterRecommendations_button";
	public static final String USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_ANCHOR = "get_users_getClusterRecommendations_anchor";
	public static final String USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_CUSTOMERID = "get_users_getClusterRecommendations_customerId";
	public static final String USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_TYPE = "get_users_getClusterRecommendations_type";
	public static final String USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_MODE = "get_users_getClusterRecommendations_mode";
	public static final String USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_LIMIT = "get_users_getClusterRecommendations_limit";
	public static final String USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_CHANNEL = "get_users_getClusterRecommendations_channel";
	public static final String USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_TRYITOUT = "get_users_getClusterRecommendations_tryItOut";
	public static final String USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_RESPONSE = "get_users_getClusterRecommendations_response";
	
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_BUTTON = "post_users_insertSocialCompareProducts_button";
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_ANCHOR = "post_users_insertSocialCompareProducts_anchor";
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_USERID = "post_users_insertSocialCompareProducts_userId";
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID = "post_users_insertSocialCompareProducts_compareId";
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_TRYITOUT = "post_users_insertSocialCompareProducts_tryItOut";
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_RESPONSE = "post_users_insertSocialCompareProducts_response";
	
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_BUTTON = "post_users_insertSocialCompareRatings_button";
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_ANCHOR = "post_users_insertSocialCompareRatings_anchor";
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_USERID = "post_users_insertSocialCompareRatings_userId";
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_COMPAREID = "post_users_insertSocialCompareRatings_compareId";
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_MODE = "post_users_insertSocialCompareRatings_mode";
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_TRYITOUT = "post_users_insertSocialCompareRatings_tryItOut";
	public static final String USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_RESPONSE = "post_users_insertSocialCompareRatings_response";
	
	public static final String USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_BUTTON = "get_users_getSocialCompareProducts_button";
	public static final String USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_ANCHOR = "get_users_getSocialCompareProducts_anchor";
	public static final String USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_INITIATORUSERID = "get_users_getSocialCompareProducts_initiatorUserId";
	public static final String USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_COMPAREID = "get_users_getSocialCompareProducts_compareId";
	public static final String USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_MODE = "get_users_getSocialCompareProducts_mode";
	public static final String USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_LIMIT = "get_users_getSocialCompareProducts_limit";
	public static final String USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_CHANNEL = "get_users_getSocialCompareProducts_channel";
	public static final String USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_TRYITOUT = "get_users_getSocialCompareProducts_tryItOut";
	public static final String USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_RESPONSE = "get_users_getSocialCompareProducts_response";
	
	public static final String USERS_GET_USERS_GETSOCIALCOMPARERATINGS_BUTTON = "get_users_getSocialCompareRatings_button";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARERATINGS_ANCHOR = "get_users_getSocialCompareRatings_anchor";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARERATINGS_INITIATORUSERID = "get_users_getSocialCompareRatings_initiatorUserId";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARERATINGS_COMPAREID = "get_users_getSocialCompareRatings_compareId";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARERATINGS_TRYITOUT = "get_users_getSocialCompareRatings_tryItOut";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARERATINGS_RESPONSE = "get_users_getSocialCompareRatings_response";
	
	public static final String USERS_GET_USERS_GETUSERDETAILS_BUTTON = "get_users_getUserDetails_button";
	public static final String USERS_GET_USERS_GETUSERDETAILS_ANCHOR = "get_users_getUserDetails_anchor";
	public static final String USERS_GET_USERS_GETUSERDETAILS_USERID = "get_users_getUserDetails_userId";
	public static final String USERS_GET_USERS_GETUSERDETAILS_CHANNEL = "get_users_getUserDetails_channel";
	public static final String USERS_GET_USERS_GETUSERDETAILS_TRYITOUT = "get_users_getUserDetails_tryItOut";
	public static final String USERS_GET_USERS_GETUSERDETAILS_RESPONSE = "get_users_getUserDetails_response";
	
	public static final String USERS_GET_USERS_GETSOCIALCOMPARES_BUTTON = "get_users_getSocialCompares_button";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARES_ANCHOR = "get_users_getSocialCompares_anchor";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARES_USERID = "get_users_getSocialCompares_userId";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARES_TRYITOUT = "get_users_getSocialCompares_tryItOut";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARES_RESPONSE = "get_users_getSocialCompares_response";
	
	public static final String USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_BUTTON = "post_users_postInsertSocialCompareProducts_button";
	public static final String USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_ANCHOR = "post_users_postInsertSocialCompareProducts_anchor";
	public static final String USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERID = "post_users_postInsertSocialCompareProducts_userId";
	public static final String USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERNAME = "post_users_postInsertSocialCompareProducts_userName";
	public static final String USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_TRYITOUT = "post_users_postInsertSocialCompareProducts_tryItOut";
	public static final String USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_RESPONSE = "post_users_postInsertSocialCompareProducts_response";
	
	public static final String USERS_GET_USERS_GETSTRATEGYNAMES_BUTTON = "get_users_getStrategyNames_button";
	public static final String USERS_GET_USERS_GETSTRATEGYNAMES_ANCHOR = "get_users_getStrategyNames_anchor";
	public static final String USERS_GET_USERS_GETSTRATEGYNAMES_USERID = "get_users_getStrategyNames_userId";
	public static final String USERS_GET_USERS_GETSTRATEGYNAMES_TRYITOUT = "get_users_getStrategyNames_tryItOut";
	public static final String USERS_GET_USERS_GETSTRATEGYNAMES_RESPONSE = "get_users_getStrategyNames_response";
	
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_BUTTON = "get_users_getStrategyRecommendations_button";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_ANCHOR = "get_users_getStrategyRecommendations_anchor";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_USERID = "get_users_getStrategyRecommendations_userId";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_TRYITOUT = "get_users_getStrategyRecommendations_tryItOut";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_RESPONSE = "get_users_getStrategyRecommendations_response";
	
	public static final String USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_BUTTON = "get_users_getIntentBasedRecommendations_button";
	public static final String USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_ANCHOR = "get_users_getIntentBasedRecommendations_anchor";
	public static final String USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_USERID = "get_users_getIntentBasedRecommendations_userId";
	public static final String USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_COUNT = "get_users_getIntentBasedRecommendations_count";
	public static final String USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_MODE = "get_users_getIntentBasedRecommendations_mode";
	public static final String USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_TRYITOUT = "get_users_getIntentBasedRecommendations_tryItOut";
	public static final String USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_RESPONSE = "get_users_getIntentBasedRecommendations_response";
	
	public static final String USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_BUTTON = "get_users_getSuggestedItemsForYou_button";
	public static final String USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_ANCHOR = "get_users_getSuggestedItemsForYou_anchor";
	public static final String USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_USERID = "get_users_getSuggestedItemsForYou_userId";
	public static final String USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_PRODUCTID = "get_users_getSuggestedItemsForYou_productId";
	public static final String USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_MODE = "get_users_getSuggestedItemsForYou_mode";
	public static final String USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_LIMIT = "get_users_getSuggestedItemsForYou_limit";
	public static final String USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_CHANNEL = "get_users_getSuggestedItemsForYou_channel";
	public static final String USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_TRYITOUT = "get_users_getSuggestedItemsForYou_tryItOut";
	public static final String USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_RESPONSE = "get_users_getSuggestedItemsForYou_response";
	
	public static final String USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_BUTTON = "get_users_getStrategiesForUserByShelf_button";
	public static final String USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_ANCHOR = "get_users_getStrategiesForUserByShelf_anchor";
	public static final String USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_USERID = "get_users_getStrategiesForUserByShelf_userId";
	public static final String USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_STRATEGYID = "get_users_getStrategiesForUserByShelf_strategyId";
	public static final String USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_MODE = "get_users_getStrategiesForUserByShelf_mode";
	public static final String USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_LIMIT = "get_users_getStrategiesForUserByShelf_limit";
	public static final String USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_CHANNEL = "get_users_getStrategiesForUserByShelf_channel";
	public static final String USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_TRYITOUT = "get_users_getStrategiesForUserByShelf_tryItOut";
	public static final String USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_RESPONSE = "get_users_getStrategiesForUserByShelf_response";
	
	public static final String USERS_GET_USERS_GETPURCHASEDITEMS_BUTTON = "get_users_getPurchasedItems_button";
	public static final String USERS_GET_USERS_GETPURCHASEDITEMS_ANCHOR = "get_users_getPurchasedItems_anchor";
	public static final String USERS_GET_USERS_GETPURCHASEDITEMS_USERID = "get_users_getPurchasedItems_userId";
	public static final String USERS_GET_USERS_GETPURCHASEDITEMS_MODE = "get_users_getPurchasedItems_mode";
	public static final String USERS_GET_USERS_GETPURCHASEDITEMS_LIMIT = "get_users_getPurchasedItems_limit";
	public static final String USERS_GET_USERS_GETPURCHASEDITEMS_CHANNEL = "get_users_getPurchasedItems_channel";
	public static final String USERS_GET_USERS_GETPURCHASEDITEMS_TRYITOUT = "get_users_getPurchasedItems_tryItOut";
	public static final String USERS_GET_USERS_GETPURCHASEDITEMS_RESPONSE = "get_users_getPurchasedItems_response";
	
	public static final String USERS_GET_USERS_GETVIEWEDONLYITEMS_BUTTON = "get_users_getViewedOnlyItems_button";
	public static final String USERS_GET_USERS_GETVIEWEDONLYITEMS_ANCHOR = "get_users_getViewedOnlyItems_anchor";
	public static final String USERS_GET_USERS_GETVIEWEDONLYITEMS_USERID = "get_users_getViewedOnlyItems_userId";
	public static final String USERS_GET_USERS_GETVIEWEDONLYITEMS_COLUMNFAMILY = "get_users_getViewedOnlyItems_columnFamily";
	public static final String USERS_GET_USERS_GETVIEWEDONLYITEMS_MODE = "get_users_getViewedOnlyItems_mode";
	public static final String USERS_GET_USERS_GETVIEWEDONLYITEMS_LIMIT = "get_users_getViewedOnlyItems_limit";
	public static final String USERS_GET_USERS_GETVIEWEDONLYITEMS_CHANNEL = "get_users_getViewedOnlyItems_channel";
	public static final String USERS_GET_USERS_GETVIEWEDONLYITEMS_TRYITOUT = "get_users_getViewedOnlyItems_tryItOut";
	public static final String USERS_GET_USERS_GETVIEWEDONLYITEMS_RESPONSE = "get_users_getViewedOnlyItems_response";
	
	public static final String USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_BUTTON = "get_users_getReplenishmentRecommendations_button";
	public static final String USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_ANCHOR = "get_users_getReplenishmentRecommendations_anchor";
	public static final String USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_USERID = "get_users_getReplenishmentRecommendations_userId";
	public static final String USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_MODE = "get_users_getReplenishmentRecommendations_mode";
	public static final String USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_TRYITOUT = "get_users_getReplenishmentRecommendations_tryItOut";
	public static final String USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_RESPONSE = "get_users_getReplenishmentRecommendations_response";
	
	public static final String USERS_GET_USERS_GETFRIENDSBIRTHDAYS_BUTTON = "get_users_getFriendsBirthdays_button";
	public static final String USERS_GET_USERS_GETFRIENDSBIRTHDAYS_ANCHOR = "get_users_getFriendsBirthdays_anchor";
	public static final String USERS_GET_USERS_GETFRIENDSBIRTHDAYS_USERID = "get_users_getFriendsBirthdays_userId";
	public static final String USERS_GET_USERS_GETFRIENDSBIRTHDAYS_TRYITOUT = "get_users_getFriendsBirthdays_tryItOut";
	public static final String USERS_GET_USERS_GETFRIENDSBIRTHDAYS_RESPONSE = "get_users_getFriendsBirthdays_response";
	
	public static final String USERS_POST_USERS_AHAMFACEBOOKLOGIN_BUTTON = "post_users_ahamFacebookLogin_button";
	public static final String USERS_POST_USERS_AHAMFACEBOOKLOGIN_ANCHOR = "post_users_ahamFacebookLogin_anchor";
	public static final String USERS_POST_USERS_AHAMFACEBOOKLOGIN_USERID = "post_users_ahamFacebookLogin_userId";
	public static final String USERS_POST_USERS_AHAMFACEBOOKLOGIN_ACCESSTOKEN = "post_users_ahamFacebookLogin_accessToken";
	public static final String USERS_POST_USERS_AHAMFACEBOOKLOGIN_TRYITOUT = "post_users_ahamFacebookLogin_tryItOut";
	public static final String USERS_POST_USERS_AHAMFACEBOOKLOGIN_RESPONSE = "post_users_ahamFacebookLogin_response";
	
	public static final String USERS_GET_USERS_GETRETURNITEMS_BUTTON = "get_users_getReturnItems_button";
	public static final String USERS_GET_USERS_GETRETURNITEMS_ANCHOR = "get_users_getReturnItems_anchor";
	public static final String USERS_GET_USERS_GETRETURNITEMS_USERID = "get_users_getReturnItems_userId";
	public static final String USERS_GET_USERS_GETRETURNITEMS_MODE = "get_users_getReturnItems_mode";
	public static final String USERS_GET_USERS_GETRETURNITEMS_LIMIT = "get_users_getReturnItems_limit";
	public static final String USERS_GET_USERS_GETRETURNITEMS_CHANNEL = "get_users_getReturnItems_channel";
	public static final String USERS_GET_USERS_GETRETURNITEMS_TRYITOUT = "get_users_getReturnItems_tryItOut";
	public static final String USERS_GET_USERS_GETRETURNITEMS_RESPONSE = "get_users_getReturnItems_response";
	
	public static final String USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_BUTTON = "get_users_getSocialCompareConsolidatedRatings_button";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_ANCHOR = "get_users_getSocialCompareConsolidatedRatings_anchor";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_INITIATORUSERID = "get_users_getSocialCompareConsolidatedRatings_initiatorUserId";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_COMPAREID = "get_users_getSocialCompareConsolidatedRatings_compareId";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_TRYITOUT = "get_users_getSocialCompareConsolidatedRatings_tryItOut";
	public static final String USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_RESPONSE = "get_users_getSocialCompareConsolidatedRatings_response";
	
	public static final String USERS_GET_USERS_GETGUESTUSERBROWSED_BUTTON = "get_users_getGuestUserBrowsed_button";
	public static final String USERS_GET_USERS_GETGUESTUSERBROWSED_ANCHOR = "get_users_getGuestUserBrowsed_anchor";
	public static final String USERS_GET_USERS_GETGUESTUSERBROWSED_USERID = "get_users_getGuestUserBrowsed_userId";
	public static final String USERS_GET_USERS_GETGUESTUSERBROWSED_MODE = "get_users_getGuestUserBrowsed_mode";
	public static final String USERS_GET_USERS_GETGUESTUSERBROWSED_LIMIT = "get_users_getGuestUserBrowsed_limit";
	public static final String USERS_GET_USERS_GETGUESTUSERBROWSED_CHANNEL = "get_users_getGuestUserBrowsed_channel";
	public static final String USERS_GET_USERS_GETGUESTUSERBROWSED_TRYITOUT = "get_users_getGuestUserBrowsed_tryItOut";
	public static final String USERS_GET_USERS_GETGUESTUSERBROWSED_RESPONSE = "get_users_getGuestUserBrowsed_response";
	
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_BUTTON = "get_users_getStrategyRecommendationsEmail_button";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_ANCHOR = "get_users_getStrategyRecommendationsEmail_anchor";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_USERID = "get_users_getStrategyRecommendationsEmail_userId";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_STRATEGYID = "get_users_getStrategyRecommendationsEmail_strategyId";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_MODE = "get_users_getStrategyRecommendationsEmail_mode";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LIMIT = "get_users_getStrategyRecommendationsEmail_limit";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_CHANNEL = "get_users_getStrategyRecommendationsEmail_channel";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_PRODUCTS = "get_users_getStrategyRecommendationsEmail_products";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LAYOUT = "get_users_getStrategyRecommendationsEmail_layout";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_TRYITOUT = "get_users_getStrategyRecommendationsEmail_tryItOut";
	public static final String USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_RESPONSE = "get_users_getStrategyRecommendationsEmail_response";
	
	public static final String USERS_GET_USERS_GETUSERCLUSTERINFO_BUTTON = "get_users_getUserClusterInfo_button";
	public static final String USERS_GET_USERS_GETUSERCLUSTERINFO_ANCHOR = "get_users_getUserClusterInfo_anchor";
	public static final String USERS_GET_USERS_GETUSERCLUSTERINFO_USERID = "get_users_getUserClusterInfo_userId";
	public static final String USERS_GET_USERS_GETUSERCLUSTERINFO_TRYITOUT = "get_users_getUserClusterInfo_tryItOut";
	public static final String USERS_GET_USERS_GETUSERCLUSTERINFO_RESPONSE = "get_users_getUserClusterInfo_response";
	
	public static final String USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_BUTTON = "get_users_getBehaviorForCustomer360_button";
	public static final String USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_ANCHOR = "get_users_getBehaviorForCustomer360_anchor";
	public static final String USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_USERID = "get_users_getBehaviorForCustomer360_userId";
	public static final String USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_TRYITOUT = "get_users_getBehaviorForCustomer360_tryItOut";
	public static final String USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_RESPONSE = "get_users_getBehaviorForCustomer360_response";
	
	public static final String USERS_GET_USERS_GETLOCATIONFROMIP_BUTTON = "get_users_getLocationfromIP_button";
	public static final String USERS_GET_USERS_GETLOCATIONFROMIP_ANCHOR = "get_users_getLocationfromIP_anchor";
	public static final String USERS_GET_USERS_GETLOCATIONFROMIP_USERIP = "get_users_getLocationfromIP_userIP";
	public static final String USERS_GET_USERS_GETLOCATIONFROMIP_TRYITOUT = "get_users_getLocationfromIP_tryItOut";
	public static final String USERS_GET_USERS_GETLOCATIONFROMIP_RESPONSE = "get_users_getLocationfromIP_response";
	
	public static final String USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_BUTTON = "get_users_getTopViewedCategories_button";
	public static final String USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_ANCHOR = "get_users_getTopViewedCategories_anchor";
	public static final String USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_LIMIT = "get_users_getTopViewedCategories_limit";
	public static final String USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_TRYITOUT = "get_users_getTopViewedCategories_tryItOut";
	public static final String USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_RESPONSE = "get_users_getTopViewedCategories_response";
	
	public static final String USERS_GET_USERS_GETTOPVIEWEDSOURCES_BUTTON = "get_users_getTopViewedSources_button";
	public static final String USERS_GET_USERS_GETTOPVIEWEDSOURCES_ANCHOR = "get_users_getTopViewedSources_anchor";
	public static final String USERS_GET_USERS_GETTOPVIEWEDSOURCES_LIMIT = "get_users_getTopViewedSources_limit";
	public static final String USERS_GET_USERS_GETTOPVIEWEDSOURCES_TRYITOUT = "get_users_getTopViewedSources_tryItOut";
	public static final String USERS_GET_USERS_GETTOPVIEWEDSOURCES_RESPONSE = "get_users_getTopViewedSources_response";
	
	public static final String USERS_GET_USERS_GETMYANALYTICS_BUTTON = "get_users_getMyAnalytics_button";
	public static final String USERS_GET_USERS_GETMYANALYTICS_ANCHOR = "get_users_getMyAnalytics_anchor";
	public static final String USERS_GET_USERS_GETMYANALYTICS_USERID = "get_users_getMyAnalytics_userId";
	public static final String USERS_GET_USERS_GETMYANALYTICS_LIMIT = "get_users_getMyAnalytics_limit";
	public static final String USERS_GET_USERS_GETMYANALYTICS_TRYITOUT = "get_users_getMyAnalytics_tryItOut";
	public static final String USERS_GET_USERS_GETMYANALYTICS_RESPONSE = "get_users_getMyAnalytics_response";
	
	public static final String USERS_GET_USERS_GETTOPCATEGORIES_BUTTON = "get_users_getTopCategories_button";
	public static final String USERS_GET_USERS_GETTOPCATEGORIES_ANCHOR = "get_users_getTopCategories_anchor";
	public static final String USERS_GET_USERS_GETTOPCATEGORIES_USERID = "get_users_getTopCategories_userId";
	public static final String USERS_GET_USERS_GETTOPCATEGORIES_LIMIT = "get_users_getTopCategories_limit";
	public static final String USERS_GET_USERS_GETTOPCATEGORIES_TRYITOUT = "get_users_getTopCategories_tryItOut";
	public static final String USERS_GET_USERS_GETTOPCATEGORIES_RESPONSE = "get_users_getTopCategories_response";
	
	public static final String STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_BUTTON = "post_strategy_insertAlgorithmParameters_button";
	public static final String STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_ANCHOR = "post_strategy_insertAlgorithmParameters_anchor";
	public static final String STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS = "post_strategy_insertAlgorithmParameters_parameters";
	public static final String STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME = "post_strategy_insertAlgorithmParameters_algorithmName";
	public static final String STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_TRYITOUT = "post_strategy_insertAlgorithmParameters_tryItOut";
	public static final String STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_RESPONSE = "post_strategy_insertAlgorithmParameters_response";
	
	public static final String STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_BUTTON = "get_strategy_fetchAlgorithmParameters_button";
	public static final String STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_ANCHOR = "get_strategy_fetchAlgorithmParameters_anchor";
	public static final String STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME = "get_strategy_fetchAlgorithmParameters_algorithmName";
	public static final String STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_TRYITOUT = "get_strategy_fetchAlgorithmParameters_tryItOut";
	public static final String STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_RESPONSE = "get_strategy_fetchAlgorithmParameters_response";
	
	public static final String STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_BUTTON = "get_strategy_getTraceAnalytics_button";
	public static final String STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_ANCHOR = "get_strategy_getTraceAnalytics_anchor";
	public static final String STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_PRODUCTID = "get_strategy_getTraceAnalytics_productId";
	public static final String STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_ALGONAME = "get_strategy_getTraceAnalytics_algoName";
	public static final String STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_MODE = "get_strategy_getTraceAnalytics_mode";
	public static final String STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_TRYITOUT = "get_strategy_getTraceAnalytics_tryItOut";
	public static final String STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_RESPONSE = "get_strategy_getTraceAnalytics_response";
	
	public static final String STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_BUTTON = "get_strategy_getStrategyAnalytics_button";
	public static final String STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_ANCHOR = "get_strategy_getStrategyAnalytics_anchor";
	public static final String STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME = "get_strategy_getStrategyAnalytics_algoName";
	public static final String STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_MODE = "get_strategy_getStrategyAnalytics_mode";
	public static final String STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_TRYITOUT = "get_strategy_getStrategyAnalytics_tryItOut";
	public static final String STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_RESPONSE = "get_strategy_getStrategyAnalytics_response";
	
	public static final String STRATEGY_GET_STRATEGY_GETSUMMARY_BUTTON = "get_strategy_getSummary_button";
	public static final String STRATEGY_GET_STRATEGY_GETSUMMARY_ANCHOR = "get_strategy_getSummary_anchor";
	public static final String STRATEGY_GET_STRATEGY_GETSUMMARY_TYPE = "get_strategy_getSummary_type";
	public static final String STRATEGY_GET_STRATEGY_GETSUMMARY_TRYITOUT = "get_strategy_getSummary_tryItOut";
	public static final String STRATEGY_GET_STRATEGY_GETSUMMARY_RESPONSE = "get_strategy_getSummary_response";
	
	public static final String SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_BUTTON = "get_search_getSearchedAndUltimatelyBought_button";
	public static final String SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_ANCHOR = "get_search_getSearchedAndUltimatelyBought_anchor";
	public static final String SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY = "get_search_getSearchedAndUltimatelyBought_searchKey";
	public static final String SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_MODE = "get_search_getSearchedAndUltimatelyBought_mode";
	public static final String SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_LIMIT = "get_search_getSearchedAndUltimatelyBought_limit";
	public static final String SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_CHANNEL = "get_search_getSearchedAndUltimatelyBought_channel";
	public static final String SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_TRYITOUT = "get_search_getSearchedAndUltimatelyBought_tryItOut";
	public static final String SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_RESPONSE = "get_search_getSearchedAndUltimatelyBought_response";
	
    public static final String CLUSTERS_GET_BRANDTOPSELLERS_BUTTON   = "get_brandTopSellers_button";
    public static final String CLUSTERS_GET_BRANDTOPSELLERS_ANCHOR  = "get_brandTopSellers_anchor";
    public static final String CLUSTERS_GET_BRANDTOPSELLERS_BRANDID  = "get_brandTopSellers_brandId";
    public static final String CLUSTERS_GET_BRANDTOPSELLERS_MODE  = "get_brandTopSellers_mode";
    public static final String CLUSTERS_GET_BRANDTOPSELLERS_LIMIT  = "get_brandTopSellers_limit";
    public static final String CLUSTERS_GET_BRANDTOPSELLERS_CHANNEL  = "get_brandTopSellers_channel";
    public static final String CLUSTERS_GET_BRANDTOPSELLERS_TRYITOUT  = "get_brandTopSellers_tryItOut";
    public static final String CLUSTERS_GET_BRANDTOPSELLERS_RESPONSE  = "get_brandTopSellers_response";
    public static final String CLUSTERS_GET_BRANDTOPSELLERS_MODE_LIGHT = "get_brandtopsellers_mode_light";

    public static final String BRAND_Id_VALID = "brandId.valid";
    public static final String BRAND_Id_RESULT_LIGHT = "brandId.result_light";
    public static final String BRAND_Id_RESULT_FULL = "brandId.result_full";
    public static final String BRAND_Id_INVALID = "brandId.invalid";

    public static final String CLUSTERS_GET_ALLSEGMENTS_ANCHOR = "get_allSegments_anchor";
    public static final String CLUSTERS_GET_ALLSEGMENTS_CLUSTERTYPE  = "get_allSegments_clusterType";
    public static final String CLUSTERS_GET_ALLSEGMENTS_TRYITOUT  = "get_allSegments_tryItOut";
    public static final String CLUSTERS_GET_ALLSEGMENTS_RESPONSE  = "get_allSegments_response";

    public static final String CLUSTERTYPE_VALID ="clustertype.valid";
    public static final String CLUSTERTYPE_VALID_RESULT ="clustertype.result";
    public static final String CLUSTERTYPE_INVALID = "clustertype.invalid";
    public static final String CLUSTERTYPE_INVALID_RESULT="clustertype.invalid.result";

   public static final String GET_COMBINEDCLUSTERRECOMMENDATIONS_ANCHOR = "get_combinedClusterRecommendations_anchor" ;
   public static final String GET_COMBINEDCLUSTERRECOMMENDATIONS_CLUSTERID = "get_combinedClusterRecommendations_clusterId";
   public static final String GET_COMBINEDCLUSTERRECOMMENDATIONS_MODE = "get_combinedClusterRecommendations_mode";
   public static final String GET_COMBINEDCLUSTERRECOMMENDATIONS_TRYITOUT = "get_combinedClusterRecommendations_tryItOut";
   public static final String GET_COMBINEDCLUSTERRECOMMENDATIONS_RESPONSE = "get_combinedClusterRecommendations_response";
   
   public static final String CLUSTERID_VALID = "clusterid.valid";


   public static final String CLUSTERS_GET_AFFINITYDETAILS_ANCHOR ="get_affinityDetails_anchor";
   public static final String CLUSTERS_GET_AFFINITYDETAILS_SEGMENTID = "get_affinityDetails_segmentId";
   public static final String CLUSTERS_GET_AFFINITYDETAILS_TRYITOUT ="get_affinityDetails_tryItOut";
   public static final String CLUSTERS_GET_AFFINITYDETAILS_RESPONSE ="get_affinityDetails_response";

   public static final String SEGMENTID_VALID  ="segmentid.valid";
   public static final String SEGMENTID_AFFINITY_RESULT="segment.affinity.result";

 public static final String SEGMENTID_INVALID = "segmentid.invalid";
 public static final String SEGMENT_AFFINITY_INVALID_RESULT = "segment.affinity.invalid.result";


	public static final String CLUSTERS_GET_CLUSTERANALYTICS_ANCHOR = "get_clusterAnalytics_anchor";
	public static final String CLUSTERS_GET_CLUSTERANALYTICS_SEGMENTID = "get_clusterAnalytics_segmentId";
	public static final String CLUSTERS_GET_CLUSTERANALYTICS_TRYITOUT = "get_clusterAnalytics_tryItOut";
	public static final String CLUSTERS_GET_CLUSTERANALYTICS_RESPONSE = "get_clusterAnalytics_response";

	public static final String SEGMENTID_ANALYTICS_RESULT="segment.analytics.result";
	public static final String SEGMENT_ANALYTICS_INVALID_RESULT = "segment.analytics.invalid.result";


	public static final String CLUSTERS_GET_TOPSELLERS_ANCHOR = "get_topSellers_anchor";
	public static final String CLUSTERS_GET_TOPSELLERS_CLUSTERID = "get_topSellers_clusterId";
	public static final String CLUSTERS_GET_TOPSELLERS_MODE = "get_topSellers_mode";
	public static final String CLUSTERS_GET_TOPSELLERS_TRYITOUT = "get_topSellers_tryItOut";
	public static final String CLUSTERS_GET_TOPSELLERS_RESPONSE = "get_topSellers_response";

	public static final String	SEGMENT_TOPSELLERS_RESULT_LIGHT ="segment.topsellers.result_light";
	public static final String	SEGMENT_TOPSELLERS_RESULT_FULL = "segment.topsellers.result_full";
	public static final String	SEGMENT_TOPSELLERS_INVALID_RESULT = "segment.topsellers.invalid.result";
	

	public static final String CLUSTERS_CLUSTERS_ANCHOR = "clusters_anchor";
	public static final String CLUSTERS_CLUSTERS_CLUSTERTYPE = "clusters_clusterType";
	public static final String CLUSTERS_CLUSTERS_MODE = "clusters_mode";
	public static final String CLUSTERS_CLUSTERS_ALGONAME  = "clusters_algoName";
	public static final String CLUSTERS_CLUSTERS_TRYITOUT = "clusters_tryItOut";
	public static final String CLUSTERS_CLUSTERS_RESPONSE = "clusters_response";

	public static final String CLUSTERS_VALID_RESULT_LIGHT = "clusters.valid.result_light";
	public static final String CLUSTERS_VALID_RESULT_FULL = "clusters.valid.result_full";

	public static final String CLUSTER_INVALID_ALGONAME = "cluster.algoName";
	public static final String CLUSTER_INVALID_RESULT = "cluster.invalid.result";


	public static final String CLUSTERS_GET_CLUSTERDETAILS_ANCHOR  = "get_clusterDetails_anchor";
	public static final String CLUSTERS_GET_CLUSTERDETAILS_CLUSTERID = "get_clusterDetails_clusterid";
	public static final String CLUSTERS_GET_CLUSTERDETAILS_TRYITOUT = "get_clusterDetails_tryItOut";
	public static final String CLUSTERS_GET_CLUSTERDETAILS_RESPONSE = "get_clusterDetails_response";

	public static final String CLUSTERDETAILS_VALID_RESULT   = "clusterDetails.valid.result";
	public static final String CLUSTERDETAILS_INVALID_RESULT1= "clusterDetails.invalid.result1";
	public static final String CLUSTERDETAILS_INVALID_RESULT2= "clusterDetails.invalid.result2";


	public static final String CLUSTERS_GET_SIMILARUSERS_ANCHOR  ="get_similarusers_anchor";
	public static final String CLUSTERS_GET_SIMILARUSERS_USERID  = "get_similarusers_userId";
	public static final String CLUSTERS_GET_SIMILARUSERS_TRYITOUT= "get_similarusers_tryItOut";
	public static final String CLUSTERS_GET_SIMILARUSERS_RESPONSE= "get_similarusers_response";

	public static final String SIMILARUSER_VALID_RESULT = "similarUser.valid.result";
	public static final String SIMILARUSER_INVALID_RESULT = "similarUser.invalid.result";

	public static final String USERID_VALID   ="userId.valid";
	public static final String USERID_INVALID ="userId.invalid";


	public static final String CLUSTERS_FREQBOUGHTTOGETHER_ANCHOR = "freqBoughtTogether_anchor";
	public static final String CLUSTERS_FREQBOUGHTTOGETHER_CLUSTERID = "freqBoughtTogether_clusterId";
	public static final String CLUSTERS_FREQBOUGHTTOGETHER_MODE   = "freqBoughtTogether_mode";
	public static final String CLUSTERS_FREQBOUGHTTOGETHER_CHANNEL = "freqBoughtTogether_channel";
	public static final String CLUSTERS_FREQBOUGHTTOGETHER_TRYITOUT = "freqBoughtTogether_tryItOut";
	public static final String CLUSTERS_FREQBOUGHTTOGETHER_RESPONSE = "freqBoughtTogether_response";

	public static final String FREQBOUGHT_VALID_RESULT1 = "freqBought.valid.result1";
	public static final String FREQBOUGHT_VALID_RESULT2  = "freqBought.valid.result2";
	public static final String FREQBOUGHT_INVALID_RESULT1 = "freqBought.invalid.result1";


	public static final String CLUSTERS_RECOMMENDATIONS_ANCHOR   = "recommendations_anchor";
	public static final String CLUSTERS_RECOMMENDATIONS_CLUSTERID= "recommendations_clusterId";
	public static final String CLUSTERS_RECOMMENDATIONS_MODE     = "recommendations_mode";
	public static final String CLUSTERS_RECOMMENDATIONS_CHANNEL  = "recommendations_channel";
	public static final String CLUSTERS_RECOMMENDATIONS_TRYITOUT = "recommendations_tryItOut";
	public static final String CLUSTERS_RECOMMENDATIONS_RESPONSE = "recommendations_response";

	public static final String RECOMMENDATIONS_VALID_RESULT1 = "recommendations.valid.result1";
	public static final String RECOMMENDATIONS_VALID_RESULT2 = "recommendations.valid.result2";
	public static final String RECOMMENDATIONS_INVALID_RESULT= "recommendations.invalid.result";


	public static final String CLUSTERS_CHARTS_ANCHOR	= "charts_anchor";
	public static final String CLUSTERS_CHARTS_CLUSTERTYPE = "charts_clusterType";
	public static final String CLUSTERS_CHARTS_MODE		= "charts_mode";
	public static final String CLUSTERS_CHARTS_TRYITOUT = "charts_tryItOut";
	public static final String CLUSTERS_CHARTS_RESPONSE = "charts_response";
	public static final String CLUSTERS_CHARTS_ALGONAME = "charts_algoName";

	public static final String CHARTS_VALID_RESULT1 	= "charts.valid.result1";
	public static final String CHARTS_VALID_RESULT2 	= "charts.valid.result2";
	public static final String CHARTS_INVALID_ALGONAME ="charts.invalid.algoName";
	public static final String CHARTS_INVALID_RESULT 	="charts.invalid.result";


	public static final String CLUSTERS_RECOMMENDATIONRULE_ANCHOR = "recommendationRule_anchor";
	public static final String CLUSTERS_RECOMMENDATIONRULE_CLUSTERID  = "recommendationRule_clusterId";
	public static final String CLUSTERS_RECOMMENDATIONRULE_TRYITOUT  = "recommendationRule_tryItOut";
	public static final String CLUSTERS_RECOMMENDATIONRULE_RESPONSE  = "recommendationRule_response";


	public static final String RECOMMENDATIONRULE_INVALID_RESULT = "recommendationrule.invalid.result";


	public static final String CLUSTERS_JOBDETAILS_ANCHOR ="jobdetails_anchor";
	public static final String CLUSTERS_JOBDETAILS_TRYITOUT = "jobdetails_tryItOut";
	public static final String CLUSTERS_JOBDETAILS_RESPONSE = "jobdetails_response";

	public static final String JOBDETAILS_VALID_RESULT1 = "jobDetails.valid.result1";
	public static final String JOBDETAILS_VALID_RESULT2 = "jobDetails.valid.result2";
	public static final String JOBDETAILS_INVALID_RESULT = "jobDetails.invalid.result";

	public static final String BRANDID_VALID = "brandid.valid";
	public static final String BRANDID_INVALID = "brandid.invalid";
	public static final String CATEGORYID_VALID = "categoryid.valid";
	public static final String CATEGORYID_VALID1 ="categoryid.valid1";
	public static final String CATEGORYID_INVALID = "categoryid.invalid";
	public static final String ASPIRINGBRANDS_VALID_RESULT= "aspiringBrands.valid.result";
	public static final String ASPIRINGBRANDS_INVALID_RESULT= "aspiringBrands.invalid.result";


	public static final String CLUSTERS_ASPIRINGBRANDS_ANCHOR ="aspiringbrands_anchor";
	public static final String CLUSTERS_ASPIRINGBRANDS_BRANDID ="aspiringbrands_brandId";
	public static final String CLUSTERS_ASPIRINGBRANDS_LIMIT ="aspiringbrands_limit";
	public static final String CLUSTERS_ASPIRINGBRANDS_TRYITOUT ="aspiringbrands_tryItOut";
	public static final String CLUSTERS_ASPIRINGBRANDS_RESPONSE ="aspiringbrands_response";


	public static final String CLUSTERS_RELATEDCATEGORIESMATRIX_ANCHOR = "relatedcategoriesmatrix_anchor";
	public static final String CLUSTERS_RELATEDCATEGORIESMATRIX_CATEGORYID = "relatedcategoriesmatrix_categoryId";
	public static final String CLUSTERS_RELATEDCATEGORIESMATRIX_TRYITOUT = "relatedcategoriesmatrix_tryItOut";
	public static final String CLUSTERS_RELATEDCATEGORIESMATRIX_RESPONSE = "relatedcategoriesmatrix_response";

	public static final String RELATEDCATEGORIESMATRIX_INVALID_RESULT = "relatedcategoriesmatrix.invalid.result";

	public static final String JOBID_VALID = "jobId.valid";
	public static final String JOBID_INVALID = "jobId.invalid";
	public static final String JOBID_VALID1 = "jobId.valid1";

	public static final  String CLUSTERS_JOBDETAILSBYID_ANCHOR = "jobdetailsbyID_anchor";
	public static final  String CLUSTERS_JOBDETAILSBYID_JOBID  = "jobdetailsbyID_jobId";
	public static final  String CLUSTERS_JOBDETAILSBYID_TRYITOUT = "jobdetailsbyID_tryItOut";
	public static final  String CLUSTERS_JOBDETAILSBYID_RESPONSE = "jobdetailsbyID_response";

	public static final  String JOBDETAILSBYID_VALID_RESULT ="jobDetailsbyid.valid.result";
	public static final  String JOBDETAILSBYID_VALID_RESULT1 ="jobDetailsbyid.valid.result1";
    public static final  String JOBDETAILSBYID_INVALID_RESULT = "jobDetailsbyid.invalid.result";


	public static final String CLUSTERS_CUSTOMERRFM_ANCHOR  = "customerRFM_anchor";
	public static final String CLUSTERS_CUSTOMERRFM_ID		= "customerRFM_id";
	public static final String CLUSTERS_CUSTOMERRFM_TRYITOUT = "customerRFM_tryItOut";
	public static final String CLUSTERS_CUSTOMERRFM_RESPONSE = "customerRFM_response";

	public static final String CUSTOMERRFM_VALID_RESULT = "customerRFM.valid.result";


	public static final String CLUSTERS_RELATEDCATEGORIES_ANCHOR = "relatedcategories_anchor";
	public static final String CLUSTERS_RELATEDCATEGORIES_CATID  = "relatedcategories_catId";
	public static final String CLUSTERS_RELATEDCATEGORIES_TRYITOUT= "relatedcategories_tryItOut";
	public static final String CLUSTERS_RELATEDCATEGORIES_RESPONSE= "relatedcategories_response";
	
	public static final String RELATEDCATEGORIES_VALID_RESULT1="relatedCategories.valid.result1";
	public static final String RELATEDCATEGORIES_VALID_RESULT2="relatedCategories.valid.result2";
	public static final String RELATEDCATEGORIES_INVALID_RESULT= "relatedCategories.invalid.result";


	public static final String CLUSTERS_TOPVIEWED_ANCHOR = "topViewed_anchor";
	public static final String CLUSTERS_TOPVIEWED_CLUSTERID = "topViewed_clusterID";
	public static final String CLUSTERS_TOPVIEWED_MODE  = "topViewed_mode";
	public static final String CLUSTERS_TOPVIEWED_TRYITOUT = "topViewed_tryItOut";
	public static final String CLUSTERS_TOPVIEWED_RESPONSE = "topViewed_response";

	public static final String TOPVIEWED_RESULT = "topviewed.result";


	public static final String CLUSTERS_SOCIALRECOMMENDATIONS_ANCHOR = "socialRecommendations_anchor";
	public static final String CLUSTERS_SOCIALRECOMMENDATIONS_CLUSTERID = "socialRecommendations_clusterId";
	public static final String CLUSTERS_SOCIALRECOMMENDATIONS_MODE  = "socialRecommendations_mode";
	public static final String CLUSTERS_SOCIALRECOMMENDATIONS_CHANNEL = "socialRecommendations_channel";
	public static final String CLUSTERS_SOCIALRECOMMENDATIONS_TRYITOUT = "socialRecommendations_tryItOut";
	public static final String CLUSTERS_SOCIALRECOMMENDATIONS_RESPONSE  = "socialRecommendations_response";

	public static final String SOCIALRECOMMENDATION_RESULT = "socialrecommendation.result";


	public static final String CLUSTERS_CONFIGURATIONREAD_ANCHOR = "configurationread_anchor";
	public static final String CLUSTERS_CONFIGURATIONREAD_TRYITOUT = "configurationread_tryItOut";
	public static final String CLUSTERS_CONFIGURATIONREAD_RESPONSE  = "configurationread_response";

	public static final String CONFIGURATION_READ_RESULT  = "configuration.read.result";
}