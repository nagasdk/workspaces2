package ocpe.aut.fwk.constants;

/**
 * All the constants are placed in this constants file to avoid hard coding and for re-use
 * @author Nagaraju Kura
 *
 */
public class AppConstants {

	//THIS SECTION HAS DRIVER RELATED CONSTANTS THAT ARE CONFIGURABLE
	public static String PATH_TO_FIREFOX_BINARY  = "D:/Program Files/Mozilla Firefox/firefox.exe";
	public static String FIREFOX_PROFILE_DEFAULT = "default";
	public static String	PROXY_URL = "http://10.219.3.170/PRAKRITI.pac";

	//THIS SECTION CONTAINS CONSTANTS RELATED TO HBASE CONNECTION, USED IN HBaseUtil
	public static String ZOOKEEPER_QUORUM= "hbase.zookeeper.quorum";
	public static String ZOOKEEPER_QUORUM_VALUE = "10.68.210.38";
	public static String ZOOKEEPER_CLIENT_PORT = "hbase.zookeeper.property.clientPort";
	public static String ZOOKEEPER_CLIENT_PORT_VALUE = "2181";
	public static String HBASE_MASTER = "hbase.master";
	public static String HBASE_MASTER_VALUE = "10.68.210.38:60010";
	

	public static String LOGIN_PAGE = "LoginPage";
	public static String USER_NAME = "username";
	public static String VALID_USERNAME = "validUsername";
	public static String PASSWORD = "password";
	public static String VALID_PASSWORD = "validPassword";
	public static final String NON_ALPHA_USERNAME = "nonAlphaUserName";
	public static final String EMPTY_STRING = "";
	public static String LOGIN_SUBMIT = "loginSubmit";
	public static String FORGOT_PASSWORD_LINK = "forgotPasswordLink";
	public static String LOGIN_CAPTCHA = "loginCaptcha";
	public static String FIRST_NAME = "firstName";
	public static String LAST_NAME = "lastName";
	public static String EMAIL = "email";
	public static String CAPTCHA = "captcha";
	public static String FP_SUBMIT = "fpSubmit";
	public static String FP_CANCEL = "fpCancel";
	public static String FP_CLOSE = "fpClose";
	public static String FP_ERR_MSG = "fpErrorMsg";
	public static final String FP_FIRST_NAME = "fpFirstName";
	public static final String FP_LAST_NAME = "fpLastName";
	public static final String FP_EMAIL = "fpEmail";
	public static final String FP_MSG_CAPTCHA_FAIL = "fpMsgCaptchFail";
	public static final String FP_MSG_MANDATORY = "fpMsgMandatory";
	public static String FP_OK_BTN = "fpOkBtn";
	public static String CHANGE_PWD = "changePwd";
	public static String UPDATE_PROFILE = "updateProfile";
	public static String LOGOUT = "logout";
	public static String INVALID_USERNAME = "invalidUsername";
	public static String INVALID_PASSWORD = "invalidPassword";
	public static String INVALID_CREDENTIALS_MSG = "invalidCredentialsMsg";
	public static String WELCOME_MSG = "welcomeMessage";
	public static String USER_DIV = "userDiv";
	public static String RP_OLD_PWD = "oldPwd";
	public static String RP_NEW_PWD = "newPwd";
	public static String RP_RETYPE_PWD = "reTypePwd";
	public static String RP_CAPTCHA = "rpCaptcha";
	public static String RP_CANCEL = "rpCancel";
	public static String RP_UPDATE = "rpUpdate";
	public static String RP_CLOSE_BTN = "rpCloseBtn";
	public static String RP_ERR_MSG = "rpErrorMsg";
	public static String RP_OK_BTN = "rpOkBtn";
	public static String UP_USER_NAME = "upUserName";
	public static String UP_FIRST_NAME = "upFirstName";
	public static String UP_LAST_NAME = "upLastName";
	public static String UP_EMAIL = "upEmail";
	public static String UP_ROLE = "upRole";
	public static String UP_STATUS= "upStatus";
	public static String UP_PHONE = "upPhone";
	public static String UP_MOBILE = "upMobile";
	public static String UP_CANCEL = "upCancel";
	public static String UP_UPDATE = "upUpdate";
	public static String UP_CLOSE = "upClose";
	public static String BASE_URL = "http://blrkec241952d:8282/aham-console-web";
	public static String LOGIN_URL = "/login.jsp";
	public static String HOME_URL = "/index.html";	
	public static String ANALYSIS_URL = "/aham-console-web/index.html#/main/13/submenu/99/searchBrandSegment";
	public static String BLANK_STRING = "";
	public static String OK = "OK";
	public static String ERROR_MESSAGE = "errorMessage";
	public static String OK_BTN = "OkBtn";
	public static String REPORTS_DIRECTORY_PATH = "D:\\OCPE_AutomationReports";
	public static String DETAILED_REPORTS = "DetailedReports";
	public static String FORWARD_SLASH = "/";
	// public static String YYYY_MM_DD_HH_MM = "MMMdd,YYYY_hhmm a";
	public static String ddMMMYYYY_HHmm = "ddMMMyyyy_HHmm";
	public static String RESOURCES_FOLDER_PATH = "src/ocpe/aut/fwk/resources/"; 
	public static String DETAILED_REPORT_XSL = "DetailedReportXSL.xsl";
	public static String SUMMARY_REPORT_XSL = "src/ocpe/aut/fwk/resources/SummaryReportXSL.xsl";
	public static String LOGIN = "login";
	public static String LOGIN_SCRIPT_NAME = "Login";
	public static String HOME_SCRIPT_NAME = "Home";
	public static String LOGIN_PROPERTIES= "src/ocpe/aut/fwk/resources/login.properties";
	public static String HOME_PROPERTIES= "src/ocpe/aut/fwk/resources/home.properties";
	public static String LOGIN_PASS_PROPERTIES= "src/ocpe/aut/fwk/resources/login_vp_pass.properties";
	public static String LOGIN_FAIL_PROPERTIES= "src/ocpe/aut/fwk/resources/login_vp_fail.properties";
	public static final String HOME_PASS_PROPERTIES = "src/ocpe/aut/fwk/resources/home_vp_pass.properties";
	public static final String HOME_FAIL_PROPERTIES = "src/ocpe/aut/fwk/resources/home_vp_fail.properties";
	public static final String HOME = "home";
	public static final String HOME_PAGE = "LoginPage";
	public static final String RP_TITLE = "rpTitle";
	public static String DATA_PROPERTIES= "src/ocpe/aut/fwk/resources/data.properties";
	public static String ANALYSIS_PROPERTIES= "src/ocpe/aut/fwk/resources/analysis.properties";
	public static String API_TAB_PROPERTIES= "src/ocpe/aut/fwk/resources/apitab.properties";
	public static String DOT_XML = ".xml";
	public static String DOT_HTML = ".html";
	public static String XML = "xml";
	public static String vPass = "Pass";
	public static String vFail = "Fail";
	public static String DATA = "data";
	public static String DATA_SCRIPT_NAME = "Data";
	public static String SELECTED = "selected";
	public static String DATA_TAB = "DataTab";
	public static String ANALYSIS_TAB = "AnalysisTab";
	public static String ANALYSIS = "analysis";
	public static String ANALYSIS_SCRIPT_NAME = "Analysis";
	
	public static String API_TAB = "APITab";

	//THIS ECTION CONTAINS passCount, failCount and notRunCount
	public static int passCount= 0,failCount = 0, notRunCount = 0;
	
	public static String PROPERTIES_FILE_PATH=""; // this variable will change dynamically according to the script 
	public static String TOTAL_VERIFICATION_POINTS = "totalVerificationPoints";
	public static String TOTAL_TESTCASES = "totalTestCases";

	// THIS SECTION HAS THE DEFINITION OF CONSTANTS BEING USED FOR DETAILED XML REPORT GENERATION
	public static String XML_FILE_PATH="";		 // This variable gets initialized/uninitialized dynamically by the TestScript which uses this, Every new script should have mechanism to handle this 
	public static String ELE_VERIFICATIONPOINTS = "VerificationPoints";
	public static String ELE_VERIFICATIONPOINT = "verificationPoint";	
	public static String ELE_TESTCASEID = "TestCaseId";
	public static String ELE_VPNAME = "VPName";
	public static String ELE_VPRESULT = "VPResult";
	public static String ELE_VPSTATUS = "VPStatus";
	public static String ELE_TESTSCRIPTNAME = "TestScriptName";
	public static String HEADER_ELE_TOTALVPS = "TotalVerificationPoints";
	public static String HEADER_ELE_TOTALTCS = "TotalTestCases";
	public static String HEADER_ELE_PASSED ="Passed";
	public static String HEADER_ELE_FAILED ="Failed";
	public static String HEADER_ELE_NOTRUN ="NotRun";
	public static String ELE_HEADERSECTION = "Header";


	
	//THIS SECTION HAS FOLDER CREATION CONSTANTS
	public static String SUMMARY_REPORT_FOLDER = "D:/OCPE_AutomationReports/19Dec2013_1540";	
	public static String DETAIL_REPORT_FOLDER = "D:/OCPE_AutomationReports/19Dec2013_1540/DetailedReports";		
	public static String XML_FOLDER = "D:/OCPE_AutomationReports/19Dec2013_1540/DetailedReports/xml"; 
	public static String SUMMARY_REPORT_XML_FILE_PATH = "D:/OCPE_AutomationReports/19Dec2013_1540/DetailedReports/xml/SummaryReport.xml"; 
	

/* 	public static String SUMMARY_REPORT_FOLDER = "";	
	public static String DETAIL_REPORT_FOLDER = "";		
	public static String XML_FOLDER = ""; 
	public static String SUMMARY_REPORT_XML_FILE_PATH = "";
*/	
		// THIS SECTION HAS THE DEFINITION OF CONSTANTS BEING USED FOR SUMMARY XML REPORT GENERATION
	public static String SUMMARY_REPORT = "SummaryReport";
	
	public static String SUMMARY_REPORT_NAME = "OCPE Regression Testing Report";
	public static String ELE_SUMMARYREPORT = "SummaryReport";
	public static String ELE_SCRIPT = "Script";
	public static String ELE_REPORTNAME = "ReportName";
	public static String ELE_SCRIPTNAME = "ScriptName";
	public static String ELE_HTMLREPORTPATH = "HtmlReportPath";

	// THIS SECTION HAS CONSTANTS OF OCPE WEBELEMENTPROPERTIES EXCEL FILE 
	public static String WORKBOOK_PATH = "src/ocpe/aut/fwk/resources/OCPE_WebElementProperties.xlsx";

	//THIS SECTION HAS CONSTANTS FOR DATA TAB
	public static String DATA_TAB_NAME = "Data";
	public static String TAB_DATA = "tab_data";
	public static String MENU_CUSTOMERS = "menu_customers";
	
	
	public static String SPACE = " ";
	public static String READONLY = "readonly";
	public static String TRUE = "true";
	public static String INPUT = "input";
	public static String CHECKED = "checked";
	public static String ID = "id";
	public static String OPTION = "option";
	public static String TYPE = "type";
	public static String CHECKBOX = "checkbox";
	public static String CLASS = "class";
	public static String TR = "tr";
	public static String TD = "td";
	public static String SRC = "src";
	public static String QUESTION_MARK = "?";
	
	public static String ASCENDING = "ascending";
	public static String DESCENDING = "descending";	
	

	
}
