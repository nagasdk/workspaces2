package ocpe.aut.fwk.testScripts;

import static org.junit.Assert.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import ocpe.aut.fwk.constants.AnalysisTabConstants;
import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.HBaseUtil;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.filter.BinaryComparator;
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp;
import org.apache.hadoop.hbase.filter.RowFilter;
import org.apache.hadoop.hbase.util.Bytes;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;




@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class AnalysisTab {
	
	
	private static ExcelUtil excelRW;
	private static PropertiesUtil propsRW;
	private static PropertiesUtil propsANnalysis;
	private static GenerateXml generateXML;
	private static WebDriver driver;
	private static GenerateHTML generateReport;
	private static DesiredCapabilities cap = null; 
	private static FirefoxBinary ffBinary = null; 
	private static FirefoxProfile ffprofile = null;
	private static String pageName;
	private static StringBuffer verificationErrors = new StringBuffer();
	static int pass= 0,fail = 0, notRun = 0;
	
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// one-time initialization code   
				System.out.println("@BeforeClass - AnalysisTab");
				File  pathToFirefoxBinary = new File(AppConstants.PATH_TO_FIREFOX_BINARY);
				ffBinary = new FirefoxBinary(pathToFirefoxBinary);
				ProfilesIni profile = new ProfilesIni();		   		   
				ffprofile = profile.getProfile(AppConstants.FIREFOX_PROFILE_DEFAULT);
				org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();		  		  
				proxy.setProxyAutoconfigUrl(AppConstants.PROXY_URL);	
				cap = new DesiredCapabilities();		  
				cap.setCapability(CapabilityType.PROXY, proxy);	

				//Change the xml file path according to name of the script
				AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER+AppConstants.FORWARD_SLASH+AppConstants.ANALYSIS+AppConstants.DOT_XML;
				AppConstants.PROPERTIES_FILE_PATH = AppConstants.ANALYSIS_PROPERTIES;

				generateXML = new GenerateXml();		
				generateReport = new GenerateHTML();
				
				//Create a new XML file
				generateXML.createVPXML(AppConstants.ANALYSIS_SCRIPT_NAME);

				//Util classes that reads the excel sheet and properties files
				excelRW = new ExcelUtil(); 										
				propsRW = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);
				propsANnalysis = new PropertiesUtil(AppConstants.ANALYSIS_PROPERTIES);
				
				driver = new FirefoxDriver(ffBinary,ffprofile,cap);		
				driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
				driver.manage().window().maximize();	
				driver.get(AppConstants.BASE_URL + AppConstants.LOGIN_URL);	
				

				/*xpathExpression is the value present in column B of 
				  the sheet for the control name "username"
				  Ex: //input[@id='j_username'] 
				 */
//				userNameXPath = excelRW.readProps(pageName, AppConstants.USER_NAME);
//				passwordXPath = excelRW.readProps(pageName, AppConstants.PASSWORD);
//				loginBtnXPath = excelRW.readProps(pageName, AppConstants.LOGIN_SUBMIT);
				
				//Sheet Name of excel from where the xpath values are fetched
				pageName = AppConstants.ANALYSIS_TAB;

				//Create a new XML file
				generateXML.createVPXML(AppConstants.ANALYSIS_SCRIPT_NAME);

				//Login
				/*Firefox browser gets opened with OCPE Login page, provide 
				 * with username rg@gmail.com and click on submit button.
				 * After login, Data tab selected with it's first side menu highlighted */

				/*Clear the User Name textbox*/
				String xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.USER_NAME);
				driver.findElement(By.xpath(xpathExpression)).clear();

				propsRW = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);
				//propsANnalysis = new PropertiesUtil(AppConstants.ANALYSIS_PROPERTIES);
				/* Get valid username from properties file
				 * ex: rg@gmail.com*/
				String userName = propsRW.read(AppConstants.VALID_USERNAME).trim();
				driver.findElement(By.xpath(xpathExpression)).sendKeys(userName);


				/* Clear the Password textbox*/
				xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.PASSWORD);
				driver.findElement(By.xpath(xpathExpression)).clear();

				/* Get valid password from properties file
				 * ex: Aham123+*/
				String password = propsRW.read(AppConstants.VALID_PASSWORD).trim();
				driver.findElement(By.xpath(xpathExpression)).sendKeys(password);


				/*Click on login button*/
				xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.LOGIN_SUBMIT);		
				driver.findElement(By.xpath(xpathExpression)).click();
				
				/*Click on login button*/
				//xpathExpression = excelRW.readProps(AppConstants.ANALYSIS_TAB, "analysis");		
				driver.findElement(By.linkText("Analysis")).click();
				

	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		notRun = 	 Integer.parseInt(propsANnalysis.read(AppConstants.TOTAL_VERIFICATION_POINTS).trim())-pass-fail;		

		//log header report counts in XML file
		//generateXML.logHeaderReportCounts(pass, fail, notRun);
		//Generate html report using xml created in test method
		//Report should be according to test case name, ex: data.html
		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH+AppConstants.DETAILED_REPORT_XSL;
		String outputHTML =AppConstants.DETAIL_REPORT_FOLDER+AppConstants.FORWARD_SLASH+AppConstants.DATA+AppConstants.DOT_HTML;
		generateReport.generateHTML(AppConstants.XML_FILE_PATH, inputXSL, outputHTML);
        AppConstants.notRunCount =       Integer.parseInt(propsRW.read(AppConstants.TOTAL_VERIFICATION_POINTS).trim())-AppConstants.passCount-AppConstants.failCount;                   

		System.out.println("Successfully generated the report");

		//log script in summary report xml file
		generateXML.logScript(AppConstants.DATA_SCRIPT_NAME, outputHTML);
        generateXML.logHeaderReportCounts();
        
        generateXML.logScript(AppConstants.LOGIN_SCRIPT_NAME, outputHTML);
		//Reset xml & properties files path to ""	
		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;

		
        //Set pass, fail and notrun count to zero
        AppConstants.passCount= 0;
        AppConstants.failCount = 0;
        AppConstants.notRunCount = 0;

        
		//Close the browser
		driver.close();
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}

	}

	@Test
	public void test_2() throws InterruptedException 
	{
		//wait for 4 secs
		Thread.sleep(100);

		//Check whether Data tab is selected or not
//		String xpathExpression = excelRW.readProps(pageName, AppConstants.TAB_DATA);
//		String selectedTab  = driver.findElement(By.xpath(xpathExpression)).getText();
//		String xpathExpression = excelRW.readProps(AppConstants.ANALYSIS_TAB, "analysis");		
		String selectedTab=driver.findElement(By.id("overview")).getText();       //overview

		if(selectedTab.equals(AnalysisTabConstants.ANALYSIS_OVERVIEW_TAB_NAME) ) {
			generateXML.logVP("2.1", "Verify Ui of Analysis tab screen",	"After login Analysis tab is selected", AppConstants.vPass);				
			pass++;
		} else {
			generateXML.logVP("2.1", "Verify Ui of Analysis tab screen",	 "After login Analysis tab is not selected", AppConstants.vFail);		
			fail++;
		}
		
		 List<WebElement> sideMenuList=driver.findElements(By.xpath(".//*[@id='navigation']/li/*")); //verify all left menu items are hyperlinks
	     int count=0;
	     for(int i=0;i<sideMenuList.size();i=i+2)
	     {
	    	
		   String anchor=sideMenuList.get(i).getTagName();
		   if(anchor.equalsIgnoreCase("a"))
		   {
			   System.out.println("Success");
			   count++;
		
		   }
	     }
	     if(count>=3)
	     {
	    	 generateXML.logVP("2.2", "Verify default tab ",	"Verify if left menu items are hyperlinks ", AppConstants.vPass);				
				pass++;
	     }
	 
	     else
	     {
	    	 generateXML.logVP("2.2", "Verify default tab ",	 "Verify if left menu items are hyperlinks ", AppConstants.vFail);		
				fail++;
	     }
	    /*end of side menu items -- hyperlinks*/
	     
	     
	     //// check if age, gender ,location, visual are disabled
	     String ageTab=driver.findElement(By.xpath(".//*[@id='navigation']/li[4]/a/b")).getAttribute("class");
	     String genderTab=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div/div/ul/li[5]/a/b")).getAttribute("class");
	     String LocationTab=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div/div/ul/li[6]/a/b")).getAttribute("class");
	     String visualTab=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div/div/ul/li[7]/a/b")).getAttribute("class");
	     System.out.println("ageTab-"+ageTab);
	     System.out.println("genderTab-"+genderTab);
	     System.out.println("LocationTab-"+LocationTab);
	     System.out.println("visualTab-"+visualTab);
	     
	 	if((ageTab.equals(AnalysisTabConstants.LTR_DISABLED))&&(genderTab.equals(AnalysisTabConstants.LTR_DISABLED))&&(LocationTab.equals(AnalysisTabConstants.LTR_DISABLED))&&(visualTab.equals(AnalysisTabConstants.LTR_DISABLED)))
	 	{
	 		generateXML.logVP("2.3", "Verify default tab ",	"Age, Gender, Location, Visual links are disabled", AppConstants.vPass);				
			pass++;
		} else {
			generateXML.logVP("2.3", "Verify default tab ",	 "Age, Gender, Location, Visual links are not disabled", AppConstants.vFail);		
			fail++;
		}	
	 	
	     
	}

	
		
		@Test
		public void test_3() throws InterruptedException {
			//wait for 1 secs
			Thread.sleep(100);

			//Check whether Data tab is selected or not
//			String xpathExpression = excelRW.readProps(pageName, AppConstants.TAB_DATA);
//			String selectedTab  = driver.findElement(By.xpath(xpathExpression)).getText();
//			String xpathExpression = excelRW.readProps(AppConstants.ANALYSIS_TAB, "analysis");		
			String selectedTab=driver.findElement(By.name("searchBrandSegment")).getText();       //overview

			if(selectedTab.equals(AnalysisTabConstants.ANALYSIS_BRAND_LINK_NAME) ) {
				generateXML.logVP("3", "Verify default tab ",	"After login Analysis tab,Brand Side Menue is selected", AppConstants.vPass);				
				pass++;
			} else {
				generateXML.logVP("3", "Verify default tab ",	 "After login Analysis tab,Brand Side Menue is not selected", AppConstants.vFail);		
				fail++;
			}	
		}
			@Test
			public void test_4() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);

				
				String selectedTab=driver.findElement(By.xpath("//*[@id='overview']")).getText();       //overview

				if(selectedTab.equals(AnalysisTabConstants.ANALYSIS_OVERVIEW_TAB_NAME) ) {
					generateXML.logVP("4", "Verify Ui of brand screen ",	"After login Analysis tab, Overview tab of Brand is selected", AppConstants.vPass);				
					pass++;
				} else {
					generateXML.logVP("4", "Verify Ui of brand screen ",	 "After login Analysis tab, Overview tab of Brand is selected", AppConstants.vFail);		
					fail++;
				}
			
	}

			
			@Test
			public void test_5() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);

				//Check whether Overview tab is selected or not
				
				//String xpathExpression = excelRW.readProps(pageName, AppConstants.ANALYSIS_TAB_OVERVIEW);	
				//System.out.println(xpathExpression);
				String selectedTab=driver.findElement(By.xpath("//*[@id='overview']")).getAttribute("class");       //overview
				String ListOfSegmentTab=driver.findElement(By.xpath("//*[@id='list']")).getText();///  //*[@id="list"]
				String advanceSearch=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div[3]/div/ul/li[3]/a/b")).getText();//       /html/body/div/div/div[3]/div[2]/div[3]/div/ul/li[3]/a/b
				
				System.out.println("Test4-"+selectedTab);
				if((selectedTab.equals(AnalysisTabConstants.LTR_CURRENT))&& (!ListOfSegmentTab.isEmpty()||ListOfSegmentTab!=null) && (!advanceSearch.isEmpty()||advanceSearch!=null) ) {
					generateXML.logVP("5.1", "Verify Ui of Brand tab -  Overview tab screen  ",	"After login Analysis tab, Overview tab of Brand is selected", AppConstants.vPass);				
					pass++;
					//System.out.println("pass4");
				} else {
					generateXML.logVP("5.1", "Verify Ui of Brand tab -  Overview tab screen ",	 "After login Analysis tab, Overview tab of Brand is selected", AppConstants.vFail);		
					fail++;
					//System.out.println("Fail4");
				}
				
				List<WebElement> sideMenuList=driver.findElements(By.xpath("/html/body/div/div/div[3]/div[2]/div[3]/div[1]/*[1]/*/*[1]")); //verify tabs in Brand view are hyperlinks
			    System.out.println("Test5.2 sideMenueListSize="+sideMenuList.size());
				int count=0;
			     for(int i=0;i<sideMenuList.size();i++)
			     {
			    	
				   String anchor=sideMenuList.get(i).getTagName();
				   if(anchor.equalsIgnoreCase("a"))
				   {
					   System.out.println("Success");
					   count++;
				
				   }
			     }
			     if(count==3)
			     {
			    	 generateXML.logVP("5.2", "Verify Ui of Brand tab -  Overview tab screen ",	"Analysis Tab Brand View contains 3 tabs.", AppConstants.vPass);				
						pass++;
			     }
			 
			     else
			     {
			    	 generateXML.logVP("5.2", "Verify Ui of Brand tab -  Overview tab screen",	 "Analysis Tab Brand View does not contains 3 tabs.", AppConstants.vFail);		
						fail++;
			     }
			
	}

			@Test
			public void test_6() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);

				
				String selectedTab=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div[3]/div[2]/div/div[2]/div[2]")).getAttribute("class");      //BubbleChart

				if(selectedTab.equals(AnalysisTabConstants.LTR_BUBBLE_CHART) ) {
					generateXML.logVP("6.1", "Verify Ui of Brand tab -  Overview tab screen ",	"Overview tab Should be highlighted and Bubble chart is displayed.", AppConstants.vPass);				
					pass++;
				} else {
					generateXML.logVP("6.1", "Verify Ui of Brand tab -  Overview tab screen ",	 "Overview tab Should be highlighted and Bubble chart is not displayed.", AppConstants.vFail);		
					fail++;
				}
				
				
				String totalSegment	=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div[3]/div[2]/div/div/div/div/table/tbody/tr/td")).getAttribute("class");
				String avgCusSeg	=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div[3]/div[2]/div/div/div/div/table/tbody/tr/td[5]")).getAttribute("class");
				String largestSegemtn	=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div[3]/div[2]/div/div/div/div/table/tbody/tr[2]/td")).getAttribute("class");
				String smallestSegment	=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div[3]/div[2]/div/div/div/div/table/tbody/tr[2]/td[5]")).getAttribute("class");

				if((totalSegment.equals(AnalysisTabConstants.LTR_TABLE_DATA))&&(avgCusSeg.equals(AnalysisTabConstants.LTR_TABLE_DATA))&&(largestSegemtn.equals(AnalysisTabConstants.LTR_TABLE_DATA))&&(smallestSegment.equals(AnalysisTabConstants.LTR_TABLE_DATA)) ) {
					generateXML.logVP("6.2", "Verify Ui of Brand tab -  Overview tab screen ",	"The TotalSegment, AverageCustomer/Segment, Largest Segment, Smallest Segment is displayed in Bold and Black.", AppConstants.vPass);				
					pass++;
				} else {
					generateXML.logVP("6.2", "Verify Ui of Brand tab -  Overview tab screen ",	 "The TotalSegment, AverageCustomer/Segment, Largest Segment, Smallest Segment is displayed in Bold and Black.", AppConstants.vFail);		
					fail++;
				}
				
		}
			
			
			@Test
			public void test_7() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);

				HBaseUtil hbaseUtil=new HBaseUtil();
				RowFilter rwFilter = new RowFilter(CompareOp.EQUAL, new BinaryComparator(Bytes.toBytes("Brand_".toString())));
				
				List<Result> brandClusters=hbaseUtil.rowFilter("CLUSTER_INFO", rwFilter, 1);
//				String test=hbaseUtil.getQualifierValue("PRODUCT_INSIGHT", "PRODUCT_INSIGHT", "00880666000", "PRODUCT_NAME", 1);
//				 System.out.println("test**********"+test);
				String totalSegmentDisplayed=driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[3]/div[2]/div[3]/div[2]/div[1]/div[1]/div[1]/div[1]/table[1]/tbody/tr[1]/td[3]")).getText(); 
				System.out.println("BrandClusterSize="+brandClusters.size());
				System.out.println("Total Segments="+Integer.getInteger(totalSegmentDisplayed));
				if(brandClusters.size()==Integer.getInteger(totalSegmentDisplayed))  {
					generateXML.logVP("7", "Validation of Segment field values  ",	"The total segments displayed is correct.", AppConstants.vPass);				
					pass++;
				}
				else {
					generateXML.logVP("7", "Validation of Segment field values  ",	 "The total segments displayed is not correct.", AppConstants.vFail);		
					fail++;
				}
				
				
			}
			
			
			@Test
			public void test_8() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);

				// String bubbleChart=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div[3]/div[2]/div/div[2]/div[2]/svg")).getAttribute("class");
				WebElement bubbleChart=((driver).findElement(By.tagName(AnalysisTabConstants.LTR_SVG)));

 
				
				if(bubbleChart!=null)
				 {
					generateXML.logVP("8", "Validation of Bubble chart size/names/colours   in overview tab screen ",	"Bubble Chart has been verified.", AppConstants.vPass);				
					pass++;
				 }
					else
					{
						generateXML.logVP("8", "Validation of Bubble chart size/names/colours   in overview tab screen ",	 "Bubble Chart not present.", AppConstants.vFail);		
						fail++;
					}
			
			}
			@Test
			public void test_9() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);
				driver.findElement(By.xpath("//*[@id=\"list\"]")).click();
				Thread.sleep(5);
				 String listOfSegmentTab=driver.findElement(By.xpath("//*[@id=\"list\"]")).getAttribute("class");
				 if(listOfSegmentTab.equals(AnalysisTabConstants.LTR_CURRENT))
				 {
					generateXML.logVP("9.1", "Verify Ui of Brand tab -  List of segments tab  screen ",	"List of segment Tab is highlited with Orange.", AppConstants.vPass);				
					pass++;
				 }
					else
					{
						generateXML.logVP("9.1", "Verify Ui of Brand tab -  List of segments tab  screen ",	 "List of segment Tab is not highlited with Orange.", AppConstants.vFail);		
						fail++;
					}
			
				 
				 
				 String dataTableColumn1=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div[3]/div[2]/div/div/div/table/thead/tr/th")).getText();  
				 String dataTableColumn2=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div[3]/div[2]/div/div/div/table/thead/tr/th[2]")).getText();  
				 if((dataTableColumn1.equals(AnalysisTabConstants.LTR_SEGMENT_NAME))&&(dataTableColumn2.equals(AnalysisTabConstants.LTR_NUMBER_OF_CUSTOMER)))
				 {
					generateXML.logVP("9.2", "Verify Ui of Brand tab -  List of segments tab  screen ",	"Table header contains Segment Name and number Of customers.", AppConstants.vPass);				
					pass++;
				 }
					else
					{
						generateXML.logVP("9.2", "Verify Ui of Brand tab -  List of segments tab  screen ",	 "Table header does not contains Segment Name and number Of customers.", AppConstants.vFail);		
						fail++;
					}
			
				 
			}
			
			@Test
			public void test_10() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);
				
								 
				 List<WebElement> segmentNameList=driver.findElements(By.xpath(".//*[@class='dataTables_wrapper']//table//tr/*[1]/*[1]")); //verify all segment Names are hyperlinks
			    boolean isAllAnchor=true;
			     for(int i=0;i<segmentNameList.size();i++)
			     {
			    	
				   String anchor=segmentNameList.get(i).getTagName();
				   if(!anchor.equalsIgnoreCase("a"))
				   {
					   System.out.println("Success");
					   isAllAnchor=false;
				
				   }
			     }
				  
				 if(isAllAnchor)
				 {
					generateXML.logVP("10", "Verify whether Segment name is a hyperlink in the list ",	"The Segment name is hyperlink.", AppConstants.vPass);				
					pass++;
				 }
					else
					{
						generateXML.logVP("10", "Verify whether Segment name is a hyperlink in the list ",	 "The Segment name is not hyperlink.", AppConstants.vFail);		
						fail++;
					}
			
				 
			}
			
			@Test
			public void test_11() throws InterruptedException {
				
								  
				
					generateXML.logVP("11", "Segment Overview screen ",	"Refet to Segment Overview Test Cases below.", AppConstants.vPass);				
					pass++;
				 
			
				 
			}
			@Test
			public void test_12() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);
				
								 
//				 List<WebElement> segmentNameList=driver.findElements(By.xpath(".//*[@class='dataTables_wrapper']//table//tr/*[1]/*[1]")); //verify all segment Names are hyperlinks
//			    boolean isAllAnchor=true;
//			     for(int i=0;i<segmentNameList.size();i++)
//			     {
//			    	
//				   String anchor=segmentNameList.get(i).getTagName();
//				   if(!anchor.equalsIgnoreCase("a"))
//				   {
//					   System.out.println("Success");
//					   isAllAnchor=false;
//				
//				   }
//			     }
				  
//				 if(isAllAnchor)
//				 {
//					generateXML.logVP("12", "Verify whether user can click on the arrow available next to  columns of Grid",	"Yet to be implemented.", AppConstants.vPass);				
//					pass++;
//				 }
//					else
//					{
						generateXML.logVP("12", "Verify whether user can click on the arrow available next to  columns of Grid",	 "Yet to be implemented.", AppConstants.vFail);		
//						fail++;
//					}
			}
			
			@Test
			public void test_13() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);
				
								 
				 String divText=driver.findElement(By.xpath("//*[@id=\"grid-list-table_info\"]")).getText(); // text saying 'showing  n/n records ' should be displayed.
			   
			  
				  
				 if(divText.contains("Showing"))
				 {
					generateXML.logVP("13", "Verify whether the text saying 'showing  n/n records'",	"The text saying 'showing  n/n records' is present.", AppConstants.vPass);				
					pass++;
				 }
					else
					{
						generateXML.logVP("13", "Verify whether the text saying 'showing  n/n records'",	 "The text saying 'showing  n/n records' is not present.", AppConstants.vFail);		
						fail++;
					}
			}
			
			@Test
			public void test_14() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);
				
								 
				 WebElement segmentEntriesDisplaySelect=driver.findElement(By.xpath("/html/body/div/div/div[3]/div[2]/div[3]/div[2]/div/div/div/div/label/select")); // text saying 'showing  n/n records ' should be displayed.
			   
			  
				  
				 if(segmentEntriesDisplaySelect!=null)
				 {
					generateXML.logVP("14", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the bottom of the page ",	"' no of rows per page' drop down is available for the user to set and view results.", AppConstants.vPass);				
					pass++;
				 }
					else
					{
						generateXML.logVP("14", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the bottom of the page ",	 "' no of rows per page' drop down is not available for the user to set and view.", AppConstants.vFail);		
						fail++;
					}
			}
			@Test
			public void test_15() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);
				
								 
				 String nextButton=driver.findElement(By.xpath("//*[@id=\"grid-list-table_next\"]")).getText(); // text saying 'next ' should be displayed.
				 String previousButton=driver.findElement(By.xpath("//*[@id=\"grid-list-table_previous\"]")).getText();  // text saying 'previous ' should be displayed.
			  
				  
				 if(nextButton.equalsIgnoreCase("Next")&&previousButton.equalsIgnoreCase("Previous"))
				 {
					generateXML.logVP("15", "Verify Pagination-Prev and next buttons.",	"Pagination-Prev and next buttons present.", AppConstants.vPass);				
					pass++;
				 }
					else
					{
						generateXML.logVP("15", "Verify Pagination-Prev and next buttons.",	 "Pagination-Prev and next buttons not present.", AppConstants.vFail);		
						fail++;
					}
			}
			
			@Test
			public void test_16() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);
				
								 
				
				 String previousButton=driver.findElement(By.xpath("//*[@id=\"grid-list-table_previous\"]")).getAttribute("class");  // text saying 'previous ' should be displayed.
			  
				  
				 if(previousButton.equalsIgnoreCase("paginate_disabled_previous"))
				 {
					generateXML.logVP("16", "Verify Pagination- Prev button.",	"Pagination-Prev and previous buttons present.", AppConstants.vPass);				
					pass++;
				 }
					else
					{
						generateXML.logVP("16", "Verify Pagination- Prev button.",	 "Pagination-Prev and previous buttons not present.", AppConstants.vFail);		
						fail++;
					}
			}
			
			@Test
			public void test_17() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);
				
				String nextButton=driver.findElement(By.xpath("//*[@id=\"grid-list-table_next\"]")).getAttribute("class"); // text saying 'next ' should be displayed.
		  
			  
			 if(nextButton.equalsIgnoreCase("paginate_enabled_next"))
			 {
				generateXML.logVP("17", "Verify Pagination- Prev button.",	"Pagination-Prev and next buttons present.", AppConstants.vPass);				
				pass++;
			 }
				else
				{
					generateXML.logVP("17", "Verify Pagination- Prev button.",	 "Pagination-Prev and next buttons not present.", AppConstants.vFail);		
					fail++;
				}
		}
			
			@Test
			public void test_18() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);
				
				String nextButton=driver.findElement(By.xpath("//*[@id=\"grid-list-table_info\"]")).getAttribute("class"); // text saying 'next ' should be displayed.
		  
			  
			 if(nextButton.equalsIgnoreCase("dataTables_info"))
			 {
				generateXML.logVP("18", "Verify Pagination text .",	"The pagination  text saying '1 of n'is displayed.", AppConstants.vPass);				
				pass++;
			 }
				else
				{
					generateXML.logVP("18", "Verify Pagination text .",	 "The pagination  text saying '1 of n' is not displayed.", AppConstants.vFail);		
					fail++;
				}
		}
			
			@Test
			public void test_19() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);
				
				driver.findElement(By.xpath("//*[@id=\"advsearch\"]")).click(); // text saying 'next ' should be displayed.
				String AdvanceSearchTab=driver.findElement(By.xpath("//*[@id=\"advsearch\"]")).getAttribute("class"); // class of advance tab
//				WebElement submitButton=driver.findElement(By.xpath("*[@id=\"advgo\"]"));      ///// submit button of advance search tab				
//				propsRW = new PropertiesUtil(AppConstants.ANALYSIS_PROPERTIES);
			
				
				
			  
				
					if(AdvanceSearchTab.equalsIgnoreCase("current"))
					{
						generateXML.logVP("19", "Verify the user is able to click and navigate to advance search tab in the Brand screen.",	"The user has navigated to advance search tab.", AppConstants.vPass);				
						
						pass++;
					}
					
				
			 }
				
			
			@Test
			public void test_20() throws InterruptedException {
				//wait for 1 secs
				Thread.sleep(100);
				
				driver.findElement(By.xpath("//*[@id=\"advsearch\"]")).click(); // text saying 'next ' should be displayed.
				List<WebElement>searchLableList=driver.findElements(By.xpath(".//*[@class='new-search-label']")); 
				WebElement submitButton=driver.findElement(By.xpath("//*[@id=\"advgo\"]"));      ///// submit button of advance search tab				
				propsRW = new PropertiesUtil(AppConstants.ANALYSIS_PROPERTIES);
			
				
				String AnalysisTabAdvanceSearchLabel1=(propsRW.read(AnalysisTabConstants.LTR_ANALYSISADVANCESEARCHLABEL1).trim());
				String AnalysisTabAdvanceSearchLabel2=(propsRW.read(AnalysisTabConstants.LTR_ANALYSISADVANCESEARCHLABEL2).trim());
				String AnalysisTabAdvanceSearchLabel3=(propsRW.read(AnalysisTabConstants.LTR_ANALYSISADVANCESEARCHLABEL3).trim());
				String AnalysisTabAdvanceSearchLabel4=(propsRW.read(AnalysisTabConstants.LTR_ANALYSISADVANCESEARCHLABEL4).trim());
				String AnalysisTabAdvanceSearchLabel5=(propsRW.read(AnalysisTabConstants.LTR_ANALYSISADVANCESEARCHLABEL5).trim());
			  
				boolean testPassed=false;
				for(WebElement AdvSearchLabel:searchLableList)
				{
					if(AdvSearchLabel.getText().equalsIgnoreCase(AnalysisTabAdvanceSearchLabel1))
					{
						generateXML.logVP("20.1", "Verify the user is able to click and navigate to advance search tab in the Brand screen.",	"The segment Id label is present.", AppConstants.vPass);				
						testPassed=true;
						pass++;
					}
					if(AdvSearchLabel.getText().equalsIgnoreCase(AnalysisTabAdvanceSearchLabel2))
					{
						generateXML.logVP("20.2", "Verify the user is able to click and navigate to advance search tab.",	"The segment Name label is present.", AppConstants.vPass);				
						testPassed=true;
						pass++;
					}
					if(AdvSearchLabel.getText().equalsIgnoreCase(AnalysisTabAdvanceSearchLabel3))
					{
						generateXML.logVP("20.3", "Verify the user is able to click and navigate to advance search tab.",	"The Brand label is present.", AppConstants.vPass);				
						testPassed=true;
						pass++;
					}
					if(AdvSearchLabel.getText().equalsIgnoreCase(AnalysisTabAdvanceSearchLabel4))
					{
						generateXML.logVP("20.4", "Verify the user is able to click and navigate to advance search tab.",	"The Affinity Rank label is present.", AppConstants.vPass);				
						testPassed=true;
						pass++;
					}
					if(AdvSearchLabel.getText().equalsIgnoreCase(AnalysisTabAdvanceSearchLabel5))
					{
						generateXML.logVP("20.5", "Verify the user is able to click and navigate to advance search tab.",	"The Affinity Score label is present.", AppConstants.vPass);				
						testPassed=true;
						pass++;
					}
				}
				
				if(submitButton!=null)
				{
					generateXML.logVP("20.6", "Verify the user is able to click and navigate to advance search tab.",	"The GO(submit) button is present.", AppConstants.vPass);				
					testPassed=true;
					pass++;
				}
				
			 if(!testPassed)
			 {
				generateXML.logVP("20", "Verify the user is able to click and navigate to advance search tab in the Brand screen .",	"User not able to navigate to Advance search Tab.", AppConstants.vPass);				
				pass++;
			 }
				
				
		}
			
			
						
}
//////////////test case 7 , 8,12
