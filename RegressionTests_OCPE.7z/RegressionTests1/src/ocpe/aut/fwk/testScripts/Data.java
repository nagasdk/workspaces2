package ocpe.aut.fwk.testScripts;

//imported classes
import static org.junit.Assert.fail;

import java.io.File;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.constants.DataConstants;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.PropertiesUtil;
import ocpe.aut.fwk.util.HBaseUtil;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * Data tab test cases
 * @author Devalanka_Pavani
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Data {

	private static StringBuffer verificationErrors = new StringBuffer();

	private static WebDriver driver;
	static DesiredCapabilities cap = null; static FirefoxBinary ffBinary = null; static FirefoxProfile ffprofile = null;

	private static GenerateXml generateXML;
	private static GenerateHTML generateReport;

	static int pass= 0,fail = 0, notRun = 0;

	private static PropertiesUtil propsRW;
	private static ExcelUtil excelRW;
	private static String pageName;
	/**
	 * One time set up for Data.java
	 */
	@BeforeClass
	public static void oneTimeSetUp() {
		// one-time initialization code   
		System.out.println("@BeforeClass - oneTimeSetUp");
		File  pathToFirefoxBinary = new File(AppConstants.PATH_TO_FIREFOX_BINARY);
		ffBinary = new FirefoxBinary(pathToFirefoxBinary);
		ProfilesIni profile = new ProfilesIni();		   		   
		ffprofile = profile.getProfile(AppConstants.FIREFOX_PROFILE_DEFAULT);
		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();		  		  
		proxy.setProxyAutoconfigUrl(AppConstants.PROXY_URL);	
		cap = new DesiredCapabilities();		  
		cap.setCapability(CapabilityType.PROXY, proxy);				

		driver = new FirefoxDriver(ffBinary,ffprofile,cap);		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(AppConstants.BASE_URL + AppConstants.LOGIN_URL);

		generateXML = new GenerateXml();		
		generateReport = new GenerateHTML();		
		excelRW = new ExcelUtil(); 

		//Change the xml file path according to name of the script
		AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER+AppConstants.FORWARD_SLASH+AppConstants.DATA+AppConstants.DOT_XML;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.DATA_PROPERTIES;		

		//Sheet Name of excel from where the xpath values are fetched
		pageName = AppConstants.DATA_TAB;

		//Create a new XML file
		generateXML.createVPXML(AppConstants.DATA_SCRIPT_NAME);

		//Login
		/*Firefox browser gets opened with OCPE Login page, provide 
		 * with username rg@gmail.com and click on submit button.
		 * After login, Data tab selected with it's first side menu highlighted */

		/*Clear the User Name textbox*/
		String xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE, AppConstants.USER_NAME);
		driver.findElement(By.xpath(xpathExpression)).clear();

		propsRW = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);

		/* Get valid username from properties file
		 * ex: rg@gmail.com*/
		String userName = propsRW.read(AppConstants.VALID_USERNAME).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(userName);


		/* Clear the Password textbox*/
		xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE, AppConstants.PASSWORD);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid password from properties file
		 * ex: Aham123+*/
		String password = propsRW.read(AppConstants.VALID_PASSWORD).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(password);


		/*Click on login button*/
		xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE, AppConstants.LOGIN_SUBMIT);		
		driver.findElement(By.xpath(xpathExpression)).click();


	}

	/**
	 * One time set up for each method annotated with @Test annotation 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {

	}

	/**
	 * This method is used to check whether after login, Data tab is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_1() throws Exception {		

		//wait for 4 secs
		Thread.sleep(4000);

		//Check whether Data tab is selected or not
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TAB_DATA);
		String selectedTab  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedTab.equals(DataConstants.DATA_TAB_NAME) ) {
			generateXML.logVP("1", "Check whether after login, Data tab is selected or not",	"After login Data tab is selected", AppConstants.vPass);				

		} else {
			generateXML.logVP("1", "Check whether after login, Data tab is selected or not",	 "After login Data tab is not selected", AppConstants.vFail);		

		}		 		

	}

	/**This method is used to check data tab screen should be displayed with a left Menu with the following 4 options :
	1. Customers [ Hyper link][default]
	2. Catalog[ Hyper link]
	3.Activities[ Hyper link]
	4.Scribe[ Hyper link]


	All hper links should be blue in color and upon clicking should be highlighted in gray color with an orange slide  next to it
	"
	 **
	 */
	@Test
	public void test_2() throws Exception {

		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.MENU_CUSTOMERS))).click();
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.MENU_CUSTOMERS);
		String selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		propsRW = new PropertiesUtil(AppConstants.DATA_PROPERTIES);
		if(selectedMenu.equals(propsRW.read(DataConstants.MENU_CUSTOMERS)) ) {
			generateXML.logVP("3", "After selecting Data tab, check whether Customers menu is by default selected or not",	"After selecting Data tab, by default Customers menu is selected", AppConstants.vPass);				

		} else {
			generateXML.logVP("3", "After selecting Data tab, check whether Customers menu is by default selected or not",	"After selecting Data tab, by default Customers menu is not selected", AppConstants.vFail);		

		}
		/*start of sidemenu items- text*/
		List<WebElement> sideMenuItemsText=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SIDEMENU))); //verify all left menu items
		int textCount=0;
		for(int i=0;i<sideMenuItemsText.size();i++){
			String text=sideMenuItemsText.get(i).getText();
			if(text.equalsIgnoreCase("Customers")|| text.equalsIgnoreCase("Catalog")||text.equalsIgnoreCase("Activities")||text.equalsIgnoreCase("Scribe")){
				textCount++;
			}
		}
		if(textCount==4)
		{
			generateXML.logVP("2.1" ,"check data tab screen should be displayed with a left Menu with the following 4 options :	1. Customers [ Hyper link][default]	2. Catalog[ Hyper link]	3.Activities[ Hyper link]	4.Scribe[ Hyper link]",
					"data tab screen is displayed with a left Menu having the 4 options", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("2.1" ,"check data tab screen should be displayed with a left Menu with the following 4 options :	1. Customers [ Hyper link][default]	2. Catalog[ Hyper link]	3.Activities[ Hyper link]	4.Scribe[ Hyper link]",
					"data tab screen is not displayed with a left Menu having the 4 options", AppConstants.vFail);
		}
		/*end of sidemenu items - text*/

		/*start of left menu items -- hyperlink*/
		List<WebElement> sideMenuList=driver.findElements(By.xpath(ExcelUtil.readProps(pageName,  DataConstants.SIDEMENU))); //verify all left menu items are hyperlinks
		int count=0;
		for(int i=0;i<sideMenuList.size();i=i+2){

			String anchor=sideMenuList.get(i).getTagName();
			if(anchor.equalsIgnoreCase("a")){
				//			   /System.out.println("Success");
				count++;
			}
		}

		if(count==4)
		{
			generateXML.logVP("2.2" ,"check data tab screen should be displayed with hyperlinks",
					"data tab screen is displayed with hyperlinks", AppConstants.vPass);
		}

		else
		{
			generateXML.logVP("2.2" ,"check data tab screen should be displayed with hyperlinks",
					"data tab screen is not displayed with hyperlinks", AppConstants.vFail);
		}
		/*end of side menu items -- hyperlinks*/

		/*start of sidemenu clicks and verifying css*/

		List<WebElement> sideMenuElements=driver.findElements(By.className("nochild")); 
		int sideMenuColorCount=0;
		System.out.println();
		for(int j=0;j<sideMenuElements.size();j++){
			sideMenuElements.get(j).click();
			String classArray[]=sideMenuElements.get(j).getAttribute("class").split(" ");
			for(String classElement:classArray){
				System.out.println(classElement+"sideMenuElements.size()"+sideMenuElements.size());
				if(classElement.equalsIgnoreCase("activeList")){
					sideMenuColorCount++;
				}
			}
		}
		System.out.println(sideMenuColorCount);
		if(sideMenuColorCount==4){
			generateXML.logVP("2.3" ,"verify if left menu items are changing their background up on click ",
					"all leftmenu items are highlighted upon clicking", AppConstants.vPass);
		}

		else
		{ generateXML.logVP("2.3" ,"verify if left menu items are changing their background up on click ",
				"all leftmenu items are not highlighted upon clicking", AppConstants.vFail);
		}


		/*end of sidemenu clicks and verifying css*/


		/*start of sidemenu clicks and verifying slide color  css*/

		List<WebElement> slideColorItems=driver.findElements(By.xpath(ExcelUtil.readProps(pageName,  DataConstants.SIDEMENU)));
		int slideColorCount=0;
		for(int j=0;j<slideColorItems.size();j++){
			slideColorItems.get(j).click();
			String classArray[]=slideColorItems.get(j).getAttribute("class").split(" ");
			for(String classElement:classArray)
				if(classElement.equalsIgnoreCase("activeSpan")){
					slideColorCount++;
				}
		}
		if(slideColorCount==4){
			generateXML.logVP("2.4", " verify orange slide is shown next to the left menu items upon clicking up on click", "orange slide is shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("2.4", " verify orange slide is shown next to the left menu items upon clicking up on click ", "orange slide is not shown", AppConstants.vFail);

		}
		/*end of sidemenu clicks and verifying slide color css*/


	}

	/**
	 * This method is used to check after successful login.
	 * Click on Data tab, check whether Customers menu is by default selected or not"
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_3() throws Exception {
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.MENU_CUSTOMERS))).click();
		//Check whether Data tab is selected or not
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.MENU_CUSTOMERS);
		String selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		propsRW = new PropertiesUtil(AppConstants.DATA_PROPERTIES);
		if(selectedMenu.equals(propsRW.read(DataConstants.MENU_CUSTOMERS)) ) {
			generateXML.logVP("2", "After selecting Data tab, check whether Customers menu is by default selected or not",	"After selecting Data tab, by default Customers menu is selected", AppConstants.vPass);				

		} else {
			generateXML.logVP("2", "After selecting Data tab, check whether Customers menu is by default selected or not",	"After selecting Data tab, by default Customers menu is not selected", AppConstants.vFail);		

		}

	}


	/**
	 * This method is used to check The data tab, customers submenu,
	 * it should be displayed  with following 5 sections on number of customers :
	1.Customer Distribution 
	2.Personalization funnel
	3.Active customers-channel view
	4.Customer-Percentile Activities
	5.RFM Global Customer Chart
	 **/
	@Test
	public void test_4() throws Exception {
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.MENU_CUSTOMERS))).click();
		// List<WebElement> sections=driver.findElements(By.cssSelector(excelRW.readProps(pageName, DataConstants.CUSTOMERS_SECTIONS)));
		/*start of CUSTOMERS_SECTIONS items- text*/
		String selector = ExcelUtil.readProps(pageName, DataConstants.CUSTOMERS_SECTIONS);
		List<WebElement> sections = driver.findElements(By.className(ExcelUtil.readProps(pageName,DataConstants.PARENT_GROOVE)));

		int textCount=0;
		for(int i=0;i<sections.size();i++){
			String text=sections.get(i).findElement(By.className(selector)).getText();
			System.out.println(sections.size()+"  sideMenuItemsText.size()123"+text);
			if(text.equalsIgnoreCase("Customer Distribution")|| text.equalsIgnoreCase("Personalization Funnel")||text.equalsIgnoreCase("Active Customers - Channel View")||text.equalsIgnoreCase("Customer Percentile Activities")||text.equalsIgnoreCase("RFM Global Customer Chart")){
				textCount++;
			}
		}
		if(textCount==5)
		{
			generateXML.logVP("4.1" ,"This method is used to check The data tab, customers submenu sections",
					" customers submenu with the sections were displayed", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("4.1" ,"This method is used to check The data tab, customers submenu sections",
					" customers submenu with the sections were not displayed", AppConstants.vFail);
		}	      /*end of CUSTOMERS_SECTIONS items - text*/

	}


	/**
	 * This method is used to check Customer Distribution section with,
1.Title 'Customer Distribution 'in Bold and black in color 
2.A Pie chart with a proportion of Anonymous against Registered customers in top left corner 
3.Anonymous customers area should be shown in Orange colour and Registered customers  in  green colour
4.Upon mouse hover,system should display the indicator/edit box with a label 'Anonymous'  in Bold and black in color  with its percentage .
5.The values must be shown with comma seperated for thousand and crores
6.The legend should be shown for Anonymous with orange and registered with Green
	 * @throws Exception
	 */
	@Test
	public void test_5() throws Exception {
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.MENU_CUSTOMERS))).click();
		//Check whether Data tab is selected or not

		String selector = ExcelUtil.readProps(pageName, DataConstants.CUSTOMERS_SECTIONS);

		List<WebElement> sections = driver.findElements(By.className(ExcelUtil.readProps(pageName,DataConstants.PARENT_GROOVE)));
		System.out.println(sections.get(0).findElement(By.className(selector)).getCssValue("color"));
		String color = sections.get(0).findElement(By.className(selector)).getCssValue("color");
		String fontWeight =  sections.get(0).findElement(By.className(selector)).getCssValue("font-weight");
		String str = color.replace("rgba(", "").replace(")", "");
		String verifyColor ="61, 70, 90, 1";
		if (fontWeight.equals("bold") || fontWeight.equals("700")) {
			generateXML.logVP("5.1" ,"This method is used to check if Customer Distribution is Bold ",
					"Customer Distribution is in Bold ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("5.1" ,"This method is used to check if Customer Distribution is Bold ",
					"Customer Distribution is not in Bold ", AppConstants.vFail);
		}	      
		if(str.equals(verifyColor)){
			generateXML.logVP("5.2" ,"This method is used to check if Customer Distribution is black ",
					"Customer Distribution is in black ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("5.2" ,"This method is used to check if Customer Distribution is black ",
					"Customer Distribution is not in black ", AppConstants.vFail);
		}	      


		HBaseUtil x = new HBaseUtil(); 
		String registered = x.getQualifierValue("AHAM_DASHBOARD","DATA","CUSTOMERS","registered",1);
		String guest = x.getQualifierValue("AHAM_DASHBOARD","DATA","CUSTOMERS","guest",1);
		Integer TotalCustomers = Integer.parseInt(registered) + Integer.parseInt(guest);
		Integer registeredPerc = Math.round((Float.parseFloat(registered)/TotalCustomers)*100);
		Integer guestPerc = Math.round((Float.parseFloat(guest)/TotalCustomers)*100);

		NumberFormat n = NumberFormat.getInstance(); 
		String guestFormat = n.format(Float.parseFloat(guest));
		String regFormat = n.format(Float.parseFloat(registered));

		String Anonymous = ("Anonymous ").concat(guestFormat).concat(guestPerc.toString()+"%");
		String registeredUsers = ("Registered ").concat(regFormat).concat(registeredPerc.toString()+"%");



		String customerDistribution = ExcelUtil.readProps(pageName, DataConstants.CUSTOMER_DISTRIBUTION);
		WebElement dataCustDis  = driver.findElement(By.id(customerDistribution));
		if(dataCustDis.findElement(By.className("arc")).getText().equals(Anonymous)){
			generateXML.logVP("5.3" ,"This method is used to check  Customer Distribution piechart  ",
					"Customer Distribution piechart is displayed ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("5.3" ,"This method is used to check Customer Distribution piechart ",
					"Customer Distribution piechart is not displayed ", AppConstants.vFail);
		}	
		String customerDistributionXpath = ExcelUtil.readProps(pageName, DataConstants.CUSTOMER_DISTRIBUTION_XPATh);
		WebElement dataCD  = driver.findElement(By.xpath(customerDistributionXpath));

		System.out.println(dataCD.getText()+"  ----------------------");
		if(dataCD.getText().contains(registeredUsers)){
			generateXML.logVP("5.4" ,"This method is used to check Customer Distribution piechart registeredUsers  ",
					"Customer Distribution piechart registeredUsers is displayed ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("5.4" ,"This method is used to check Customer Distribution piechart registeredUsers ",
					"Customer Distribution piechart  registeredUsers is not displayed ", AppConstants.vFail);
		}	

	}



	/**
	 * This method is used to check if the values in Hbase table
	 * is same as the one displayed on Bussiness console
	 * 
	 * @throws Exception
	 */
	@Test
	public void test_6() throws Exception {
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.MENU_CUSTOMERS))).click();
		HBaseUtil x = new HBaseUtil(); 
		String registered = x.getQualifierValue("AHAM_DASHBOARD","DATA","CUSTOMERS","registered",1);
		String guest = x.getQualifierValue("AHAM_DASHBOARD","DATA","CUSTOMERS","guest",1);
		Integer TotalCustomers = Integer.parseInt(registered) + Integer.parseInt(guest);

		float fltRegisteredPerc= ( Float.parseFloat(registered)/TotalCustomers) * 100;
		Integer registeredPerc = (int)fltRegisteredPerc;
		float fltGuestPerc= ((  Float.parseFloat(guest)/TotalCustomers)* 100);
		Integer guestPerc = (int) fltGuestPerc;

		System.out.println(guestPerc+"guestPerc "+ registeredPerc+" registered"+Float.parseFloat(registered)+"::  "+TotalCustomers);
		String customerDistribution = ExcelUtil.readProps(pageName, DataConstants.CUSTOMER_DISTRIBUTION);
		WebElement dataCD  = driver.findElement(By.id(customerDistribution));
		System.out.println(dataCD.findElement(By.tagName("text")).getText()+"  kashdlk " +guestPerc.toString());

		if((guestPerc.toString()+"%").equals(dataCD.findElement(By.tagName("text")).getText())){
			generateXML.logVP("6.1" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Customer Distribution piechart", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("6.1" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Customer Distribution piechart ", AppConstants.vFail);
		}

		if(dataCD.getText().contains((registeredPerc.toString()+"%")))
			if((guestPerc.toString()+"%").equals(dataCD.findElement(By.tagName("text")).getText())){
				generateXML.logVP("6.2" ,"This method is used to check if values in Hbase table is same as " +
						"the one displayed on Bussiness console  ",
						"valid data is displayed in Customer Distribution piechart", AppConstants.vPass);
			}
			else
			{
				generateXML.logVP("6.2" ,"This method is used to check if values in Hbase table is same as " +
						"the one displayed on Bussiness console  ",
						"valid data is not displayed in Customer Distribution piechart ", AppConstants.vFail);
			}

	}
	/***
	 *
1. Personalisation Funnel section should be displayed with title 'Personalization Funnel' in bold and black in colour 
2.Histogram graphical display  for number of  Registered Customers/number of Active Customers and the number of customers 
for whom recommendations (Top Picks) have been generated in Y-axis Vs Total number of customers in xaxis 
3.The Bar graph should be shown with the indicator and edit box with Label as type of customer 
(say Registered Customers or Active Customers or Recommendations  )in Bold ,black in color with value 
4. The bars in the graph should be displayed orange green and blue colour with gray line for x and Y axis
	 * 
	 * */
	@Test
	public void test_7() throws Exception {
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.MENU_CUSTOMERS))).click();
		String selector = ExcelUtil.readProps(pageName, DataConstants.CUSTOMERS_SECTIONS);
		List<WebElement> sections = driver.findElements(By.className(ExcelUtil.readProps(pageName,DataConstants.PARENT_GROOVE)));
		String color = sections.get(1).findElement(By.className(selector)).getCssValue("color");
		String fontWeight =  sections.get(1).findElement(By.className(selector)).getCssValue("font-weight");
		System.out.println(color+"color");
		String str = color.replace("rgba(", "").replace(")", "");
		String verifyColor ="61, 70, 90, 1";
		//System.out.println(sections.get(1).getText()+" sections.get(1)");
		if (fontWeight.equals("bold") || fontWeight.equals("700")) {
			generateXML.logVP("7.1" ,"This method is used to check if Personalisation Funnel is Bold ",
					"Personalisation Funnel is in Bold ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("7.1" ,"This method is used to check if Personalisation Funnel is Bold ",
					"Personalisation Funnel is not in Bold ", AppConstants.vFail);
		}	      
		if(str.equals(verifyColor)){
			generateXML.logVP("7.2" ,"This method is used to check if Personalisation Funnel is black ",
					"Personalisation Funnel is in black ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("7.2" ,"This method is used to check if Personalisation Funnel is black ",
					"Personalisation Funnel is not in black ", AppConstants.vFail);
		}	      



		List<WebElement> personalisationFunnel = driver.findElements(By.className("nv-bar"));
		ArrayList<String> valueList = new ArrayList<String>();
		valueList.add("366968");
		valueList.add("128755");
		valueList.add("128755");
		int colCount = 0;
		for(int i=0;i<personalisationFunnel.size();i++){
			String text = personalisationFunnel.get(i).getText();
			String pieColor =  personalisationFunnel.get(i).getCssValue("fill");
			System.out.println(pieColor+"pieColor" +text);
			String pieCol = pieColor.replace("rgb(", "").replace(")", "");
			if(
					pieCol.equals("247, 142, 30") ||
					pieCol.equals("105, 190, 40") ||
					pieCol.equals("71, 186, 235")
					){
				colCount++;
			}

			String count = "7."+i;
			if(text.equals(valueList.get(i))){
				generateXML.logVP( count,"This method is used to check Personalisation Funnel ",
						"Personalisation Funnel is displayed properly ", AppConstants.vPass);
			}
			else
			{
				generateXML.logVP(count ,"This method is used to check Personalisation Funnel ",
						"Personalisation Funnel is not displayed properly", AppConstants.vFail);
			}	
		}
		if(colCount == 3){
			generateXML.logVP( "7.5","This method is used to check Personalisation Funnel colors",
					"Personalisation Funnel colors is displayed properly ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("7.5" ,"This method is used to check Personalisation Funnel colors",
					"Personalisation Funnel colors is not displayed properly", AppConstants.vFail);
		}
		String Funnel = ExcelUtil.readProps(pageName, DataConstants.FUNNEL_ID);
		WebElement funnelId= driver.findElement(By.id(Funnel));
		List<WebElement> personalisationFunnelpie = funnelId.findElements(By.className("major"));
		int countpie = 0;
		for(int i=0;i<personalisationFunnelpie.size();i++){
			String text=personalisationFunnelpie.get(i).getText();
			if( text.equals("Registered Customers")||
					text.equals("Recommendations")||
					text.equals("Active Customers")){
				countpie++;
			}
		}
		if(countpie == 3){
			generateXML.logVP( "7.4","This method is used to check Personalisation Funnel y axis",
					"Personalisation Funnel y axis is displayed properly ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("7.4" ,"This method is used to check Personalisation Funnel y axis",
					"Personalisation Funnel y axis is not displayed properly", AppConstants.vFail);
		}	




	}


	/**
	 * This method is used to check if the values in Hbase table
	 * is same as the one displayed on Bussiness console
	 * 
	 * @throws Exception
	 */
	@Test
	public void test_8() throws Exception {
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.MENU_CUSTOMERS))).click();
		HBaseUtil x = new HBaseUtil(); 
		String registered_wt = x.getQualifierValue("AHAM_DASHBOARD","DATA","CUSTOMERS","registered_wt_purc",1);
		String registered = x.getQualifierValue("AHAM_DASHBOARD","DATA","CUSTOMERS","registered",1);
		String recomended = x.getQualifierValue("AHAM_DASHBOARD","DATA","CUSTOMERS","recommendations",1);

		List<WebElement> personalisationFunnel = driver.findElements(By.className("nv-bar"));
		ArrayList<String> valueList = new ArrayList<String>();
		valueList.add(registered);
		valueList.add(recomended);
		valueList.add(registered_wt);
		int colCount = 0;
		for(int i=0;i<personalisationFunnel.size();i++){
			String text = personalisationFunnel.get(i).getText();
			if(text.equals(valueList.get(i))){
				colCount++;
			}
		}
		if(colCount == 3){
			generateXML.logVP( "8","This method is used to check Personalisation Funnel values",
					"Personalisation Funnel values is displayed properly ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("8" ,"This method is used to check Personalisation Funnel values",
					"Personalisation Funnel values is not displayed properly", AppConstants.vFail);
		}

	}

	/**
	 * 
	 * 1)Active Customers-channel view should be displayed with title 'Active customers-channel view' title in bold and black highlighted in blue.
2)A pie chart showing the percentage of active customers in various channels is displayed with respective colors.
3)the legend of the chart is shown with various channels and respective colors shown on pie chart.
	 */
	@Test
	public void test_9() throws Exception {
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.MENU_CUSTOMERS))).click();
		String selector = ExcelUtil.readProps(pageName, DataConstants.CUSTOMERS_SECTIONS);
		List<WebElement> sections = driver.findElements(By.className(ExcelUtil.readProps(pageName, DataConstants.PARENT_GROOVE)));
		String color = sections.get(2).findElement(By.className(selector)).getCssValue("color");
		String fontWeight =  sections.get(2).findElement(By.className(selector)).getCssValue("font-weight");
		String str = color.replace("rgba(", "").replace(")", "");
		String verifyColor ="61, 70, 90, 1";
		//System.out.println(sections.get(1).getText()+" sections.get(1)");
		if (fontWeight.equals("bold") || fontWeight.equals("700")) {
			generateXML.logVP("9.1" ,"This method is used to check if Active Customers-channel view is Bold ",
					"Active Customers-channel view is in Bold ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("9.1" ,"This method is used to check if Active Customers-channel view is Bold ",
					"Active Customers-channel view is not in Bold ", AppConstants.vFail);
		}	      
		if(str.equals(verifyColor)){
			generateXML.logVP("9.2" ,"This method is used to check if Active Customers-channel view is black ",
					"Active Customers-channel view is in black ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("9.2" ,"This method is used to check if Active Customers-channel view is black ",
					"Active Customers-channel view is not in black ", AppConstants.vFail);
		}	      
		String channelViewlegend = ExcelUtil.readProps(pageName, DataConstants.CHANNELVIEW_LEGEND);
		WebElement legendsId = driver.findElement(By.id(channelViewlegend));
		List<WebElement> legends = legendsId.findElements(By.tagName("g"));
		int count = 0;
		for(int i=0;i<legends.size();i++){
			//  System.out.println(legends.get(i).getText());
			if(legends.get(i).getText().equals("Web Only")||
					legends.get(i).getText().equals("Store Only")||
					legends.get(i).getText().equals("Both")
					){
				count++;
			}
		}
		if(count == 3){
			generateXML.logVP( "9.3","This method is used to check Personalisation Funnel values",
					"Personalisation Funnel values is displayed properly ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("9.3" ,"This method is used to check Personalisation Funnel values",
					"Personalisation Funnel values is not displayed properly", AppConstants.vFail);
		}


	}

	/**
	 * 
	1.Customer Percentile Purchases section should be displayed with Title
	 'Customer -Percentile Purchases' in bold and black in colour 
	2.  A  Graph should be displayed with the purchased of all customers as 
	percentile.The  number of total purchases in Y-axis and number of customers 
	normalized to 100 X-axis.
	3.the graph should also show the activities of all the customers as percentile.
	The  number of total purchases in Y-axis and number of customers normalized to 100 X-axis
	3. The graph should be displayed orange in colour and with gray lines for  X and Y axis
	4. The legend for the graph should have' value' 'indicated with orange colour

	 */
	@Test
	public void test_A_1() throws Exception {
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.MENU_CUSTOMERS))).click();
		String selector = ExcelUtil.readProps(pageName, DataConstants.CUSTOMERS_SECTIONS);
		List<WebElement> sections = driver.findElements(By.className(ExcelUtil.readProps(pageName, DataConstants.PARENT_GROOVE)));
		String color = sections.get(3).findElement(By.className(selector)).getCssValue("color");
		String fontWeight =  sections.get(3).findElement(By.className(selector)).getCssValue("font-weight");
		String str = color.replace("rgba(", "").replace(")", "");
		String verifyColor ="61, 70, 90, 1";
		//System.out.println(sections.get(1).getText()+" sections.get(1)");
		if (fontWeight.equals("bold") || fontWeight.equals("700")) {
			generateXML.logVP("10.1" ,"This method is used to check if Customer Percentile Activities is in Bold",
					"Customer Percentile Activities  is in Bold ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("10.1" ,"This method is used to check if Customer Percentile Activities is in Bold",
					"Customer Percentile Activities is not in Bold ", AppConstants.vFail);
		}	      
		if(str.equals(verifyColor)){
			generateXML.logVP("10.2" ,"This method is used to check if Customer Percentile Activities is black ",
					"Customer Percentile Activities is in black ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("10.2" ,"This method is used to check if Customer Percentile Activities is black ",
					"Customer Percentile Activitiesis not in black ", AppConstants.vFail);
		}	      

		String areaChartLegend = ExcelUtil.readProps(pageName, DataConstants.AREA_CHART_LEGEND);
		WebElement legendsId = driver.findElement(By.id(areaChartLegend));
		List<WebElement> legends = legendsId.findElements(By.tagName("g"));
		int count = 0;
		for(int i=0;i<legends.size();i++){
			if(legends.get(i).getText().equals("Activities")||
					legends.get(i).getText().equals("Purchases")
					){
				count++;
			}
		}
		if(count ==2){
			generateXML.logVP( "10.3","This method is used to check  Customer Percentile Activities values",
					"Personalisation Funnel values is displayed properly ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("10.3" ,"This method is used to check  Customer Percentile Activities values",
					"Personalisation Funnel values is not displayed properly", AppConstants.vFail);
		}
		String chart = ExcelUtil.readProps(pageName, DataConstants.CHART); 
		WebElement chartCol = driver.findElement(By.id(chart));
		WebElement chartCol1 = chartCol.findElement(By.tagName("svg"));
		List<WebElement>  chartColour = chartCol1.findElements(By.tagName("path"));
		int counter = 0 ;
		for(int i =0 ; i<chartColour.size();i++){
			//chartColour.get(i).findElement(By.tagName("path")).getCssValue("fill");
			String areaColor = chartColour.get(i).getCssValue("fill").replace("rgba(", "").replace(")", "");
			if(areaColor.equals("247, 142, 30")||areaColor.equals("105, 190, 40")){
				counter++;
			}
		}
		if(count == 2){
			generateXML.logVP( "10.4","This method is used to check  Customer Percentile Activities chart area valuea",
					"Personalisation Funnel area values is displayed properly ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("10.4" ,"This method is used to check  Customer Percentile Activities area values",
					"Personalisation Funnel area values is not displayed properly", AppConstants.vFail);
		}



	}


	/** test case 12 and 13
	 * This method is used to check if the values in Hbase table
	 * is same as the one displayed on Bussiness console for area chart
	 * 
	 * @throws Exception
	 */
	@Test
	public void test_A_2() throws Exception {
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.MENU_CUSTOMERS))).click();
		HBaseUtil x = new HBaseUtil(); 
		String registered_wt = x.getQualifierValue("AHAM_DASHBOARD","DATA","CUSTOMERS","percentile_activity_total",1);
		String registered = x.getQualifierValue("AHAM_DASHBOARD","DATA","CUSTOMERS","percentile_reg_purc",1);
		String chart = ExcelUtil.readProps(pageName, DataConstants.CHART);
		List<WebElement> areaChart = driver.findElement(By.id(chart)).findElement(By.tagName("svg")).findElements(By.tagName("rect"));
		List<WebElement> areaChartWt = driver.findElement(By.id(chart)).findElement(By.tagName("svg")).findElements(By.tagName("circle"));
		int colCountReg = 0;
		int colCountRegWt = 0;
		String[] registeredArray = registered.replace("[", "").replace("]","").split(",");
		String[] registered_wtArray = registered_wt.replace("[", "").replace("]","").split(",");
		for(int i=0;i<areaChart.size();i++){
			WebElement text = areaChart.get(i);
			String[] arrayText=text.getText().replace("value Stat:", "").split(",");

			if((Math.round(Float.parseFloat(arrayText[1])) == Math.round(Float.parseFloat(registeredArray[i])))){
				colCountReg++;
			}
			/* 	if(text.equals(valueList.get(i))){
		   		colCount++;
		   	}*/
		}
		for(int i=0;i<areaChartWt.size();i++){
			WebElement text = areaChartWt.get(i);
			String[] arrayText=text.getText().replace("value Stat:", "").split(",");
			if((Math.round(Float.parseFloat(arrayText[1])) == Math.round(Float.parseFloat(registered_wtArray[i])))){
				colCountRegWt++;
			}
			/* 	if(text.equals(valueList.get(i))){
			   		colCount++;
			   	}*/
		}


		if((colCountReg == areaChart.size()) && (colCountRegWt == areaChartWt.size())){
			generateXML.logVP( "12","This method is used to check area chart values",
					"area chart values is displayed properly ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("12" ,"This method is used to check area chart  values",
					"area chart values is not displayed properly", AppConstants.vFail);
		}

	}
	// catalog sub menu
	/***
	 * Catalog Screen should be displayed with following:
	1.product-channel view section should be displayed with title bold/black highlighted in blue
	and Total Common Products title and value seperated by colon on the top left corner under header.
	2.chart representing different channels on y-axis and no of products on x-axis should be
	 shown in respective colors.the legend for the chart should be shown for various channel with
	  respective colors shown on the chart.

	 ***/
	@Test
	public void test_A_3() throws Exception{
		String catalogPath = ExcelUtil.readProps(pageName, DataConstants.SIDEMENU_CATALOG);
		driver.findElement(By.xpath(catalogPath)).click();
		List<WebElement> catalogSubHeadder = driver.findElements(By.className("parentGroove"));
		System.out.println(catalogSubHeadder.get(0).findElement(By.className("newheader")).getText());

		if (catalogSubHeadder.get(0).findElement(By.className("newheader")).getText().equals("Product - Channel View")) {
			generateXML.logVP("13.1" ,"This method is used to check if product-channel view section",
					"product-channel view section  is displayed ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("13.1" ,"This method is used to check if product-channel view section",
					"product-channel view section is not displayed ", AppConstants.vFail);
		}

		WebElement sections= catalogSubHeadder.get(0).findElement(By.className("newheader"));
		String color = sections.getCssValue("color");
		String fontWeight =  sections.getCssValue("font-weight");
		String str = color.replace("rgba(", "").replace(")", "");
		String verifyColor ="61, 70, 90, 1";
		if (fontWeight.equals("bold") || fontWeight.equals("700")) {
			generateXML.logVP("13.2" ,"This method is used to check if product-channel view section is in Bold",
					"product-channel view section  is in Bold ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("13.2" ,"This method is used to check if product-channel view section is in Bold",
					"product-channel view section is not in Bold ", AppConstants.vFail);
		}	      
		if(str.equals(verifyColor)){
			generateXML.logVP("13.3" ,"This method is used to check if product-channel view section is black ",
					"product-channel view section is in black ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("13.3" ,"This method is used to check if product-channel view section is black ",
					"product-channel view sectionis not in black ", AppConstants.vFail);
		}	
		WebElement TotalCommonProducts = driver.findElement(By.className("grooveheader"));
		HBaseUtil x = new HBaseUtil(); 
		String TotalCommonProductsCount = x.getQualifierValue("AHAM_DASHBOARD","DATA","PRODUCTS","count",1);
		//System.out.println("TotalCommonProducts "+TotalCommonProductsCount+" ::::"+TotalCommonProducts.getText());
		String TotalCommonProductsWitValue = "Total Common Products : "+TotalCommonProductsCount;
		System.out.println(TotalCommonProductsWitValue+"---"+TotalCommonProducts.getText());
		if(TotalCommonProducts.getText().equals(TotalCommonProductsWitValue)){
			generateXML.logVP("13.4" ,"This method is used to check if Total Common Products is displayed ",
					"Total Common Products is displayed with its value ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("13.4" ,"This method is used to check if Total Common Products is displayed",
					"Total Common Products is not displayed with proper value ", AppConstants.vFail);
		}	

	}
	/**
	 * 
	 * 1.Product - Percentile Purchases Section  with title as "Product - Percentile Purchases " in bold
	 and black in colour
	2.Graph representing the frequency of purchase activity and frequency of activities of all products
	 as percentile
	Percentile Purchases: Y-axis- no. of times a product has been purchased, X-axis- no. of products
	 normalized to 100
	3.The graph should be displayed orange and green colour with gray for X and Y axis
	4. The legend for the graph should have' value' 'indicated with orange/green colour.
	5.'products count per vertical' section should be shown.	 */
	@Test
	public void test_A_4() throws Exception{
		String catalogPath = ExcelUtil.readProps(pageName, DataConstants.SIDEMENU_CATALOG);
		driver.findElement(By.xpath(catalogPath)).click();
		List<WebElement> catalogSubHeadder = driver.findElements(By.className("parentGroove"));
		System.out.println(catalogSubHeadder.get(1).findElement(By.className("newheader")).getText());

		if (catalogSubHeadder.get(1).findElement(By.className("newheader")).getText().equals("Product - Percentile Purchases")) {
			generateXML.logVP("14.1" ,"This method is used to check if product-channel view section",
					"product-channel view section  is displayed ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("14.1" ,"This method is used to check if product-channel view section",
					"product-channel view section is not displayed ", AppConstants.vFail);
		}

		WebElement sections= catalogSubHeadder.get(1).findElement(By.className("newheader"));
		String color = sections.getCssValue("color");
		String fontWeight =  sections.getCssValue("font-weight");
		String str = color.replace("rgba(", "").replace(")", "");
		String verifyColor ="61, 70, 90, 1";
		if (fontWeight.equals("bold") || fontWeight.equals("700")) {
			generateXML.logVP("14.2" ,"This method is used to check if product-channel view section is in Bold",
					"product-channel view section  is in Bold ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("14.2" ,"This method is used to check if product-channel view section is in Bold",
					"product-channel view section is not in Bold ", AppConstants.vFail);
		}	      
		if(str.equals(verifyColor)){
			generateXML.logVP("14.3" ,"This method is used to check if product-channel view section is black ",
					"product-channel view section is in black ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("14.3" ,"This method is used to check if product-channel view section is black ",
					"product-channel view sectionis not in black ", AppConstants.vFail);
		}	

		HBaseUtil x = new HBaseUtil(); 
		String percentileActivityTotal = x.getQualifierValue("AHAM_DASHBOARD","DATA","PRODUCTS","percentile_activity_total",1);
		String percentileRegPurc = x.getQualifierValue("AHAM_DASHBOARD","DATA","CUSTOMERS","percentile_reg_purc",1);

		List<WebElement> areaChartRect = driver.findElement(By.id("chart")).findElement(By.tagName("svg")).findElements(By.tagName("rect"));
		List<WebElement> areaChartCircle = driver.findElement(By.id("chart")).findElement(By.tagName("svg")).findElements(By.tagName("circle"));
		int colCountReg = 0;
		int colCountRegWt = 0;
		String[] registeredArray = percentileRegPurc.replace("[", "").replace("]","").split(",");
		String[] registeredCircleArray = percentileActivityTotal.replace("[", "").replace("]","").split(",");
		for(int i=0;i<areaChartRect.size();i++){
			WebElement text = areaChartRect.get(i);
			String[] arrayText=text.getText().replace("value Stat:", "").split(",");
			if((Math.round(Float.parseFloat(arrayText[1])) == Math.round(Float.parseFloat(registeredArray[i])))){
				colCountReg++;
			}

		}
		for(int i=0;i<areaChartCircle.size();i++){
			WebElement text = areaChartCircle.get(i);
			String[] arrayText=text.getText().replace("value Stat:", "").split(",");
			if((Math.round(Float.parseFloat(arrayText[1])) == Math.round(Float.parseFloat(registeredCircleArray[i])))){
				colCountRegWt++;
			}
		}


		if((colCountReg == areaChartCircle.size()) && (colCountRegWt == areaChartRect.size())){
			generateXML.logVP( "14.4","This method is used to check area chart values",
					"area chart values is displayed properly ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("14.4" ,"This method is used to check area chart  values",
					"area chart values is not displayed properly", AppConstants.vFail);
		}





	}
	@Test
	public void test_A_5() throws Exception{
		String catalogPath = ExcelUtil.readProps(pageName, DataConstants.SIDEMENU_CATALOG);
		driver.findElement(By.xpath(catalogPath)).click();
		List<WebElement> catalogSubHeadder = driver.findElements(By.className("parentGroove"));
		System.out.println(catalogSubHeadder.get(2).findElement(By.className("newheader")).getText());

		if (catalogSubHeadder.get(2).findElement(By.className("newheader")).getText().equals("Product Distribution")) {
			generateXML.logVP("15.1" ,"This method is used to check if product-channel view section",
					"product-channel view section  is displayed ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("15.1" ,"This method is used to check if product-channel view section",
					"product-channel view section is not displayed ", AppConstants.vFail);
		}

		WebElement sections= catalogSubHeadder.get(2).findElement(By.className("newheader"));
		String color = sections.getCssValue("color");
		String fontWeight =  sections.getCssValue("font-weight");
		String str = color.replace("rgba(", "").replace(")", "");
		String verifyColor ="61, 70, 90, 1";
		if (fontWeight.equals("bold") || fontWeight.equals("700")) {
			generateXML.logVP("15.2" ,"This method is used to check if product-channel view section is in Bold",
					"product-channel view section  is in Bold ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("15.2" ,"This method is used to check if product-channel view section is in Bold",
					"product-channel view section is not in Bold ", AppConstants.vFail);
		}	      
		if(str.equals(verifyColor)){
			generateXML.logVP("15.3" ,"This method is used to check if product-channel view section is black ",
					"product-channel view section is in black ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("15.3" ,"This method is used to check if product-channel view section is black ",
					"product-channel view sectionis not in black ", AppConstants.vFail);
		}	



	}
	//activities tab
	@Test
	public void test_A_6() throws Exception{
		String activityPath = ExcelUtil.readProps(pageName, DataConstants.SIDEMENU_ACTIVITIES);
		driver.findElement(By.xpath(activityPath)).click();
		/*String path = "//*[@id='navigation']/li[3]/a/b";
		driver.findElement(By.xpath(path)).click();*/
		List<WebElement> catalogSubHeadder = driver.findElements(By.className("parentGroove"));
		System.out.println(catalogSubHeadder.get(0).findElement(By.className("newheader")).getText());

		if (catalogSubHeadder.get(0).findElement(By.className("newheader")).getText().equals("Activity Distribution: By Customer Type")) {
			generateXML.logVP("16.1" ,"This method is used to check Activity Distribution: By Customer Type pie chart",
					"Activity Distribution: By Customer Type is displayed ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("16.1" ,"This method is used to check if Activity Distribution: By Customer Type pie chart",
					"Activity Distribution: By Customer Type is not displayed ", AppConstants.vFail);
		}

		WebElement sections= catalogSubHeadder.get(1).findElement(By.className("newheader"));
		String color = sections.getCssValue("color");
		String fontWeight =  sections.getCssValue("font-weight");
		String str = color.replace("rgba(", "").replace(")", "");
		String verifyColor ="61, 70, 90, 1";
		if (fontWeight.equals("bold") || fontWeight.equals("700")) {
			generateXML.logVP("16.2" ,"This method is used to check Activity Distribution: By Customer Type is in Bold",
					"Activity Distribution: By Customer Type  is in Bold ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("16.2" ,"This method is used to check Activity Distribution: By Customer Type is in Bold",
					"Activity Distribution: By Customer Type is not in Bold ", AppConstants.vFail);
		}	      
		if(str.equals(verifyColor)){
			generateXML.logVP("16.3" ,"This method is used to check Activity Distribution: By Customer Type is black ",
					"Activity Distribution: By Customer Type is in black ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("16.3" ,"This method is used to check Activity Distribution: By Customer Type is black ",
					" Activity Distribution: By Customer Type is not in black ", AppConstants.vFail);
		}	



	}
	@Test
	public void test_A_7() throws Exception{
		String activityPath = ExcelUtil.readProps(pageName, DataConstants.SIDEMENU_ACTIVITIES);

		driver.findElement(By.xpath(activityPath)).click();
		List<WebElement> catalogSubHeadder = driver.findElements(By.className("parentGroove"));
		WebElement ele = catalogSubHeadder.get(1).findElement(By.className("newheader"));
		System.out.println(ele.getText());
		if (ele.getText().equals("Activity Distribution: By Activity Type")) {
			generateXML.logVP("17.1" ,"This method is used to check Activity Distribution: By Activity Type",
					"Activity Distribution: By Activity Type is displayed ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("17.1" ,"This method is used to check Activity Distribution: By Activity Type",
					"Activity Distribution: By Activity Type is not displayed ", AppConstants.vFail);
		}

		WebElement sections= catalogSubHeadder.get(1).findElement(By.className("newheader"));
		String color = sections.getCssValue("color");
		String fontWeight =  sections.getCssValue("font-weight");
		String str = color.replace("rgba(", "").replace(")", "");
		String verifyColor ="61, 70, 90, 1";
		if (fontWeight.equals("bold") || fontWeight.equals("700")) {
			generateXML.logVP("17.2" ,"This method is used to check Activity Distribution: By Activity Type is in Bold",
					"Activity Distribution: By Activity Type  is in Bold ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("17.2" ,"This method is used to check Activity Distribution: By Activity Type is in Bold",
					"Activity Distribution: By Activity Type is not in Bold ", AppConstants.vFail);
		}	      
		if(str.equals(verifyColor)){
			generateXML.logVP("17.3" ,"This method is used to check Activity Distribution: By Activity Type is black ",
					"Activity Distribution: By Activity Type is in black ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("17.3" ,"This method is used to check Activity Distribution: By Activity Type is black ",
					"Activity Distribution: By Activity Type is not in black ", AppConstants.vFail);
		}	



	}

	@Test
	public void test_A_8() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_CATALOG))).click();
		HBaseUtil hbutil = new HBaseUtil();
		Long count = Long.parseLong(hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","PRODUCTS","count",1).trim());
		//System.out.println("count "+count);
		String[] perActTotal = hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","PRODUCTS","percentile_activity_total",1).replace("[", "").replace("]", "").split("\\,");
		String[] perRegPurc = hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","PRODUCTS","percentile_reg_purc",1).replace("[", "").replace("]", "").split("\\,");
		int colCountReg = 0;
		int colCountRegWt = 0;
		String gooveHeader = ExcelUtil.readProps(pageName, DataConstants.GROOVE_HEADER);
		WebElement totalProductsWeb = driver.findElement(By.className(gooveHeader));
		Long totalProducts = Long.parseLong(totalProductsWeb.getText().split("\\:")[1].trim());
		//System.out.println("total products "+ totalProducts);
		String chart = ExcelUtil.readProps(pageName, DataConstants.CHART);
		List<WebElement> areaChart = driver.findElement(By.id(chart)).findElement(By.tagName("svg")).findElements(By.tagName("rect"));
		List<WebElement> areaChartWt = driver.findElement(By.id(chart)).findElement(By.tagName("svg")).findElements(By.tagName("circle"));
		/*System.out.println("area chart size "+ areaChart.size());
		System.out.println("area chart weight "+ areaChartWt.size());*/
		List<Double> perActList = new ArrayList<Double>();
		List<Double> perRegList = new ArrayList<Double>();
		DecimalFormat df = new DecimalFormat("##.00");
		for(int i=0; i < areaChart.size();++i){
			WebElement text = areaChart.get(i);
			String[] arrayText=text.getText().replace("value Stat:", "").split(",");
			perRegList.add(Double.parseDouble(df.format(Double.parseDouble(arrayText[1]))));
		}
		Collections.sort(perRegList, Collections.reverseOrder());
		for(int i=0;i<perRegPurc.length;++i){
			if(Double.parseDouble(df.format(Double.parseDouble(perRegPurc[i]))) == perRegList.get(i)){
				colCountReg++;
			}
		}
		for(int j=0; j < areaChartWt.size();++j){
			WebElement text = areaChartWt.get(j);
			String[] arrayText=text.getText().replace("value Stat:", "").split(",");
			perActList.add(Double.parseDouble(df.format(Double.parseDouble(arrayText[1]))));
		}
		Collections.sort(perActList, Collections.reverseOrder());
		for(int i=0;i<perActTotal.length;++i){
			if(Double.parseDouble(df.format(Double.parseDouble(perActTotal[i]))) == perActList.get(i)){
				colCountRegWt++;
			}
		}
		if(count - totalProducts == 0){
			generateXML.logVP("18.1" ,"This method is used to check Total Products displayed on UI is same as that in hbase","Both the values are matched", AppConstants.vPass);
		}else{
			generateXML.logVP("18.1" ,"This method is used to check Total Products displayed on UI is same as that in hbase","Both the values are not matched", AppConstants.vFail);
		}
		if(colCountReg == areaChart.size()){// && (colCountRegWt == areaChartWt.size())){
			generateXML.logVP( "18.2","This method is used to check area chart values",
					"area chart values is displayed properly ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("18.2" ,"This method is used to check area chart  values",
					"area chart values is not displayed properly", AppConstants.vFail);
		}

	}

	@Test
	public void test_A_9() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_CATALOG))).click();
		HBaseUtil hbutil = new HBaseUtil();
		String[] perActTotal = hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","PRODUCTS","percentile_activity_total",1).replace("[", "").replace("]", "").split("\\,");
		int colCountRegWt = 0;
		String chart = ExcelUtil.readProps(pageName, DataConstants.CHART);
		List<WebElement> areaChartWt = driver.findElement(By.id(chart)).findElement(By.tagName("svg")).findElements(By.tagName("circle"));
		List<Double> perActList = new ArrayList<Double>();
		DecimalFormat df = new DecimalFormat("##.00");
		for(int j=0; j < areaChartWt.size();++j){
			WebElement text = areaChartWt.get(j);
			String[] arrayText=text.getText().replace("value Stat:", "").split(",");
			perActList.add(Double.parseDouble(df.format(Double.parseDouble(arrayText[1]))));
		}
		Collections.sort(perActList, Collections.reverseOrder());
		for(int i=0;i<perActTotal.length;++i){
			if(Double.parseDouble(df.format(Double.parseDouble(perActTotal[i]))) == perActList.get(i)){
				colCountRegWt++;
			}
		}
		if((colCountRegWt == areaChartWt.size())){
			generateXML.logVP( "19","This method is used to check area chart values",
					"area chart values is displayed properly ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("19" ,"This method is used to check area chart  values",
					"area chart values is not displayed properly", AppConstants.vFail);
		}

	}

	@Test
	public void test_B_1() throws Exception{

	}

	@Test
	public void test_B_2() throws Exception{

	}

	@Test
	public void test_B_3() throws Exception{

	}

	@Test
	public void test_B_4() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_ACTIVITIES))).click();
		HBaseUtil hbutil = new HBaseUtil();
		Double guest = Double.parseDouble(hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","ACTIVITIES","guest",1).trim());
		Double registered = Double.parseDouble(hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","ACTIVITIES","registered",1).trim());
		Double totalCustomers = guest + registered;
		//DecimalFormat df = new DecimalFormat("##.00");
		/*System.out.println("guest users "+ guest);
		System.out.println("total users " + totalCustomers);
		System.out.println("registered "+ registered);
		System.out.println(guest/totalCustomers)*100);*/
		Long anonymousPerc = (long) (Math.round((guest/totalCustomers)*100));
		Long regiseredPerc = (long) (Math.round((registered/totalCustomers)*100));
		//System.out.println("anonymous "+ anonymousPerc + " registerd "+regiseredPerc);
		NumberFormat n = NumberFormat.getInstance(); 
		String guestFormat = n.format(guest);
		String regFormat = n.format(registered);

		String Anonymous = ("Anonymous ").concat(guestFormat).concat(anonymousPerc.toString()+"%");
		String registeredUsers = ("Registered ").concat(regFormat).concat(regiseredPerc.toString()+"%");
		int count=0;
		String activityDistCustType = ExcelUtil.readProps(pageName, DataConstants.ACTIVITY_DISTRIBUTION_CUSTOMER);
		WebElement distCustType = driver.findElement(By.id(activityDistCustType));
		List<WebElement> webElements = distCustType.findElements(By.className("arc"));
		for(WebElement webElement: webElements){
			//System.out.println("Web Element " + webElement.getText());
			if(webElement.getText().equals(Anonymous)){
				count++;
			}else if(webElement.getText().equals(registeredUsers)){
				count++;
			}
		}
		if(count==2){
			generateXML.logVP( "23","This method is used to check pie chart values",
					"pie chart values is displayed properly ", AppConstants.vPass);
		}else{
			generateXML.logVP("23" ,"This method is used to check pie chart  values",
					"pie chart values is not displayed properly", AppConstants.vFail);
		}


	}

	@Test
	public void test_B_5() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_ACTIVITIES))).click();
		HBaseUtil hbutil = new HBaseUtil();
		Double search = Double.parseDouble(hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","ACTIVITIES","SEARCH",1).trim());
		Double view = Double.parseDouble(hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","ACTIVITIES","VIEW",1).trim());
		Double purchase = Double.parseDouble(hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","ACTIVITIES","PURC",1).trim());
		Double add = Double.parseDouble(hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","ACTIVITIES","ADD",1).trim());
		Double orderStore = 598717d;
		Double offerRedemptionStore = 101278d;
		Double offerRedemptionWeb = 75123d;
		Double totalActivities = search + view + purchase + add + orderStore + offerRedemptionStore+ offerRedemptionWeb;

		long searchPec = (Math.round((search/totalActivities)*100));
		long viewPec =  (Math.round((view/totalActivities)*100));
		long purchasePec = (Math.round((purchase/totalActivities)*100));
		long addPec = (Math.round((add/totalActivities)*100));
		long orderStorePec = (Math.round((orderStore/totalActivities)*100));
		long offerRedemptionStorePec = (Math.round((offerRedemptionStore/totalActivities)*100));
		long offerRedemptionWebPec = (Math.round((offerRedemptionWeb/totalActivities)*100));

		NumberFormat n = NumberFormat.getInstance(); 
		String searchFormat = n.format(search);
		String viewFormat = n.format(view);
		String purchaseFormat = n.format(purchase);
		String addFormat = n.format(add);
		String orderStoreFormat = n.format(orderStore);
		String offerRedemptionStoreFormat = n.format(offerRedemptionStore);
		String offerRedemptionWebFormat = n.format(offerRedemptionWeb);

		String searchStr = ("Search ").concat(searchFormat).concat(String.valueOf(searchPec)+"%");
		String browse = ("Browse ").concat(viewFormat).concat(String.valueOf(viewPec)+"%");
		String order = ("Order ").concat(purchaseFormat).concat(String.valueOf(purchasePec)+"%");
		String cart = ("Cart ").concat(addFormat).concat(String.valueOf(addPec)+"%");
		String orderStoreStr = ("Order - Store ").concat(orderStoreFormat).concat(String.valueOf(orderStorePec)+"%");
		String offerRemStore = ("Offer Redemption - Store ").concat(offerRedemptionStoreFormat).concat(String.valueOf(offerRedemptionStorePec)+"%");
		String offerRemWeb = ("Offer Redemption - Web ").concat(offerRedemptionWebFormat).concat(String.valueOf(offerRedemptionWebPec)+"%");


		int count=0;
		String activityDistActType = ExcelUtil.readProps(pageName, DataConstants.ACTIVITY_DISTIRBUTION_ACTIVITY);
		WebElement distCustType = driver.findElement(By.id(activityDistActType));
		List<WebElement> webElements = distCustType.findElements(By.className("arc"));
		for(WebElement webElement: webElements){
			//System.out.println("Web Element " + webElement.getText());
			if(webElement.getText().equals(searchStr)){
				count++;
			}else if(webElement.getText().equals(browse)){
				count++;
			}else if(webElement.getText().equals(order)){
				count++;
			}else if(webElement.getText().equals(cart)){
				count++;
			}else if(webElement.getText().equals(orderStoreStr)){
				count++;
			}else if(webElement.getText().equals(offerRemStore)){
				count++;
			}else if(webElement.getText().equals(offerRemWeb)){
				count++;
			}
		}

		if(count==7){
			generateXML.logVP( "24","This method is used to check pie chart values",
					"pie chart values is displayed properly ", AppConstants.vPass);
		}else{
			generateXML.logVP("24" ,"This method is used to check pie chart  values",
					"pie chart values is not displayed properly", AppConstants.vFail);
		}

	}

	@Test
	public void test_B_6(){

	}

	@Test
	public void test_B_7(){
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		int tabCount=0;
		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		WebElement webElement1 = cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.OUTLINE)));//.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.OUTLINE)));
		if(webElement1.getText().equalsIgnoreCase("Overview")){
			tabCount++;
		}
		WebElement webElement2 = cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE)));
		if(webElement2.getText().equalsIgnoreCase("Shelf Wise")){
			tabCount++;
		}
		if(tabCount==2)
		{
			generateXML.logVP("26.1" ,"This method is used to check The data tab, scribe submenu sections, overview and shelf wise sub-tabs",
					" scribe submenu, overview and shelfwise sub-tabs with the sections were displayed", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("26.1" ,"This method is used to check The data tab, scribe submenu sections, overview and shelf wise sub-tabs",
					" scribe submenu, overview and shelfwise sub-tabs with the sections were not displayed", AppConstants.vFail);
		}
		WebElement webElement3 = cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.DEFAULT_TAB)));

		//System.out.println("Web Element text "+ webElement1.getAttribute("class"));
		if( webElement1.getAttribute("class").equalsIgnoreCase("current")){
			generateXML.logVP("26.2" ,"This method is used to check The data tab, scribe submenu sections, overview is selected as default tab",
					" scribe submenu, overview and overview tab is displayed", AppConstants.vPass);
		}
		else{
			generateXML.logVP("26.2" ,"This method is used to check The data tab, scribe submenu sections, overview is selected as default tab",
					" scribe submenu, overview and overview tab is not displayed", AppConstants.vFail);
		}

		//System.out.println("Text value of webElement "+ webElement2.get(1).getText());
		/*for(int k=0; k< tabList.size();++k){
			WebElement webElement = tabList.get(k).findElement(By.id(ExcelUtil.readProps(pageName, DataConstants.OUTLINE)));
			String text = webElement.getText();
			if(text.equalsIgnoreCase("Overview")){
				System.out.println("In the Overview tab");
			}
		}
		 *///List<WebElement> subsections= driver.findElements(By.className(ExcelUtil.readProps(pageName, DataConstants.PARENT_GROOVE)));
		List<WebElement> sections = driver.findElements(By.className(ExcelUtil.readProps(pageName,DataConstants.TAB_CONTENT)));
		String subsection = ExcelUtil.readProps(pageName, DataConstants.PARENT_GROOVE);
		String selector = ExcelUtil.readProps(pageName, DataConstants.SCRIBE_OVERVIEW_SECTIONS);
		int sectionCount=0;
		for(int i=0; i< sections.size();++i){
			List<WebElement> subsections = sections.get(i).findElements(By.className(subsection));
			for(int j=0; j<subsections.size();++j){
				String text = subsections.get(j).findElement(By.className(selector)).getText();
				if(text.equalsIgnoreCase("Shelf Wise Report")|| text.equalsIgnoreCase("Average Clicks Per Customer")){
					sectionCount++;
				}
			}
		}
		if(sectionCount==2)
		{
			generateXML.logVP("26.3" ,"This method is used to check The data tab, scribe submenu sections, overview tab",
					" scribe submenu, overview tab with the sections were displayed", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("26.3" ,"This method is used to check The data tab, scribe submenu sections",
					" scribe submenu, overview tab with the sections were not displayed", AppConstants.vFail);
		}


	}

	@Test
	public void test_B_8(){
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.INVALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.INVALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		WebElement tableContainer = driver.findElement(By.className(ExcelUtil.readProps(pageName,DataConstants.TABLE_CONTAINER)));
		if(tableContainer.getText().equalsIgnoreCase("System error. Please try again later!")){
			generateXML.logVP("27.1" ,"This method is used to check with invalid from and to date error message should be displayed",
					" invalied from and to dates has shown error message were displayed", AppConstants.vPass);
		}else{
			generateXML.logVP("27.1" ,"This method is used to check with invalid from and to date error message should be displayed",
					" invalied from and to dates has shown error message were not displayed", AppConstants.vFail);
		}		
	}

	@Test
	public void test_B_9(){
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date 
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.INVALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);*/

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date 
		String toDate = ExcelUtil.readProps(pageName, DataConstants.INVALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);*/

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		WebElement webElementFrmDate = driver.findElement(By.xpath(xpathExpression));
		String borderColorFrm = webElementFrmDate.getCssValue("border-color");

		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		WebElement webElementToDate = driver.findElement(By.xpath(xpathExpression));
		String borderColorTo = webElementToDate.getCssValue("border-color");

		if(borderColorFrm.equalsIgnoreCase("red") && borderColorTo.equalsIgnoreCase("red")){
			generateXML.logVP("28.1" ,"This method is used to check with empty from and to date border red color is shown or not",
					"  with empty from and to date border red color is shown", AppConstants.vPass);
		}else{
			generateXML.logVP("28.1" ,"This method is used to check with empty from and to date border red color is shown or not",
					"  with empty from and to date border red color is not shown", AppConstants.vFail);
		}

		/*WebElement tableContainer = driver.findElement(By.className(ExcelUtil.readProps(pageName,DataConstants.TABLE_CONTAINER)));
		if(tableContainer.getText().equalsIgnoreCase("System error. Please try again later!")){
			generateXML.logVP("27.1" ,"This method is used to check with invalid from and to date error message should be displayed",
					" invalied from and to dates has shown error message were displayed", AppConstants.vPass);
		}else{
			generateXML.logVP("27.1" ,"This method is used to check with invalid from and to date error message should be displayed",
					" invalied from and to dates has shown error message were not displayed", AppConstants.vFail);
		}*/		
	}

	@Test
	public void test_C_1(){

	}

	@Test
	public void test_C_2(){

	}

	@Test
	public void test_C_3() throws Exception{
		/*HBaseUtil hutil = new HBaseUtil();
		Double search = Double.parseDouble(hutil.getQualifierValue("AHAM_DASHBOARD","DATA","ACTIVITIES","SEARCH",1).trim());
		System.out.println(search+"==Search");*/
	}

	@Test
	public void test_C_4() throws Exception{

		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		//Clear the from date text box 
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		// Get valid From Date 
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		// Clear the to date text box 
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		//Get valid From Date 
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		//Click on Go Button 
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();
		HBaseUtil hbutil = new HBaseUtil();
		//Double search = Double.parseDouble(hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","ACTIVITIES","SEARCH",1).trim());
		Double avgGuest = Double.parseDouble(hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","AVG_CLICKS-Guest","",1).trim());
		Double avgRegistered = Double.parseDouble(hbutil.getQualifierValue("AHAM_DASHBOARD","DATA","AVG_CLICKS-Registered","",1).trim());

		int count=0;
		String avgAnyStr = ExcelUtil.readProps(pageName, DataConstants.AVG_ANONYMOUS); 
		WebElement avgAnyWebElement = driver.findElement(By.className(avgAnyStr));
		//if(avgAnyWebElement.getText().equalsIgnoreCase(arg0))
		List<WebElement> WebelementList = avgAnyWebElement.findElements(By.tagName("td"));
		for(WebElement webelmt : WebelementList){
			if(webelmt.getText().equalsIgnoreCase(String.valueOf(avgGuest))){
				count++;
			}
		}

		String avgRegStr = ExcelUtil.readProps(pageName, DataConstants.AVG_REGISTERED);
		WebElement avgReg = driver.findElement(By.className(avgRegStr));
		List<WebElement> WebeleList = avgReg.findElements(By.tagName("td"));
		for(WebElement webelmt : WebeleList){
			if(webelmt.getText().equalsIgnoreCase(String.valueOf(avgRegistered))){
				count++;
			}
		}

		if(count == 2){
			generateXML.logVP("32.1" ,"This method is used to check average clicks (guest and registered) are same as in hbase",
					"average clicks (guest and registered) are same as in hbase", AppConstants.vPass);
		}else{
			generateXML.logVP("32.1" ,"This method is used to check average clicks (guest and registered) are same as in hbase",
					"average clicks (guest and registered) are not same as in hbase", AppConstants.vFail);
		}

	}

	@Test
	public void test_C_5() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		HBaseUtil x = new HBaseUtil(); 
		String recommendations = x.getQualifierValue("AHAM_DASHBOARD","DATA","RECOMMENDATIONS","",1);
		String clicks = x.getQualifierValue("AHAM_DASHBOARD","DATA","AHAM Clicks","",1);
		String orders = x.getQualifierValue("AHAM_DASHBOARD","DATA","ORDER_CONFIRM","",1);

		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		// Get valid From Date 
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		// Clear the to date text box 
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		//Get valid From Date 
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		//Click on Go Button 
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();
		//WebElement shelfWiseReport = driver.findElement(By.className("nv-barsWrap"));
		//WebElement nvBar = driver.findElement(By.className("nv-groups"));
		List<WebElement> nvBars = driver.findElements(By.className("nv-bar"));
		ArrayList<String> summary = new ArrayList<String>();
		summary.add(recommendations);
		summary.add(clicks);
		summary.add(orders);

		int colCount=0;
		for(int i=0; i< nvBars.size(); i++){
			String text = nvBars.get(i).getText();
			if(text.equalsIgnoreCase(summary.get(i))){
				colCount++;
			}
		}
		if(colCount == 3){
			generateXML.logVP( "33.1","This method is used to check Shelf Wise Report values",
					"Shelf Wise Report values is displayed properly ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("33.1" ,"This method is used to check Shelf Wise Report values",
					"Shelf Wise Report values is not displayed properly", AppConstants.vFail);
		}

	}

	@Test
	public void test_C_6() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();

		HBaseUtil hutil = new HBaseUtil();
		String Clicks_BBH = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-Based on your browsing history", "", 1);
		String Clicks_BSI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-Best selling items", "", 1);
		String Clicks_NFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-New for you", "", 1);
		String Clicks_RVI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-Recently viewed items", "", 1);
		String Clicks_SFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-Suggested For You", "", 1);
		String Clicks_TP = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-Top picks", "", 1);

		Double TOTAL_CLICKS = Double.parseDouble(Clicks_BBH)+Double.parseDouble(Clicks_BSI)+Double.parseDouble(Clicks_NFY)+Double.parseDouble(Clicks_RVI)+Double.parseDouble(Clicks_SFY)+Double.parseDouble(Clicks_TP);
		DecimalFormat df = new DecimalFormat("##.##");

		System.out.println(df.format(Double.parseDouble(Clicks_BBH)/TOTAL_CLICKS*100) +" "+Math.round(Double.parseDouble(Clicks_BBH)/TOTAL_CLICKS*100));
		String Clicks_BBH_STR = ("Based On Your Browsing History ").concat(df.format(Double.parseDouble(Clicks_BBH)/TOTAL_CLICKS*100)).concat(String.valueOf(Math.round(Double.parseDouble(Clicks_BBH)/TOTAL_CLICKS*100))+"%");
		String Clicks_BSI_STR = ("Best Selling Items ").concat(df.format(Double.parseDouble(Clicks_BSI)/TOTAL_CLICKS*100)).concat(String.valueOf(Math.round(Double.parseDouble(Clicks_BSI)/TOTAL_CLICKS*100))+"%");
		String Clicks_NFY_STR = ("New For You ").concat(df.format(Double.parseDouble(Clicks_NFY)/TOTAL_CLICKS*100)).concat(String.valueOf(Math.round(Double.parseDouble(Clicks_NFY)/TOTAL_CLICKS*100))+"%");
		String Clicks_RVI_STR = ("Recently Viewed Items ").concat(df.format(Double.parseDouble(Clicks_RVI)/TOTAL_CLICKS*100)).concat(String.valueOf(Math.round(Double.parseDouble(Clicks_RVI)/TOTAL_CLICKS*100))+"%");
		String Clicks_SFY_STR = ("Suggested For You ").concat(df.format(Double.parseDouble(Clicks_SFY)/TOTAL_CLICKS*100)).concat(String.valueOf(Math.round(Double.parseDouble(Clicks_SFY)/TOTAL_CLICKS*100))+"%");
		String Clicks_TP_STR = ("Top Picks ").concat(df.format(Double.parseDouble(Clicks_TP)/TOTAL_CLICKS*100)).concat(String.valueOf(Math.round(Double.parseDouble(Clicks_TP)/TOTAL_CLICKS*100))+"%");

		int colCount=0;
		WebElement shelfWiseClicks = driver.findElement(By.id("analytics1"));
		List<WebElement> arcs = shelfWiseClicks.findElements(By.className("arc"));
		for(WebElement arc : arcs){
			//System.out.println(" Browsing history count "+arc.getText());
			if(arc.getText().equals(Clicks_BBH_STR)){
				colCount++;				
			}
			else if(arc.getText().equals(Clicks_BSI_STR)){
				colCount++;
			}
			else if(arc.getText().equals(Clicks_NFY_STR)){
				colCount++;
			}
			else if(arc.getText().equals(Clicks_RVI_STR)){
				colCount++;
			}
			else if(arc.getText().equals(Clicks_SFY_STR)){
				colCount++;
			}
			else if(arc.getText().equals(Clicks_TP_STR)){
				colCount++;
			}
		}

		if(colCount == 6){
			generateXML.logVP("34.1" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Shelf Wise Clicks piechart", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("34.1" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Shelf Wise Clicks piechart ", AppConstants.vFail);
		}

	}

	@Test
	public void test_C_7() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();

		HBaseUtil hutil = new HBaseUtil();
		String ORDERS_BBH = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-Based on your browsing history", "", 1);
		String ORDERS_BSI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-Best selling items", "", 1);
		String ORDERS_NFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-New for you", "", 1);
		String ORDERS_RVI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-Recently viewed items", "", 1);
		String ORDERS_SFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-Suggested For You", "", 1);
		String ORDERS_TP = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-Top picks", "", 1);

		Double TOTAL_ORDERS = Double.parseDouble(ORDERS_BBH)+Double.parseDouble(ORDERS_BSI)+Double.parseDouble(ORDERS_NFY)+Double.parseDouble(ORDERS_RVI)+Double.parseDouble(ORDERS_SFY)+Double.parseDouble(ORDERS_TP);
		DecimalFormat df = new DecimalFormat("##.##");

		System.out.println(df.format(Double.parseDouble(ORDERS_BBH)/TOTAL_ORDERS*100) +" "+Math.round(Double.parseDouble(ORDERS_BBH)/TOTAL_ORDERS*100));
		String Orders_BBH_STR = ("Based On Your Browsing History ").concat(df.format(Double.parseDouble(ORDERS_BBH)/TOTAL_ORDERS*100)).concat(String.valueOf(Math.round(Double.parseDouble(ORDERS_BBH)/TOTAL_ORDERS*100))+"%");
		String Orders_BSI_STR = ("Best Selling Items ").concat(df.format(Double.parseDouble(ORDERS_BSI)/TOTAL_ORDERS*100)).concat(String.valueOf(Math.round(Double.parseDouble(ORDERS_BSI)/TOTAL_ORDERS*100))+"%");
		String Orders_NFY_STR = ("New For You ").concat(df.format(Double.parseDouble(ORDERS_NFY)/TOTAL_ORDERS*100)).concat(String.valueOf(Math.round(Double.parseDouble(ORDERS_NFY)/TOTAL_ORDERS*100))+"%");
		String Orders_RVI_STR = ("Recently Viewed Items ").concat(df.format(Double.parseDouble(ORDERS_RVI)/TOTAL_ORDERS*100)).concat(String.valueOf(Math.round(Double.parseDouble(ORDERS_RVI)/TOTAL_ORDERS*100))+"%");
		String Orders_SFY_STR = ("Suggested For You ").concat(df.format(Double.parseDouble(ORDERS_SFY)/TOTAL_ORDERS*100)).concat(String.valueOf(Math.round(Double.parseDouble(ORDERS_SFY)/TOTAL_ORDERS*100))+"%");
		String Orders_TP_STR = ("Top Picks ").concat(df.format(Double.parseDouble(ORDERS_TP)/TOTAL_ORDERS*100)).concat(String.valueOf(Math.round(Double.parseDouble(ORDERS_TP)/TOTAL_ORDERS*100))+"%");

		int colCount=0;
		WebElement shelfWiseClicks = driver.findElement(By.id("analytics2"));
		List<WebElement> arcs = shelfWiseClicks.findElements(By.className("arc"));
		for(WebElement arc : arcs){
			//System.out.println(" Browsing history count "+arc.getText());
			if(arc.getText().equals(Orders_BBH_STR)){
				colCount++;				
			}
			else if(arc.getText().equals(Orders_BSI_STR)){
				colCount++;
			}
			else if(arc.getText().equals(Orders_NFY_STR)){
				colCount++;
			}
			else if(arc.getText().equals(Orders_RVI_STR)){
				colCount++;
			}
			else if(arc.getText().equals(Orders_SFY_STR)){
				colCount++;
			}
			else if(arc.getText().equals(Orders_TP_STR)){
				colCount++;
			}
		}

		if(colCount == 6){
			generateXML.logVP("35.1" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Shelf Wise Orders piechart", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("35.1" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Shelf Wise Orders piechart ", AppConstants.vFail);
		}

	}

	@Test
	public void test_C_8() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();
		DecimalFormat df = new DecimalFormat("##.##");

		HBaseUtil hutil = new HBaseUtil();
		String Clicks_BBH = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-Based on your browsing history", "", 1);
		String Clicks_BSI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-Best selling items", "", 1);
		String Clicks_NFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-New for you", "", 1);
		String Clicks_RVI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-Recently viewed items", "", 1);
		String Clicks_SFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-Suggested For You", "", 1);
		String Clicks_TP = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "CLICKS-Top picks", "", 1);

		String ORDERS_BBH = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-Based on your browsing history", "", 1);
		String ORDERS_BSI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-Best selling items", "", 1);
		String ORDERS_NFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-New for you", "", 1);
		String ORDERS_RVI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-Recently viewed items", "", 1);
		String ORDERS_SFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-Suggested For You", "", 1);
		String ORDERS_TP = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "ORDER_CONFIRM-Top picks", "", 1);

		String Conversion_BBH_STR = ("Based On Your Browsing History ").concat("Orders: "+ORDERS_BBH+" ").concat("Clicks: "+Clicks_BBH+" ").concat("Conversion: "+df.format(Double.parseDouble(ORDERS_BBH)/Double.parseDouble(Clicks_BBH)*100)+"%");
		String Conversion_BSI_STR = ("Best Selling Items ").concat("Orders: "+ORDERS_BSI+" ").concat("Clicks: "+Clicks_BSI+" ").concat("Conversion: "+df.format(Double.parseDouble(ORDERS_BSI)/Double.parseDouble(Clicks_BSI)*100)+"%");
		String Conversion_NFY_STR = ("New For You ").concat("Orders: "+ORDERS_NFY+" ").concat("Clicks: "+Clicks_NFY+" ").concat("Conversion: "+df.format(Double.parseDouble(ORDERS_NFY)/Double.parseDouble(Clicks_NFY)*100)+"%");
		String Conversion_RVI_STR = ("Recently Viewed Items ").concat("Orders: "+ORDERS_RVI+" ").concat("Clicks: "+Clicks_RVI+" ").concat("Conversion: "+df.format(Double.parseDouble(ORDERS_RVI)/Double.parseDouble(Clicks_RVI)*100)+"%");
		String Conversion_SFY_STR = ("Suggested For You ").concat("Orders: "+ORDERS_SFY+" ").concat("Clicks: "+Clicks_SFY+" ").concat("Conversion: "+df.format(Double.parseDouble(ORDERS_SFY)/Double.parseDouble(Clicks_SFY)*100)+"%");
		String Conversion_TP_STR = ("Top Picks ").concat("Orders: "+ORDERS_TP+" ").concat("Clicks: "+Clicks_TP+" ").concat("Conversion: "+df.format(Double.parseDouble(ORDERS_TP)/Double.parseDouble(Clicks_TP)*100)+"%");
		int colCount=0;
		WebElement shelfWiseClicks = driver.findElement(By.id("testDot"));
		List<WebElement> circles = shelfWiseClicks.findElements(By.tagName("circle"));
		System.out.println(Conversion_BBH_STR);
		for(WebElement circle: circles){
			System.out.println(circle.getText());
			if(circle.getText().equals(Conversion_BBH_STR)){
				colCount++;				
			}
			else if(circle.getText().equals(Conversion_BSI_STR)){
				colCount++;
			}
			else if(circle.getText().equals(Conversion_NFY_STR)){
				colCount++;
			}
			else if(circle.getText().equals(Conversion_RVI_STR)){
				colCount++;
			}
			else if(circle.getText().equals(Conversion_SFY_STR)){
				colCount++;
			}
			else if(circle.getText().equals(Conversion_TP_STR)){
				colCount++;
			}
		}

		if(colCount == 6){
			generateXML.logVP("36.1" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Shelf Wise Clicks Vs Orders bubble chart", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("36.1" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Shelf Wise Clicks Vs Orders bubble chart", AppConstants.vFail);
		}
	}

	@Test
	public void test_C_9() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();

		HBaseUtil hutil = new HBaseUtil();
		String AVG_Clicks_BBH = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-Based on your browsing history", "", 1);
		String AVG_Clicks_BSI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-Best selling items", "", 1);
		String AVG_Clicks_NFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-New for you", "", 1);
		String AVG_Clicks_RVI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-Recently viewed items", "", 1);
		String AVG_Clicks_SFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-Suggested For You", "", 1);
		String AVG_Clicks_TP = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-Top picks", "", 1);


		int colCount =0;
		//String avgClicks = ExcelUtil.readProps(pageName, DataConstants.AVERAGE_CLICKS_TABLE);
		WebElement avgClicksWrapper = driver.findElement(By.className("dataTables_wrapper"));
		WebElement avgClicksTable = avgClicksWrapper.findElement(By.tagName("table"));
		WebElement avgClicksBody = avgClicksTable.findElement(By.tagName("tbody"));
		List<WebElement> avgClicksRows = avgClicksBody.findElements(By.tagName("tr"));
		for(WebElement row: avgClicksRows){
			List<WebElement> columns = row.findElements(By.tagName("td"));
			for(WebElement col : columns){
				System.out.println("values " + col.getText());
				if(col.getText().equalsIgnoreCase("Based on your browsing history")){
					if(Double.parseDouble(columns.get(3).getText()) == Double.parseDouble(AVG_Clicks_BBH)){
						colCount++;
					}
				}else if(col.getText().equalsIgnoreCase("Best selling items")){
					if(Double.parseDouble(columns.get(3).getText()) == Double.parseDouble(AVG_Clicks_BSI)){
						colCount++;
					}
				}else if(col.getText().equalsIgnoreCase("New for you")){
					if(Double.parseDouble(columns.get(3).getText()) == Double.parseDouble(AVG_Clicks_NFY)){
						colCount++;
					}
				}else if(col.getText().equalsIgnoreCase("Recently viewed items")){
					if(Double.parseDouble(columns.get(3).getText()) == Double.parseDouble(AVG_Clicks_RVI)){
						colCount++;
					}
				}else if(col.getText().equalsIgnoreCase("Suggested For You")){
					if(Double.parseDouble(columns.get(3).getText()) == Double.parseDouble(AVG_Clicks_SFY)){
						colCount++;
					}
				}else if(col.getText().equalsIgnoreCase("Top picks")){
					if(Double.parseDouble(columns.get(3).getText()) == Double.parseDouble(AVG_Clicks_TP)){
						colCount++;
					}
				}
			}
		}
		if(colCount == 6){
			generateXML.logVP("37.1" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Average Clicks Table Chart", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("37.1" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Average Clicks Table Chart", AppConstants.vFail);
		}

	}

	@Test
	public void test_D_1() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();

		/*HBaseUtil hutil = new HBaseUtil();
		String AVG_Clicks_BBH = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-Based on your browsing history", "", 1);
		String AVG_Clicks_BSI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-Best selling items", "", 1);
		String AVG_Clicks_NFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-New for you", "", 1);
		String AVG_Clicks_RVI = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-Recently viewed items", "", 1);
		String AVG_Clicks_SFY = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-Suggested For You", "", 1);
		String AVG_Clicks_TP = hutil.getQualifierValue("AHAM_DASHBOARD", "DATA", "AVG_CLICKS-Top picks", "", 1);*/


		int chartCount_1 = 0, chartCount_2 = 0;
		boolean SFU_Header = false, TP_Header = false;
		
		String SFULinkXpath = ExcelUtil.readProps(pageName, DataConstants.SFULink);
		WebElement sfuWebElement = driver.findElement(By.xpath(SFULinkXpath));
		sfuWebElement.click();
		Thread.sleep(4000);
		//String strategyDetails =  ExcelUtil.readProps(pageName,"/html/body/div[3]/div/div/div");
		WebElement webElement = driver.findElement(By.xpath("/html/body/div[3]/div/div/div"));
		//System.out.println("WebElement "+ webElement.getText());
		if(webElement.getText().trim().equalsIgnoreCase("Strategy Details")){
			SFU_Header = true;
		}
		
		String SFU_ChartBoard = ExcelUtil.readProps(pageName, DataConstants.SFU_CHARTBOARD);
		WebElement webElement1 = driver.findElement(By.xpath(SFU_ChartBoard));
		List<WebElement> webElements1 = webElement1.findElements(By.className("groove"));
		for(WebElement element : webElements1){
			WebElement header = element.findElement(By.className("newheader"));
			if(header.getText().trim().equalsIgnoreCase("Strategy Configuration")){
				chartCount_1++;
			}else if (header.getText().trim().equalsIgnoreCase("Strategy Aggregation")) {
				chartCount_1++;
			}else if (header.getText().trim().equalsIgnoreCase("Clicks")) {
				chartCount_1++;
			} else if (header.getText().trim().equalsIgnoreCase("Orders")) {
				chartCount_1++;
			}
		}	

		webElement.findElement(By.xpath("/html/body/div[3]/div/div/div/a")).click();
		
		String TPLinkXpath = ExcelUtil.readProps(pageName, DataConstants.TPLink);
		WebElement tpWebElement = driver.findElement(By.xpath(TPLinkXpath));
		tpWebElement.click();
		//String strategyDetails =  ExcelUtil.readProps(pageName,"/html/body/div[3]/div/div/div");
		Thread.sleep(4000);
		WebElement webElement_tp = driver.findElement(By.xpath("/html/body/div[3]/div/div/div"));
		System.out.println("WebElement "+ webElement_tp.getText());
		if(webElement_tp.getText().trim().equalsIgnoreCase("Strategy Details")){
			TP_Header = true;
		}

		String TP_ChartBoard = ExcelUtil.readProps(pageName, DataConstants.TP_CHARTBOARD);
		WebElement webElement2 = driver.findElement(By.xpath(TP_ChartBoard));
		List<WebElement> webElements2 = webElement2.findElements(By.className("groove"));
		for(WebElement element : webElements2){
			WebElement header = element.findElement(By.className("newheader"));
			if(header.getText().trim().equalsIgnoreCase("Strategy Configuration")){
				chartCount_2++;
			}else if (header.getText().trim().equalsIgnoreCase("Strategy Aggregation")) {
				chartCount_2++;
			}else if (header.getText().trim().equalsIgnoreCase("Clicks")) {
				chartCount_2++;
			} else if (header.getText().trim().equalsIgnoreCase("Orders")) {
				chartCount_2++;
			}
		}	
		
		//webElement_tp.findElement(By.xpath("/html/body/div[3]/div/div/div/a")).click();
		if(SFU_Header || TP_Header){
			generateXML.logVP("38.1" ,"This method is used to check if on clicking suggested for you and top picks" +
					"the heading Strategy Details is shown",
					"Heading Strategy Details is displayed ", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("38.1" ,"This method is used to check if on clicking suggested for you and top picks" +
					"the heading Strategy Details is shown",
					"Heading Strategy Details is not displayed", AppConstants.vFail);
		}

		if (chartCount_1 == 4 || chartCount_2==4){
			generateXML.logVP("38.2" ,"This method is used to check if four pie charts: strategy configuration, strategy aggregate, clicks and orders are shown on suggested for you strategy" +
					"Four pie charts are getting shown",
					"Four Pie charts are getting displayed ", AppConstants.vPass);
		}else {
			generateXML.logVP("38.2" ,"This method is used to check if four pie charts: strategy configuration, strategy aggregate, clicks and orders are shown on suggested for you strategy" +
					"Four pie charts are getting shown",
					"Four Pie charts are not getting displayed", AppConstants.vFail);
		}
/*		if (chartCount_2 == 4){
			generateXML.logVP("38.3" ,"This method is used to check if four pie charts: strategy configuration, strategy aggregate, clicks and orders are shown on top picks strategy" +
					"Four pie charts are getting shown",
					"Four Pie charts are getting displayed ", AppConstants.vPass);
		}else {
			generateXML.logVP("38.3" ,"This method is used to check if four pie charts: strategy configuration, strategy aggregate, clicks and orders are shown on top picks strategy" +
					"Four pie charts are getting shown",
					"Four Pie charts are not getting displayed", AppConstants.vFail);
		}*/

	}

	
	@Test
	public void test_D_2() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();
		
		String alsoViewed = ("Also Viewed ").concat("50").concat("50"+"%");
		String similarItems = ("Similar Items ").concat("10").concat("10"+"%");
		String ultiBought = ("Ultimately Bought ").concat("30").concat("30"+"%");
		String topSellers = ("Top Sellers ").concat("10").concat("10"+"%");
		
		String SFULinkXpath = ExcelUtil.readProps(pageName, DataConstants.SFULink);
		WebElement sfuWebElement = driver.findElement(By.xpath(SFULinkXpath));
		sfuWebElement.click();
		Thread.sleep(4000);
		
		int colCount=0;
		//WebElement page2 = driver.findElement(By.className("page2"));
		
		WebElement StratConfigWebElement = driver.findElement(By.id("configPie")); 
		//System.out.println(" StratConfigWebElement "+ StratConfigWebElement.getText());
		WebElement svgElement = StratConfigWebElement.findElement(By.tagName("svg"));
		WebElement gElement = svgElement.findElement(By.tagName("g"));
		
		List<WebElement> StConList = gElement.findElements(By.className("arc"));
		for(WebElement we : StConList){
			//System.out.println("get Text "+ we.getText());
			if(we.getText().trim().equalsIgnoreCase(alsoViewed)){
				colCount++;
			}else if(we.getText().trim().equalsIgnoreCase(similarItems)){
				colCount++;
			}else if(we.getText().trim().equalsIgnoreCase(topSellers)){
				colCount++;
			}else if(we.getText().trim().equalsIgnoreCase(ultiBought)){
				colCount++;
			}
		}
		
		if(colCount == 4){
			generateXML.logVP("39.1" ,"This method is used to check percentage of four strategies in strategy configuration" +
					"All the four strategies Also Viewed, Similar Items, Ultimately Bought and Top Sellers are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("39.1" ,"This method is used to check percentage of four strategies in strategy configuration" +
					"All the four strategies Also Viewed, Similar Items, Ultimately Bought and Top Sellers are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}
	}

	@Test
	public void test_D_3() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();
		
		//String alsoViewed = ("Also Viewed ").concat("50").concat("50"+"%");
		String similarItems = ("Similar Items ").concat("24").concat("24"+"%");
		//String ultiBought = ("Ultimately Bought ").concat("30").concat("30"+"%");
		String topSellers = ("Top Sellers ").concat("76").concat("76"+"%");
		
		String SFULinkXpath = ExcelUtil.readProps(pageName, DataConstants.SFULink);
		WebElement sfuWebElement = driver.findElement(By.xpath(SFULinkXpath));
		sfuWebElement.click();
		Thread.sleep(4000);
		
		int colCount=0;
		//WebElement page2 = driver.findElement(By.className("page2"));
		
		WebElement StratConfigWebElement = driver.findElement(By.id("aggrePie")); 
		//System.out.println(" StratConfigWebElement "+ StratConfigWebElement.getText());
		WebElement svgElement = StratConfigWebElement.findElement(By.tagName("svg"));
		WebElement gElement = svgElement.findElement(By.tagName("g"));
		
		List<WebElement> StConList = gElement.findElements(By.className("arc"));
		for(WebElement we : StConList){
			//System.out.println("get Text "+ we.getText());
			if(we.getText().trim().equalsIgnoreCase(similarItems)){
				colCount++;
			}else if(we.getText().trim().equalsIgnoreCase(topSellers)){
				colCount++;
			}
		}
		
		if(colCount == 2){
			generateXML.logVP("40.1" ,"This method is used to check percentage of four strategies in strategy aggregate" +
					"All the four strategies Also Viewed, Similar Items, Ultimately Bought and Top Sellers are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("40.1" ,"This method is used to check percentage of four strategies in strategy aggregate" +
					"All the four strategies Also Viewed, Similar Items, Ultimately Bought and Top Sellers are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}
	}
	
	@Test
	public void test_D_4() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();
		
		String TPLinkXpath = ExcelUtil.readProps(pageName, DataConstants.TPLink);
		WebElement tpWebElement = driver.findElement(By.xpath(TPLinkXpath));
		tpWebElement.click();
		//String strategyDetails =  ExcelUtil.readProps(pageName,"/html/body/div[3]/div/div/div");
		Thread.sleep(4000);
		
		
		String suggesteditems = ("Suggested Items ").concat("60").concat("60"+"%");
		String feqBrought = ("Frequently Bought ").concat("30").concat("30"+"%");
		String collbFil = ("Collaborative Filtering ").concat("10").concat("10"+"%");
		//String topSellers = ("Top Sellers ").concat("10").concat("10"+"%");
		
		int colCount=0;
		//WebElement page2 = driver.findElement(By.className("page2"));
		
		WebElement StratConfigWebElement = driver.findElement(By.id("configPie")); 
		//System.out.println(" StratConfigWebElement "+ StratConfigWebElement.getText());
		WebElement svgElement = StratConfigWebElement.findElement(By.tagName("svg"));
		WebElement gElement = svgElement.findElement(By.tagName("g"));
		
		List<WebElement> StConList = gElement.findElements(By.className("arc"));
		for(WebElement we : StConList){
			//System.out.println("get Text "+ we.getText());
			if(we.getText().trim().equalsIgnoreCase(suggesteditems)){
				colCount++;
			}else if(we.getText().trim().equalsIgnoreCase(feqBrought)){
				colCount++;
			}else if(we.getText().trim().equalsIgnoreCase(collbFil)){
				colCount++;
			}
		}
		
		if(colCount == 3){
			generateXML.logVP("41.1" ,"This method is used to check percentage of four strategies in Strategy Configuration " +
					"All the four strategies Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("41.1" ,"This method is used to check percentage of four strategies in Strategy Configuration " +
					"All the four strategies  Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}	
	}
	
	@Test
	public void test_D_5() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();
		
		String TPLinkXpath = ExcelUtil.readProps(pageName, DataConstants.TPLink);
		WebElement tpWebElement = driver.findElement(By.xpath(TPLinkXpath));
		tpWebElement.click();
		//String strategyDetails =  ExcelUtil.readProps(pageName,"/html/body/div[3]/div/div/div");
		Thread.sleep(4000);
		
		
		String suggesteditems = ("Suggested For You ").concat("69").concat("69"+"%");
		String feqBrought = ("Frequently Bought ").concat("8").concat("8"+"%");
		String collbFil = ("Collaborative Filtering ").concat("23").concat("23"+"%");
		//String topSellers = ("Top Sellers ").concat("10").concat("10"+"%");
		
		int colCount=0;
		//WebElement page2 = driver.findElement(By.className("page2"));
		
		WebElement StratConfigWebElement = driver.findElement(By.id("aggrePie")); 
		//System.out.println(" StratConfigWebElement "+ StratConfigWebElement.getText());
		WebElement svgElement = StratConfigWebElement.findElement(By.tagName("svg"));
		WebElement gElement = svgElement.findElement(By.tagName("g"));
		
		List<WebElement> StConList = gElement.findElements(By.className("arc"));
		for(WebElement we : StConList){
			//System.out.println("get Text "+ we.getText());
			if(we.getText().trim().equalsIgnoreCase(suggesteditems)){
				colCount++;
			}else if(we.getText().trim().equalsIgnoreCase(feqBrought)){
				colCount++;
			}else if(we.getText().trim().equalsIgnoreCase(collbFil)){
				colCount++;
			}
		}
		
		if(colCount == 3){
			generateXML.logVP("42.1" ,"This method is used to check percentage of four strategies in Strategy Aggregate " +
					"All the four strategies Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("42.1" ,"This method is used to check percentage of four strategies in Strategy Aggregate " +
					"All the four strategies  Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}
	}
	
	@Test
	public void test_D_6() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();
		
		String TPLinkXpath = ExcelUtil.readProps(pageName, DataConstants.TPLink);
		WebElement tpWebElement = driver.findElement(By.xpath(TPLinkXpath));
		tpWebElement.click();
		//String strategyDetails =  ExcelUtil.readProps(pageName,"/html/body/div[3]/div/div/div");
		Thread.sleep(4000);
		
		
		String suggesteditems = ("Suggested Items ").concat("60").concat("60"+"%");
		String feqBrought = ("Frequently Bought ").concat("30").concat("30"+"%");
		String collbFil = ("Collaborative Filtering ").concat("10").concat("10"+"%");
		//String topSellers = ("Top Sellers ").concat("10").concat("10"+"%");
		String SIColor = "fill: rgb(71, 186, 235);";
		String FBColor = "fill: rgb(105, 190, 40);";
		String CFColor = "fill: rgb(247, 142, 30);";
		int colCount=0;
		int colColor=0;
		//WebElement page2 = driver.findElement(By.className("page2"));
		
		WebElement StratConfigWebElement = driver.findElement(By.id("configPie")); 
		//System.out.println(" StratConfigWebElement "+ StratConfigWebElement.getText());
		WebElement svgElement = StratConfigWebElement.findElement(By.tagName("svg"));
		WebElement gElement = svgElement.findElement(By.tagName("g"));
		
		List<WebElement> StConList = gElement.findElements(By.className("arc"));
		for(WebElement we : StConList){
			//System.out.println("get Text "+ we.getText());
			if(we.getText().trim().equalsIgnoreCase(suggesteditems)){
				colCount++;
				//System.out.println("color SI "+ we.findElement(By.tagName("path")).getAttribute("style").trim());
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(SIColor)){
					colColor++;
				}
			}else if(we.getText().trim().equalsIgnoreCase(feqBrought)){
				colCount++;
				//System.out.println("color FB "+ we.findElement(By.tagName("path")).getAttribute("style").trim());
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(FBColor)){
					colColor++;
				}
			}else if(we.getText().trim().equalsIgnoreCase(collbFil)){
				colCount++;
				//System.out.println("color CF "+ we.findElement(By.tagName("path")).getAttribute("style").trim());
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(CFColor)){
					colColor++;
				}
			}
		}
		
		if(colCount == 3){
			generateXML.logVP("43.1" ,"This method is used to check percentage of four strategies in Strategy Configuration " +
					"All the four strategies Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("43.1" ,"This method is used to check percentage of four strategies in Strategy Configuration " +
					"All the four strategies  Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}	
		
		if(colColor == 3){
			generateXML.logVP("43.2" ,"This method is used to check colors of three strategies in Strategy Configuration " +
					"All the four strategies Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("43.2" ,"This method is used to check colors of three strategies in Strategy Configuration " +
					"All the four strategies  Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}	
		
		
	}
	
	@Test
	public void test_D_7() throws Exception {
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();
		
		String TPLinkXpath = ExcelUtil.readProps(pageName, DataConstants.TPLink);
		WebElement tpWebElement = driver.findElement(By.xpath(TPLinkXpath));
		tpWebElement.click();
		//String strategyDetails =  ExcelUtil.readProps(pageName,"/html/body/div[3]/div/div/div");
		Thread.sleep(4000);
		
		
		String suggesteditems = ("Suggested For You ").concat("69").concat("69"+"%");
		String feqBrought = ("Frequently Bought ").concat("8").concat("8"+"%");
		String collbFil = ("Collaborative Filtering ").concat("23").concat("23"+"%");
		//String topSellers = ("Top Sellers ").concat("10").concat("10"+"%");
		
		int colCount=0;
		int colColor =0;
		String SIColor = "fill: rgb(71, 186, 235);";
		String FBColor = "fill: rgb(105, 190, 40);";
		String CFColor = "fill: rgb(247, 142, 30);";
		//WebElement page2 = driver.findElement(By.className("page2"));
		
		WebElement StratConfigWebElement = driver.findElement(By.id("aggrePie")); 
		//System.out.println(" StratConfigWebElement "+ StratConfigWebElement.getText());
		WebElement svgElement = StratConfigWebElement.findElement(By.tagName("svg"));
		WebElement gElement = svgElement.findElement(By.tagName("g"));
		
		List<WebElement> StConList = gElement.findElements(By.className("arc"));
		for(WebElement we : StConList){
			//System.out.println("get Text "+ we.getText());
			if(we.getText().trim().equalsIgnoreCase(suggesteditems)){
				colCount++;
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(SIColor)){
					colColor++;
				}
			}else if(we.getText().trim().equalsIgnoreCase(feqBrought)){
				colCount++;
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(FBColor)){
					colColor++;
				}
			}else if(we.getText().trim().equalsIgnoreCase(collbFil)){
				colCount++;
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(CFColor)){
					colColor++;
				}
			}
		}
		
		
		
		if(colCount == 3){
			generateXML.logVP("44.1" ,"This method is used to check percentage of four strategies in Strategy Aggregate " +
					"All the four strategies Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("44.1" ,"This method is used to check percentage of four strategies in Strategy Aggregate " +
					"All the four strategies  Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}
		if(colColor == 3){
			generateXML.logVP("44.2" ,"This method is used to check colors of three strategies in Strategy Configuration " +
					"All the four strategies Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("44.2" ,"This method is used to check colors of three strategies in Strategy Configuration " +
					"All the four strategies  Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}	
	}
	
	@Test
	public void test_D_8() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();
		
		String TPLinkXpath = ExcelUtil.readProps(pageName, DataConstants.TPLink);
		WebElement tpWebElement = driver.findElement(By.xpath(TPLinkXpath));
		tpWebElement.click();
		//String strategyDetails =  ExcelUtil.readProps(pageName,"/html/body/div[3]/div/div/div");
		Thread.sleep(4000);
		
		
		String suggesteditems = ("Suggested For You ").concat("49").concat("49"+"%");
		String feqBrought = ("Bought Together ").concat("15").concat("15"+"%");
		String collbFil = ("Collaborative Filtering ").concat("36").concat("36"+"%");
		//String topSellers = ("Top Sellers ").concat("10").concat("10"+"%");
		
		int colCount=0;
		int colColor =0;
		String SIColor = "fill: rgb(105, 190, 40);";
		String FBColor = "fill: rgb(71, 186, 235);";
		String CFColor = "fill: rgb(247, 142, 30);";
		//WebElement page2 = driver.findElement(By.className("page2"));
		
		WebElement StratConfigWebElement = driver.findElement(By.id("clicksPie")); 
		//System.out.println(" StratConfigWebElement "+ StratConfigWebElement.getText());
		WebElement svgElement = StratConfigWebElement.findElement(By.tagName("svg"));
		WebElement gElement = svgElement.findElement(By.tagName("g"));
		
		List<WebElement> StConList = gElement.findElements(By.className("arc"));
		for(WebElement we : StConList){
			//System.out.println("get Text "+ we.getText());
			if(we.getText().trim().equalsIgnoreCase(suggesteditems)){
				colCount++;
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(SIColor)){
					colColor++;
				}
			}else if(we.getText().trim().equalsIgnoreCase(feqBrought)){
				colCount++;
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(FBColor)){
					colColor++;
				}
			}else if(we.getText().trim().equalsIgnoreCase(collbFil)){
				colCount++;
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(CFColor)){
					colColor++;
				}
			}
		}
		
		
		
		if(colCount == 3){
			generateXML.logVP("45.1" ,"This method is used to check percentage of three strategies in Clicks " +
					"All the four strategies Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("45.1" ,"This method is used to check percentage of three strategies in Clicks " +
					"All the four strategies  Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}
		if(colColor == 3){
			generateXML.logVP("45.2" ,"This method is used to check colors of three strategies in Clicks " +
					"All the four strategies Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("45.2" ,"This method is used to check colors of three strategies in Clicks " +
					"All the four strategies  Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}	
	}
	
	@Test
	public void test_D_9() throws Exception{
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName,DataConstants.SIDEMENU_SCRIBE))).click();
		//HBaseUtil hutil = new HBaseUtil();

		//String xpathExpression;
		/* Clear the from date text box */
		String xpathExpression = ExcelUtil.readProps(pageName, DataConstants.FROM_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String frmDate = ExcelUtil.readProps(pageName, DataConstants.VALID_FROM_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(frmDate);

		/* Clear the to date text box */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.TO_DATE);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid From Date */
		String toDate = ExcelUtil.readProps(pageName, DataConstants.VALID_TO_DATE).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(toDate);

		/* Click on Go Button */
		xpathExpression = ExcelUtil.readProps(pageName, DataConstants.GO);
		driver.findElement(By.xpath(xpathExpression)).click();

		String gridPage = ExcelUtil.readProps(pageName, DataConstants.GRID_PAGE);
		List<WebElement> tabList = driver.findElements(By.className(gridPage));
		WebElement cssWebElement = tabList.get(0).findElement(By.className(ExcelUtil.readProps(pageName, DataConstants.CSS_TABS)));
		cssWebElement.findElement(By.xpath(ExcelUtil.readProps(pageName, DataConstants.SHELFWISE))).click();
		
		String TPLinkXpath = ExcelUtil.readProps(pageName, DataConstants.TPLink);
		WebElement tpWebElement = driver.findElement(By.xpath(TPLinkXpath));
		tpWebElement.click();
		//String strategyDetails =  ExcelUtil.readProps(pageName,"/html/body/div[3]/div/div/div");
		Thread.sleep(4000);
		
		
		String suggesteditems = ("Suggested For You ").concat("37").concat("37"+"%");
		String feqBrought = ("Bought Together ").concat("31").concat("31"+"%");
		String collbFil = ("Collaborative Filtering ").concat("32").concat("32"+"%");
		//String topSellers = ("Top Sellers ").concat("10").concat("10"+"%");
		
		int colCount=0;
		int colColor =0;
		String SIColor = "fill: rgb(105, 190, 40);";
		String FBColor = "fill: rgb(71, 186, 235);";
		String CFColor = "fill: rgb(247, 142, 30);";
		//WebElement page2 = driver.findElement(By.className("page2"));
		
		WebElement StratConfigWebElement = driver.findElement(By.id("ordersPie")); 
		//System.out.println(" StratConfigWebElement "+ StratConfigWebElement.getText());
		WebElement svgElement = StratConfigWebElement.findElement(By.tagName("svg"));
		WebElement gElement = svgElement.findElement(By.tagName("g"));
		
		List<WebElement> StConList = gElement.findElements(By.className("arc"));
		for(WebElement we : StConList){
			//System.out.println("get Text "+ we.getText());
			if(we.getText().trim().equalsIgnoreCase(suggesteditems)){
				colCount++;
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(SIColor)){
					colColor++;
				}
			}else if(we.getText().trim().equalsIgnoreCase(feqBrought)){
				colCount++;
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(FBColor)){
					colColor++;
				}
			}else if(we.getText().trim().equalsIgnoreCase(collbFil)){
				colCount++;
				if(we.findElement(By.tagName("path")).getAttribute("style").trim().equalsIgnoreCase(CFColor)){
					colColor++;
				}
			}
		}
		
		
		
		if(colCount == 3){
			generateXML.logVP("45.1" ,"This method is used to check percentage of three strategies in Orders " +
					"All the four strategies Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("45.1" ,"This method is used to check percentage of three strategies in Orders " +
					"All the four strategies  Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}
		if(colColor == 3){
			generateXML.logVP("45.2" ,"This method is used to check colors of three strategies in Orders " +
					"All the four strategies Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("45.2" ,"This method is used to check colors of three strategies in Orders " +
					"All the four strategies  Frequently Bought, Suggested items, Collaborative Filtering are shown",
					"The percentage of each strategy are properly shown", AppConstants.vFail);
		}	
	}
	/**
	 * After executing each test method, this method
	 * is called
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {

	}

	/**
	 * This method is invoked after all test methods in Data.java
	 * are executed
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */
	@AfterClass
	public static void tearDownAfterClass() throws TransformerConfigurationException, TransformerException {		

		AppConstants.notRunCount = Integer.parseInt(propsRW.read(AppConstants.TOTAL_VERIFICATION_POINTS).trim())-AppConstants.passCount-AppConstants.failCount;
		//log header report counts in XML file
		generateXML.logHeaderReportCounts();
		//Generate html report using xml created in test method
		//Report should be according to test case name, ex: data.html
		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH+AppConstants.DETAILED_REPORT_XSL;
		String outputHTML = AppConstants.DETAIL_REPORT_FOLDER+AppConstants.FORWARD_SLASH+AppConstants.DATA+AppConstants.DOT_HTML;
		generateReport.generateHTML(AppConstants.XML_FILE_PATH, inputXSL, outputHTML);

		System.out.println("Successfully generated the report");

		//log script in summary report xml file
		generateXML.logScript(AppConstants.DATA_SCRIPT_NAME, outputHTML);

		//Reset xml & properties files path to ""	
		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;

		//Set pass, fail and notrun count to zero
		AppConstants.passCount= 0;
		AppConstants.failCount = 0;
		AppConstants.notRunCount = 0;

		//Close the browser
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!AppConstants.BLANK_STRING.equals(verificationErrorString)) {
			fail(verificationErrorString);
		}

	}


}
