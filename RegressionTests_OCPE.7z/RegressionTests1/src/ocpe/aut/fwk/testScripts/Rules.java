package ocpe.aut.fwk.testScripts;

import static org.junit.Assert.*;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.constants.RuleConstants;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.apache.xpath.operations.Bool;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Rules {
	
	private static StringBuffer verificationErrors = new StringBuffer();

	private static WebDriver driver;
	static DesiredCapabilities cap = null; 
	static FirefoxBinary ffBinary = null; 
	static FirefoxProfile ffprofile = null;

	private static GenerateXml generateXML;
	private static GenerateHTML generateReport;

	//static int pass= 0,fail = 0, notRun = 0;

	private static PropertiesUtil propsRW_login;
	private static PropertiesUtil propsRW_rules;
	private static ExcelUtil excelRW;
	private static String pageName;
	
	@BeforeClass
	public static void oneTimeSetUp() {
		// one-time initialization code   
		// one-time initialization code   
		System.out.println("@BeforeClass - oneTimeSetUp");
		
		File  pathToFirefoxBinary = new File(AppConstants.PATH_TO_FIREFOX_BINARY);
		ffBinary = new FirefoxBinary(pathToFirefoxBinary);
		ProfilesIni profile = new ProfilesIni();		   		   
		ffprofile = profile.getProfile(AppConstants.FIREFOX_PROFILE_DEFAULT);
		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();		  		  
		proxy.setProxyAutoconfigUrl(AppConstants.PROXY_URL);	
		cap = new DesiredCapabilities();		  
		cap.setCapability(CapabilityType.PROXY, proxy);	
		

		driver = new FirefoxDriver(ffBinary,ffprofile,cap);		
		
		
		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(AppConstants.BASE_URL + AppConstants.LOGIN_URL);

		generateXML = new GenerateXml();		
		generateReport = new GenerateHTML();		
		excelRW = new ExcelUtil(); 
		
		//Change the xml file path according to name of the script
		AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER+AppConstants.FORWARD_SLASH+RuleConstants.RULES+AppConstants.DOT_XML;
		AppConstants.PROPERTIES_FILE_PATH = RuleConstants.RULES_PROPERTIES;		

		//Sheet Name of excel from where the xpath values are fetched
		pageName = RuleConstants.RULES_TAB;

		//Create a new XML file
		generateXML.createVPXML(RuleConstants.RULES_SCRIPT_NAME);

		//Login
		/*Firefox browser gets opened with OCPE Login page, provide 
		 * with username rg@gmail.com and click on submit button.
		 * After login, Data tab selected with it's first side menu highlighted */

		/*Clear the User Name textbox*/
		String xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.USER_NAME);
		driver.findElement(By.xpath(xpathExpression)).clear();

		propsRW_login = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);

		/* Get valid username from properties file
		 * ex: rg@gmail.com*/
		String userName = propsRW_login.read(AppConstants.VALID_USERNAME).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(userName);


		/* Clear the Password textbox*/
		xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.PASSWORD);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid password from properties file
		 * ex: Aham123+*/
		String password = propsRW_login.read(AppConstants.VALID_PASSWORD).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(password);


		/*Click on login button*/
		xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.LOGIN_SUBMIT);		
		driver.findElement(By.xpath(xpathExpression)).click();
		
		propsRW_rules=new PropertiesUtil(RuleConstants.RULES_PROPERTIES);
		String xpathExpression_rules = excelRW.readProps(RuleConstants.RULES_TAB, RuleConstants.TAB_RULES);
		driver.findElement(By.xpath(xpathExpression_rules)).click();
		
		
		

	}

	/**
	 * One time set up for each method annotated with @Test annotation 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {

	}
	
	

	
	@Test
	public void test_001() throws Exception {	
		
		Thread.sleep(1000);

		//Check whether Data tab is selected or not
		String xpathExpression = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ID);
		String rule_name  = driver.findElement(By.xpath(xpathExpression)).getText();
		
		
		if(rule_name.equals(RuleConstants.RULE_INSTANCE_NAME) ) {
			generateXML.logVP("1.1", "Check whether after navigate to rules tab, Rules Instance selected or not",	"after navigate to rules tab, Rules Instance selected", AppConstants.vPass);				
			//pass++;
		} else {
			generateXML.logVP("1.1", "Check whether after navigate to rules tab, Rules Instance selected or not",	 "after navigate to rules tab, Rules Instance not selected ", AppConstants.vFail);		
			//fail++;
		}	

		
	}
	
	@Test
	public void test_002() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(1000);

		//Check whether Data tab is selected or not
		String xpathExpression = excelRW.readProps(pageName, RuleConstants.RULES_COUNT_PATH);
		
	    int count= driver.findElements(By.xpath(xpathExpression)).size();
	    
		 
		  
		if(count==Integer.parseInt(propsRW_rules.read(RuleConstants.RULES_COUNT).trim()) ) {
			generateXML.logVP("2.1", "after navigate to rules tab, it display two unordered list or not",	"after navigate to rules tab, it displaying two unordered list", AppConstants.vPass);				
			//pass++;
		} else {
			generateXML.logVP("2.1", "after navigate to rules tab, it display two unordered list or not",	 "after navigate to rules tab, it's not displaying  two unordered list ", AppConstants.vFail);		
			//fail++;
		}	

		
	}
	
	
	@Test
	public void test_003() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(1000);

		//Check whether Data tab is selected or not
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.LIST_OF_RULES_ID);
		String list_of_rules  = driver.findElement(By.xpath(xpathExpression1)).getText();
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.ADVANCE_SEARCH_ID);
		String advance_search  = driver.findElement(By.xpath(xpathExpression2)).getText();
		
	
		
		
		if(list_of_rules.equals(RuleConstants.LIST_OF_RULES_NAME) && advance_search.equals(RuleConstants.ADVANCE_SEARCH_NAME)) {
			generateXML.logVP("3.1", "after navigate to rules tab and after selecting the Rule Instance wheteher it displaying two tabs or not ",	"after navigate to rules tab and after selecting the Rule Instance  it displaying two tabs ", AppConstants.vPass);				
			//pass++;
		} else {
			generateXML.logVP("3.1", "after navigate to rules tab and after selecting the Rule Instance wheteher it displaying two tabs or not ",	 "after navigate to rules tab and after selecting the Rule Instance  it's not displaying two tabs", AppConstants.vFail);		
			//fail++;
		}	

		
	}
	
	@Test
	public void test_004() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(1000);

		//Check whether Data tab is selected or not
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_ID);
		String rule_name  = driver.findElement(By.xpath(xpathExpression1)).getText();
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_DESCRIPTION_ID);
		String rule_description  = driver.findElement(By.xpath(xpathExpression2)).getText();
		
		
		if(rule_name.equals(RuleConstants.RULE_NAME_NAME) && rule_description.equals(RuleConstants.RULE_DESCRIPTION_NAME)) {
			generateXML.logVP("4.1", "Verify if Rule Instance tab is shown after after navigate to Rules tab ",	"'Rule Instance' Tab is shown After after navigate to Rules tab ", AppConstants.vPass);			
			generateXML.logVP("4.2", "Verify if Rule Scopee tab is shown after after navigate to Rules tab ",	"'Rule Scope' Tab is shown After after navigate to Rules tab ", AppConstants.vPass);			
			//pass=pass+2;
		} else {
			generateXML.logVP("4.1", "Verify if Rule Instance tab is shown after after navigate to Rules tab ",	"'Rule Instance' Tab is Not shown After after navigate to Rules tab ", AppConstants.vFail);			
			generateXML.logVP("4.2", "Verify if Rule Scopee tab is shown after after navigate to Rules tab ",	"'Rule Scope' Tab is Not shown After after navigate to Rules tab ", AppConstants.vFail);			
			//fail=fail+2;
		}	

		
	}
	@Test
	public void test_005() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(1000);

		//Check whether Data tab is selected or not
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_HYPER_LINK_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_OVERVIEW_ID);
		String rule_overview= driver.findElement(By.xpath(xpathExpression2)).getText();
		
		
		if(rule_overview.equals(RuleConstants.RULE_OVERVIEW_NAME) ) {
			generateXML.logVP("5.1", "after navigate to Rules tab , Rule Instance and List of Rules wheteher it displaying Rule Name and Rule Description or not ",	"after navigate to Rules tab , Rule Instance and List of Rules , it's displaying Rule Name and Rule Description ", AppConstants.vPass);				
			//pass++;
		} else {
			generateXML.logVP("5.1", "after navigate to Rules tab , Rule Instance and List of Rules wheteher it displaying Rule Name and Rule Description or not ",	 "after navigate to Rules tab , Rule Instance and List of Rules wheteher it's not displaying Rule Name and Rule Description", AppConstants.vFail);		
			//fail++;
		}	

		
	}
	
	@Test
	public void test_006() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(1000);

		//Check whether Data tab is selected or not
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.SHOWING_ID);
		String showing_data= driver.findElement(By.xpath(xpathExpression2)).getText();
		
		
		
		if(showing_data.contains(RuleConstants.SHOWING_NAME) ) {
			generateXML.logVP("6.1", "Verify whether the tex t saying 'showing  n/n records ' is displayed at the bottom of the screen",	"'showing  n/n records ' is displayed at the bottom of the screen", AppConstants.vPass);				
			//pass++;
		} else {
			generateXML.logVP("6.1", "Verify whether the tex t saying 'showing  n/n records ' is displayed at the bottom of the screen ",	 "'showing  n/n records ' is not displayed at the bottom of the screen", AppConstants.vFail);		
			//fail++;
		}	

		
	}
	
	@Test
	public void test_007() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(1000);

		//Check whether Data tab is selected or not
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.SHOW_ENTRIES_ID_1);
		String show_entries1= driver.findElement(By.xpath(xpathExpression2)).getText();
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.SHOW_ENTRIES_ID_2);
		String show_entries2= driver.findElement(By.xpath(xpathExpression1)).getText();
		
		
		
		if(show_entries1.contains(RuleConstants.SHOW_ENTRIES_NAME_1) &&  show_entries2.contains(RuleConstants.SHOW_ENTRIES_NAME_2)) {
			generateXML.logVP("7.1", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the bottom of the page",	"'no of rows per page' drop down is available for the user to set and view results at the bottom of the page", AppConstants.vPass);				
			generateXML.logVP("7.2", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the bottom of the page",	"'no of rows per page' drop down is available for the user to set and view results at the bottom of the page", AppConstants.vPass);
			//pass=pass+2;
		} else {
			generateXML.logVP("7.1", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the bottom of the page ",	 "'no of rows per page' drop down is not available for the user to set and view results at the bottom of the page", AppConstants.vFail);
			generateXML.logVP("7.2", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the bottom of the page ",	 "'no of rows per page' drop down is not available for the user to set and view results at the bottom of the page", AppConstants.vFail);
			//fail=fail+2;
		}	

		
	}
	@Test
	public void test_008() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(1000);

		//Check whether Data tab is selected or not
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.PAGE_PREVIOUS_ID);
		String page_prev= driver.findElement(By.xpath(xpathExpression2)).getText();
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.PAGE_NEXT_ID);
		String page_next= driver.findElement(By.xpath(xpathExpression1)).getText();
		
		
		
		if(page_prev.equals(RuleConstants.PAGE_PREVIOUS_NAME) &&  page_next.equals(RuleConstants.PAGE_NEXT_NAME)) {
			generateXML.logVP("8.1", "verify Pagination-Prev ",	" Pagination-Prev and next buttons displayed", AppConstants.vPass);				
			generateXML.logVP("8.2", "verify Pagination-Prev and next buttons",	" Pagination-Prev and next buttons displayed", AppConstants.vPass);
			//pass=pass+2;
		} else {
			generateXML.logVP("8.1", "verify Pagination-Prev and next buttons",	 "Pagination-Prev and next buttons not dispalyed", AppConstants.vFail);
			generateXML.logVP("8.2", "verify Pagination-Prev and next buttons",	 "Pagination-Prev and next buttons not dispalyed", AppConstants.vFail);
			//fail=fail+2;
		}	

		
	}
	@Test
	public void test_009() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(1000);

		//Check whether Data tab is selected or not
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.PAGE_PREVIOUS_BUTTON_ID);
		boolean page_prev= driver.findElement(By.xpath(xpathExpression2)).isEnabled();
		
		
		
		
		
		if(!page_prev) {
			generateXML.logVP("9.1", "verify Pagination-Prev button clicking on it",	" it disabled", AppConstants.vPass);				
			//pass=pass+1;
		} else {
			generateXML.logVP("9.1", "verify Pagination-Prev button clicking on it ",	 "it's not disabled", AppConstants.vFail);		
			//fail=fail+1;
		}	

		
	}
	
	@Test
	public void test_011() throws Exception {	
		
//		//wait for 4 secs
//		Thread.sleep(4000);
//
//		//Check whether Data tab is selected or not
//		
//		String xpathExpression2 = excelRW.readProps(pageName, AppConstants.PAGE_PREVIOUS_BUTTON_ID);
//		boolean page_prev= driver.findElement(By.xpath(xpathExpression2)).isEnabled();
//		
//		
//		
//		
//		
//		if(!page_prev) {
//			generateXML.logVP("1", "verify Pagination-Prev button clicking on it",	" it disabled", AppConstants.vPass);				
//			pass=pass+1;
//		} else {
//			generateXML.logVP("1", "verify Pagination-Prev button clicking on it ",	 "it's not disabled", AppConstants.vFail);		
//			fail=fail+1;
//		}	

		
	}
	
	@Test
	public void test_012() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(1000);

		//Check whether Data tab is selected or not
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.SHOWING_ID);
		String showing_data= driver.findElement(By.xpath(xpathExpression2)).getText();
		
		
		
		if(showing_data.contains(RuleConstants.SHOWING_1_OF_N_NAME) ) {
			generateXML.logVP("11.1", "Verify whether the tex t saying 'showing  1 of n records ' is displayed at the bottom of the screen",	"'showing  1 of n records ' is displayed at the bottom of the screen", AppConstants.vPass);				
			//pass++;
		} else {
			generateXML.logVP("11.1", "Verify whether the tex t saying 'showing  1 of n records ' is displayed at the bottom of the screen ",	 "'showing  1 of n records ' is not displayed at the bottom of the screen", AppConstants.vFail);		
			//fail++;
		}	

		
	}
	@Test
	public void test_013() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(1000);

		//Check whether Data tab is selected or not
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.ADVANCE_SERCH_ID_RS);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath(xpathExpression2)).click();
//		driver.findElement(By.cssSelector("a[id=\"searchRule\"] > b")).click();
		String advance_search_data= driver.findElement(By.xpath(xpathExpression2)).getText();
		
		Thread.sleep(1000);
		
		if(advance_search_data.equals(RuleConstants.ADVANCE_SERCH_NAME) ) {
			generateXML.logVP("12.1", "Verify the user is able to click and navigate to advance search tab in the console",	"able to click and navigate to advance search tab in the console", AppConstants.vPass);				
			//pass++;
		} else {
			generateXML.logVP("12.2", "Verify the user is able to click and navigate to advance search tab in the console",	 "not able to click and navigate to advance search tab in the console", AppConstants.vFail);		
			//fail++;
		}	
		Thread.sleep(3000);
		
	}
	@Test
	public void test_014() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(3000);

		//Check whether Data tab is selected or not
		//String xpathExpression2_1 = excelRW.readProps(pageName, AppConstants.ADVANCE_SERCH_ID_RS);
	//	String xpathExpression1_1 = excelRW.readProps(pageName, AppConstants.RULE_INSTANCE_ID);
		//driver.findElement(By.xpath(xpathExpression1_1)).click();
		
		//Thread.sleep(3000);
		//driver.findElement(By.xpath(xpathExpression2_1)).click();
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_ADVS_ID);
		String rule_name_advs_data= driver.findElement(By.xpath(xpathExpression1)).getText();
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_DESC_ADVS_ID);
		String rule_desc_advs_data= driver.findElement(By.xpath(xpathExpression2)).getText();
		
		
		
		if(rule_name_advs_data.equals(RuleConstants.RULE_NAME_ADVS_NAME) && rule_desc_advs_data.equals(RuleConstants.RULE_DESC_ADVS_NAME)) {
			generateXML.logVP("13.1", "Verify The advance search tab should have Rule Name and Rule description text boxes with  Go button",	"The advance search tab have Rule Name and Rule description text boxes with  Go button", AppConstants.vPass);				
			generateXML.logVP("13.2", "Verify The advance search tab should have Rule Name and Rule description text boxes with  Go button",	"The advance search tab have Rule Name and Rule description text boxes with  Go button", AppConstants.vPass);
		//	pass=pass+2;
		} else {
			generateXML.logVP("13.1", "The advance search tab should have Rule Name and Rule description text boxes with  Go button",	 "The advance search tab DONT HAVE Rule Name and Rule description text boxes with  Go button", AppConstants.vFail);		
			generateXML.logVP("13.2", "The advance search tab should have Rule Name and Rule description text boxes with  Go button",	 "The advance search tab DONT HAVE Rule Name and Rule description text boxes with  Go button", AppConstants.vFail);
			//fail=fail+2;
		}	

		
	}
	
	@Test
	public void test_015() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(3000);

		//Check whether Data tab is selected or not
		//String xpathExpression2_1 = excelRW.readProps(pageName, AppConstants.ADVANCE_SERCH_ID_RS);
	//	String xpathExpression1_1 = excelRW.readProps(pageName, AppConstants.RULE_INSTANCE_ID);
		//driver.findElement(By.xpath(xpathExpression1_1)).click();
		
		//Thread.sleep(3000);
		//driver.findElement(By.xpath(xpathExpression2_1)).click();
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_ADVS_ID);
		
	    String type1=	driver.findElement(By.xpath(xpathExpression1)).getAttribute("type");
	
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_DESC_TEXT_ADVS_ID);
		String type2= driver.findElement(By.xpath(xpathExpression2)).getAttribute("type");
		
		String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_ADVS_BTN_ID);
		String type3= driver.findElement(By.xpath(xpathExpression3)).getAttribute("type");
		
		
		
		
		if(type1.equals(RuleConstants.RULE_ADVS_TYPE_TEXT) && type2.equals(RuleConstants.RULE_ADVS_TYPE_TEXT) && type3.equals(RuleConstants.RULE_ADVS_TYPE_SUBMIT)) {
			generateXML.logVP("14.1", "Verify The advance search tab should have Rule Name and Rule description text boxes with  Go button",	"The advance search tab have Rule Name and Rule description text boxes with  Go button", AppConstants.vPass);				
			generateXML.logVP("14.2", "Verify The advance search tab should have Rule Name and Rule description text boxes with  Go button",	"The advance search tab have Rule Name and Rule description text boxes with  Go button", AppConstants.vPass);
			generateXML.logVP("14.3", "Verify The advance search tab should have Rule Name and Rule description text boxes with  Go button",	"The advance search tab have Rule Name and Rule description text boxes with  Go button", AppConstants.vPass);
			//pass=pass+3;
		} else {
			generateXML.logVP("14.1", "The advance search tab should have Rule Name and Rule description text boxes with  Go button",	 "The advance search tab DONT HAVE Rule Name and Rule description text boxes with  Go button", AppConstants.vFail);		
			generateXML.logVP("14.2", "The advance search tab should have Rule Name and Rule description text boxes with  Go button",	 "The advance search tab DONT HAVE Rule Name and Rule description text boxes with  Go button", AppConstants.vFail);
			generateXML.logVP("14.3", "The advance search tab should have Rule Name and Rule description text boxes with  Go button",	 "The advance search tab DONT HAVE Rule Name and Rule description text boxes with  Go button", AppConstants.vFail);
			//fail=fail+3;
		}	

		
	}
	
	@Test
	public void test_016() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_ADVS_ID);
		
		 driver.findElement(By.xpath(xpathExpression1)).clear();
	    driver.findElement(By.xpath(xpathExpression1)).sendKeys(",.?#>");
	    String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_ADVS_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression3)).click();
		
	
	    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_ERROR_ADVS_ID);
		
		String msg=driver.findElement(By.xpath(xpathExpression2)).getText();
		
		
		
		
		
		if(msg.equals(RuleConstants.RULE_NAME_TEXT_ERROR_ADVS_MSG) ) {
			generateXML.logVP("15.1", "Verify The 'Rule Name' segment text  box should allow alphanumeric ",	" The segment text  box is allowing alphanumeric", AppConstants.vPass);				
			//pass=pass+1;
		} else {
			generateXML.logVP("15.1", "Verify The 'Rule Name' segment text  box should allow alphanumeric",	 " The segment text  box  is not allowing alphanumeric", AppConstants.vFail);		
			//fail=fail+1;
		}	

		
	}
	
	@Test
	public void test_017() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
		String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_ADVS_ID);
		
		 driver.findElement(By.xpath(xpathExpression1_0)).sendKeys("");
		 
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_DESC_TEXT_ADVS_ID);
		 driver.findElement(By.xpath(xpathExpression1)).clear();
	    
	    driver.findElement(By.xpath(xpathExpression1)).sendKeys(",.?#>");
	    String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_ADVS_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression3)).click();
		
	
	    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_ERROR_ADVS_ID);
		
		String msg=driver.findElement(By.xpath(xpathExpression2)).getText();
		
		
		
		
		
		if(msg.equals(RuleConstants.RULE_NAME_TEXT_ERROR_ADVS_MSG) ) {
			generateXML.logVP("15.2", "Verify The 'Rule Description' segment text  box should allow alphanumeric ",	" The segment text  box is allowing alphanumeric", AppConstants.vPass);				
			//pass=pass+1;
		} else {
			generateXML.logVP("15.2", "Verify The 'Rule Description' segment text  box should allow alphanumeric",	 " The segment text  box  is not allowing alphanumeric", AppConstants.vFail);		
		//	fail=fail+1;
		}	

		
	}
	
	@Test
	public void test_018() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
		String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_ADVS_ID);
		
		 driver.findElement(By.xpath(xpathExpression1_0)).clear();
		 driver.findElement(By.xpath(xpathExpression1_0)).sendKeys(">>>>>>>>>");;
		 
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_DESC_TEXT_ADVS_ID);
		 driver.findElement(By.xpath(xpathExpression1)).clear();
	    
	    driver.findElement(By.xpath(xpathExpression1)).sendKeys(",.?#>");
	    String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_ADVS_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression3)).click();
		
	
	    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_ERROR_ADVS_ID);
		
		String msg=driver.findElement(By.xpath(xpathExpression2)).getText();
		
		
		
		
		
		if(msg.equals(RuleConstants.RULE_NAME_TEXT_SPECIAL_ADVS_MSG) ) {
			generateXML.logVP("16.1", "Verify The 'Rule Description' and 'Rule Name' segment text  box should not allow special characters ",	" The segment text  box is not allowing special cahracters", AppConstants.vPass);				
			generateXML.logVP("16.2", "Verify The 'Rule Description' and 'Rule Name' segment text  box should not allow special characters ",	" The segment text  box is not allowing special cahracters", AppConstants.vPass);
			//pass=pass+2;
		} else {
			generateXML.logVP("16.1", "Verify The 'Rule Description' and 'Rule Name' segment text  box should not allow special characters ",	 " The segment text  box  is allowing special characters", AppConstants.vFail);		
			generateXML.logVP("16.2", "Verify The 'Rule Description' and 'Rule Name' segment text  box should not allow special characters ",	 " The segment text  box  is allowing special characters", AppConstants.vFail);
		//	fail=fail+2;
		}	

		
	}
	
	@Test
	public void test_019() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
		String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_ADVS_ID);
		
		 driver.findElement(By.xpath(xpathExpression1_0)).clear();
		 driver.findElement(By.xpath(xpathExpression1_0)).sendKeys("Brand");;
		 
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_DESC_TEXT_ADVS_ID);
		 driver.findElement(By.xpath(xpathExpression1)).clear();
	    
	    driver.findElement(By.xpath(xpathExpression1)).sendKeys("This");
	    String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_ADVS_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression3)).click();
		
	
	    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_BRAND_ADVS_ID);
		
		String msg=driver.findElement(By.xpath(xpathExpression2)).getText();
		
		
		
		
		
		if(msg.equals(RuleConstants.RULE_NAME_TEXT_BRAND_ADVS_MSG) ) {
			generateXML.logVP("17.1", "Verify That system shall validate the details entered by user upon clicking Go button and should display the search results  applying 'and' search  ",	" displaying the search results  applying 'and' search  ", AppConstants.vPass);				
			//pass=pass+1;
		} else {
			generateXML.logVP("17.2", "Verify That system shall validate the details entered by user upon clicking Go button and should display the search results  applying 'and' search  ",	 "not displaying the search results  applying 'and' search ", AppConstants.vFail);		
			//fail=fail+1;
		}	

		
	}
	
	@Test
	public void test_021() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
		String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_ADVS_ID);
		
		 driver.findElement(By.xpath(xpathExpression1_0)).clear();
		 driver.findElement(By.xpath(xpathExpression1_0)).sendKeys("Brand");;
		 
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_DESC_TEXT_ADVS_ID);
		 driver.findElement(By.xpath(xpathExpression1)).clear();
	    
	    driver.findElement(By.xpath(xpathExpression1)).sendKeys("This");
	    String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_ADVS_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression3)).click();
		
	    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_BRAND_ADVS_ID);
		
		String msg=driver.findElement(By.xpath(xpathExpression2)).getText();
		
		
		
		
		
		if(msg.equals(RuleConstants.RULE_NAME_TEXT_BRAND_ADVS_MSG) ) {
			generateXML.logVP("18.1", "Verify That system shall validate the details entered by user upon clicking Go button and should display the search results  applying 'and' search  ",	" displaying the search results  applying 'and' search  ", AppConstants.vPass);				
			//pass=pass+1;
		} else {
			generateXML.logVP("18.2", "Verify That system shall validate the details entered by user upon clicking Go button and should display the search results  applying 'and' search  ",	 "not displaying the search results  applying 'and' search ", AppConstants.vFail);		
			//fail=fail+1;
		}	

		
	}
	@Test
	public void test_022() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
		String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_ADVS_ID);
		
		 driver.findElement(By.xpath(xpathExpression1_0)).clear();
		 driver.findElement(By.xpath(xpathExpression1_0)).sendKeys("Brand");;
		 
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_DESC_TEXT_ADVS_ID);
		 driver.findElement(By.xpath(xpathExpression1)).clear();
	    
	    driver.findElement(By.xpath(xpathExpression1)).sendKeys("This");
	    String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_ADVS_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression3)).click();
		
	
	    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_ADVS_RULE_NAME_ID);
		
		String msg1=driver.findElement(By.xpath(xpathExpression2)).getText();
     String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_ADVS_RULE_DESC_ID);
		
		String msg2=driver.findElement(By.xpath(xpathExpression4)).getText();
		
		
		
		
		
		if(msg1.equals(RuleConstants.RULE_NAME_ADVS_RULE_NAME_MSG) && msg2.equals(RuleConstants.RULE_NAME_ADVS_RULE_DESC_MSG)) {
			generateXML.logVP("19.1", "Verify That search results in the grid should have  Rule Name and Rule description columns displayed ",	" displaying the 'Rule Name' & 'Rule Description'  ", AppConstants.vPass);				
			generateXML.logVP("19.2", "Verify That search results in the grid should have  Rule Name and Rule description columns displayed ",	" displaying the 'Rule Name' & 'Rule Description'  ", AppConstants.vPass);
			//pass=pass+2;
		} else {
			generateXML.logVP("19.1", "Verify That search results in the grid should have  Rule Name and Rule description columns displayed ",	 "not displaying the 'Rule Name' & 'Rule Description' ", AppConstants.vFail);		
			generateXML.logVP("19.2", "Verify That search results in the grid should have  Rule Name and Rule description columns displayed ",	 "not displaying the 'Rule Name' & 'Rule Description' ", AppConstants.vFail);
			//fail=fail+2;
		}	

		
	}
	@Test
	public void test_023() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

//		
//		String xpathExpression1_0 = excelRW.readProps(pageName, AppConstants.RULE_NAME_TEXT_ADVS_ID);
//		
//		 driver.findElement(By.xpath(xpathExpression1_0)).clear();
//		 driver.findElement(By.xpath(xpathExpression1_0)).sendKeys("Brand");;
//		 
//		String xpathExpression1 = excelRW.readProps(pageName, AppConstants.RULE_DESC_TEXT_ADVS_ID);
//		 driver.findElement(By.xpath(xpathExpression1)).clear();
//	    
//	    driver.findElement(By.xpath(xpathExpression1)).sendKeys("This");
//	    String xpathExpression3 = excelRW.readProps(pageName, AppConstants.RULE_ADVS_BTN_ID);
//		 driver.findElement(By.xpath(xpathExpression3)).click();
		
	
//	    String xpathExpression2 = excelRW.readProps(pageName, AppConstants.RULE_NAME_ADVS_RULE_NAME_ID);
//		
//		String msg1=driver.findElement(By.xpath(xpathExpression2)).getText();
//     String xpathExpression4 = excelRW.readProps(pageName, AppConstants.RULE_NAME_ADVS_RULE_DESC_ID);
//		
//		String msg2=driver.findElement(By.xpath(xpathExpression4)).getText();
		
       String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_TEXT_BRAND_ADVS_ID);
		
		driver.findElement(By.xpath(xpathExpression2)).click();
		
      String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_RULE_INSTANCE_ADVS_ID);
		
		String msg1=driver.findElement(By.xpath(xpathExpression1)).getText();
		
		
		
		if(msg1.equals(RuleConstants.RULE_NAME_RULE_INSTANCE_ADVS_MSG) ) {
			generateXML.logVP("20.1", "Verify That user should be able to navigate Rule Instance list screen successfully clicking on any of the Rules search result link from the grid",	" able to navigate to other pages  ", AppConstants.vPass);				
			//pass=pass+1;
		} else {
			generateXML.logVP("20.1", "Verify That user should be able to navigate Rule Instance list screen successfully clicking on any of the Rules search result link from the grid",	 "not able to navigate to other pages   ", AppConstants.vFail);		
			//fail=fail+1;
		}	

		
	}
	
	@Test
	public void test_024() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
//       String xpathExpression2 = excelRW.readProps(pageName, AppConstants.RULE_NAME_TEXT_BRAND_ADVS_ID);
//		
//		driver.findElement(By.xpath(xpathExpression2)).click();
//		
//      String xpathExpression1 = excelRW.readProps(pageName, AppConstants.RULE_NAME_RULE_INSTANCE_ADVS_ID);
//		
//		String msg1=driver.findElement(By.xpath(xpathExpression1)).getText();
//		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_RULE_OVERVIEW_ADVS_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression1)).getText();
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_LIST_OF_RULES_ADVS_ID);
		String msg2=driver.findElement(By.xpath(xpathExpression2)).getText();
		
		String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_RULES_ADVS_ADVS_ID);
		String msg3=driver.findElement(By.xpath(xpathExpression3)).getText();
		
		String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_CREATE_NEW_RULE_ADVS_ID);
		String msg4=driver.findElement(By.xpath(xpathExpression4)).getText();
		
		if(msg1.equals(RuleConstants.RULE_NAME_RULE_OVERVIEW_ADVS_NAME)&&msg2.equals(RuleConstants.RULE_NAME_LIST_OF_RULES_ADVS_NAME)&&msg3.equals(RuleConstants.RULE_NAME_RULES_ADVS_ADVS_NAME)&&msg4.equals(RuleConstants.RULE_NAME_CREATE_NEW_RULE_ADVS_NAME) ) {
			generateXML.logVP("21.1", "Verify Rule instance list screen",	"displaying all tabs", AppConstants.vPass);				
			generateXML.logVP("21.2", "Verify Rule instance list screen",	"displaying all tabs", AppConstants.vPass);
			generateXML.logVP("21.3", "Verify Rule instance list screen",	"displaying all tabs", AppConstants.vPass);
			generateXML.logVP("21.4", "Verify Rule instance list screen",	"displaying all tabs", AppConstants.vPass);
			//pass=pass+4;
		} else {
			generateXML.logVP("21.1", "Verify Rule instance list screen",	 "not displaying all tabs", AppConstants.vFail);		
			generateXML.logVP("21.2", "Verify Rule instance list screen",	 "not displaying all tabs", AppConstants.vFail);
			generateXML.logVP("21.3", "Verify Rule instance list screen",	 "not displaying all tabs", AppConstants.vFail);
			generateXML.logVP("21.4", "Verify Rule instance list screen",	 "not displaying all tabs", AppConstants.vFail);
			//fail=fail+4;
		}	

		
	}
	
	@Test
	public void test_025() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
		
		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_CREATE_NEW_RULE_ADVS_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_CREATE_NEW_RULE_FOR_RULE_ADVS_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression2)).getText();
		
		if(msg1.equals(RuleConstants.RULE_NAME_CREATE_NEW_RULE_FOR_RULE_ADVS_NAME) ) {
			generateXML.logVP("22.1", "Verify create new rule instance button",	"able to create new rule instance", AppConstants.vPass);				
			//pass=pass+1;
		} else {
			generateXML.logVP("22.1", "Verify create new rule instance button",	 "not able to create new rule instance", AppConstants.vFail);		
			//fail=fail+1;
		}	

		
	}
	@Test
	public void test_026() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
		
		
		
//		String xpathExpression1 = excelRW.readProps(pageName, AppConstants.RULE_NAME_CREATE_NEW_RULE_ADVS_ID);
//		driver.findElement(By.xpath(xpathExpression1)).click();
//		
//		String xpathExpression2 = excelRW.readProps(pageName, AppConstants.RULE_NAME_CREATE_NEW_RULE_FOR_RULE_ADVS_ID);
//		String msg1=driver.findElement(By.xpath(xpathExpression2)).getText();
//		
//		if(msg1.equals(AppConstants.RULE_NAME_CREATE_NEW_RULE_FOR_RULE_ADVS_NAME) ) {
//			generateXML.logVP("1", "Verify create new rule instance button",	"able to create new rule instance", AppConstants.vPass);				
//			pass=pass+1;
//		} else {
//			generateXML.logVP("1", "Verify create new rule instance button",	 "not able to create new rule instance", AppConstants.vFail);		
//			fail=fail+1;
//		}	
//
//		Thread.sleep(2000);
	}
	
	@Test
	public void test_027() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
		
		
		
	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_CREATE_NEW_RULE_CANCEL_ADVS_ID);
	driver.findElement(By.xpath(xpathExpression1)).click();
	
	String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_RULE_DELETE_ADVS_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression2)).getText();
		
		if(msg1.equals(RuleConstants.RULE_NAME_RULE_DELETE_NAME) ) {
			generateXML.logVP("24.1", "Verify in 'Rule Instance' delete option is there or not ",	"delete option is there", AppConstants.vPass);				
			//pass=pass+1;
		} else {
			generateXML.logVP("24.1", "Verify in 'Rule Instance' delete option is there or not ",	 "delete option is not there", AppConstants.vFail);		
			//fail=fail+1;
		}	

//		Thread.sleep(2000);
	}
	@Test
	public void test_028() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
		
		
		
	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_HYPERLINK_ID);
	driver.findElement(By.xpath(xpathExpression1)).click();
	
	String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression2)).getText();
		
		if(msg1.equals(RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_NAME) ) {
			generateXML.logVP("25.1", "Verify  'Rule Instance' have hyperlink  or not,by clicking on it should goes to 'Edit Rule Instance' ",	"it has the hyperlink and clicking on it goes to edit rule instance", AppConstants.vPass);				
			//pass=pass+1;
		} else {
			generateXML.logVP("25.1", "Verify  'Rule Instance' have hyperlink  or not,by clicking on it should goes to 'Edit Rule Instance'",	 "it has the hyperlink and clicking on it goes to edit rule instance", AppConstants.vFail);		
			//fail=fail+1;
			}	

//		Thread.sleep(2000);
	}
	
	
	@Test
	public void test_029() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
		
		
		
	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_NAME_CREATE_NEW_RULE_CANCEL_NEW_ADVS_ID);
	driver.findElement(By.xpath(xpathExpression1)).click();
	
	String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_DELETE_RULE_INSTANCE_ID);
		driver.findElement(By.xpath(xpathExpression2)).click();
		String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_DELETE_RULE_INSTANCE_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression3)).getText();
		
		if(msg1.equals(RuleConstants.RULE_INSTANCE_DELETE_RULE_INSTANCE_CONFIRM_NAME) ) {
			generateXML.logVP("26.1", "Verify  'Rule Instance' delete button working   or not,with confirmation message ",	"able to delete 'Rule Instance'", AppConstants.vPass);
			
			String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_DELETE_RULE_INSTANCE_OK_ID);
			driver.findElement(By.xpath(xpathExpression4)).click();
			
			//pass=pass+1;
		} else {
			generateXML.logVP("26.1", "Verify  'Rule Instance' delete button working   or not,with confirmation message ",	 "able to delete 'Rule Instance'", AppConstants.vFail);		
			//fail=fail+1;
			}	

//		Thread.sleep(2000);
	}
	@Test
	public void test_031() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
		
		
		
	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCES_NAME_SORT_ID);
	String msg1=driver.findElement(By.xpath(xpathExpression1)).getAttribute("class");
	System.out.println("==================="+msg1);
//	String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_DELETE_RULE_INSTANCE_ID);
//		driver.findElement(By.xpath(xpathExpression2)).click();
//		String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_DELETE_RULE_INSTANCE_ID);
//		String msg1=driver.findElement(By.xpath(xpathExpression3)).getText();
		
		if(msg1.equals(RuleConstants.RULE_INSTANCES_NAME_SORT_NAME) ) {
			generateXML.logVP("27.1", "Verify  'Rule Instance Name' sorting column  working   or not ",	"sorting column working ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("27.1", "Verify  'Rule Instance Name' sorting column  working   or not ",	 "sorting column not working ", AppConstants.vFail);		
			//fail=fail+1;
			}	

//		Thread.sleep(2000);
	}
	@Test
	public void test_032() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
		
		
		
	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCES_ADVS_SEARCH_ID);
	driver.findElement(By.xpath(xpathExpression1)).click();
	
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_ID);
    String msg1=	driver.findElement(By.xpath(xpathExpression2)).getText();
//	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_DELETE_RULE_INSTANCE_ID);
//		String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
		
		if(msg1.equals(RuleConstants.RULE_INSTANCES_ADVS_SEARCH_RULE_NAME_NAME) ) {
			generateXML.logVP("28.1", "Verify  in Rule Instance List 'Advance Search Tab'  working   or not ",	"'Advance Search Tab' working in Rule Instance List ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("28.1", "Verify  in Rule Instance List 'Advance Search Tab'  working   or not ",	 "'Advance Search Tab' is not working in Rule Instance List ", AppConstants.vFail);		
			//fail=fail+1;
			}	

//		Thread.sleep(2000);
	}
	@Test
	public void test_033() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
		
		
		
//	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCES_ADVS_SEARCH_ID);
//	driver.findElement(By.xpath(xpathExpression1)).click();
	
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_ID);
    String msg1=	driver.findElement(By.xpath(xpathExpression2)).getText();
	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    String msg3=driver.findElement(By.xpath(xpathExpression4)).getAttribute("id");
		
		if(msg1.equals(RuleConstants.RULE_INSTANCES_ADVS_SEARCH_RULE_NAME_NAME) ) {
			generateXML.logVP("29.1", "Verify  in Rule Instance List 'Advance Search Tab' have 'Rule Instance Name' TextBox or not ",	"'Advance Search Tab' have 'Rule Instance Name' text box", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("29.1", "Verify  in Rule Instance List 'Advance Search Tab' have 'Rule Instance Name' TextBox or not",	 "'Advance Search Tab' dont have 'Rule Instance Name' text box", AppConstants.vFail);		
			//fail=fail+1;
			}	
		if(msg2.equals(RuleConstants.RULE_INSTANCES_ADVS_SEARCH_RULE_DESC_NAME) ) {
			generateXML.logVP("29.2", "Verify  in Rule Instance List 'Advance Search Tab' have 'Rule Instance Description' TextBox or not",	"'Advance Search Tab' have 'Rule Instance Description' text box", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("29.2", "Verify  in Rule Instance List 'Advance Search Tab' have 'Rule Instance Description' TextBox or not",	 "'Advance Search Tab' dont have 'Rule Instance Description' text box", AppConstants.vFail);		
			//fail=fail+1;
			}	
		if(msg3.equals(RuleConstants.RULE_INSTANCES_ADVS_SEARCH_GO_BTN_NAME) ) {
			generateXML.logVP("29.3", "Verify  in Rule Instance List 'Advance Search Tab' have 'GO' Button or not",	"'Advance Search Tab' have 'GO' Button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("29.3", "Verify  in Rule Instance List 'Advance Search Tab' have 'GO' Button or not",	 "'Advance Search Tab' dont have 'GO' Button", AppConstants.vFail);		
			//fail=fail+1;
			}	

//		Thread.sleep(2000);
	}
	
	@Test
	public void test_034() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
		
		
		
//	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCES_ADVS_SEARCH_ID);
//	driver.findElement(By.xpath(xpathExpression1)).click();
	
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
    driver.findElement(By.xpath(xpathExpression2)).sendKeys("@aa>");
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    driver.findElement(By.xpath(xpathExpression4)).click();
	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_NO_DATA_AVAILABLE_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    
		
		
		if(msg2.equals(RuleConstants.RULE_INSTANCES_ADVS_SEARCH_NO_DATA_AVAILABLE_NAME) ) {
			generateXML.logVP("30.1", "Verify  in Rule Instance List 'Advance Search Tab' 'Rule Instance Name' Textbox should allow alphanumeric only",	"'Advance Search Tab'  'Rule Instance Name' text box allowing alphanumeric", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("30.1", "Verify  in Rule Instance List 'Advance Search Tab' 'Rule Instance Name' Textbox should allow alphanumeric only",	 "'Advance Search Tab'  'Rule Instance Name' text box is not allowing alphanumeric", AppConstants.vFail);		
			//fail=fail+1;
			}	
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_035() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
		
		
		
//	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCES_ADVS_SEARCH_ID);
//	driver.findElement(By.xpath(xpathExpression1)).click();
		
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
    driver.findElement(By.xpath(xpathExpression2)).sendKeys("@aa>");
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    driver.findElement(By.xpath(xpathExpression4)).click();
	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_NO_DATA_AVAILABLE_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    
		
		
		if(msg2.equals(RuleConstants.RULE_INSTANCES_ADVS_SEARCH_NO_DATA_AVAILABLE_NAME) ) {
			generateXML.logVP("31.1", "Verify  in Rule Instance List 'Advance Search Tab' 'Rule Instance Description' Textbox should allow alphanumeric only",	"'Advance Search Tab'  'Rule Instance Description' text box allowing alphanumeric", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("31.1", "Verify  in Rule Instance List 'Advance Search Tab' 'Rule Instance Description' Textbox should allow alphanumeric only",	 "'Advance Search Tab'  'Rule Instance Description' text box is not allowing alphanumeric", AppConstants.vFail);		
			//fail=fail+1;
			}	
		

//		Thread.sleep(2000);
	}
	
	@Test
	public void test_036() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);


		
		
		
		
//	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCES_ADVS_SEARCH_ID);
//	driver.findElement(By.xpath(xpathExpression1)).click();
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
	    driver.findElement(By.xpath(xpathExpression1)).sendKeys("@aa>");
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
    driver.findElement(By.xpath(xpathExpression2)).sendKeys("@aa>");
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    driver.findElement(By.xpath(xpathExpression4)).click();
	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_NO_DATA_AVAILABLE_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    
		
		
		if(msg2.equals(RuleConstants.RULE_NAME_TEXT_SPECIAL_ADVS_MSG) ) {
			generateXML.logVP("32.1", "Verify  in Rule Instance List 'Advance Search Tab' 'Rule Instance Description' Textbox enter some special characters,it should throw an error message 'special characters are not allowed'",	"'Advance Search Tab'  'Rule Instance Description' text box is throwing error message 'special characters are not allowed' ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("32.1", "Verify  in Rule Instance List 'Advance Search Tab' 'Rule Instance Description' Textbox enter some special characters,it should throw an error message 'special characters are not allowed'",	 "'Advance Search Tab'  'Rule Instance Description' text box is not throwing error message 'special characters are not allowed' ", AppConstants.vFail);		
			//fail=fail+1;
			}	
		if(msg2.equals(RuleConstants.RULE_NAME_TEXT_SPECIAL_ADVS_MSG) ) {
			generateXML.logVP("32.2", "Verify  in Rule Instance List 'Advance Search Tab' 'Rule Instance Name' Textbox enter some special characters,it should throw an error message 'special characters are not allowed'",	"'Advance Search Tab'  'Rule Instance Name' text box is throwing error message 'special characters are not allowed' ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("32.2", "Verify  in Rule Instance List 'Advance Search Tab' 'Rule Instance Name' Textbox enter some special characters,it should throw an error message 'special characters are not allowed'",	 "'Advance Search Tab'  'Rule Instance Name' text box is not throwing error message 'special characters are not allowed' ", AppConstants.vFail);		
			//fail=fail+1;
			}	
		

//		Thread.sleep(2000);
	}
	
	@Test
	public void test_037() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
	    driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
    driver.findElement(By.xpath(xpathExpression2)).clear();
    driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    driver.findElement(By.xpath(xpathExpression4)).click();
	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_DESC_ID);
    String msg1=driver.findElement(By.xpath(xpathExpression5)).getText();
		
		
		if(msg2.equals(RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_DESC_NAME) ) {
			generateXML.logVP("33.1", "Verify  The system shall validate the details entered by user upon clicking Go button and should display the search results  applying 'and' search",	"applied 'and' operation and showing correct results", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("33.1", "Verify The system shall validate the details entered by user upon clicking Go button and should display the search results  applying 'and' search",	 "applied 'and' operation and not showing correct results", AppConstants.vFail);		
			//fail=fail+1;
			}	
		if(msg1.equals(RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_NAME) ) {
			generateXML.logVP("33.2", "Verify  The system shall validate the details entered by user upon clicking Go button and should display the search results  applying 'and' search",	"applied 'and' operation and showing correct results ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("33.2", "Verify  The system shall validate the details entered by user upon clicking Go button and should display the search results  applying 'and' search",	 "applied 'and' operation and not showing correct results ", AppConstants.vFail);		
			//fail=fail+1;
			}	
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_038() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
    driver.findElement(By.xpath(xpathExpression2)).clear();
   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    driver.findElement(By.xpath(xpathExpression4)).click();
	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_DESC_ID);
    String msg1=driver.findElement(By.xpath(xpathExpression5)).getText();
		
		
		if(msg2.equals(RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_DESC_NAME) ) {
			generateXML.logVP("34.1", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	"it showing all results", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("34.1", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	 "it's not showing all results", AppConstants.vFail);		
			//fail=fail+1;
			}	
		if(msg1.equals(RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_NAME) ) {
			generateXML.logVP("34.2", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	"it showing all results", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("34.2", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	 "it's not showing all results", AppConstants.vFail);		
			//fail=fail+1;
			}	
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_039() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
    driver.findElement(By.xpath(xpathExpression2)).clear();
   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    driver.findElement(By.xpath(xpathExpression4)).click();
	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_DESC_ID);
    String msg1=driver.findElement(By.xpath(xpathExpression5)).getText();
		
		
		if(msg2.equals(RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_DESC_NAME) ) {
			generateXML.logVP("35.1", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	"it showing all results", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("35.1", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	 "it's not showing all results", AppConstants.vFail);		
			//fail=fail+1;
			}	
		if(msg1.equals(RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_NAME) ) {
			generateXML.logVP("35.2", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	"it showing all results", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("35.2", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	 "it's not showing all results", AppConstants.vFail);		
			//fail=fail+1;
			}	
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_041() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
    driver.findElement(By.xpath(xpathExpression2)).clear();
   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    driver.findElement(By.xpath(xpathExpression4)).click();
	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_GO_RULE_INSTANCE_NAME_ID);
    String msg1=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_GO_RULE_INSTANCE_DESC_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression5)).getText();
    String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_GO_RULE_INSTANCE_DELETE_ID);
    String msg3=driver.findElement(By.xpath(xpathExpression6)).getText();
		
		
		if(msg1.equals(RuleConstants.RULE_INSTANCE_GO_RULE_INSTANCE_NAME_NAME) ) {
			generateXML.logVP("36.1", "Verify  functionality of 'GO' button witout entering any values,The search results in the grid should have Rule Instance Name",	"it have Rule Instance Name", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("36.1", "Verify  functionality of 'GO' button witout entering any values,The search results in the grid should have Rule Instance Name",	 "it dont have Rule Instance Name", AppConstants.vFail);		
			//fail=fail+1;
			}	
		if(msg2.equals(RuleConstants.RULE_INSTANCE_GO_RULE_INSTANCE_DESC_NAME) ) {
			generateXML.logVP("36.2", "Verify  functionality of 'GO' button witout entering any values,The search results in the grid should have Rule Instance Description",	"it have Rule Instance Description", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("36.2", "Verify  functionality of 'GO' button witout entering any values,The search results in the grid should have Rule Instance Description",	 "it dont  have Rule Instance Description", AppConstants.vFail);		
			//fail=fail+1;
			}	
		if(msg3.equals(RuleConstants.RULE_INSTANCE_GO_RULE_INSTANCE_DELETE_NAME) ) {
			generateXML.logVP("36.3", "Verify  functionality of 'GO' button witout entering any values,The search results in the grid should have delete column",	"it have delete column", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("36.3", "Verify  functionality of 'GO' button witout entering any values,The search results in the grid should have delete column",	 "it dont have delete column", AppConstants.vFail);		
			//fail=fail+1;
			}	
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_042() throws Exception {	
		
//		//wait for 4 secs
//		Thread.sleep(2000);
//		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
//		driver.findElement(By.xpath(xpathExpression1)).clear();
//	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
//    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
//    driver.findElement(By.xpath(xpathExpression2)).clear();
//   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
//    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
//    driver.findElement(By.xpath(xpathExpression4)).click();
//	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
//    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_DESC_ID);
//    String msg1=driver.findElement(By.xpath(xpathExpression5)).getText();
//		
//		
//		if(msg2.equals(RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_DESC_NAME) ) {
//			generateXML.logVP("37.1", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	"it showing all results", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("37.1", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	 "it's not showing all results", AppConstants.vFail);		
//			//fail=fail+1;
//			}	
//		if(msg1.equals(RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_NAME) ) {
//			generateXML.logVP("37.2", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	"it showing all results", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("37.2", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	 "it's not showing all results", AppConstants.vFail);		
//			//fail=fail+1;
//			}	
//		
//
////		Thread.sleep(2000);
	}
	@Test
	public void test_043() throws Exception {	
		
//		//wait for 4 secs
//		Thread.sleep(2000);
//		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
//		driver.findElement(By.xpath(xpathExpression1)).clear();
//	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
//    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
//    driver.findElement(By.xpath(xpathExpression2)).clear();
//   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
//    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
//    driver.findElement(By.xpath(xpathExpression4)).click();
//	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
//    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_DESC_ID);
//    String msg1=driver.findElement(By.xpath(xpathExpression5)).getText();
//		
//		
//		if(msg2.equals(RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_DESC_NAME) ) {
//			generateXML.logVP("38.1", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	"it showing all results", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("38.1", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	 "it's not showing all results", AppConstants.vFail);		
//			//fail=fail+1;
//			}	
//		if(msg1.equals(RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_NAME) ) {
//			generateXML.logVP("38.2", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	"it showing all results", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("38.2", "Verify  functionality of 'GO' button witout entering any values,it should display all results",	 "it's not showing all results", AppConstants.vFail);		
//			//fail=fail+1;
//			}	
//		
//
////		Thread.sleep(2000);
	}
	@Test
	public void test_044() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
    driver.findElement(By.xpath(xpathExpression2)).clear();
   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    driver.findElement(By.xpath(xpathExpression4)).click();
//	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SHOWING_ID);
    String msg1=driver.findElement(By.xpath(xpathExpression5)).getText();
		
		
		
		if(msg1.contains(RuleConstants.RULE_INSTANCE_ADVS_SHOWING_ID_NAME) ) {
			generateXML.logVP("39.1", "Verify whether the text saying 'showing  n/n records ' is displayed at the bottom of the screen",	"it showing  n/n records ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("39.1", "Verify whether the text saying 'showing  n/n records ' is displayed at the bottom of the screen",	 "it's not showing  n/n records ", AppConstants.vFail);		
			//fail=fail+1;
			}	
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_045() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
    driver.findElement(By.xpath(xpathExpression2)).clear();
   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    driver.findElement(By.xpath(xpathExpression4)).click();
//	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_ENTRIES_ID);
    String msg1=driver.findElement(By.xpath(xpathExpression5)).getText();
		
		
		
		if(msg1.contains(RuleConstants.RULE_INSTANCE_ADVS_ENTRIES_NAME) ) {
			generateXML.logVP("40.1", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the bottom of the page ",	"it showing 'no of rows per page' drop down ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("40.1", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the bottom of the page ",	 "it's not showing  'no of rows per page' drop down ", AppConstants.vFail);		
			//fail=fail+1;
			}	
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_046() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
    driver.findElement(By.xpath(xpathExpression2)).clear();
   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    driver.findElement(By.xpath(xpathExpression4)).click();
//	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_PREV_ID);
    String msg1=driver.findElement(By.xpath(xpathExpression5)).getText();
    String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_NEXT_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression6)).getText();
		
		
		
		if(msg1.contains(RuleConstants.RULE_INSTANCE_ADVS_PREV_NAME) ) {
			generateXML.logVP("41.1", "verify Pagination-Prev and next buttons",	"displaying 'Prev' button ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("41.1", "verify Pagination-Prev and next buttons",	 "not displaying 'Prev' button ", AppConstants.vFail);		
			//fail=fail+1;
			}	
		if(msg2.contains(RuleConstants.RULE_INSTANCE_ADVS_NEXT_NAME) ) {
			generateXML.logVP("41.2", "verify Pagination-Prev and next buttons",	"displaying 'Next' buuton ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("41.2", "verify Pagination-Prev and next buttons",	 "not displaying 'Next' buuton  ", AppConstants.vFail);		
			//fail=fail+1;
			}	
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_047() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
    driver.findElement(By.xpath(xpathExpression2)).clear();
   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
    driver.findElement(By.xpath(xpathExpression4)).click();
//	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_PREV_ID);
    String msg1=driver.findElement(By.xpath(xpathExpression5)).getText();
    String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_NEXT_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression6)).getText();
		
		
		
		if(msg1.contains(RuleConstants.RULE_INSTANCE_ADVS_PREV_NAME) ) {
			generateXML.logVP("41.1", "verify Pagination-Prev and next buttons",	"displaying 'Prev' button ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("41.1", "verify Pagination-Prev and next buttons",	 "not displaying 'Prev' button ", AppConstants.vFail);		
			//fail=fail+1;
			}	
		if(msg2.contains(RuleConstants.RULE_INSTANCE_ADVS_NEXT_NAME) ) {
			generateXML.logVP("41.2", "verify Pagination-Prev and next buttons",	"displaying 'Next' buuton ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("41.2", "verify Pagination-Prev and next buttons",	 "not displaying 'Next' buuton  ", AppConstants.vFail);		
			//fail=fail+1;
			}	
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_048() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
//		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
//		driver.findElement(By.xpath(xpathExpression1)).clear();
	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
//    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
//    driver.findElement(By.xpath(xpathExpression2)).clear();
   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
//    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
//    driver.findElement(By.xpath(xpathExpression4)).click();
//	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_PREV_BTN_CHECKING_ID);
   Boolean msg1=driver.findElement(By.xpath(xpathExpression5)).isEnabled();
//    String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_NEXT_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression6)).;
		
		
		
		if(msg1==false ) {
			generateXML.logVP("42.1", "verify Pagination-Prev button clicking on it ",	"system  not performing any action upon clicking on it", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("42.1", "verify Pagination-Prev button clicking on it ",	 "system  performing some action upon clicking on it", AppConstants.vFail);		
			//fail=fail+1;
			}	
		
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_049() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
//		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
//		driver.findElement(By.xpath(xpathExpression1)).clear();
	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
//    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
//    driver.findElement(By.xpath(xpathExpression2)).clear();
   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
//    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
//    driver.findElement(By.xpath(xpathExpression4)).click();
//	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_NEXT_BTN_CHECKING_ID);
   Boolean msg1=driver.findElement(By.xpath(xpathExpression5)).isEnabled();
//    String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_NEXT_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression6)).;
		
		
		
		if(msg1==false ) {
			generateXML.logVP("43.1", "verify Pagination-Next button clicking on it ",	"system  not performing any action upon clicking on it", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("43.1", "verify Pagination-Next button clicking on it ",	 "system  performing some action upon clicking on it", AppConstants.vFail);		
			//fail=fail+1;
			}	
		
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_051() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
//		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
//		driver.findElement(By.xpath(xpathExpression1)).clear();
	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
//    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
//    driver.findElement(By.xpath(xpathExpression2)).clear();
   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
//    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
//    driver.findElement(By.xpath(xpathExpression4)).click();
//	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_PAGINATION_TEXT_ID);
   String msg1=driver.findElement(By.xpath(xpathExpression5)).getText();
//    String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_NEXT_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression6)).;
		
		
		
		if(msg1.contains(RuleConstants.RULE_INSTANCE_ADVS_PAGINATION_TEXT_NAME) ) {
			generateXML.logVP("44.1", "verify Pagination text",	"The pagination  text saying '1 of n' displayed", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("44.1", "verify Pagination text",	 "The pagination  text saying '1 of n' not displayed", AppConstants.vFail);		
			//fail=fail+1;
			}	
		
		

//		Thread.sleep(2000);
	}
	
	@Test
	public void test_052() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
//		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_NAME_TEXTBOX_ID);
//		driver.findElement(By.xpath(xpathExpression1)).clear();
	   // driver.findElement(By.xpath(xpathExpression1)).sendKeys("aasd");
//    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_RULE_DESC_TEXTBOX_ID);
//    driver.findElement(By.xpath(xpathExpression2)).clear();
   // driver.findElement(By.xpath(xpathExpression2)).sendKeys("sda");
//    String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_SEARCH_GO_BTN_ID);
//    driver.findElement(By.xpath(xpathExpression4)).click();
//	String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_DATA_AVAILABLE_NAME_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression3)).getText();
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_ID);
   boolean msg1=driver.findElement(By.xpath(xpathExpression5)).isEnabled();
//    String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ADVS_NEXT_ID);
//    String msg2=driver.findElement(By.xpath(xpathExpression6)).;
		
		
		
		if(msg1==true) {
			driver.findElement(By.xpath(xpathExpression5)).click();
			generateXML.logVP("45.1", "Verify whether user is able to navigate to Create  New Rule Instance successfully",	"able to navigate to Create  New Rule Instance successfully", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("45.1", "Verify whether user is able to navigate to Create  New Rule Instance successfully",	 "not able to navigate to Create  New Rule Instance ", AppConstants.vFail);		
			//fail=fail+1;
			}	
		
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_053() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_NAME_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression1)).getText();
	   
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_DESC_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression2)).getText();
    
    String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_ID);
    String msg3=driver.findElement(By.xpath(xpathExpression3)).getText();
    
	String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_DESC_ID);
    String msg4=driver.findElement(By.xpath(xpathExpression4)).getText();
    
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CANCEL_ID);
   String msg5=driver.findElement(By.xpath(xpathExpression5)).getText();
   
    String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_ID);
    String msg6=driver.findElement(By.xpath(xpathExpression6)).getText();
		
		
		
		if(msg1.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_NAME_NAME)) {
			
			generateXML.logVP("46.1", "Verify Create  New Rule Instance page :Rule Name",	"Rule Name is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("46.1", "Verify Create  New Rule Instance page :Rule Name",	 "Rule Name is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg2.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_DESC_NAME)) {
			
			generateXML.logVP("46.2", "Verify Create  New Rule Instance page :Rule Description",	"Rule Description is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("46.2", "Verify Create  New Rule Instance page :Rule Description",	 "Rule Description is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg3.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_NAME)) {
			
			generateXML.logVP("46.3", "Verify Create  New Rule Instance page :Rule Instance Name",	"Rule Instance Name is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("46.3", "Verify Create  New Rule Instance page :Rule Instance Name",	 "Rule Instance Name is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg4.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_DESC_NAME)) {
			
			generateXML.logVP("46.4", "Verify Create  New Rule Instance page :Rule Instance Description",	"Rule Instance Description is dispalying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("46.4", "Verify Create  New Rule Instance page :Rule Instance Description",	 "Rule Instance Description is not dispalying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg5.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CANCEL_NAME)) {
			
			generateXML.logVP("46.5", "Verify Create  New Rule Instance page :Cancel button",	"Cancel button is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("46.5", "Verify Create  New Rule Instance page :Cancel button",	 "Cancel button is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg6.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_NAME)) {
			
			generateXML.logVP("46.6", "Verify Create  New Rule Instance page :Create button",	"Create button is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("46.6", "Verify Create  New Rule Instance page :Create button",	 "Create button is not  displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_054() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_TEXTBOX_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression1)).getAttribute("type");
	   
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_DESC_TEXTBOX_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression2)).getAttribute("type");
    
   
		
		
		if(msg1.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_TEXTBOX_NAME)) {
			
			generateXML.logVP("47.1", "Verify Create  New Rule Instance page -Rule Instance Name  textbox",	"Rule Instance Name  textbox allowing to enter characters", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("47.1", "Verify Create  New Rule Instance page -Rule Instance Name textbox",	 "Rule Instance Name  textbox is not allowing to enter characters", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg2.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_TEXTBOX_NAME)) {
			
			generateXML.logVP("47.2", "Verify Create  New Rule Instance page -Rule Instance Description  textbox",	"Rule Instance Description  textbox allowing to enter characters", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("47.2", "Verify Create  New Rule Instance page -Rule Instance Description  textbox",	 "Rule Instance Description  textbox is not allowing to enter characters", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_055() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
		
	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_DESC_TEXTBOX_ID);
	 driver.findElement(By.xpath(xpathExpression2)).clear();
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_ID);
	 driver.findElement(By.xpath(xpathExpression3)).click();
	 
   
    
    String msg1=driver.findElement(By.xpath(xpathExpression1)).getAttribute("style");
    String msg2=driver.findElement(By.xpath(xpathExpression2)).getAttribute("style");
		
		
		if(msg1.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_TEXTBOX_RED_NAME)) {
			
			generateXML.logVP("48.1", "Verify Create  New Rule Instance page -Rule Instance Name  textbox,clicking upon create button without giving values",	"Rule Instance Name  textbox throwing error message", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("48.1", "Verify Create  New Rule Instance page -Rule Instance Name textbox,clicking upon create button without giving values",	 "Rule Instance Name  textbox is not throwing error message", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg2.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_TEXTBOX_RED_NAME)) {
			
			generateXML.logVP("48.2", "Verify Create  New Rule Instance page -Rule Instance Description  textbox,clicking upon create button without giving values",	"Rule Instance Description textbox throwing error message", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("48.2", "Verify Create  New Rule Instance page -Rule Instance Description  textbox,clicking upon create button without giving values",	 "Rule Instance Description textbox is not  throwing error message", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
	}
	@Test
	public void test_056() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
		driver.findElement(By.xpath(xpathExpression1)).sendKeys("///>>>>");
		
//	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_DESC_TEXTBOX_ID);
//	 driver.findElement(By.xpath(xpathExpression2)).clear();
//	 driver.findElement(By.xpath(xpathExpression2)).sendKeys(":::>>>??????");
//	 
//	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_ID);
//	 driver.findElement(By.xpath(xpathExpression3)).click();
//	
		String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_ALERT_ID);
        String msg1=driver.findElement(By.xpath(xpathExpression3)).getText();
   
    
//    String msg1=driver.findElement(By.xpath(xpathExpression1)).getAttribute("style");
//    String msg2=driver.findElement(By.xpath(xpathExpression2)).getAttribute("style");
		
		
		if(msg1.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_ALERT_NAME)) {
			
			generateXML.logVP("49.1", "Verify  special characterscan be entered  in Rule Instance Name and Rule Instance  description text boxes",	" throwing an error message saying 'special characters are not allowed'", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("49.1", "Verify  special characterscan be entered  in Rule Instance Name and Rule Instance  description text boxes",	 "not throwing an error message saying 'special characters are not allowed'", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_ALERT_OK_ID);
        driver.findElement(By.xpath(xpathExpression4)).click();
		
	}
	
	@Test
	public void test_057() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
		driver.findElement(By.xpath(xpathExpression1)).sendKeys("new rule instance");
		
	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_DESC_TEXTBOX_ID);
	 driver.findElement(By.xpath(xpathExpression2)).clear();
	 driver.findElement(By.xpath(xpathExpression2)).sendKeys("new rule instance description");
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_ID);
	 driver.findElement(By.xpath(xpathExpression3)).click();
	
		String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_ALERT_ID);
        String msg1=driver.findElement(By.xpath(xpathExpression4)).getText();
   
    
//    String msg1=driver.findElement(By.xpath(xpathExpression1)).getAttribute("style");
//    String msg2=driver.findElement(By.xpath(xpathExpression2)).getAttribute("style");
		
		
		if(msg1.contains(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_ALERT_OK_SUCC_NAME)) {
			
			generateXML.logVP("50.1", "Verify functionality of Create button ",	"system allowing to create new instance upon clicking on create button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("50.1", "Verify functionality of Create button ",	 "system not allowing to create new instance upon clicking on create button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_ALERT_OK_ID);
        driver.findElement(By.xpath(xpathExpression5)).click();
		
	}
	@Test
	public void test_058() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_TEXTBOX_ID);
		driver.findElement(By.xpath(xpathExpression1)).clear();
		driver.findElement(By.xpath(xpathExpression1)).sendKeys("new rule instance");
		
	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_DESC_TEXTBOX_ID);
	 driver.findElement(By.xpath(xpathExpression2)).clear();
	 driver.findElement(By.xpath(xpathExpression2)).sendKeys("new rule instance description");
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CANCEL_ID);
	 driver.findElement(By.xpath(xpathExpression3)).click();
	
		String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CANCEL_BACK_ID);
        String msg1=driver.findElement(By.xpath(xpathExpression4)).getText();
   
    
//    String msg1=driver.findElement(By.xpath(xpathExpression1)).getAttribute("style");
//    String msg2=driver.findElement(By.xpath(xpathExpression2)).getAttribute("style");
		
		
		if(msg1.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CANCEL_BACK_NAME)) {
			
			generateXML.logVP("51.1", "Verify functionality of Cancel button ",	"clicking upon Cancel button ,it's returning back to old page", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("51.1", "Verify functionality of Cancel button ",	 "clicking upon Cancel button ,it's not returning back to old page", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
		
	}
	
	@Test
	public void test_059() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		
		
	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_RULE_NAME_ID);
	 driver.findElement(By.xpath(xpathExpression2)).click();
	 
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_ID);
	 driver.findElement(By.xpath(xpathExpression3)).click();
	
		String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_ID);
        String msg1=driver.findElement(By.xpath(xpathExpression4)).getText();
   
    
//    String msg1=driver.findElement(By.xpath(xpathExpression1)).getAttribute("style");
//    String msg2=driver.findElement(By.xpath(xpathExpression2)).getAttribute("style");
		
		
		if(msg1.equals(RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_NAME)) {
			
			generateXML.logVP("52.1", "Verify whether user is able to navigate to Edit New Rule Instance successfully",	"able to navigate to Edit Rule Instance tab", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("52.1", "Verify whether user is able to navigate to Edit New Rule Instance successfully",	 "able to navigate to Edit Rule Instance tab", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		}
	@Test
	public void test_060() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_NAME_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression1)).getText();
	   
    String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_DESC_ID);
    String msg2=driver.findElement(By.xpath(xpathExpression2)).getText();
    
    String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
    String msg3=driver.findElement(By.xpath(xpathExpression3)).getText();
    
	String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_DESC_TB_ID);
    String msg4=driver.findElement(By.xpath(xpathExpression4)).getText();
    
    String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_CANCEL_ID);
   String msg5=driver.findElement(By.xpath(xpathExpression5)).getText();
   
//    String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_CREATE_ID);
//    String msg6=driver.findElement(By.xpath(xpathExpression6)).getText();
		
		
		
		if(msg1.equals(RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_NAME_NAME)) {
			
			generateXML.logVP("53.1", "Verify Edit Rule Instance page :Rule Name",	"Rule Instance Name is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("53.1", "Verify Edit Rule Instance page :Rule Name",	 "Rule Instance Name is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg2.equals(RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_DESC_NAME)) {
			
			generateXML.logVP("53.2", "Verify Edit Rule Instance page :Rule Description",	"Rule Instance Description is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("53.2", "Verify Edit Rule Instance page :Rule Description",	 "Rule Instance Description is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg3.equals(RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_NAME)) {
			
			generateXML.logVP("53.3", "Verify Edit Rule Instance page :Rule Instance Name",	"Rule Instance Name is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("53.3", "Verify Edit Rule Instance page :Rule Instance Name",	 "Rule Instance Name is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg4.equals(RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_DESC_TB_NAME)) {
			
			generateXML.logVP("53.4", "Verify Edit Rule Instance page :Rule Instance Description",	"Rule Instance Description is dispalying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("53.4", "Verify Edit  Rule Instance page :Rule Instance Description",	 "Rule Instance Description is not dispalying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg5.equals(RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_CANCEL_NAME)) {
			
			generateXML.logVP("53.5", "Verify Edit Rule Instance page :Cancel button",	"Cancel button is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("53.5", "Verify EditRule Instance page :Cancel button",	 "Cancel button is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
//		if(msg6.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CREATE_NAME)) {
//			
//			generateXML.logVP("46.6", "Verify Create  New Rule Instance page :Create button",	"Create button is displaying", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("46.6", "Verify Create  New Rule Instance page :Create button",	 "Create button is not  displaying", AppConstants.vFail);		
//			//fail=fail+1;
//			  }	
		
		

//		Thread.sleep(2000);
	}
	@Test
	public void test_061() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

    
    String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_NAME_TB1_ID);
    String msg3=driver.findElement(By.xpath(xpathExpression3)).getAttribute("type");
    
	String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_DESC_TB2_ID);
    String msg4=driver.findElement(By.xpath(xpathExpression4)).getAttribute("type");
    
   
		
		
		
		if(msg3.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_TEXTBOX_NAME)) {
			
			generateXML.logVP("54.1", "Verify Edit New Rule Instance page -Rule Instance Name textbox",	"Rule Instance Name textbox allowing user to enter characters", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("54.1", "Verify Edit New Rule Instance page -Rule Instance Name textbox",	 "Rule Instance Name textbox is not allowing user to enter characters", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		if(msg4.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_RULE_INSTANCE_NAME_TEXTBOX_NAME)) {
			
			generateXML.logVP("54.2", "Verify Edit New Rule Instance page -Rule Instance Description textbox",	"Rule Instance Description textbox allowing user to enter characters", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("54.2", "Verify Edit New Rule Instance page -Rule Instance Description textbox",	 "Rule Instance Description textbox is not allowing user to enter characters", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
		//		Thread.sleep(2000);
	}
	@Test
	public void test_062() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

    
    String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_NAME_TB1_ID);
    driver.findElement(By.xpath(xpathExpression3)).clear();
    driver.findElement(By.xpath(xpathExpression3)).sendKeys("??@@$$$");
    
	String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_DESC_TB2_ID);
	 driver.findElement(By.xpath(xpathExpression4)).clear();
	driver.findElement(By.xpath(xpathExpression4)).sendKeys("????*****");

	String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_CREATE_ID);
	 driver.findElement(By.xpath(xpathExpression5)).click();
	 
	 String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_SVAE_MSG_ID);
	String msg1= driver.findElement(By.xpath(xpathExpression6)).getText();

    
   
		
		
		
		if(msg1.equals(RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_SVAE_MSG_NAME)) {
			
			generateXML.logVP("55.1", "Verify  special characters can be entered  in Rule Instance Name and Rule Instance  description text boxes",	"throwing error message 'special characters are not allowed'", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("55.1", "Verify  special characters can be entered  in Rule Instance Name and Rule Instance  description text boxes",	 "not throwing error message 'special characters are not allowed'", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		String xpathExpression7= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_SVAE_MSG_OK_ID);
		driver.findElement(By.xpath(xpathExpression7)).click();
		//		Thread.sleep(2000);
	}
	
	@Test
	public void test_063() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

    
    String xpathExpression3= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_NAME_TB1_ID);
    driver.findElement(By.xpath(xpathExpression3)).clear();
    driver.findElement(By.xpath(xpathExpression3)).sendKeys("rule123");
    
	String xpathExpression4= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_INSTANCE_DESC_TB2_ID);
	 driver.findElement(By.xpath(xpathExpression4)).clear();
	driver.findElement(By.xpath(xpathExpression4)).sendKeys("rule123desc");

	String xpathExpression5= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_EDIT_RULE_INSTANCE_RULE_CANCEL_ID);
	 driver.findElement(By.xpath(xpathExpression5)).click();
	 
	 String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CANCEL_BACK_ID);
	String msg1= driver.findElement(By.xpath(xpathExpression6)).getText();

    
      if(msg1.equals(RuleConstants.RULE_INSTANCE_CREATE_NEW_RULE_INSTANCE_CANCEL_BACK_NAME)) {
			
			generateXML.logVP("57.1", "Verify functionality of Cancel  button ",	"The system is allowing user to come back  upon clicking Cancel button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("57.1", "Verify functionality of Cancel  button ",	 "The system is not allowing user to come back  upon clicking Update button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
		//		Thread.sleep(2000);
	}
	
	@Test
	public void test_064() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		
		
	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_RULE_NAME_ID);
	 driver.findElement(By.xpath(xpathExpression2)).click();
	 
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_ID);
	 driver.findElement(By.xpath(xpathExpression3)).click();
	 
	 String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_ID);
	 driver.findElement(By.xpath(xpathExpression4)).click();
	 
	 String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_ID);
	 String msg1= driver.findElement(By.xpath(xpathExpression5)).getText();
	 
    

    
      if(msg1.contains(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_NAME)) {
			
			generateXML.logVP("58.1", "Verify the user is able to click and navigate to Manage scope tab in the console",	"The user  able to navigate Manage scope tab successfully by clicking 'Manage Scope' tab in Edit screen ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("58.1", "Verify the user is able to click and navigate to Manage scope tab in the console",	 "The user  able to navigate Manage scope tab successfully by clicking 'Manage Scope' tab in Edit screen ", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
		//		Thread.sleep(2000);
	}
	@Test
	public void test_065() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
	 
	 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_ID);
	 String msg1= driver.findElement(By.xpath(xpathExpression1)).getText();
	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXIST_SCOPE_ID);
	 String msg2= driver.findElement(By.xpath(xpathExpression2)).getText();
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_DELETE_SCOPE_ID);
	 String msg3= driver.findElement(By.xpath(xpathExpression3)).getText();
	 
    

    
      if(msg1.contains(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_NAME)) {
			
			generateXML.logVP("59.1", "Verify Manage Scope screen:New Scope",	"New Scope button  is displaying by clicking 'Manage Scope' tab in Edit screen ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("59.1", "Verify Manage Scope screen:New Scope",	 "New Scope button  is not displaying by clicking 'Manage Scope' tab in Edit screen ", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXIST_SCOPE_NAME)) {
			
			generateXML.logVP("59.2", "Verify Manage Scope screen:Exist Scope",	"Exist Scope button  is displaying by clicking 'Manage Scope' tab in Edit screen ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("59.2", "Verify Manage Scope screen:Exist Scope",	 "Exist Scope button  is not displaying by clicking 'Manage Scope' tab in Edit screen ", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg3.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_DELETE_SCOPE_NAME)) {
			
			generateXML.logVP("59.3", "Verify Manage Scope screen:Delete Scope",	"Delete Scope button  is displaying by clicking 'Manage Scope' tab in Edit screen  ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("59.3", "Verify Manage Scope screen:Delete Scope",	 "Delete Scope button  is not displaying by clicking 'Manage Scope' tab in Edit screen ", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
		//		Thread.sleep(2000);
	}
	
	@Test
	public void test_066() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
	 
	 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
	 driver.findElement(By.xpath(xpathExpression1)).click();
	 
	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_ID);
	 String msg2= driver.findElement(By.xpath(xpathExpression2)).getText();
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_ID);
	 String msg3= driver.findElement(By.xpath(xpathExpression3)).getText();
	 
	 String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_ID);
	 String msg4= driver.findElement(By.xpath(xpathExpression4)).getText();
	 
	 String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MHRCHY_ID);
	 String msg5= driver.findElement(By.xpath(xpathExpression5)).getText();
	 
	 String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CANCEL_ID);
	 String msg6= driver.findElement(By.xpath(xpathExpression6)).getText();
	 
	 String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CREATE_ID);
	 String msg7= driver.findElement(By.xpath(xpathExpression7)).getText();
	 
    

    
      if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_NAME)) {
			
			generateXML.logVP("60.1", "Verfiy the functionality of 'Create New scope' button :Channels",	"Channels sction is displaying Upon clicking �Create New scope� button'", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("60.1", "Verfiy the functionality of 'Create New scope' button :Channels",	 "Channels sction is displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg3.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_NAME)) {
			
			generateXML.logVP("60.2", "Verfiy the functionality of 'Create New scope' button :Users",	"Users sction is displaying Upon clicking �Create New scope� button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("60.2", "Verfiy the functionality of 'Create New scope' button :Users",	 "Users sction is not displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg4.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_NAME)) {
			
			generateXML.logVP("60.3", "Verfiy the functionality of 'Create New scope' button :Segments",	"Segments sction is displaying Upon clicking �Create New scope� button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("60.3", "Verfiy the functionality of 'Create New scope' button :Segments",	 "Segments sction is not displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg5.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MHRCHY_NAME)) {
			
			generateXML.logVP("60.4", "Verfiy the functionality of 'Create New scope' button :Merchandise Hierarchy",	"Merchandise Hierarchy sction is displaying Upon clicking �Create New scope� button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("60.4", "Verfiy the functionality of 'Create New scope' button :Merchandise Hierarchy",	 "Merchandise Hierarchy sction is not displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg6.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CANCEL_NAME)) {
			
			generateXML.logVP("60.5", "Verfiy the functionality of 'Create New scope' button :Cancel",	"Cancel button is displaying Upon clicking �Create New scope� button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("60.5", "Verfiy the functionality of 'Create New scope' button :Cancel",	 "Cancel button is not displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg7.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CREATE_NAME)) {
			
			generateXML.logVP("60.6", "Verfiy the functionality of 'Create New scope' button :Create Scope",	"Create button is displaying Upon clicking �Create New scope� button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("60.6", "Verfiy the functionality of 'Create New scope' button :Create Scope",	 "Create button is not displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		//		Thread.sleep(2000);
	}
	
	@Test
	public void test_067() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
	 
	 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
	 driver.findElement(By.xpath(xpathExpression1)).click();
	 
	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_ID);
	 String msg2= driver.findElement(By.xpath(xpathExpression2)).getText();
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_ID);
	 String msg3= driver.findElement(By.xpath(xpathExpression3)).getText();
	 
	 String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_ID);
	 String msg4= driver.findElement(By.xpath(xpathExpression4)).getText();
	 
	 String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MHRCHY_ID);
	 String msg5= driver.findElement(By.xpath(xpathExpression5)).getText();
	 
	 String xpathExpression6= excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CANCEL_ID);
	 String msg6= driver.findElement(By.xpath(xpathExpression6)).getText();
	 
	 String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CREATE_ID);
	 String msg7= driver.findElement(By.xpath(xpathExpression7)).getText();
	 
    

    
      if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_NAME)) {
			
			generateXML.logVP("61.1", "Verfiy the functionality of 'Create New scope' button :Channels",	"Channels sction is displaying Upon clicking �Create New scope� button'", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("61.1", "Verfiy the functionality of 'Create New scope' button :Channels",	 "Channels sction is displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg3.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_NAME)) {
			
			generateXML.logVP("61.2", "Verfiy the functionality of 'Create New scope' button :Users",	"Users sction is displaying Upon clicking �Create New scope� button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("61.2", "Verfiy the functionality of 'Create New scope' button :Users",	 "Users sction is not displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg4.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_NAME)) {
			
			generateXML.logVP("61.3", "Verfiy the functionality of 'Create New scope' button :Segments",	"Segments sction is displaying Upon clicking �Create New scope� button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("61.3", "Verfiy the functionality of 'Create New scope' button :Segments",	 "Segments sction is not displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg5.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MHRCHY_NAME)) {
			
			generateXML.logVP("61.4", "Verfiy the functionality of 'Create New scope' button :Merchandise Hierarchy",	"Merchandise Hierarchy sction is displaying Upon clicking �Create New scope� button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("61.4", "Verfiy the functionality of 'Create New scope' button :Merchandise Hierarchy",	 "Merchandise Hierarchy sction is not displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg6.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CANCEL_NAME)) {
			
			generateXML.logVP("61.5", "Verfiy the functionality of 'Create New scope' button :Cancel",	"Cancel button is displaying Upon clicking �Create New scope� button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("61.5", "Verfiy the functionality of 'Create New scope' button :Cancel",	 "Cancel button is not displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg7.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CREATE_NAME)) {
			
			generateXML.logVP("61.6", "Verfiy the functionality of 'Create New scope' button :Create Scope",	"Create button is displaying Upon clicking �Create New scope� button", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("61.6", "Verfiy the functionality of 'Create New scope' button :Create Scope",	 "Create button is not displaying Upon clicking �Create New scope� button", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		//		Thread.sleep(2000);
	}
	
	@Test
	public void test_068() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
	 
	 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
	 driver.findElement(By.xpath(xpathExpression1)).click();
	 
	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT1_ID);
	 String msg1= driver.findElement(By.xpath(xpathExpression2)).getText();
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT2_ID);
	 String msg2= driver.findElement(By.xpath(xpathExpression3)).getText();
	 
	 String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT3_ID);
	 String msg3= driver.findElement(By.xpath(xpathExpression4)).getText();
	 
	 String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT4_ID);
	 String msg4= driver.findElement(By.xpath(xpathExpression5)).getText();
	 
	 String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT5_ID);
	 String msg5= driver.findElement(By.xpath(xpathExpression6)).getText();
	 
	 String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_MID1_ID);
	 String msg6= driver.findElement(By.xpath(xpathExpression7)).getAttribute("value");
	 
	 String xpathExpression8 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_MID2_ID);
	 String msg7= driver.findElement(By.xpath(xpathExpression8)).getAttribute("value");
	 
	 
	 
    


     if(msg1.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT1_NAME)) {
			
			generateXML.logVP("62.1", "Verify Create New scope section -Channels:left menu",	"Channel 'All' is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("62.1", "Verify Create New scope section -Channels:left menu",	 "Channel 'All' is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT2_NAME)) {
			
			generateXML.logVP("62.2", "Verify Create New scope section -Channels:left menu",	"Channel 'Web' is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("62.2", "Verify Create New scope section -Channels:left menu",	 "Channel 'Web' is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg3.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT3_NAME)) {
			
			generateXML.logVP("62.3", "Verify Create New scope section -Channels:left menu",	"Channel 'Kiosk' is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("62.3", "Verify Create New scope section -Channels:left menu",	 "Channel 'Kiosk' is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg4.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT4_NAME)) {
			
			generateXML.logVP("62.4", "Verify Create New scope section -Channels:left menu",	"Channel 'Mobile' is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("62.4", "Verify Create New scope section -Channels:left menu",	 "Channel 'Mobile' is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg5.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT5_NAME)) {
			
			generateXML.logVP("62.5", "Verify Create New scope section -Channels:left menu",	"Channel 'Social' is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("62.5", "Verify Create New scope section -Channels:left menu",	 "Channel 'Social' is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg6.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_MID1_NAME)) {
			
			generateXML.logVP("62.6", "Verify Create New scope section -Channels:arrow button",	"arrow button '>' is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("62.6", "Verify Create New scope section -Channels:arrow button",	 "arrow button '>' is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg7.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_MID2_NAME)) {
			
			generateXML.logVP("62.7", "Verify Create New scope section -Channels:arrow button",	"arrow button '<' is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("62.7", "Verify Create New scope section -Channels:arrow button",	 "arrow button '<' is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		//		Thread.sleep(2000);
	}
	
	@Test
	public void test_069() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
	 
	 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
	 driver.findElement(By.xpath(xpathExpression1)).click();
	 
	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEGMENT_TYPE_ID);
	 String msg1= driver.findElement(By.xpath(xpathExpression2)).getText();
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEGMENT_NAME_ID);
	 String msg2= driver.findElement(By.xpath(xpathExpression3)).getText();

	 String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_MID1_ID);
	 String msg6= driver.findElement(By.xpath(xpathExpression7)).getAttribute("value");
	 
	 String xpathExpression8 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_MID2_ID);
	 String msg7= driver.findElement(By.xpath(xpathExpression8)).getAttribute("value");
	 
	 
	 
    


     if(msg1.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEGMENT_TYPE_NAME)) {
			
			generateXML.logVP("63.1", "Verify Create New scope section -Segments:Segment Type",	"'Segment Type' textbox is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("63.1", "Verify Create New scope section -Segments:Segment Type",	 "'Segment Type' textbox is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEGMENT_NAME_NAME)) {
			
			generateXML.logVP("63.2", "Verify Create New scope section -Segments:Segment Name",	"'Segment Name' textbox is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("63.2", "Verify Create New scope section -Segments:Segment Name",	 "'Segment Name' textbox is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
    
      if(msg6.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_MID1_NAME)) {
			
			generateXML.logVP("63.3", "Verify Create New scope section -Segments:arrow button",	"arrow button '>' is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("63.3", "Verify Create New scope section -Segments:arrow button",	 "arrow button '>' is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg7.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_MID2_NAME)) {
			
			generateXML.logVP("63.4", "Verify Create New scope section -Segments:arrow button",	"arrow button '<' is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("63.4", "Verify Create New scope section -Segments:arrow button",	 "arrow button '<' is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		//		Thread.sleep(2000);
	}
	
	@Test
	public void test_070() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
	 
	 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
	 driver.findElement(By.xpath(xpathExpression1)).click();
	 
//	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEGMENT_TYPE_DROPDOWN_ID);
//	 String msg1= driver.findElement(By.xpath(xpathExpression2)).getText();
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEGMENT_NAME_TB_ID);
	 String msg2= driver.findElement(By.xpath(xpathExpression3)).getAttribute("type");
	 
	 String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEARCH_BTN_ID);
	 String msg3= driver.findElement(By.xpath(xpathExpression4)).getText();
	 

     if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEGMENT_NAME_TB_NAME)) {
			
			generateXML.logVP("64.1", "Verify Create New scope section -segment name text box",	"'Segment Name' textbox is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("64.1", "Verify Create New scope section -segment name text box",	 "'Segment Name' textbox is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      if(msg3.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEARCH_BTN_NAME)) {
			
			generateXML.logVP("64.2", "Verify Create New scope section -search button",	"'Search' button is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("64.2", "Verify Create New scope section -Search button",	 "'Search' button is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
    
     
	}
	
	@Test
	public void test_071() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
	 
	 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
	 driver.findElement(By.xpath(xpathExpression1)).click();
	 
//	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEGMENT_TYPE_DROPDOWN_ID);
//	 String msg1= driver.findElement(By.xpath(xpathExpression2)).getText();
	 
	 String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEARCH_BTN_ID);
	boolean msg1= driver.findElement(By.xpath(xpathExpression4)).isEnabled();
	 
	 
	 if(msg1==false){
	 
		 
		 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEGMENT_NAME_TB_ID);
		  driver.findElement(By.xpath(xpathExpression3)).clear();
		  driver.findElement(By.xpath(xpathExpression3)).sendKeys("asd");
		 boolean msg2= driver.findElement(By.xpath(xpathExpression4)).isEnabled();

     if(msg2==true) {
			
			generateXML.logVP("65.1", "Verify the functionality of 'Search' button",	"The search button enabled  when user enters a keyword in segment name text box ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("65.1", "Verify the functionality of 'Search' button",	 "The search button is not enabled  when user enters a keyword in segment name text box", AppConstants.vFail);		
			//fail=fail+1;
			  }	
     
	 }else{
		 generateXML.logVP("65.2", "Verify the functionality of 'Search' button",	 "The search button  enabled without  user entering a keyword in segment name text box", AppConstants.vFail);
	 }
    
     
	}
	@Test
	public void test_072() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
	 
	 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
	 driver.findElement(By.xpath(xpathExpression1)).click();
	 
	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_ID);
	 String msg1= driver.findElement(By.xpath(xpathExpression2)).getText();
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_RESULT_SIZE_ID);
	 String msg2= driver.findElement(By.xpath(xpathExpression3)).getText();
	 
	 String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_TB_ID);
	 String msg3= driver.findElement(By.xpath(xpathExpression4)).getAttribute("type");
	 
//	 String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_DROP_DOWN_ID);
//	 String msg4= driver.findElement(By.xpath(xpathExpression5)).getText();
	 
	 String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_RESULT_SIZE_TB_ID);
	String msg5= driver.findElement(By.xpath(xpathExpression6)).getAttribute("type");
	
	String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_SEARCH_BTN_ID);
	String msg6= driver.findElement(By.xpath(xpathExpression7)).getText();
	
	String xpathExpression8 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_MID1_ID);
	String msg7= driver.findElement(By.xpath(xpathExpression8)).getText();
	
	String xpathExpression9 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_MID2_ID);
	String msg8= driver.findElement(By.xpath(xpathExpression9)).getText();
	 
	
	  if(msg1.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_NAME)) {
			
			generateXML.logVP("66.1", "Verify Create New scope section -Users:'User By' textbox",	"'User By' textbox is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("66.1", "Verify Create New scope section -Users:'User By' textbox",	 "'User By' textbox is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
    if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_RESULT_SIZE_NAME)) {
			
			generateXML.logVP("66.2", "Verify Create New scope section -Users:'Result Size' textbox",	"'Result Size' textbox is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("66.2", "Verify Create New scope section -Users:'Result Size' textbox",	 "'Result Size' textbox is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
    if(msg3.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_TB_NAME)) {
			
			generateXML.logVP("66.3", "Verify Create New scope section -Users:'User By' textbox",	"'User By' textbox is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("62.3", "Verify Create New scope section -Users:'User By' textbox",	 "'User By' textbox is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
//    if(msg4.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_DROP_DOWN_NAME)) {
//			
//			generateXML.logVP("66.4", "Verify Create New scope section -Channels:left menu",	"Channel 'Mobile' is displaying", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("66.4", "Verify Create New scope section -Channels:left menu",	 "Channel 'Mobile' is not displaying", AppConstants.vFail);		
//			//fail=fail+1;
//			  }	
    if(msg5.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_RESULT_SIZE_TB_NAME)) {
			
			generateXML.logVP("66.5", "Verify Create New scope section -Users:'Result Size' textbox",	"'Result Size' textbox is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("66.5", "Verify Create New scope section -Users:'Result Size' textbox",	 "'Result Size' textbox  is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
    if(msg6.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_SEARCH_BTN_NAME)) {
			
			generateXML.logVP("66.6", "Verify Create New scope section -Users:'Search' button",	"'Search' button  is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("66.6", "Verify Create New scope section -Users:'Search' button",	 "'Search' button is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
    if(msg7.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_MID1_NAME)) {
			
			generateXML.logVP("66.7", "Verify Create New scope section -Users:arrow button",	"arrow button '>' is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("66.7", "Verify Create New scope section -Users:arrow button",	 "arrow button '>' is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
    if(msg8.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_MID2_NAME)) {
		
		generateXML.logVP("66.8", "Verify Create New scope section -Users:arrow button",	"arrow button '<' is displaying", AppConstants.vPass);
		//pass=pass+1;
	} else {
		generateXML.logVP("66.8", "Verify Create New scope section -Users:arrow button",	 "arrow button '<' is not displaying", AppConstants.vFail);		
		//fail=fail+1;
		  }	
    
     
	}
	
	@Test
	public void test_073() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);

		
	 
	 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
	 driver.findElement(By.xpath(xpathExpression1)).click();
	 
//	 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_ID);
//	 String msg1= driver.findElement(By.xpath(xpathExpression2)).getText();
	 
//	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_RESULT_SIZE_ID);
//	 String msg2= driver.findElement(By.xpath(xpathExpression3)).getText();
//	 
		String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_SEARCH_BTN_ID);
		boolean msg6= driver.findElement(By.xpath(xpathExpression7)).isEnabled();
	 
	 
//	 String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_DROP_DOWN_ID);
//	 String msg4= driver.findElement(By.xpath(xpathExpression5)).getText();
	 
	 
	
	
//	String xpathExpression8 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_MID1_ID);
//	String msg7= driver.findElement(By.xpath(xpathExpression8)).getText();
//	
//	String xpathExpression9 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_MID2_ID);
//	String msg8= driver.findElement(By.xpath(xpathExpression9)).getText();
	 
	
	  if(msg6==false) {
			
		  
		  String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_TB_ID);
			 driver.findElement(By.xpath(xpathExpression4)).sendKeys("asd");
			
			boolean msg1= driver.findElement(By.xpath(xpathExpression7)).isEnabled();
			
			 if(msg1==true){
			generateXML.logVP("67.1", "Verify the functionality of 'Search' button",	"The search button  enabled after user entering a keyword in users  text box", AppConstants.vPass);
			//pass=pass+1;
			 }else{
				 generateXML.logVP("67.1", "Verify the functionality of 'Search' button",	 "The search button  enabled without user entering a keyword in  users  text box ", AppConstants.vFail);
			 }
			 String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_RESULT_SIZE_TB_ID);
				driver.findElement(By.xpath(xpathExpression6)).sendKeys("sds");
				boolean msg2= driver.findElement(By.xpath(xpathExpression7)).isEnabled();
		 if(msg2==true){
		  generateXML.logVP("67.2", "Verify the functionality of 'Search' button",	"The search button  enabled after user entering a keyword in  Result size text box", AppConstants.vPass);
		 //pass=pass+1;
		  }else{
				generateXML.logVP("67.2", "Verify the functionality of 'Search' button",	 "The search button  enabled without user entering a keyword in  Result size text box ", AppConstants.vFail);
				}
		 
		} else {
			generateXML.logVP("67.3", "Verify the functionality of 'Search' button",	 "The search button  enabled without user entering a keyword in either users or Result size text box ", AppConstants.vFail);		
			//fail=fail+1;
			  }	
     
	}
	
	
	@Test
	public void test_074() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression1)).click();
		 
		 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_VERTICAL_ID);
		 String msg1= driver.findElement(By.xpath(xpathExpression2)).getText();
		 
		 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_CTG_ID);
		 String msg2= driver.findElement(By.xpath(xpathExpression3)).getText();
		 
		 String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_SUBCTG_ID);
		 String msg3= driver.findElement(By.xpath(xpathExpression4)).getText();
		 
		 String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_PRODUCT_ID);
		 String msg4= driver.findElement(By.xpath(xpathExpression5)).getText();
		 
		 String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_ID);
		String msg5= driver.findElement(By.xpath(xpathExpression6)).getText();
		
		String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_TB_ID);
		String msg6= driver.findElement(By.xpath(xpathExpression7)).getAttribute("type");
		
		String xpathExpression8 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID1_ID);
		String msg7= driver.findElement(By.xpath(xpathExpression8)).getText();
		
		String xpathExpression9 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID2_ID);
		String msg8= driver.findElement(By.xpath(xpathExpression9)).getText();
		 
		
		  if(msg1.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_VERTICAL_NAME)) {
				
				generateXML.logVP("68.1", "Verify Create New scope section -Merchandise hierarchy :Vertical",	"'Vertical' is displaying", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("68.1", "Verify Create New scope section -Merchandise hierarchy :Vertical",	 "'Vertical'  is not displaying", AppConstants.vFail);		
				//fail=fail+1;
				  }	
	    if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_CTG_NAME)) {
				
				generateXML.logVP("68.2", "Verify Create New scope section -Merchandise hierarchy:Category",	"'Category'  is displaying", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("68.2", "Verify Create New scope section -Merchandise hierarchy:Category",	 "'Category'  is not displaying", AppConstants.vFail);		
				//fail=fail+1;
				  }	
	    if(msg3.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_SUBCTG_NAME)) {
				
				generateXML.logVP("68.3", "Verify Create New scope section -Merchandise hierarchy:'Sub Category' ",	"'Sub Category' is displaying", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("68.3", "Verify Create New scope section -Merchandise hierarchy:'Sub Category'",	 "'Sub Category'  is not displaying", AppConstants.vFail);		
				//fail=fail+1;
				  }	
	    if(msg4.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_PRODUCT_NAME)) {
				
				generateXML.logVP("66.4", "Verify Create New scope section -Merchandise hierarchy:Product",	"'Product' is displaying", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("68.4", "Verify Create New scope section -Merchandise hierarchy:Product",	 "'Product' is not displaying", AppConstants.vFail);		
				//fail=fail+1;
				  }	
	    if(msg5.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_NAME)) {
				
				generateXML.logVP("68.5", "Verify Create New scope section -Merchandise hierarchy:'Merchandise Hierarchy' textbox",	"'Merchandise Hierarchy' textbox is displaying", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("68.5", "Verify Create New scope section -Merchandise hierarchy:'Merchandise Hierarchy' textbox",	 "'Merchandise Hierarchy' textbox  is not displaying", AppConstants.vFail);		
				//fail=fail+1;
				  }	
	    if(msg6.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_TB_NAME)) {
				
				generateXML.logVP("68.6", "Verify Create New scope section -Merchandise hierarchy:'Merchandise Hierarchy' textbox",	"'Merchandise Hierarchy' textbox  is displaying", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("68.6", "Verify Create New scope section -Merchandise hierarchy:'Merchandise Hierarchy' textbox",	 "'Merchandise Hierarchy' textbox is not displaying", AppConstants.vFail);		
				//fail=fail+1;
				  }	
	    if(msg7.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID1_NAME)) {
				
				generateXML.logVP("68.7", "Verify Create New scope section -Merchandise hierarchy:arrow button",	"arrow button '>' is displaying", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("68.7", "Verify Create New scope section -Merchandise hierarchy:arrow button",	 "arrow button '>' is not displaying", AppConstants.vFail);		
				//fail=fail+1;
				  }	
	    if(msg8.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID2_NAME)) {
			
			generateXML.logVP("68.8", "Verify Create New scope section -Merchandise hierarchy:arrow button",	"arrow button '<' is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("68.8", "Verify Create New scope section -Merchandise hierarchy:arrow button",	 "arrow button '<' is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
	 
	 
	}
	
	@Test
	public void test_075() throws Exception {	
		
		//wait for 4 secs
//		Thread.sleep(2000);
//		
//		 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
//		 driver.findElement(By.xpath(xpathExpression1)).click();
//		 
//		 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_VERTICAL_ID);
//		 String msg1= driver.findElement(By.xpath(xpathExpression2)).getText();
//		 
//		 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_CTG_ID);
//		 String msg2= driver.findElement(By.xpath(xpathExpression3)).getText();
//		 
//		 String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_SUBCTG_ID);
//		 String msg3= driver.findElement(By.xpath(xpathExpression4)).getText();
//		 
//		 String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_PRODUCT_ID);
//		 String msg4= driver.findElement(By.xpath(xpathExpression5)).getText();
//		 
//		 String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_ID);
//		String msg5= driver.findElement(By.xpath(xpathExpression6)).getText();
//		
//		String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_TB_ID);
//		String msg6= driver.findElement(By.xpath(xpathExpression7)).getAttribute("type");
//		
//		String xpathExpression8 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID1_ID);
//		String msg7= driver.findElement(By.xpath(xpathExpression8)).getText();
//		
//		String xpathExpression9 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID2_ID);
//		String msg8= driver.findElement(By.xpath(xpathExpression9)).getText();
//		 
//		
//		  if(msg1.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_VERTICAL_NAME)) {
//				
//				generateXML.logVP("68.1", "Verify Create New scope section -Merchandise hierarchy :Vertical",	"'Vertical' is displaying", AppConstants.vPass);
//				//pass=pass+1;
//			} else {
//				generateXML.logVP("68.1", "Verify Create New scope section -Merchandise hierarchy :Vertical",	 "'Vertical'  is not displaying", AppConstants.vFail);		
//				//fail=fail+1;
//				  }	
//	    if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_CTG_NAME)) {
//				
//				generateXML.logVP("68.2", "Verify Create New scope section -Merchandise hierarchy:Category",	"'Category'  is displaying", AppConstants.vPass);
//				//pass=pass+1;
//			} else {
//				generateXML.logVP("68.2", "Verify Create New scope section -Merchandise hierarchy:Category",	 "'Category'  is not displaying", AppConstants.vFail);		
//				//fail=fail+1;
//				  }	
//	    if(msg3.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_SUBCTG_NAME)) {
//				
//				generateXML.logVP("68.3", "Verify Create New scope section -Merchandise hierarchy:'Sub Category' ",	"'Sub Category' is displaying", AppConstants.vPass);
//				//pass=pass+1;
//			} else {
//				generateXML.logVP("68.3", "Verify Create New scope section -Merchandise hierarchy:'Sub Category'",	 "'Sub Category'  is not displaying", AppConstants.vFail);		
//				//fail=fail+1;
//				  }	
//	    if(msg4.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_PRODUCT_NAME)) {
//				
//				generateXML.logVP("66.4", "Verify Create New scope section -Merchandise hierarchy:Product",	"'Product' is displaying", AppConstants.vPass);
//				//pass=pass+1;
//			} else {
//				generateXML.logVP("68.4", "Verify Create New scope section -Merchandise hierarchy:Product",	 "'Product' is not displaying", AppConstants.vFail);		
//				//fail=fail+1;
//				  }	
//	    if(msg5.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_NAME)) {
//				
//				generateXML.logVP("68.5", "Verify Create New scope section -Merchandise hierarchy:'Merchandise Hierarchy' textbox",	"'Merchandise Hierarchy' textbox is displaying", AppConstants.vPass);
//				//pass=pass+1;
//			} else {
//				generateXML.logVP("68.5", "Verify Create New scope section -Merchandise hierarchy:'Merchandise Hierarchy' textbox",	 "'Merchandise Hierarchy' textbox  is not displaying", AppConstants.vFail);		
//				//fail=fail+1;
//				  }	
//	    if(msg6.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_TB_NAME)) {
//				
//				generateXML.logVP("68.6", "Verify Create New scope section -Merchandise hierarchy:'Merchandise Hierarchy' textbox",	"'Merchandise Hierarchy' textbox  is displaying", AppConstants.vPass);
//				//pass=pass+1;
//			} else {
//				generateXML.logVP("68.6", "Verify Create New scope section -Merchandise hierarchy:'Merchandise Hierarchy' textbox",	 "'Merchandise Hierarchy' textbox is not displaying", AppConstants.vFail);		
//				//fail=fail+1;
//				  }	
//	    if(msg7.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID1_NAME)) {
//				
//				generateXML.logVP("68.7", "Verify Create New scope section -Merchandise hierarchy:arrow button",	"arrow button '>' is displaying", AppConstants.vPass);
//				//pass=pass+1;
//			} else {
//				generateXML.logVP("68.7", "Verify Create New scope section -Merchandise hierarchy:arrow button",	 "arrow button '>' is not displaying", AppConstants.vFail);		
//				//fail=fail+1;
//				  }	
//	    if(msg8.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID2_NAME)) {
//			
//			generateXML.logVP("68.8", "Verify Create New scope section -Merchandise hierarchy:arrow button",	"arrow button '<' is displaying", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("68.8", "Verify Create New scope section -Merchandise hierarchy:arrow button",	 "arrow button '<' is not displaying", AppConstants.vFail);		
//			//fail=fail+1;
//			  }	
		
	 
	 
	}
	@Test
	public void test_076() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression1)).click();
		 
//		 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_VERTICAL_ID);
//		 String msg1= driver.findElement(By.xpath(xpathExpression2)).getText();
//		 
//		 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_CTG_ID);
//		 String msg2= driver.findElement(By.xpath(xpathExpression3)).getText();
//		 
//		 String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_SUBCTG_ID);
//		 String msg3= driver.findElement(By.xpath(xpathExpression4)).getText();
//		 
//		 String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_PRODUCT_ID);
//		 String msg4= driver.findElement(By.xpath(xpathExpression5)).getText();
//		 
		 String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_SEARCH_BTN_ID);
		 boolean msg1=driver.findElement(By.xpath(xpathExpression6)).isEnabled();
		
		
		
//		String xpathExpression8 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID1_ID);
//		String msg7= driver.findElement(By.xpath(xpathExpression8)).getText();
//		
//		String xpathExpression9 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID2_ID);
//		String msg8= driver.findElement(By.xpath(xpathExpression9)).getText();
		 
		
		  if(msg1==false){
			  
			  String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_TB_ID);
				driver.findElement(By.xpath(xpathExpression7)).sendKeys("asd");
				boolean msg2=driver.findElement(By.xpath(xpathExpression6)).isEnabled();
				if(msg2==true){
					
					generateXML.logVP("70.1", "Verify the functionality of 'Search' button ",	"The search button   enabled when user enters a keyword in Merchandise hierarchy  text box ", AppConstants.vPass);
					
				}else{
					generateXML.logVP("70.1", "Verify the functionality of 'Search' button ",	 "The search button  is not enabled after user enters a keyword in Merchandise hierarchy  text box", AppConstants.vFail);
				}
			  
		  }else{
			  generateXML.logVP("70.2", "Verify the functionality of 'Search' button ",	 "The search button   enabled without user enters a keyword in Merchandise hierarchy  text box / a validation to accomplish this", AppConstants.vFail);
		  }
	 
	 
	}
	
	@Test
	public void test_077() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression1)).click();
		 

		
		 
		 String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT3_ID);
		 String msg2=driver.findElement(By.xpath(xpathExpression4)).getText();
		 
		 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT3_ID);
		 driver.findElement(By.xpath(xpathExpression2)).click();

		 String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression7)).click();
		 
		 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_RIGHT1_ID);
		 String msg1=driver.findElement(By.xpath(xpathExpression3)).getText();
		 
		 
		 if(msg1.equals(msg2)) {
				
				generateXML.logVP("71.1", "Verify functionality of Right  arrow in Channels",	"The right arrow adding selected item into right menu", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("71.1", "Verify functionality of Right  arrow in Channels",	 "The right arrow not adding selected item into right menu", AppConstants.vFail);		
				//fail=fail+1;
				  }	
		 
		 
		 String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_RIGHT1_ID);
		 String msg3=driver.findElement(By.xpath(xpathExpression5)).getText();
		 
		 
		 
		 
		 driver.findElement(By.xpath(xpathExpression5)).click();
		 
		 String xpathExpression8 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_MID2_ID);
		 driver.findElement(By.xpath(xpathExpression8)).click();
		 
		 String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT_AFTER_CLICK_ID);
		 String msg4=driver.findElement(By.xpath(xpathExpression6)).getText();
		
		 if(msg3.equals(msg4)) {
				
				generateXML.logVP("71.2", "Verify functionality of Left  arrow in Channels",	"The left arrow adding selected item into left menu", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("71.2", "Verify functionality of Left  arrow in Channels",	 "The left arrow not adding selected item into left menu", AppConstants.vFail);		
				//fail=fail+1;
				  }	
		 
		 
		 
		 
		 
		 
		 String xpathExpression9_1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEARCH_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression9_1)).click();
		 
		 
		 Thread.sleep(2000);
		 
		 
		 String xpathExpression9 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_LEFT_OPTION1_ID);
		 String msg9=driver.findElement(By.xpath(xpathExpression9)).getText();
		 
		 driver.findElement(By.xpath(xpathExpression9)).click();
		 
		 
		 String xpathExpression9_2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression9_2)).click();
		 
		 
		 String xpathExpression9_3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_RIGHT1_ID);
		 String msg9_3= driver.findElement(By.xpath(xpathExpression9_3)).getText();
		 
		 
		 
		 if(msg9.equals(msg9_3)) {
				
				generateXML.logVP("71.3", "Verify functionality of  Right  arrow in Segments",	"The Right arrow adding selected item into left menu", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("71.3", "Verify functionality of Right  arrow in Segments",	 "The Right arrow not adding selected item into left menu", AppConstants.vFail);		
				//fail=fail+1;
				  }	
		 
		 
		 
		 String xpathExpression10 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_RIGHT1_ID);
		 driver.findElement(By.xpath(xpathExpression10)).click();
		 
		 String xpathExpression10_1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_MID2_ID);
		 driver.findElement(By.xpath(xpathExpression10_1)).click();
		 
		 String xpathExpression11 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_LEFT_AFTER_CLICK_ID);
		 String msg11=driver.findElement(By.xpath(xpathExpression11)).getText();
		
		 if(msg9_3.equals(msg11)) {
				
				generateXML.logVP("71.4", "Verify functionality of Left  arrow in Segments",	"The left arrow adding selected item into left menu", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("71.4", "Verify functionality of Left  arrow in Segments",	 "The left arrow not adding selected item into left menu", AppConstants.vFail);		
				//fail=fail+1;
				  }	
		 
		 
		 
		 
		 String xpathExpression12_0_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_TB_ID);
		 driver.findElement(By.xpath(xpathExpression12_0_0)).sendKeys("1");
		 
		 String xpathExpression12_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_SEARCH_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression12_0)).click();
		 
		 
		 Thread.sleep(2000);
		 
		 
		 String xpathExpression12 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_LEFT1_ID);
		 
		String msg12_0= driver.findElement(By.xpath(xpathExpression12)).getText();
		 
	    driver.findElement(By.xpath(xpathExpression12)).click();
		 
		 String xpathExpression12_1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression12_1)).click();
		 
		 String xpathExpression12_2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_RIGHT1_ID);
		 String msg12_1=driver.findElement(By.xpath(xpathExpression12_2)).getText();
		
		 if(msg12_1.equals(msg12_0)) {
				
				generateXML.logVP("71.5", "Verify functionality of Right  arrow in Users",	"The Right arrow adding selected item into Right menu", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("71.5", "Verify functionality of Right  arrow in Users",	 "The Right arrow not adding selected item into Right menu", AppConstants.vFail);		
				//fail=fail+1;
				  }	
		 
		 driver.findElement(By.xpath(xpathExpression12_2)).click();
		 String xpathExpression12_3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_MID2_ID);
		 driver.findElement(By.xpath(xpathExpression12_3)).click();
		 
		 String xpathExpression12_4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_LEFT_AFTER_CLICK_ID);
		 String msg12_2=driver.findElement(By.xpath(xpathExpression12_4)).getText();
		 
		 if(msg12_2.equals(msg12_0)) {
				
				generateXML.logVP("71.6", "Verify functionality of Left  arrow in Users",	"The Left arrow adding selected item into left menu", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("71.6", "Verify functionality of Left  arrow in Users",	 "The Leftt arrow not adding selected item into left menu", AppConstants.vFail);		
				//fail=fail+1;
				  }	
		
	 
		 //mh
		 
		 String xpathExpression13_0_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_TB_ID);
		 driver.findElement(By.xpath(xpathExpression13_0_0)).sendKeys("Men");
		 
		 String xpathExpression13_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_SEARCH_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression13_0)).click();
		 
		 
		 Thread.sleep(2000);
		 
		 
		 String xpathExpression13 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_LEFT1_ID);
		 
		String msg13_0= driver.findElement(By.xpath(xpathExpression13)).getText();
		 
	    driver.findElement(By.xpath(xpathExpression13)).click();
		 
		 String xpathExpression13_1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression13_1)).click();
		 
		 String xpathExpression13_2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_RIGHT1_ID);
		 String msg13_1=driver.findElement(By.xpath(xpathExpression13_2)).getText();
		
		 if(msg13_1.equals(msg13_0)) {
				
				generateXML.logVP("71.7", "Verify functionality of Right  arrow in MH",	"The Right arrow adding selected item into Right menu", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("71.7", "Verify functionality of Right  arrow in MH",	 "The Right arrow not adding selected item into Right menu", AppConstants.vFail);		
				//fail=fail+1;
				  }	
		 
		 driver.findElement(By.xpath(xpathExpression13_2)).click();
		 String xpathExpression13_3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID2_ID);
		 driver.findElement(By.xpath(xpathExpression13_3)).click();
		 
		 String xpathExpression13_4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_LEFT_AFTER_CLICK_ID);
		 String msg13_2=driver.findElement(By.xpath(xpathExpression13_4)).getText();
		 
		 if(msg13_2.equals(msg13_0)) {
				
				generateXML.logVP("71.8", "Verify functionality of Left  arrow in MH",	"The Left arrow adding selected item into left menu", AppConstants.vPass);
				//pass=pass+1;
			} else {
				generateXML.logVP("71.8", "Verify functionality of Left  arrow in MH",	 "The Leftt arrow not adding selected item into left menu", AppConstants.vFail);		
				//fail=fail+1;
				  }	
		
		 
		 
	}

	@Test
	public void test_078() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ID);
		driver.findElement(By.xpath(xpathExpression1_0)).click();
		
		
	 String xpathExpression2_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_RULE_NAME_ID);
	 driver.findElement(By.xpath(xpathExpression2_0)).click();
	 
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_ID);
	 driver.findElement(By.xpath(xpathExpression3)).click();
	 
	 String xpathExpression4_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_ID);
	 driver.findElement(By.xpath(xpathExpression4_0)).click();
	 
		
		 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression1)).click();
		 

		
		 

		 
		 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT3_ID);
		 driver.findElement(By.xpath(xpathExpression2)).click();

		 String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression7)).click();
		 

		 
		 
		 
		 
		 
		 String xpathExpression9_1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEARCH_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression9_1)).click();
		 
		 
		 Thread.sleep(2000);
		 
		 
	 String xpathExpression9 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_LEFT_OPTION1_ID);
//		 String msg9=driver.findElement(By.xpath(xpathExpression9)).getText();
		 
		 driver.findElement(By.xpath(xpathExpression9)).click();
		 
		 
		 String xpathExpression9_2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression9_2)).click();
		 
		 

		 
		 
		 
		 
		 String xpathExpression12_0_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_TB_ID);
		 driver.findElement(By.xpath(xpathExpression12_0_0)).sendKeys("1");
		 
		 String xpathExpression12_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_SEARCH_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression12_0)).click();
		 
		 
		 Thread.sleep(2000);
		 
		 
		 String xpathExpression12 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_LEFT1_ID);
		 
		//String msg12_0= driver.findElement(By.xpath(xpathExpression12)).getText();
		 
	    driver.findElement(By.xpath(xpathExpression12)).click();
		 
		 String xpathExpression12_1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression12_1)).click();

		
	 
		 //mh
		 
		 String xpathExpression13_0_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_TB_ID);
		 driver.findElement(By.xpath(xpathExpression13_0_0)).sendKeys("Men");
		 
		 String xpathExpression13_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_SEARCH_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression13_0)).click();
		 
		 
		 Thread.sleep(2000);
		 
		 
		 String xpathExpression13 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_LEFT1_ID);
		 
		
		 
	    driver.findElement(By.xpath(xpathExpression13)).click();
		 
		 String xpathExpression13_1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression13_1)).click();
		 
		
		 String xpathExpression14 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CREATE_ID);		 
		 
		 driver.findElement(By.xpath(xpathExpression14)).click();
		 
		 Thread.sleep(2000);
		 

		 String xpathExpression15 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CREATE_SUCC_ID);		 
		 
		String msg14= driver.findElement(By.xpath(xpathExpression15)).getText();
		
		if(msg14.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CREATE_SUCC_MSG_ID)) {
			
			generateXML.logVP("72.1", "Verify the functionality of 'Create ' button",	"Upon clicking create button,user  able to create a scope with selected values ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("72.1", "Verify the functionality of 'Create ' button",	 "Upon clicking create button,user not  able to create a scope with selected values ", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		 
		 String xpathExpression16 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CREATE_SUCC_OK_ID);		 
		 
			driver.findElement(By.xpath(xpathExpression16)).click();
	}
	
	@Test
	public void test_079() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		
		String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ID);
		driver.findElement(By.xpath(xpathExpression1_0)).click();
		
		
	 String xpathExpression2_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_RULE_NAME_ID);
	 driver.findElement(By.xpath(xpathExpression2_0)).click();
	 
	 
	 String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_ID);
	 driver.findElement(By.xpath(xpathExpression3)).click();
	 
	 String xpathExpression4_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_ID);
	 driver.findElement(By.xpath(xpathExpression4_0)).click();
	 
		
		

		
		
		 String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression1)).click();
		 

		
		 

		 
		 String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_LEFT3_ID);
		 driver.findElement(By.xpath(xpathExpression2)).click();

		 String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CHANNELS_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression7)).click();
		 

		 
		 
		 
		 
		 
		 String xpathExpression9_1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_SEARCH_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression9_1)).click();
		 
		 
		 Thread.sleep(2000);
		 
		 
	 String xpathExpression9 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_LEFT_OPTION1_ID);
//		 String msg9=driver.findElement(By.xpath(xpathExpression9)).getText();
		 
		 driver.findElement(By.xpath(xpathExpression9)).click();
		 
		 
		 String xpathExpression9_2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_SEGMENTS_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression9_2)).click();
		 
		 

		 
		 
		 
		 
		 String xpathExpression12_0_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_USER_BY_TB_ID);
		 driver.findElement(By.xpath(xpathExpression12_0_0)).sendKeys("1");
		 
		 String xpathExpression12_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_SEARCH_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression12_0)).click();
		 
		 
		 Thread.sleep(2000);
		 
		 
		 String xpathExpression12 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_LEFT1_ID);
		 
		//String msg12_0= driver.findElement(By.xpath(xpathExpression12)).getText();
		 
	    driver.findElement(By.xpath(xpathExpression12)).click();
		 
		 String xpathExpression12_1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_USERS_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression12_1)).click();

		
	 
		 //mh
		 
		 String xpathExpression13_0_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MH_NAME_TB_ID);
		 driver.findElement(By.xpath(xpathExpression13_0_0)).sendKeys("Men");
		 
		 String xpathExpression13_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_SEARCH_BTN_ID);
		 driver.findElement(By.xpath(xpathExpression13_0)).click();
		 
		 
		 Thread.sleep(2000);
		 
		 
		 String xpathExpression13 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_LEFT1_ID);
		 
		
		 
	    driver.findElement(By.xpath(xpathExpression13)).click();
		 
		 String xpathExpression13_1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_MH_MID1_ID);
		 driver.findElement(By.xpath(xpathExpression13_1)).click();
		 
		
		 String xpathExpression14 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CANCEL_ID);		 
		 
		 driver.findElement(By.xpath(xpathExpression14)).click();
		 
		 Thread.sleep(2000);
		 

		 String xpathExpression15 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CANCEL_SUCC_ID);		 
		 
		String msg14= driver.findElement(By.xpath(xpathExpression15)).getText();
		
		if(msg14.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_NEW_SCOPE_BTN_CANCEL_SUCC_MSG_ID)) {
			
			generateXML.logVP("73.1", "Verify the functionality of 'Cancel ' button",	"Upon clicking cancel button,user  able to cancel a scope with selected values ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("73.1", "Verify the functionality of 'Cancel ' button",	 "Upon clicking cancel button,user not  able to cancel a scope with selected values ", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		 
		 
	}
	@Test
	public void test_080() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		
		
		String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_ID);
		driver.findElement(By.xpath(xpathExpression1_0)).click();
		
		
	 String xpathExpression2_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_RULE_NAME_ID);
	 driver.findElement(By.xpath(xpathExpression2_0)).click();
	 
	 
	 String xpathExpression3_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_ID);
	 driver.findElement(By.xpath(xpathExpression3_0)).click();
	 
	 String xpathExpression4_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_ID);
	 driver.findElement(By.xpath(xpathExpression4_0)).click();
	 
		
		
		 

		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression1)).getText();
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_CHANNELS_ID);
		String msg2=driver.findElement(By.xpath(xpathExpression2)).getText();
		
		String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_SEGMENTS_ID);
		String msg3=driver.findElement(By.xpath(xpathExpression3)).getText();
		
		String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_USERS_ID);
		String msg4=driver.findElement(By.xpath(xpathExpression4)).getText();
		
		String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_MH_ID);
		String msg5=driver.findElement(By.xpath(xpathExpression5)).getText();
		
		String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_DELETE_SCOPE_ID);
		String msg6=driver.findElement(By.xpath(xpathExpression6)).getText();
		
		

		if(msg1.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_NAME)) {
			
			generateXML.logVP("74.1", "Verify Manage Scope screen -Existing section",	"Existing section is displaying ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("74.1", "Verify Manage Scope screen -Existing section",	 "Existing section is not displaying ", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		   
       if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_CHANNELS_NAME)) {
			
			generateXML.logVP("74.2", "Verify Manage Scope screen -Existing section:Channels",	"Channels section is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("74.2", "Verify Manage Scope screen -Existing section:Channels",	 "Channels section is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }		
       if(msg3.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_SEGMENTS_NAME)) {
			
			generateXML.logVP("74.3", "Verify Manage Scope screen -Existing section:Segments",	"Segments section is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("74.3", "Verify Manage Scope screen -Existing section:Segments",	 "Segments section is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
       if(msg4.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_USERS_NAME)) {
			
			generateXML.logVP("74.4", "Verify Manage Scope screen -Existing section:Users",	"Users section is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("74.4", "Verify Manage Scope screen -Existing section:Users",	 "Users section is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
       if(msg5.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_MH_NAME)) {
			
			generateXML.logVP("74.5", "Verify Manage Scope screen -Existing section:Merchandise Hirearchy",	"Merchandise Hirearchy section is displaying", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("74.5", "Verify Manage Scope screen -Existing section:Merchandise Hirearchy",	 "Merchandise Hirearchy section is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
       if(msg6.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_DELETE_SCOPE_NAME)) {
			
			generateXML.logVP("74.6", "Verify Manage Scope screen -Existing section:Delete Scope",	"Delete Scope section is displaying ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("74.6", "Verify Manage Scope screen -Existing section:Delete Scope",	 "Delete Scope section is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
		 
		 
		 
	}
	
	@Test
	public void test_081() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
//		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_ID);
//		String msg1=driver.findElement(By.xpath(xpathExpression1)).getText();
//		
//		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_CHANNELS_ID);
//		String msg2=driver.findElement(By.xpath(xpathExpression2)).getText();
//		
//		String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_SEGMENTS_ID);
//		String msg3=driver.findElement(By.xpath(xpathExpression3)).getText();
//		
//		String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_USERS_ID);
//		String msg4=driver.findElement(By.xpath(xpathExpression4)).getText();
//		
//		String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_MH_ID);
//		String msg5=driver.findElement(By.xpath(xpathExpression5)).getText();
		
		String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_DELETE_SCOPE_ID);
		String msg6=driver.findElement(By.xpath(xpathExpression6)).getText();
		
		

//		if(msg1.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_NAME)) {
//			
//			generateXML.logVP("74.1", "Verify Manage Scope screen -Existing section",	"Existing section is displaying ", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("74.1", "Verify Manage Scope screen -Existing section",	 "Existing section is not displaying ", AppConstants.vFail);		
//			//fail=fail+1;
//			  }	
//		   
//       if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_CHANNELS_NAME)) {
//			
//			generateXML.logVP("74.2", "Verify Manage Scope screen -Existing section:Channels",	"Channels section is displaying", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("74.2", "Verify Manage Scope screen -Existing section:Channels",	 "Channels section is not displaying", AppConstants.vFail);		
//			//fail=fail+1;
//			  }		
//       if(msg3.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_SEGMENTS_NAME)) {
//			
//			generateXML.logVP("74.3", "Verify Manage Scope screen -Existing section:Segments",	"Segments section is displaying", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("74.3", "Verify Manage Scope screen -Existing section:Segments",	 "Segments section is not displaying", AppConstants.vFail);		
//			//fail=fail+1;
//			  }	
//       if(msg4.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_USERS_NAME)) {
//			
//			generateXML.logVP("74.4", "Verify Manage Scope screen -Existing section:Users",	"Users section is displaying", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("74.4", "Verify Manage Scope screen -Existing section:Users",	 "Users section is not displaying", AppConstants.vFail);		
//			//fail=fail+1;
//			  }	
//       if(msg5.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_MH_NAME)) {
//			
//			generateXML.logVP("74.5", "Verify Manage Scope screen -Existing section:Merchandise Hirearchy",	"Merchandise Hirearchy section is displaying", AppConstants.vPass);
//			//pass=pass+1;
//		} else {
//			generateXML.logVP("74.5", "Verify Manage Scope screen -Existing section:Merchandise Hirearchy",	 "Merchandise Hirearchy section is not displaying", AppConstants.vFail);		
//			//fail=fail+1;
//			  }	
       if(msg6.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_DELETE_SCOPE_NAME)) {
			
			generateXML.logVP("75.1", "Verify Manage Scope screen -Existing section:Delete Scope",	"Delete Scope section is displaying ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("75.1", "Verify Manage Scope screen -Existing section:Delete Scope",	 "Delete Scope section is not displaying", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
		 
		 
		 
	}
	
	@Test
	public void test_082() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		Thread.sleep(2000);
		String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_DELETE_SCOPE_ID);
		boolean msg1=driver.findElement(By.xpath(xpathExpression6)).isEnabled();

       if(msg1==false) {
			
			generateXML.logVP("76.1", "Verify Manage Scope screen -Existing section:Delete Scope",	"Delete Scope is not enabled without selecting any check-box ", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("76.1", "Verify Manage Scope screen -Existing section:Delete Scope",	 "Delete Scope is  enabled without selecting any check-box", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
		 
		 
		 
	}
	
	@Test
	public void test_083() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		Thread.sleep(2000);
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_SELECT_CHK_BOX_ID);
		driver.findElement(By.xpath(xpathExpression2)).click();
		
		
		String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_DELETE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression6)).click();
		
		Thread.sleep(2000);
		
		String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_DELETE_SCOPE_SUCC_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression7)).getText();
		

       if(msg1.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_DELETE_SCOPE_SUCC_NAME)) {
			
			generateXML.logVP("77.1", "Verify Manage Scope screen -Existing section:Delete Scope",	"Upon clicking Delete button, selected  scope deleted with an confirmation message", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("77.1", "Verify Manage Scope screen -Existing section:Delete Scope",	 "Upon clicking Delete button, selected  scope is not deleted ", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
       String xpathExpression8 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_DELETE_SCOPE_SUCC_OK_ID);
		driver.findElement(By.xpath(xpathExpression8)).click();
		 
		 
	}
	
	@Test
	public void test_084() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		Thread.sleep(2000);
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_SCOPE_HYPERLINK_ID);
		driver.findElement(By.xpath(xpathExpression2)).click();
		Thread.sleep(1000);
		
		
		
		String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_SCOPE_HYPERLINK_RESULT_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression7)).getText();
		

       if(msg1.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_SCOPE_HYPERLINK_RESULT_NAME)) {
			
			generateXML.logVP("78.1", "Verify whether the scopes available in existing section are hyperlinks ",	"The scopes available in existing section are hyperlinks and upon clicking  open a edit scope section ( same as create scope section )to edit existing values", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("78.1", "Verify whether the scopes available in existing section are hyperlinks ",	 "The scopes available in existing section are not hyperlinks ", AppConstants.vFail);		
			//fail=fail+1;
			  }	
		
       
		 
		 
	}
	
	@Test
	public void test_085() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		Thread.sleep(2000);
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_SCOPE_HYPERLINK_ID);
		driver.findElement(By.xpath(xpathExpression2)).click();
		Thread.sleep(1000);
		
		
		
		String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_CHANNELS_ID);
		String msg1=driver.findElement(By.xpath(xpathExpression7)).getText();
		

       if(msg1.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_CHANNELS_NAME)) {
			
			generateXML.logVP("79.1", "Verify edit scope section ",	"The edit scope section  open with existing values for Channels", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("79.1", "Verify edit scope section ",	 "The edit scope section not open with existing values for Channels", AppConstants.vFail);		
			//fail=fail+1;
			  }	
       
       
       String xpathExpression8 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_USERS_ID);
		String msg2=driver.findElement(By.xpath(xpathExpression8)).getText();
		

      if(msg2.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_USERS_NAME)) {
			
			generateXML.logVP("79.2", "Verify edit scope section ",	"The edit scope section  open with existing values for Users", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("79.2", "Verify edit scope section ",	 "The edit scope section not open with existing values for Users", AppConstants.vFail);		
			//fail=fail+1;
			  }	
      
      
      String xpathExpression9 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_SEGMENTS_ID);
		String msg3=driver.findElement(By.xpath(xpathExpression9)).getText();
		

    if(msg3.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_SEGMENTS_NAME)) {
			
			generateXML.logVP("79.3", "Verify edit scope section ",	"The edit scope section  open with existing values for Segments", AppConstants.vPass);
			//pass=pass+1;
		} else {
			generateXML.logVP("79.3", "Verify edit scope section ",	 "The edit scope section not open with existing values for Segments", AppConstants.vFail);		
			//fail=fail+1;
			  }	
    
    String xpathExpression10 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_MH_ID);
	String msg4=driver.findElement(By.xpath(xpathExpression10)).getText();
	

if(msg4.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_MH_NAME)) {
		
		generateXML.logVP("79.4", "Verify edit scope section ",	"The edit scope section  open with existing values for Merchandise Hierarchy", AppConstants.vPass);
		//pass=pass+1;
	} else {
		generateXML.logVP("79.4", "Verify edit scope section ",	 "The edit scope section not open with existing values for Merchandise Hierarchy", AppConstants.vFail);		
		//fail=fail+1;
		  }	


String xpathExpression11 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_CANCEL_ID);
	String msg5=driver.findElement(By.xpath(xpathExpression11)).getText();
	

if(msg5.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_CANCEL_NAME)) {
		
		generateXML.logVP("79.5", "Verify edit scope section ",	"The edit scope section  open with existing values for Cancel", AppConstants.vPass);
		//pass=pass+1;
	} else {
		generateXML.logVP("79.5", "Verify edit scope section ",	 "The edit scope section not open with existing values for Cancel", AppConstants.vFail);		
		//fail=fail+1;
		  }	

String xpathExpression12 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_SAVE_SCOPE_ID);
String msg6=driver.findElement(By.xpath(xpathExpression12)).getText();


if(msg6.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_SAVE_SCOPE_NAME)) {
	
	generateXML.logVP("79.6", "Verify edit scope section ",	"The edit scope section  open with existing values for Save Scope", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("79.6", "Verify edit scope section ",	 "The edit scope section not open with existing values for Save Scope", AppConstants.vFail);		
	//fail=fail+1;
	  }	
		
       
		 
		 
	}
	
	@Test
	public void test_086() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		Thread.sleep(2000);
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_SCOPE_HYPERLINK_ID);
		driver.findElement(By.xpath(xpathExpression2)).click();
		Thread.sleep(1000);
		
		
		
		

String xpathExpression12 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_SAVE_SCOPE_ID);

driver.findElement(By.xpath(xpathExpression12)).click();
Thread.sleep(2000);

String xpathExpression13 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_SAVE_SCOPE_RESULT_ID);

String msg6=driver.findElement(By.xpath(xpathExpression13)).getText();

if(msg6.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_SAVE_SCOPE_RESULT_NAME)) {
	
	generateXML.logVP("80.1", "Verify edit scope section ",	"The edit scope section  open with existing values for Save Scope", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("80.1", "Verify edit scope section ",	 "The edit scope section not open with existing values for Save Scope", AppConstants.vFail);		
	//fail=fail+1;
	  }	
		
String xpathExpression14 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_SAVE_SCOPE_RESULT_OK_ID);

driver.findElement(By.xpath(xpathExpression14)).click();
		 
		 
	}
	
	@Test
	public void test_087() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		Thread.sleep(1000);
		
		String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_SCOPE_HYPERLINK_ID);
		driver.findElement(By.xpath(xpathExpression2)).click();
		Thread.sleep(1000);
		
		

String xpathExpression11 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EDIT_SCOPE_CANCEL_ID);
driver.findElement(By.xpath(xpathExpression11)).click();


String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_ID);
String msg1=driver.findElement(By.xpath(xpathExpression1_0)).getText();

if(msg1.equals(RuleConstants.RULE_INSTANCE_LIST_OF_RULE_INSTANCES_MANAGE_SCOPE_EXISTING_SCOPE_NAME)) {
	
	generateXML.logVP("81.1", "Verify the functionality of Cancel button",	"Upon clicking Cancel button, user able to  cancel updating  the existing values", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("81.1", "Verify the functionality of Cancel button",	 "Upon clicking Cancel button, user not able to  cancel updating  the existing values", AppConstants.vFail);		
	//fail=fail+1;
	  }	
		

		 
		 
	}
	
	
	
	@Test
	public void test_088() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		

String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_ID);
String msg1=driver.findElement(By.xpath(xpathExpression1_0)).getText();

if(msg1.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_NAME)) {
	
	generateXML.logVP("82.1", "Verify user is able to navigate successfully to Rule Manage Scope search screen clicking on the tab available in Rules screen",	"The user able to navigate Rule Mange Scope search screen successfully clicking on  the tab in Rules screen", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("82.1", "Verify user is able to navigate successfully to Rule Manage Scope search screen clicking on the tab available in Rules screen",	 "The user not able to navigate Rule Mange Scope search screen successfully clicking on  the tab in Rules screen", AppConstants.vFail);		
	//fail=fail+1;
	  }	
		

		 
		 
	}
	
	@Test
	public void test_089() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		
		String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1)).click();
		

String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_ID);
String msg1=driver.findElement(By.xpath(xpathExpression1_0)).getText();

if(msg1.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_NAME)) {
	
	generateXML.logVP("83.1", "Verify  Rule Manage Scope search screen",	"Rule Manage Scope search screen  displayed  with search section and grid with all results", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("83.1", "Verify  Rule Manage Scope search screen",	 "Rule Manage Scope search screen  not displayed  with search section and grid with all results", AppConstants.vFail);		
	//fail=fail+1;
	  }	
		

		 
		 
	}
	
	@Test
	public void test_090() throws Exception {	
		
		//wait for 4 secs
		Thread.sleep(2000);
		
		
		String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1_0)).click();
		

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_ID);
String msg1=driver.findElement(By.xpath(xpathExpression1)).getText();

if(msg1.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_NAME)) {
	
	generateXML.logVP("84.1", "Verify  Rule Manage Scope search screen-Search section :Rule Instance Name",	"The search section  displayed with Rule Instance name", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("84.1", "Verify  Rule Manage Scope search screen-Search section :Rule Instance Name",	 "The search section  not displayed with Rule Instance name", AppConstants.vFail);		
	//fail=fail+1;
	  }	

String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_SEGMENT_TYPE_ID);
String msg2=driver.findElement(By.xpath(xpathExpression2)).getText();

if(msg2.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_SEGMENT_TYPE_NAME)) {
	
	generateXML.logVP("84.2", "Verify  Rule Manage Scope search screen-Search section :Segment Type",	"The search section  displayed with Segment Type", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("84.2", "Verify  Rule Manage Scope search screen-Search section :Segment Type",	 "The search section not displayed with Segment Type", AppConstants.vFail);		
	//fail=fail+1;
	  }	
		

String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_SEGMENT_NAME_ID);
String msg3=driver.findElement(By.xpath(xpathExpression3)).getText();

if(msg3.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_SEGMENT_NAME_NAME)) {
	
	generateXML.logVP("84.3", "Verify  Rule Manage Scope search screen-Search section :Segment Name",	"The search section  displayed with Segment Name", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("84.3", "Verify  Rule Manage Scope search screen-Search section :Segment Name",	 "The search section not displayed with Segment Name", AppConstants.vFail);		
	//fail=fail+1;
	  }	

String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_CHANNEL_ID);
String msg4=driver.findElement(By.xpath(xpathExpression4)).getText();

if(msg4.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_CHANNEL_NAME)) {
	
	generateXML.logVP("84.4", "Verify  Rule Manage Scope search screen-Search section :Channel",	"The search section  displayed with Channel", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("84.4", "Verify  Rule Manage Scope search screen-Search section :Channel",	 "The search section not displayed with Channel", AppConstants.vFail);		
	//fail=fail+1;
	  }	

String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_USERS_ID);
String msg5=driver.findElement(By.xpath(xpathExpression5)).getText();

if(msg5.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_USERS_NAME)) {
	
	generateXML.logVP("84.5", "Verify  Rule Manage Scope search screen-Search section :Users",	"The search section  displayed with Users", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("84.5", "Verify  Rule Manage Scope search screen-Search section :Users",	 "The search section not displayed with Users", AppConstants.vFail);		
	//fail=fail+1;
	  }	
String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_MH_ID);
String msg6=driver.findElement(By.xpath(xpathExpression6)).getText();

if(msg6.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_MH_NAME)) {
	
	generateXML.logVP("84.6", "Verify  Rule Manage Scope search screen-Search section :Merchandise Hierarchy",	"The search section  displayed with Merchandise Hierarchy", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("84.6", "Verify  Rule Manage Scope search screen-Search section :Merchandise Hierarchy",	 "The search section not displayed with Merchandise Hierarchy", AppConstants.vFail);		
	//fail=fail+1;
	  }	

String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
String msg7=driver.findElement(By.xpath(xpathExpression7)).getAttribute("type");

if(msg7.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_NAME)) {
	
	generateXML.logVP("84.7", "Verify  Rule Manage Scope search screen-Search section :'GO' button",	"The search section  displayed with 'GO' button", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("84.7", "Verify  Rule Manage Scope search screen-Search section :'GO' button",	 "The search section not displayed with 'GO' button", AppConstants.vFail);		
	//fail=fail+1;
	  }	

	
}

@Test
public void test_091() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
	String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
String msg1=driver.findElement(By.xpath(xpathExpression1)).getAttribute("type");

if(msg1.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_NAME)) {

generateXML.logVP("85.1", "Verify Rule Manage Scope search screen-Rule Instance name",	"The Rule Instance name text  box  allowing alphanumeric", AppConstants.vPass);
//pass=pass+1;
} else {
generateXML.logVP("85.1", "Verify Rule Manage Scope search screen-Rule Instance name",	 "The Rule Instance name text  box is not allowing alphanumeric", AppConstants.vFail);		
//fail=fail+1;
  }	



		 
		 
	}

@Test
public void test_092() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
	String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_SEGMENT_NAME_TB_ID);
String msg1=driver.findElement(By.xpath(xpathExpression1)).getAttribute("type");

if(msg1.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_SEGMENT_NAME_TB_NAME)) {

generateXML.logVP("86.1", "Verify Rule Manage Scope search screen -segment Name",	"The segment Name text  box  allowing alphanumeric ", AppConstants.vPass);
//pass=pass+1;
} else {
generateXML.logVP("86.1", "Verify Rule Manage Scope search screen -segment Name",	 "The segment Name text  box is not allowing alphanumeric ", AppConstants.vFail);		
//fail=fail+1;
  }	



}
@Test
public void test_093() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
	String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_CHANNEL_TB_ID);
String msg1=driver.findElement(By.xpath(xpathExpression1)).getText();

if(msg1.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_CHANNEL_TB_NAME)) {

generateXML.logVP("87.1", "Verify Rule Manage Scope search screen-Channel",	"The Channel text  box  allowing alphanumeric", AppConstants.vPass);
//pass=pass+1;
} else {
generateXML.logVP("87.1", "Verify Rule Manage Scope search screen-Channel",	 "The Channel text  box is not allowing alphanumeric", AppConstants.vFail);		
//fail=fail+1;
  }	



}

@Test
public void test_094() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
	String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_USERS_TB_ID);
String msg1=driver.findElement(By.xpath(xpathExpression1)).getAttribute("type");

if(msg1.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_USERS_TB_NAME)) {

generateXML.logVP("88.1", "Verify Rule Manage Scope search screen -Users",	"The Users text  box  allowing alphanumeric ", AppConstants.vPass);
//pass=pass+1;
} else {
generateXML.logVP("88.1", "Verify Rule Manage Scope search screen -Users",	 "The Users text  box is not allowing alphanumeric ", AppConstants.vFail);		
//fail=fail+1;
  }	



}

@Test
public void test_095() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
	String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
driver.findElement(By.xpath(xpathExpression1)).clear();
driver.findElement(By.xpath(xpathExpression1)).sendKeys("..///");


String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
driver.findElement(By.xpath(xpathExpression7)).click();

Thread.sleep(2000);
String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_RESULT_ID);
String msg7=driver.findElement(By.xpath(xpathExpression2)).getText();

if(msg7.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_RESULT_NAME)) {
	
	generateXML.logVP("89.1", "Verify entering special characters in Rule Instance name",	"The system  throwing an error message saying ' special characters are not allowed'", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("89.1", "Verify entering special characters in Rule Instance name",	 "The system not throwing an error message saying ' special characters are not allowed'", AppConstants.vFail);		
	//fail=fail+1;
	  }	





String xpathExpression1_1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_SEGMENT_NAME_TB_ID);
driver.findElement(By.xpath(xpathExpression1_1)).clear();
driver.findElement(By.xpath(xpathExpression1_1)).sendKeys("..///");


String xpathExpression7_1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
driver.findElement(By.xpath(xpathExpression7_1)).click();

Thread.sleep(2000);
String xpathExpression2_1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_RESULT_ID);
String msg7_1=driver.findElement(By.xpath(xpathExpression2_1)).getText();

if(msg7_1.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_RESULT_NAME)) {
	
	generateXML.logVP("89.2", "Verify entering special characters in Segment name text box",	"The system  throwing an error message saying 'special characters are not allowed'", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("89.2", "Verify entering special characters in Segment name text box",	 "The system not throwing an error message saying 'special characters are not allowed'", AppConstants.vFail);		
	//fail=fail+1;
	  }	

String xpathExpression1_2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_USERS_TB_ID);
driver.findElement(By.xpath(xpathExpression1_2)).clear();
driver.findElement(By.xpath(xpathExpression1_2)).sendKeys("..///");


String xpathExpression7_2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
driver.findElement(By.xpath(xpathExpression7_2)).click();

Thread.sleep(2000);
String xpathExpression2_2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_RESULT_ID);
String msg7_2=driver.findElement(By.xpath(xpathExpression2_2)).getText();

if(msg7_2.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_RESULT_NAME)) {
	
	generateXML.logVP("89.3", "Verify entering special characters in Users text box",	"The system  throwing an error message saying 'special characters are not allowed'", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("89.3", "Verify entering special characters in Users text box",	 "The system not throwing an error message saying 'special characters are not allowed'", AppConstants.vFail);		
	//fail=fail+1;
	  }	


}



@Test
public void test_096() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
driver.findElement(By.xpath(xpathExpression1)).clear();
driver.findElement(By.xpath(xpathExpression1)).sendKeys("a");


String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
driver.findElement(By.xpath(xpathExpression7)).click();

Thread.sleep(2000);
String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_ID);
String msg7=driver.findElement(By.xpath(xpathExpression2)).getText();

if(msg7.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_NAME)) {
	
	generateXML.logVP("90.1", "Verify the functionality of 'Go' button",	"The system  displaying the search results  applying 'and' search", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("90.1", "Verify the functionality of 'Go' button",	 "The system  not displaying the search results  applying 'and' search", AppConstants.vFail);		
	//fail=fail+1;
	  }	




}

@Test
public void test_097() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
driver.findElement(By.xpath(xpathExpression1)).clear();
//driver.findElement(By.xpath(xpathExpression1)).sendKeys("aas");


String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
driver.findElement(By.xpath(xpathExpression7)).click();

Thread.sleep(2000);
String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_ID);
String msg7=driver.findElement(By.xpath(xpathExpression2)).getText();

if(msg7.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_NAME)) {
	
	generateXML.logVP("91.1", "Verify the functionality of 'Go' button:with no input given",	"all the results  displayed", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("91.1", "Verify the functionality of 'Go' button:with no input given",	 "all the results not displayed", AppConstants.vFail);		
	//fail=fail+1;
	  }	


}


@Test
public void test_098() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
driver.findElement(By.xpath(xpathExpression1)).clear();
driver.findElement(By.xpath(xpathExpression1)).sendKeys("a");


String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
driver.findElement(By.xpath(xpathExpression7)).click();

Thread.sleep(2000);
String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_ID);
String msg7=driver.findElement(By.xpath(xpathExpression2)).getText();

if(msg7.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_NAME)) {
	
	generateXML.logVP("92.1", "Verify search results in 'Rule Scope'",	"The system  displaying the search results  applying 'and' search", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("92.1", "Verify search results in 'Rule Scope'",	 "The system not displaying the search results  applying 'and' search", AppConstants.vFail);		
	//fail=fail+1;
	  }	


}

@Test
public void test_099() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
	String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	
	
	String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
	driver.findElement(By.xpath(xpathExpression7)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_ID);
String msg1=driver.findElement(By.xpath(xpathExpression1)).getText();

if(msg1.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_NAME)) {

generateXML.logVP("93.1", "Verify  Rule Manage Scope search screen-Search section :Rule Instance Name",	"The search section  displayed with Rule Instance name", AppConstants.vPass);
//pass=pass+1;
} else {
generateXML.logVP("93.1", "Verify  Rule Manage Scope search screen-Search section :Rule Instance Name",	 "The search section  not displayed with Rule Instance name", AppConstants.vFail);		
//fail=fail+1;
  }	

String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_SEGMENT_TYPE_ID);
String msg2=driver.findElement(By.xpath(xpathExpression2)).getText();

if(msg2.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_SEGMENT_TYPE_NAME)) {

generateXML.logVP("93.2", "Verify  Rule Manage Scope search screen-Search section :Segment Type",	"The search section  displayed with Segment Type", AppConstants.vPass);
//pass=pass+1;
} else {
generateXML.logVP("93.2", "Verify  Rule Manage Scope search screen-Search section :Segment Type",	 "The search section not displayed with Segment Type", AppConstants.vFail);		
//fail=fail+1;
  }	
	

String xpathExpression3 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_SEGMENT_NAME_ID);
String msg3=driver.findElement(By.xpath(xpathExpression3)).getText();

if(msg3.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_SEGMENT_NAME_NAME)) {

generateXML.logVP("93.3", "Verify  Rule Manage Scope search screen-Search section :Segment Name",	"The search section  displayed with Segment Name", AppConstants.vPass);
//pass=pass+1;
} else {
generateXML.logVP("93.3", "Verify  Rule Manage Scope search screen-Search section :Segment Name",	 "The search section not displayed with Segment Name", AppConstants.vFail);		
//fail=fail+1;
  }	

String xpathExpression4 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_CHANNEL_ID);
String msg4=driver.findElement(By.xpath(xpathExpression4)).getText();

if(msg4.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_CHANNEL_NAME)) {

generateXML.logVP("93.4", "Verify  Rule Manage Scope search screen-Search section :Channel",	"The search section  displayed with Channel", AppConstants.vPass);
//pass=pass+1;
} else {
generateXML.logVP("93.4", "Verify  Rule Manage Scope search screen-Search section :Channel",	 "The search section not displayed with Channel", AppConstants.vFail);		
//fail=fail+1;
  }	

String xpathExpression5 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_USERS_ID);
String msg5=driver.findElement(By.xpath(xpathExpression5)).getText();

if(msg5.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_USERS_NAME)) {

generateXML.logVP("93.5", "Verify  Rule Manage Scope search screen-Search section :Users",	"The search section  displayed with Users", AppConstants.vPass);
//pass=pass+1;
} else {
generateXML.logVP("93.5", "Verify  Rule Manage Scope search screen-Search section :Users",	 "The search section not displayed with Users", AppConstants.vFail);		
//fail=fail+1;
  }	
String xpathExpression6 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_MH_ID);
String msg6=driver.findElement(By.xpath(xpathExpression6)).getText();

if(msg6.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_MH_NAME)) {

generateXML.logVP("93.6", "Verify  Rule Manage Scope search screen-Search section :Merchandise Hierarchy",	"The search section  displayed with Merchandise Hierarchy", AppConstants.vPass);
//pass=pass+1;
} else {
generateXML.logVP("93.6", "Verify  Rule Manage Scope search screen-Search section :Merchandise Hierarchy",	 "The search section not displayed with Merchandise Hierarchy", AppConstants.vFail);		
//fail=fail+1;
  }	



//if(msg7.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_NAME)) {
//
//generateXML.logVP("93.7", "Verify  Rule Manage Scope search screen-Search section :'GO' button",	"The search section  displayed with 'GO' button", AppConstants.vPass);
////pass=pass+1;
//} else {
//generateXML.logVP("93.7", "Verify  Rule Manage Scope search screen-Search section :'GO' button",	 "The search section not displayed with 'GO' button", AppConstants.vFail);		
////fail=fail+1;
//  }	


}

@Test
public void test_100() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
driver.findElement(By.xpath(xpathExpression1)).clear();
//driver.findElement(By.xpath(xpathExpression1)).sendKeys("aas");


String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
driver.findElement(By.xpath(xpathExpression7)).click();

Thread.sleep(1000);
String xpathExpression2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_ID);
driver.findElement(By.xpath(xpathExpression2)).click();

Thread.sleep(1000);

String xpathExpression2_1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_HYPERLINK_RESULT_ID);
String msg7=driver.findElement(By.xpath(xpathExpression2_1)).getText();

if(msg7.equals(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_HYPERLINK_RESULT_NAME)) {
	
	generateXML.logVP("94.1", "verify Rule instance name is an hyperlink in the search results grid",	"Rule instance name is an hyperlink and upon clicking it's navigate to respective Rule instance screen", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("94.1", "verify Rule instance name is an hyperlink in the search results grid",	 "Rule instance name is not an hyperlink and upon clicking it's navigate to respective Rule instance screen", AppConstants.vFail);		
	//fail=fail+1;
	  }	


}

@Test
public void test_101() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
driver.findElement(By.xpath(xpathExpression1)).clear();
//driver.findElement(By.xpath(xpathExpression1)).sendKeys("aas");


String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
driver.findElement(By.xpath(xpathExpression7)).click();

Thread.sleep(1000);


String xpathExpression2_1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_SHOWING_ID);
String msg7=driver.findElement(By.xpath(xpathExpression2_1)).getText();

if(msg7.contains(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_SHOWING_NAME)) {
	
	generateXML.logVP("95.1", "Verify whether the tex t saying 'showing  n/n records ' is displayed at the bottom of the screen",	"The text saying 'showing  n/n records ' displayed the bottom of the screen", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("95.1", "Verify whether the tex t saying 'showing  n/n records ' is displayed at the bottom of the screen",	 "The text saying 'showing  n/n records ' not displayed the bottom of the screen", AppConstants.vFail);		
	//fail=fail+1;
	  }	


}

@Test
public void test_102() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
driver.findElement(By.xpath(xpathExpression1)).clear();
//driver.findElement(By.xpath(xpathExpression1)).sendKeys("aas");


String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
driver.findElement(By.xpath(xpathExpression7)).click();

Thread.sleep(1000);


String xpathExpression2_1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_SHOWING_DROP_ID);
String msg7=driver.findElement(By.xpath(xpathExpression2_1)).getText();

if(msg7.contains(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_SHOWING_DROP_NAME)) {
	
	generateXML.logVP("96.1", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the bottom of the page",	"The ' no of rows per page' drop down  available for the user to set and view results at the bottom of the page ", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("96.1", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the bottom of the page ","The ' no of rows per page' drop down is not available for the user to set and view results at the bottom of the page", AppConstants.vFail);		
	//fail=fail+1;
	  }	


}

@Test
public void test_103() throws Exception {	
	
	//wait for 4 secs
	Thread.sleep(2000);
	
	
String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
	driver.findElement(By.xpath(xpathExpression1_0)).click();
	

String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
driver.findElement(By.xpath(xpathExpression1)).clear();
//driver.findElement(By.xpath(xpathExpression1)).sendKeys("aas");


String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
driver.findElement(By.xpath(xpathExpression7)).click();

Thread.sleep(1000);


String xpathExpression2_1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_PREV_ID);
String msg7=driver.findElement(By.xpath(xpathExpression2_1)).getText();

if(msg7.contains(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_PREV_NAME)) {
	
	generateXML.logVP("97.1", "verify Pagination-Prev button",	"The pagination  'prev ' button   displayed as in wireframe", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("97.1", "verify Pagination-Prev  button","The pagination  'prev ' button  not displayed as in wireframe", AppConstants.vFail);		
	//fail=fail+1;
	  }	
String xpathExpression2_2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_NEXT_ID);
String msg7_1=driver.findElement(By.xpath(xpathExpression2_2)).getText();

if(msg7_1.contains(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_NEXT_NAME)) {
	
	generateXML.logVP("97.2", "verify Pagination-next button",	"The pagination  'next'  button   displayed as in wireframe", AppConstants.vPass);
	//pass=pass+1;
} else {
	generateXML.logVP("97.2", "verify Pagination- next button","The pagination   'next'  button  not displayed as in wireframe", AppConstants.vFail);		
	//fail=fail+1;
	  }	

}

@Test
public void test_104() throws Exception {	
	
	//wait for 4 secs
		Thread.sleep(2000);
		
		
	String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1_0)).click();
		

	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
	driver.findElement(By.xpath(xpathExpression1)).clear();
	//driver.findElement(By.xpath(xpathExpression1)).sendKeys("aas");


	String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
	driver.findElement(By.xpath(xpathExpression7)).click();

	Thread.sleep(1000);


	String xpathExpression2_1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_PREV_ID);
	boolean msg7=driver.findElement(By.xpath(xpathExpression2_1)).isEnabled();

	if(msg7==false) {
		
		generateXML.logVP("98.1", "verify Pagination-Prev button clicking on it",	"The pagination  'prev ' button disabled and upon clicking 'prev' button ,system  not performing any action", AppConstants.vPass);
		//pass=pass+1;
	} else {
		generateXML.logVP("98.1", "verify Pagination-Prev button clicking on it ","The pagination  'prev ' button not disabled  ", AppConstants.vFail);		
		//fail=fail+1;
		  }	
	

}

@Test
public void test_105() throws Exception {	
	
	//wait for 4 secs
		Thread.sleep(2000);
		
		
	String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1_0)).click();
		

	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
	driver.findElement(By.xpath(xpathExpression1)).clear();
	//driver.findElement(By.xpath(xpathExpression1)).sendKeys("aas");


	String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
	driver.findElement(By.xpath(xpathExpression7)).click();

	Thread.sleep(1000);


	
	String xpathExpression2_2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_SUCC_NEXT_ID);
	boolean msg7_1=driver.findElement(By.xpath(xpathExpression2_2)).isEnabled();

	if(msg7_1==false) {
		
		generateXML.logVP("99.1", "verify Pagination-next button clicking on it",	"The pagination  'next ' button  disabled and upon clicking 'next ' button ,system  not performing any action", AppConstants.vPass);
		//pass=pass+1;
	} else {
		generateXML.logVP("99.1", "verify Pagination-next button clicking on it",   "The pagination  'next ' button not disabled", AppConstants.vFail);		
		//fail=fail+1;
		  }	

}

@Test
public void test_106() throws Exception {	
	
	//wait for 4 secs
		Thread.sleep(2000);
		
		
	String xpathExpression1_0 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_ID);
		driver.findElement(By.xpath(xpathExpression1_0)).click();
		

	String xpathExpression1 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_RULE_INSTANCE_NAME_TB_ID);
	driver.findElement(By.xpath(xpathExpression1)).clear();
	//driver.findElement(By.xpath(xpathExpression1)).sendKeys("aas");


	String xpathExpression7 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_ID);
	driver.findElement(By.xpath(xpathExpression7)).click();

	Thread.sleep(1000);


	
	String xpathExpression2_2 = excelRW.readProps(pageName, RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_PAGINATION_ID);
	String msg7_1=driver.findElement(By.xpath(xpathExpression2_2)).getText();

	if(msg7_1.contains(RuleConstants.RULE_SCOPE_SEARCH_RULE_INSTANCE_GO_BTN_PAGINATION_NAME)) {
		
		generateXML.logVP("100.1", "verify Pagination text",	"The pagination  text saying '1 of n' ' displayed", AppConstants.vPass);
		//pass=pass+1;
	} else {
		generateXML.logVP("100.1", "verify Pagination text",   "The pagination  text saying '1 of n' ' not displayed", AppConstants.vFail);		
		//fail=fail+1;
		  }	

}

	
	/**
	 * After executing each test method, this method
	 * is called
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {

	}

	/**
	 * This method is invoked after all test methods in Data.java
	 * are executed
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */
	@AfterClass
	public static void tearDownAfterClass() throws TransformerConfigurationException, TransformerException {		

		//notRun = 	 Integer.parseInt(propsRW_rules.read(AppConstants.TOTAL_VERIFICATION_POINTS).trim())-pass-fail;
		AppConstants.notRunCount =       Integer.parseInt(propsRW_rules.read(AppConstants.TOTAL_VERIFICATION_POINTS).trim())-AppConstants.passCount-AppConstants.failCount;                   

		//log header report counts in XML file
		generateXML.logHeaderReportCounts();
		//Generate html report using xml created in test method
		//Report should be according to test case name, ex: data.html
		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH+AppConstants.DETAILED_REPORT_XSL;
		String outputHTML = AppConstants.DETAIL_REPORT_FOLDER+AppConstants.FORWARD_SLASH+RuleConstants.RULES+AppConstants.DOT_HTML;
		generateReport.generateHTML(AppConstants.XML_FILE_PATH, inputXSL, outputHTML);

		System.out.println("Successfully generated the report");

		//log script in summary report xml file
		generateXML.logScript(RuleConstants.RULES_SCRIPT_NAME, outputHTML);

		//Reset xml & properties files path to ""	
		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;
		
		// displaying values
		System.out.println("passcount----"+AppConstants.passCount);
		System.out.println("failcount-----"+AppConstants.failCount);
		
		//Set pass, fail and notrun count to zero
        AppConstants.passCount= 0;
        AppConstants.failCount = 0;
        AppConstants.notRunCount = 0;


		//Close the browser
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	
	}





}
