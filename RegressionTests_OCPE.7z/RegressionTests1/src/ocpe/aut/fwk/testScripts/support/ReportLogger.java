/**
 * 
 */
package ocpe.aut.fwk.testScripts.support;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.PropertiesUtil;

/**
 * @author arindam_r
 * 
 */
public class ReportLogger {

	public static void logTestEndResults(GenerateXml xmlWriter,
			PropertiesUtil detailsReader, String htmlFile, String scriptName) {
		AppConstants.notRunCount = Integer.parseInt(detailsReader.read(
				AppConstants.TOTAL_VERIFICATION_POINTS).trim())
				- AppConstants.passCount - AppConstants.failCount;

		// log header report counts in XML file
		xmlWriter.logHeaderReportCounts();

		// Generate html report using xml created in test method
		// Report should be according to test case name, ex: login.html
		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH
				+ AppConstants.DETAILED_REPORT_XSL;
		String outputHTML = AppConstants.DETAIL_REPORT_FOLDER
				+ AppConstants.FORWARD_SLASH + htmlFile + AppConstants.DOT_HTML;
		try {
			new GenerateHTML().generateHTML(AppConstants.XML_FILE_PATH,
					inputXSL, outputHTML);
		} catch (TransformerConfigurationException e) {
			throw new RuntimeException(e);
		} catch (TransformerException e) {
			throw new RuntimeException(e);
		}

		System.out.println("Successfully generated the report");

		// log script in summary report xml file
		xmlWriter.logScript(scriptName, outputHTML);

		// Reset xml & properties files path to ""
		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;

		// Set pass, fail and notrun count to zero
		AppConstants.passCount = 0;
		AppConstants.failCount = 0;
		AppConstants.notRunCount = 0;
	}
}
