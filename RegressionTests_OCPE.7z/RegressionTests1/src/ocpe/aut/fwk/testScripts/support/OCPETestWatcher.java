/**
 * 
 */
package ocpe.aut.fwk.testScripts.support;

import static ocpe.aut.fwk.constants.AppConstants.vFail;
import static ocpe.aut.fwk.constants.AppConstants.vPass;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.junit.rules.TestWatcher;
import org.junit.runner.Description;

/**
 * @author arindam_r
 * 
 */
public class OCPETestWatcher extends TestWatcher {

	private class VPIdNamePair {
		String id, name;
	}

	private GenerateXml xmlWriter;
	private PropertiesUtil passReader, failReader, detailsReader;

	public OCPETestWatcher(GenerateXml xmlWriter, PropertiesUtil detailsReader,
			String passProperties, String failProperties) {
		this.xmlWriter = xmlWriter;
		this.detailsReader = detailsReader;
		passReader = new PropertiesUtil(passProperties);
		failReader = new PropertiesUtil(failProperties);
	}

	@Override
	protected void failed(Throwable e, Description description) {
		System.out.println("failed: " + description.getMethodName());
		VPIdNamePair idNamePair = getTestDetails(description.getMethodName());
		String vpResult = failReader.read(idNamePair.id);
		logVP(idNamePair.id, idNamePair.name, vpResult, vFail);
	}

	private VPIdNamePair getTestDetails(String methodName) {
		String testDetails = detailsReader.read(methodName);
		String[] pair = testDetails.split("\\|");
		VPIdNamePair idNamePair = new VPIdNamePair();
		idNamePair.id = pair[0];
		idNamePair.name = pair[1];
		return idNamePair;
	}

	private void logVP(String testCaseId, String vpName, String vpResult,
			String status) {
		xmlWriter.logVP(testCaseId, vpName, vpResult, status);
	}

	@Override
	protected void succeeded(Description description) {
		System.out.println("succeeded: " + description.getMethodName());
		VPIdNamePair idNamePair = getTestDetails(description.getMethodName());
		System.out.println("idNamePair.id" + idNamePair.id);
		String vpResult = passReader.read(idNamePair.id);
		logVP(idNamePair.id, idNamePair.name, vpResult, vPass);
	}

}
