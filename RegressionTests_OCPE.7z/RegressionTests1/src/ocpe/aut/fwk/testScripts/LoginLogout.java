/**
 * 
 */
package ocpe.aut.fwk.testScripts;

import static ocpe.aut.fwk.constants.AppConstants.EMPTY_STRING;
import static ocpe.aut.fwk.constants.AppConstants.FP_EMAIL;
import static ocpe.aut.fwk.constants.AppConstants.FP_FIRST_NAME;
import static ocpe.aut.fwk.constants.AppConstants.FP_LAST_NAME;
import static ocpe.aut.fwk.constants.AppConstants.FP_MSG_CAPTCHA_FAIL;
import static ocpe.aut.fwk.constants.AppConstants.FP_MSG_MANDATORY;
import static ocpe.aut.fwk.constants.AppConstants.INVALID_CREDENTIALS_MSG;
import static ocpe.aut.fwk.constants.AppConstants.INVALID_PASSWORD;
import static ocpe.aut.fwk.constants.AppConstants.INVALID_USERNAME;
import static ocpe.aut.fwk.constants.AppConstants.LOGIN;
import static ocpe.aut.fwk.constants.AppConstants.LOGIN_FAIL_PROPERTIES;
import static ocpe.aut.fwk.constants.AppConstants.LOGIN_PASS_PROPERTIES;
import static ocpe.aut.fwk.constants.AppConstants.LOGIN_PROPERTIES;
import static ocpe.aut.fwk.constants.AppConstants.LOGIN_SCRIPT_NAME;
import static ocpe.aut.fwk.constants.AppConstants.NON_ALPHA_USERNAME;
import static ocpe.aut.fwk.constants.AppConstants.VALID_PASSWORD;
import static ocpe.aut.fwk.constants.AppConstants.VALID_USERNAME;
import static ocpe.aut.fwk.constants.AppConstants.WELCOME_MSG;
import static ocpe.aut.fwk.testScripts.support.ReportLogger.logTestEndResults;
import static org.junit.Assert.assertTrue;
import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.pages.HomePage;
import ocpe.aut.fwk.pages.LoginPage;
import ocpe.aut.fwk.pages.LoginPage.ErrorMessageDiv;
import ocpe.aut.fwk.pages.LoginPage.ForgotPasswordDiv;
import ocpe.aut.fwk.pages.LoginPage.ForgotPasswordDiv.FPErrorMessageDiv;
import ocpe.aut.fwk.testScripts.support.OCPETestWatcher;
import ocpe.aut.fwk.util.DriverFactory;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

/**
 * @author arindam_r
 * 
 */
public class LoginLogout {

	private static final int LOGIN_ATTEMPTS_BEFORE_CAPTCHA = 3;

	private static WebDriver driver;

	private static PropertiesUtil propsRW;

	private static LoginPage loginPage;

	private static GenerateXml xmlWriter;

	@Rule
	public OCPETestWatcher ocpeTestWatcher;

	public LoginLogout() {
		ocpeTestWatcher = new OCPETestWatcher(xmlWriter, propsRW,
				LOGIN_PASS_PROPERTIES, LOGIN_FAIL_PROPERTIES);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		driver = DriverFactory.FIREFOX.get();

		loginPage = new LoginPage(driver);

		// Change the xml file path according to name of the script
		AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER
				+ AppConstants.FORWARD_SLASH + AppConstants.LOGIN
				+ AppConstants.DOT_XML;
		
		xmlWriter = new GenerateXml();
		xmlWriter.createVPXML(LOGIN_SCRIPT_NAME);
		propsRW = new PropertiesUtil(LOGIN_PROPERTIES);
		
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.LOGIN_PROPERTIES;
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		logTestEndResults(xmlWriter, propsRW, LOGIN, LOGIN_SCRIPT_NAME);
		driver.quit();
	}

	@Before
	public void setUp() {
		loginPage = loginPage.get();
	}

	@Test
	public void test_2() throws InterruptedException {
		ErrorMessageDiv errorMessageDiv = loginPage
				.typeUserName(propsRW.read(INVALID_USERNAME))
				.typePassword(propsRW.read(INVALID_PASSWORD))
				.loginExpectingFailure();
		assertTrue(errorMessageDiv.readErrorMessage().equals(
				propsRW.read(INVALID_CREDENTIALS_MSG)));
		loginPage = errorMessageDiv.clickOKButton();
	}

	@Test
	public void test_3() {
		ErrorMessageDiv errorMessageDiv = loginPage
				.typeUserName(propsRW.read(VALID_USERNAME))
				.typePassword(propsRW.read(INVALID_PASSWORD))
				.loginExpectingFailure();
		assertTrue(errorMessageDiv.readErrorMessage().equals(
				propsRW.read(INVALID_CREDENTIALS_MSG)));
		loginPage = errorMessageDiv.clickOKButton();
	}

	@Test
	public void test_4() throws InterruptedException {
		loginPage = loginPage.typeUserName(EMPTY_STRING)
				.typePassword(EMPTY_STRING).loginVerficationFailure();
	}

	@Test
	public void test_5() {
		ErrorMessageDiv errorMessageDiv = loginPage
				.typeUserName(propsRW.read(INVALID_USERNAME))
				.typePassword(propsRW.read(VALID_PASSWORD))
				.loginExpectingFailure();
		assertTrue(errorMessageDiv.readErrorMessage().equals(
				propsRW.read(INVALID_CREDENTIALS_MSG)));
		loginPage = errorMessageDiv.clickOKButton();
	}

	@Test
	public void test_6() throws InterruptedException {
		for (int i = 0; i < LOGIN_ATTEMPTS_BEFORE_CAPTCHA; i++) {
			ErrorMessageDiv errorMessageDiv = loginPage
					.typeUserName(propsRW.read(VALID_USERNAME))
					.typePassword(propsRW.read(INVALID_PASSWORD))
					.loginExpectingFailure();
			loginPage = errorMessageDiv.clickOKButton();
		}
		assertTrue(loginPage.captchaAppeared());
	}

	@Test
	public void test_9_10() {
		HomePage homePage = loginPage
				.typeUserName(propsRW.read(VALID_USERNAME))
				.typePassword(propsRW.read(VALID_PASSWORD))
				.loginExpectingSuccess();
		assertTrue(homePage.readWelcomeMessage().contains(
				propsRW.read(WELCOME_MSG)));
		assertTrue(homePage.readWelcomeMessage().contains(
				propsRW.read(VALID_USERNAME)));
	}

	@Test
	public void test_11_12() {
		loginPage = loginPage.typeUserName(propsRW.read(NON_ALPHA_USERNAME))
				.typePassword(propsRW.read(VALID_PASSWORD))
				.loginVerficationFailure();
	}

	@Test
	public void test_15_16() {
		ForgotPasswordDiv forgotPasswordDiv = loginPage.forgotPassword();
		assertTrue(forgotPasswordDiv.elementsInitialized());
	}

	@Test
	public void test_17() throws InterruptedException {
		ForgotPasswordDiv forgotPasswordDiv = loginPage.forgotPassword();
		FPErrorMessageDiv errorMessageDiv = forgotPasswordDiv.typeFirstName(
				EMPTY_STRING).clickSubmitButton();
		assertTrue(errorMessageDiv.readErrorMessage().contains(
				propsRW.read(FP_MSG_MANDATORY)));
	}

	@Test
	public void test_18() throws InterruptedException {
		ForgotPasswordDiv forgotPasswordDiv = loginPage.forgotPassword();
		FPErrorMessageDiv errorMessageDiv = forgotPasswordDiv
				.typeFirstName(propsRW.read(FP_FIRST_NAME))
				.typeLastName(EMPTY_STRING).clickSubmitButton();
		assertTrue(errorMessageDiv.readErrorMessage().contains(
				propsRW.read(FP_MSG_MANDATORY)));
	}

	@Test
	public void test_19() {
		ForgotPasswordDiv forgotPasswordDiv = loginPage.forgotPassword();
		FPErrorMessageDiv errorMessageDiv = forgotPasswordDiv
				.typeFirstName(propsRW.read(FP_FIRST_NAME))
				.typeLastName(propsRW.read(FP_LAST_NAME))
				.typeEmail(EMPTY_STRING).clickSubmitButton();
		assertTrue(errorMessageDiv.readErrorMessage().contains(
				propsRW.read(FP_MSG_MANDATORY)));
	}

	@Test
	public void test_20_21() {
		ForgotPasswordDiv forgotPasswordDiv = loginPage.forgotPassword();
		FPErrorMessageDiv errorMessageDiv = forgotPasswordDiv
				.typeFirstName(propsRW.read(FP_FIRST_NAME))
				.typeLastName(propsRW.read(FP_LAST_NAME))
				.typeEmail(propsRW.read(FP_EMAIL)).typeCaptcha(EMPTY_STRING)
				.clickSubmitButton();
		assertTrue(errorMessageDiv.readErrorMessage().contains(
				propsRW.read(FP_MSG_CAPTCHA_FAIL)));
	}

	@Test
	public void test_24() {
		ForgotPasswordDiv forgotPasswordDiv = loginPage.forgotPassword();
		loginPage = forgotPasswordDiv.clickCancelButton();
	}

}
