package ocpe.aut.fwk.testScripts;

import static org.junit.Assert.fail;

import java.awt.image.TileObserver;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.TimeUnit;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.constants.CatalogConstants;
import ocpe.aut.fwk.util.CommonUtil;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.HBaseUtil;
import ocpe.aut.fwk.util.PropertiesUtil;
import ocpe.aut.fwk.util.RatingComparator;

import org.apache.zookeeper.proto.SetWatches;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.thoughtworks.selenium.Wait;

/** @author nagasuryateja_m */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Catalog {

	private static StringBuffer verificationErrors = new StringBuffer();

	private static WebDriver driver;
	static DesiredCapabilities cap = null; static FirefoxBinary ffBinary = null; static FirefoxProfile ffprofile = null;

	private static GenerateXml generateXML;
	private static GenerateHTML generateReport;

	static int pass= 0,fail = 0, notRun = 0;

	private static PropertiesUtil propsRW;
	private static ExcelUtil excelRW;
	private static String pageName;
	private static HBaseUtil hbaseUtil;
	private static CommonUtil commonUtil;

	/**
	 * One time set up for Catalog.java
	 */
	@BeforeClass
	public static void oneTimeSetUp() {
		// one-time initialization code   
		System.out.println("@BeforeClass - oneTimeSetUp");
		File  pathToFirefoxBinary = new File(AppConstants.PATH_TO_FIREFOX_BINARY);
		ffBinary = new FirefoxBinary(pathToFirefoxBinary);
		ProfilesIni profile = new ProfilesIni();		   		   
		ffprofile = profile.getProfile(AppConstants.FIREFOX_PROFILE_DEFAULT);
		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();		  		  
		proxy.setProxyAutoconfigUrl(AppConstants.PROXY_URL);	
		cap = new DesiredCapabilities();		  
		cap.setCapability(CapabilityType.PROXY, proxy);				

		//driver = new FirefoxDriver(ffBinary,ffprofile,cap);		
		driver = new FirefoxDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(AppConstants.BASE_URL + AppConstants.LOGIN_URL);

		generateXML = new GenerateXml();		
		generateReport = new GenerateHTML();		
		excelRW = new ExcelUtil(); 
		hbaseUtil= new HBaseUtil();
		commonUtil=new CommonUtil();
		
		//Change the xml file path according to name of the script
		AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER+AppConstants.FORWARD_SLASH+CatalogConstants.CATALOG+AppConstants.DOT_XML;
		AppConstants.PROPERTIES_FILE_PATH = CatalogConstants.CATALOG_PROPERTIES;		

		//Sheet Name of excel from where the xpath values are fetched
		pageName = CatalogConstants.CATALOG_TAB;

		//Create a new XML file
		generateXML.createVPXML(CatalogConstants.CATALOG_SCRIPT_NAME);

		//Login
		/*Firefox browser gets opened with OCPE Login page, provide 
		 * with username rg@gmail.com and click on submit button.
		 * After login, catalog tab selected with it's first side menu highlighted */

		/*Clear the User Name textbox*/
		String xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.USER_NAME);
		driver.findElement(By.xpath(xpathExpression)).clear();

		propsRW = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);

		/* Get valid username from properties file
		 * ex: rg@gmail.com*/
		String userName = propsRW.read(AppConstants.VALID_USERNAME).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(userName);


		/* Clear the Password textbox*/
		xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.PASSWORD);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid password from properties file
		 * ex: Aham123+*/
		String password = propsRW.read(AppConstants.VALID_PASSWORD).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(password);


		/*Click on login button*/
		xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.LOGIN_SUBMIT);		
		driver.findElement(By.xpath(xpathExpression)).click();

	}
	
	/**
	 * This method is used to verify if user is able to navigate to catalog tab after login
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_A_1() throws InterruptedException
	{
		
		
			////verify if user is able to navigate to catalog tab
			
			String winHandleBefore = driver.getWindowHandle();
			driver.findElement(By.linkText(CatalogConstants.CATALOG_TAB_NAME)).click();
			String xpathExpression = excelRW.readProps(pageName, CatalogConstants.TAB_CATALOG);
			String selectedTab  = driver.findElement(By.xpath(xpathExpression)).getText();
			System.out.println("before test");
			System.out.println(driver.getWindowHandle());
		 
			for(String s:driver.getWindowHandles())
			{
			 driver.switchTo().window(s);
			}

			if(selectedTab.equals(CatalogConstants.CATALOG_TAB_NAME) ) 
			{
			generateXML.logVP("1", "Check if user is able to navigate to catalog tab after login",	"user logs in successfully and navigates to catalog tab", AppConstants.vPass);				
			pass++;
			} 
			else 
			{
			generateXML.logVP("1", "Check if user is able to navigate to catalog tab after login",	 "user logs in successfully and unable to navigates to catalog tab", AppConstants.vFail);		
			fail++;
			}		
		
	}
	
	/**
	 * This method is used to verify the UI of catalog tab
	 * Test method
	 * @throws Exception
	
	 */
	
	@Test
	public void test_A_2() throws InterruptedException
	{
		
		

			propsRW = new PropertiesUtil(CatalogConstants.CATALOG_PROPERTIES);

		
			//verify search section is available or not
		
			String xpathExpression = excelRW.readProps(pageName, CatalogConstants.SEARCHSECTION_TITLE);
			String title= driver.findElement(By.xpath(xpathExpression)).getText();
		
			if(title.equalsIgnoreCase(propsRW.read(CatalogConstants.TITLE)))
			{
			generateXML.logVP("2.1", "Check if search section exists with title 'Search Product' title",	"search section exists with title 'Search Product' title", AppConstants.vPass);				
			pass++;
			}
			else
			{
			generateXML.logVP("2.1", "Check if search section exists with title 'Search Product' title",	"search section doesnot exist with title 'Search Product' title", AppConstants.vFail);				
			fail++;
			}
	
			//verify if productOverview section is highlighted or not
		
			String xpathExpression1 = excelRW.readProps(pageName, CatalogConstants.MENU_DEFAULT);
			String selectedMenu  = driver.findElement(By.xpath(xpathExpression1)).getText();

			if(selectedMenu.equals(propsRW.read(CatalogConstants.LEFTMENUITEM_1)) ) 
			{
			generateXML.logVP("2.2", "verify if product overview left menu is highlighted by default or not",	"product overview left menu is highlighted by default", AppConstants.vPass);				
			pass++;
			} 
			else 
			{
			generateXML.logVP("2.2", "verify if product overview left menu is highlighted by default or not",	"product overview left menu is not highlighted by default", AppConstants.vFail);		
			fail++;
			}
		
	
			//verify left menu items
		
			String leftMenuItem1= driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.LEFTMENUITEM_1))).getText();
			String leftMenuItem2= driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.LEFTMENUITEM_2))).getText();
			String leftMenuItem3= driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.LEFTMENUITEM_3))).getText();
		
			if(leftMenuItem1.equalsIgnoreCase(propsRW.read(CatalogConstants.LEFTMENUITEM_1)) && leftMenuItem2.equalsIgnoreCase(propsRW.read(CatalogConstants.LEFTMENUITEM_2))
				&& leftMenuItem3.equalsIgnoreCase(propsRW.read(CatalogConstants.LEFTMENUITEM_3)))
			{
			
			generateXML.logVP("2.3", "verify if left menu items",	"leftmenu contains product overview,product analytics ,product recommendations items", AppConstants.vPass);				
			pass++;
			}
	
			else
			{
			generateXML.logVP("2.3", "verify if left menu items",	"leftmenu does not contains product overview,product analytics ,product recommendations items", AppConstants.vFail);				
			fail++;
			}
	
	
			//verify if left menu items are hyper links
	
			String tagName1=driver.findElement(By.name((CatalogConstants.PRODUCTOVERVIEW))).getTagName();
			String tagName2=driver.findElement(By.name((CatalogConstants.PRODUCTANALYTICS))).getTagName();
			String tagName3=driver.findElement(By.name((CatalogConstants.PRODUCTRECOMMENDATIONS))).getTagName();
		
			if(tagName1.equalsIgnoreCase(CatalogConstants.ANCHOR_TAG) && tagName2.equalsIgnoreCase(CatalogConstants.ANCHOR_TAG) && tagName3.equalsIgnoreCase(CatalogConstants.ANCHOR_TAG))
			{
			generateXML.logVP("2.4", "verify if left menu items are hyperlinks",	"leftmenu items are hyperlinks", AppConstants.vPass);				
			pass++;
			}
			else
			{
			generateXML.logVP("2.4", "verify if left menu items are hyperlinks",	"leftmenu items are not hyperlinks", AppConstants.vFail);				
			fail++;
			}
		
		
			//verify if orange color slide is shown on click of the left menu items
		
			List<WebElement> elements=driver.findElements((By.xpath(excelRW.readProps(pageName, CatalogConstants.SLIDECOLOR))));
			int count=0;
		
			for(int i=0;i<elements.size();i++)
			{
				elements.get(i).click();
				String classArray[]=elements.get(i).getAttribute("class").split(" ");
				for(String classElement:classArray)
				if(classElement.equalsIgnoreCase(CatalogConstants.SLIDECOLORCLASS))
				{
				count++;
				}
	    	if(count==3)
	    		break;
			}
		
	
			if(count==3)
			{
			generateXML.logVP("2.5", " verify if on click leftmenu items are highlighted in grey with an orange slide next to it",	"on click left menu items are highlighted in grey with an orange slide next to it", AppConstants.vPass);				
			pass++;
			}
		
			else
			{
			generateXML.logVP("2.5", " verify if on click leftmenu items are highlighted in grey with an orange slide next to it",	"on click left menu items are not highlighted in grey with an orange slide next to it", AppConstants.vFail);				
			fail++;
			}
		
	
	}
	/**
	 * This method is used to verify the UI of search Section
	 * Test method
	 * @throws Exception
	
	 */
	
	@Test
	public void test_A_3() throws InterruptedException
	{
		
		//verify search section title
			driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.LEFTMENUITEM_1))).click();
		
			String xpathExpression = excelRW.readProps(pageName, CatalogConstants.SEARCHSECTION_TITLE);
		
			String title= driver.findElement(By.xpath(xpathExpression)).getText();
		
			if(title.equalsIgnoreCase(propsRW.read(CatalogConstants.TITLE)))
			{
			generateXML.logVP("3.1", "Check if search section exists with title 'Search Product' title",	"search section exists with title 'Search Product' title", AppConstants.vPass);				
			pass++;
			}
		
			else
			{
			generateXML.logVP("3.1", "Check if search section exists with title 'Search Product' title",	"search section doesnot exist with title 'Search Product' title", AppConstants.vFail);				
			fail++;
			}
		
		//verify search section elements
		
			try
			{
			Boolean result=false;
			String searchLable=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHLABEL))).getText();
			System.out.println("search lable*********"+searchLable);
			if(searchLable.equalsIgnoreCase(propsRW.read(CatalogConstants.SEARCHLABLETEXT))) //verify label
			{
				result=true;
			}
			
			driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))); //verify texbox
			driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))); //verify go button
			
			if(result==true)
			{
				generateXML.logVP("3.2", "verify search section elements",	"search section consists of productId label,text box and a go button next to it", AppConstants.vPass);				
				pass++;
				
			}
			
			else
			{
				generateXML.logVP("3.2", "verify search section elements",	"search section does not consists of productId label,text box and a go button next to it", AppConstants.vFail);				
				fail++;
			}
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	/**
	 * This method is used to verify search functionality when valid product id is entered
	 * Test method
	 * @throws Exception
	
	 */
	
	@Test
	public void test_A_4() throws InterruptedException
	{
	
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(propsRW.read(CatalogConstants.VALIDPRODUCTID));
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
		
		//verify the title 'product overview'
		
		String productOverviewTitle=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SCREENTITLE))).getText();
		
			if(productOverviewTitle.equalsIgnoreCase(propsRW.read(CatalogConstants.LEFTMENUITEM_1)))
		{
			generateXML.logVP("4", "verify search functionality when valid product id is entered",	"product overview section is displayed with title Product Overview", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("4", "verify search functionality when valid product id is entered",	"product overview section is not displayed with title Product Overview", AppConstants.vFail);				
			fail++;
		}
	
	}
	/**
	 * This method is used to verify text box input.
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_A_5() throws InterruptedException
	{
		
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(CatalogConstants.SPECIALCHARACTER);
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
		
		String errorMessage=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ALERT))).getText();
		
		if(errorMessage.equalsIgnoreCase(propsRW.read(CatalogConstants.ERRORMESSAGE_TEXTBOXINPUT)))
		{
			generateXML.logVP("5", "verify text box input entering special characters other than hyphen(-),underscore(_) and dot(.)",	"'only alphanumeric and . _ - characters are allowed' alert is displayed  ", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("5", "verify text box input entering special characters other than hyphen(-),underscore(_) and dot(.)",	"'only alphanumeric and . _ - characters are allowed' alert is not displayed   ", AppConstants.vFail);				
			fail++;
		}
		
		driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ALERTBUTTON))).click();
	}
	
	/**
	 * This method is used to verify search functionality when valid invalid product id is entered
	 * Test method
	 * @throws Exception
	
	 */
	
	@Test
	public void test_A_6() throws InterruptedException
	{
		
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(propsRW.read(CatalogConstants.INVALIDPRODUCTID));
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
		
		//verify the message
		
		String errorMessage=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ERRORMESSAGE_INVALIDID))).getText();
		
		
		if(errorMessage.equalsIgnoreCase(propsRW.read(CatalogConstants.ERRORMESSAGE_INVALIDID)))
		{
			generateXML.logVP("6", "verify search functionality when invalid product id is entered",	"product not found message is displayed ", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("6", "verify search functionality when invalid product id is entered",	"product not found message is not displayed ", AppConstants.vFail);				
			fail++;
		}
	}
	
	/**
	 * This method is used to verify search functionality when no product id field is left blank
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_A_7() throws InterruptedException
	{
		
		
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(""); //text box left blank
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
		
		//verify if alert is displayed or not
		
		String errorMessage=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ALERT))).getText();
		
		if(errorMessage.equalsIgnoreCase(propsRW.read(CatalogConstants.ERRORMESSAGE_BLANK)))
		{
			generateXML.logVP("7", "verify search functionality when valid product id is left blank",	"alert is displayed with message 'please enter productId' ", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("7", "verify search functionality when valid product id is left blank",	"alert is not displayed ", AppConstants.vFail);				
			fail++;
		}
		
		driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ALERTBUTTON))).click();
	}
	
	
	
	/**
	 * This method is used to verify UI of product overview section.
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_A_8() throws InterruptedException
	{
		
		
		//verify title of product overview section
		
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(propsRW.read(CatalogConstants.VALIDPRODUCTID));
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
		
		String productOverviewTitle=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SCREENTITLE))).getText();
		
		if(productOverviewTitle.equalsIgnoreCase(propsRW.read(CatalogConstants.LEFTMENUITEM_1)))
		{
		generateXML.logVP("8.1", "verify product overview section title",	"product overview section is displayed with title Product Overview", AppConstants.vPass);				
		pass++;
		}
	
		else
		{
		generateXML.logVP("8.1", "verify product overview section title",	"product overview section is not displayed with title Product Overview", AppConstants.vFail);				
		fail++;
		}
		
		//verify lables in product Overview section
		
		List<WebElement> labelsList=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.LABELS)));
		
		String[] labels=propsRW.read(CatalogConstants.LABELS).split(",");
		System.out.println("lables size*********"+labels.length);
		int count =0;
		
		for(WebElement label:labelsList)
		{
			String labelName=label.getText();
			if(labelName.equalsIgnoreCase(labels[0]) || labelName.equalsIgnoreCase(labels[1]) ||labelName.equalsIgnoreCase(labels[2])
					|| labelName.equalsIgnoreCase(labels[3]) || labelName.equalsIgnoreCase(labels[4]) ||labelName.equalsIgnoreCase(labels[5])
					|| labelName.equalsIgnoreCase(labels[6]) || labelName.equalsIgnoreCase(labels[7]) || labelName.equalsIgnoreCase(labels[8])
					|| labelName.equalsIgnoreCase(labels[9]))
			{
				count++;
			}
		}
	
		System.out.println("*************"+count);
	
		if(count==10)
		{
			generateXML.logVP("8.2", "verify labels in product Overview section",	"product overview section is displayed with Name,Product Id,Brand,Vertical,Category,Sub Category,Sales Price (in $),Normalized Price,Age,Gender lablels", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("8.2", "verify labels in product Overview section",	"product overview section is not displayed with Name,Product Id,Brand,Vertical,Category,Sub Category,Sales Price (in $),Normalized Price,Age,Gender lables", AppConstants.vFail);				
			fail++;
		}
	}
	
	/**
	 * This method is used to verify  brand id exists with hyper link for the given product id
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_A_9() throws InterruptedException
	{
		
		
		//verify if brand id hyper link exists
		
		WebElement webElement=driver.findElement(By.id((excelRW.readProps(pageName, CatalogConstants.BRANDID))));
		String brandID=webElement.getText();
		System.out.println("brandid**********"+brandID);
		String anchorTag= webElement.getTagName();
		System.out.println("*******tag"+anchorTag);
		
		if(brandID.equalsIgnoreCase(propsRW.read(CatalogConstants.BRANDID)) && anchorTag.equalsIgnoreCase(CatalogConstants.ANCHOR_TAG))
		{
			System.out.println("true");
			generateXML.logVP("9", "verify if brand id exists with hyperlink next to brand in product overview section for the given product id",	"brand id exists with hyperlink", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("9", "verify if brand id exists with hyperlink next to brand in product overview section for the given product id",	"brand id does not exist with hyperlink", AppConstants.vFail);				
			fail++;
		}
		
		
	}
	
	/**
	 * This method is used to verify the values shown in product overview section 
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_B_1() throws InterruptedException
	{
		
		//verify the product details shown in product overview section
		
			int result=0;
		
		 String name = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.PRODUCT_NAME, CatalogConstants.MAXVERSIONS);
		 System.out.println("name***********"+name);
		 
		 String brand = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.BRAND_NAME, CatalogConstants.MAXVERSIONS);
		 
		 String vertical = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.VERTICAL_NAME, CatalogConstants.MAXVERSIONS);
		 
		 String category = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.CATEGORY_NAME, CatalogConstants.MAXVERSIONS);
		 
		 String subCategory = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.SUB_CATEGORY_NAME, CatalogConstants.MAXVERSIONS);
		 
		 String salesPrice = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.SALE_PRICE, CatalogConstants.MAXVERSIONS);
		 
		 String age = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.AGE, CatalogConstants.MAXVERSIONS);
		 
		 String gender = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.GENDER, CatalogConstants.MAXVERSIONS);
		 
		 String brandCode = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.BRANDCODE, CatalogConstants.MAXVERSIONS);
		
		 String verticalCode = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.VERTICALCODE, CatalogConstants.MAXVERSIONS);
		
		 String categoryCode = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.CATEGORYCODE, CatalogConstants.MAXVERSIONS);
		 
		 String subCategoryCode = hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.SUBCATEGORYCODE, CatalogConstants.MAXVERSIONS);
		 
		 String normPrice=hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.PRODUCTDETAILS, propsRW.read(CatalogConstants.VALIDPRODUCTID), CatalogConstants.NORM_PRICE,CatalogConstants.MAXVERSIONS);
		 
		 float normPriceConv=Float.parseFloat(normPrice);
		 
		 String normPriceCalc="";
		 
		 //norm price calculation
		 
		 if(normPriceConv>=60 && normPriceConv<=100)
		 {
			 normPriceCalc="DAIMOND";
		 }
		
		 else if((normPriceConv>=40 && normPriceConv<=60))
		 {
			 normPriceCalc="PLATINUM";
		 }
		 
		 else if(normPriceConv>=30 && normPriceConv<=40)
		 {
			 normPriceCalc="GOLD";
		 }
		 
		 else if (normPriceConv >=20 && normPriceConv<=30)
		 {
			 normPriceCalc="TOPAZ";
		 }
		 
		 else if (normPriceConv>=10 && normPriceConv<=20)
		 {
			 normPriceCalc="SILVER";
		 }
		 
		 else
		 {
			 normPriceCalc="BRONZE";
		 }

		 float salePriceCalc=Float.parseFloat(salesPrice);
		 List<String> expectedValues=new LinkedList<String>();
		 expectedValues.add(name);
		 expectedValues.add(propsRW.read(CatalogConstants.VALIDPRODUCTID));
		 expectedValues.add(brand+" ("+brandCode+")");
		 expectedValues.add(vertical+"("+verticalCode+")");
		 expectedValues.add(category+" ("+categoryCode+")");
		 expectedValues.add(subCategory+"("+subCategoryCode+")");
		 expectedValues.add(String.valueOf((int)salePriceCalc));
		 expectedValues.add(normPriceCalc);
		 expectedValues.add(age);
		 expectedValues.add(gender);
		 
				 
		 
		 List<WebElement> labelElements = driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.PRODUCTOVERVIEW_VALUES)));
		 
		 List<String> actualValues=new LinkedList<String>();
		 //String text ="";
		 for(WebElement w:labelElements)
		 {
			 actualValues.add(w.getText().trim());
			
		 }
		 System.out.println("actualValues*******"+actualValues.toString());

		 
		 for(int i=0;i<expectedValues.size();i++)
		 {
			 for(int j=0;j<actualValues.size();j++)
			 {
				 if(expectedValues.get(i).equalsIgnoreCase(actualValues.get(j)))
				 {
					 result++;
				 }
			 }
		 }
		
		 if(result==10) //if all values match then count will be 10
		 {
			 generateXML.logVP("10", "verify values displayed in the product overview section",	"values displayed on the console match with the values in the database ", AppConstants.vPass);				
				pass++;
		 }
		 
		 else
		 {
			 generateXML.logVP("10", "verify values displayed in the product overview section",	"values displayed on the console does not match with the values in the database ", AppConstants.vFail);				
				fail++;
		 }
		 

		
	}
	
	
	/**
	 * This method is used to verify  functionality of brand id hyper link
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_B_2() throws InterruptedException
	{
	
		driver.findElement(By.id((excelRW.readProps(pageName, CatalogConstants.BRANDID)))).click();
		
		//verify if user is navigated to product recommendations screen.verify
		//if product recommendations left menu is highlighted in grey or not
		
		String element= driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.LEFTMENUBACKGROUND))).getText();
		
		if(element.equalsIgnoreCase((propsRW.read(CatalogConstants.LEFTMENUITEM_3))))
		{
			
			generateXML.logVP("11.1", "verify if user is navigated to product Recommedations screen by checking if menu item in left menu is highlighted or not",	"user is navigated product Recommedations screen", AppConstants.vPass);				
			pass++;
		} 
		else 
		{
			
			generateXML.logVP("11.1", "verify if user is navigated to product Recommedations screen by checking if menu item in left menu is highlighted or not",	"user is not navigated to product Recommedations screen", AppConstants.vFail);		
			fail++;
		}
		
	
		//verify if brand id is selected from the options drop down and brand id value is shown
		
		WebElement selected=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHLABEL)));
		List<WebElement> list=selected.findElements(By.tagName(excelRW.readProps(pageName, CatalogConstants.DROPDOWNATAG)));
		Boolean result=false;
		for(WebElement labelName:list)
		{
			if(labelName.getText().equalsIgnoreCase(propsRW.read(CatalogConstants.SEARCHLABLE_BRAND)))
			{
						
				if(labelName.getAttribute(excelRW.readProps(pageName, CatalogConstants.DROPDOWNATTRIBUTE)).equalsIgnoreCase(propsRW.read(CatalogConstants.SELECTED)))

				{
					result=true;
				}
					
			}
		}	
			
		if(result==true)
		{
				
		generateXML.logVP("11.2", "verify if brand id lable is shown in the options drop down",	"brand id label is shown", AppConstants.vPass);				
						pass++;
		}
					
		else
		{
		generateXML.logVP("11.2", "verify if brand id lable is shown in the options drop down",	"brand id label is not shown", AppConstants.vFail);				
						fail++;
		}
			
		
		//verify if brand id is shown in the text box
		
		String searchText=driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).getAttribute(CatalogConstants.VALUE);
		System.out.println(searchText);
		if(searchText.equalsIgnoreCase(propsRW.read(CatalogConstants.VALIDBRANDID)))
		{
			generateXML.logVP("11.3", "verify if text box is populated with the brand id",	"brand id is populated in the text box", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("11.3", "verify if text box is populated with the brand id",	"brand id is not populated in the text box", AppConstants.vFail);				
			fail++;
		}
		
		
		//verify if customer id text box is disabled or not
	
		String disabled=driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.CATALOGCUSTOMER))).getAttribute(CatalogConstants.DISABLED);
	
		if(disabled.equalsIgnoreCase(propsRW.read(CatalogConstants.DISABLED)))
		{
		generateXML.logVP("11.4", "verify if customer id text box is disabled or not",	"customer id text box is disabled", AppConstants.vPass);				
		pass++;
		}
	
		else
		{
		generateXML.logVP("11.4", "verify if customer id text box is disabled or not",	"customer id text box is not disabled", AppConstants.vFail);				
		fail++;
		}
	
	}	
	
	/**
	 * This method is used to verify UI of product analytics screen
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_B_3() throws InterruptedException
	{
	
		//verify if product analytics screen is displayed with search section
		try
		{
		driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.LEFTMENUITEM_2))).click();
		driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.LEFTMENUITEM_2))).click();
		
		String xpathExpression = excelRW.readProps(pageName, CatalogConstants.SEARCHSECTION_TITLE);
		
		String title= driver.findElement(By.xpath(xpathExpression)).getText();
		
		if(title.equalsIgnoreCase(propsRW.read(CatalogConstants.TITLE)))
		{
			generateXML.logVP("12.1", "Check if product analytics screen contains search section with title 'Search Product' title",	"search section exists in product analytics screen with title 'Search Product' title", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("12.1", "Check if product analytics screen contains search section with title 'Search Product' title",	"search section does not exist in product analytics screen with title 'Search Product' title", AppConstants.vFail);				
			fail++;
		}
		
		// verifies UI of product Analytics screen
		
		String productAnalyticsTitle=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SCREENTITLE))).getText();
		
		if(productAnalyticsTitle.equalsIgnoreCase(propsRW.read(CatalogConstants.LEFTMENUITEM_2)))
		{
			generateXML.logVP("12.2", "verify Product Analytics section title",	"product Analytics section is displayed with title Product Analytics", AppConstants.vPass);				
			pass++;
		}
	
		else
		{
			generateXML.logVP("12.2", "verify Product Analytics section title",	"product Analytics section is not displayed with title Product Analytics", AppConstants.vFail);				
			fail++;
		}
	
		}
		catch(Exception e)
		{
			generateXML.logVP("12.2", "verify Product Analytics section title",	"product Analytics section is not displayed ", AppConstants.vFail);				
			fail++;
		}
	}
	
	
	/**
	 * This method is used to verify UI of Age pie chart in product analytics screen
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_B_4() throws InterruptedException
	{
	
		//verify age pie chart title and css
		try
		{
		Thread.sleep(1000);
		List<WebElement> titleList=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.PIECHARTTILE)));

		WebElement ageChartTitlecss=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CatalogConstants.CHARTTITLECLASS)));
		
		String fontColor=ageChartTitlecss.getCssValue(excelRW.readProps(pageName, CatalogConstants.CHARTTILECOLOR)); //verify font color
		System.out.println("font color********"+fontColor+"**********");
		
		String fontWeight=ageChartTitlecss.getCssValue(excelRW.readProps(pageName, CatalogConstants.PIECHARTTILEWEIGHT));
		
		Boolean result=false;
		
		for(WebElement title:titleList)
		{
			
			System.out.println("chart text*************"+title.getText());
			if(title.getText().equalsIgnoreCase(propsRW.read(CatalogConstants.AGEPIECHARTTILE)) && fontColor.equalsIgnoreCase(propsRW.read(CatalogConstants.CHARTTILECOLOR)) && fontWeight.equalsIgnoreCase(propsRW.read(CatalogConstants.PIECHARTTILEWEIGHT)))
			{
				result=true;
			}
		}
		
		if(result==true)
		{
			generateXML.logVP("13.1", "verify age pie chart title in bold/black font",	"age pie chart is displayed with title 'Age' in bold/black font", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("13.1", "verify age pie chart title in bold/black font",	"age pie chart is not displayed with title 'Age' in bold/black font", AppConstants.vFail);				
			fail++;
		}
		}
		catch(Exception e)
		{
			generateXML.logVP("13.1", "verify age pie chart title in bold/black font",	"age pie chart section is not displayed with title 'Age' in bold/black font", AppConstants.vFail);				
			fail++;
			
		}
		
		//verify pie chart legend
		
		try
		{
		
		WebElement legend=driver.findElement(By.id(excelRW.readProps(pageName,CatalogConstants.AGEPIECHARTLEGEND)));
		
		List<WebElement> legendElements = ((legend.findElement(By.tagName(CatalogConstants.SVG))).findElements(By.tagName(CatalogConstants.G)));
		List<String> actualList=new LinkedList<String>();
		System.out.println("**************before"+legendElements.size());
		for(WebElement w:legendElements)
		{
			actualList.add(w.getText()); //preparing actual list
			System.out.println("AGE----"+w.getText());
		}
	
		System.out.println(actualList.size()+"***********");
		List<String> expectedList =new LinkedList<String>();
		
		String[] expected=propsRW.read(CatalogConstants.AGELEGENDELEMENTS).split(",");
		
		for(String s:expected)
		{
			expectedList.add(s); //preparing expected list
		}
	
		

		int vpCount=1;
		
		for(int i=0;i<expectedList.size();i++)
		 {
			 
				 if(actualList.contains(expectedList.get(i))) //comparing actual and expected lists
				 {
					 generateXML.logVP("13."+(++vpCount), "verify if age pie chart is displayed with legend of Age group '"+expectedList.get(i)+" '", "age pie chart is displayed with legend of Age group "+expectedList.get(i), AppConstants.vPass);				
						pass++; 
				 }
				 

					else
					{
						generateXML.logVP("13."+(++vpCount), "verify if age pie chart is displayed with legend of Age group '"+expectedList.get(i)+" '",	"age pie chart is not displayed with legend of Age group "+expectedList.get(i), AppConstants.vFail);				
						fail++;
					}
			 }
			
	
		}	
		catch(Exception e)
		{
			generateXML.logVP("13.2", "verify if age pie chart is displayed with legend of Age groups Child /Seniors /Adult /Teenager /Young adult /Toddler",	"legend is not displayed", AppConstants.vFail);				
			fail++;
		}
	}
	
	/**
	 * This method is used to verify UI of gender pie chart in product analytics screen
	 * Test method
	 * @throws Exception
	 */

	@Test
	public void test_B_5() throws InterruptedException
	{
	
		//verify age pie chart title and css
		
		try
		{
		
		List<WebElement> titleList=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.PIECHARTTILE)));

		WebElement ageChartTitlecss=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CatalogConstants.CHARTTITLECLASS)));
		
		String fontColor=ageChartTitlecss.getCssValue(excelRW.readProps(pageName, CatalogConstants.CHARTTILECOLOR)); //verify font color
		System.out.println("font color********"+fontColor+"**********");
		
		String fontWeight=ageChartTitlecss.getCssValue(excelRW.readProps(pageName, CatalogConstants.PIECHARTTILEWEIGHT));
		
		Boolean result=false;
		
		for(WebElement title:titleList)
		{
			if(title.getText().equalsIgnoreCase(propsRW.read(CatalogConstants.GENDERPIECHARTTILE)) && fontColor.equalsIgnoreCase(propsRW.read(CatalogConstants.CHARTTILECOLOR)) && fontWeight.equalsIgnoreCase(propsRW.read(CatalogConstants.PIECHARTTILEWEIGHT)))
			{
				result=true;
			}
		}
		
		if(result==true)
		{
			generateXML.logVP("14.1", "verify gender pie chart title in bold/black font",	"Gender pie chart is displayed with title 'Gender' in bold/black font", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("14.1", "verify gender pie chart title in bold/black font",	"Gender pie chart is not displayed with title 'Gender' in bold/black font", AppConstants.vFail);				
			fail++;
			
		}
		}
		catch(Exception e)
		{
			generateXML.logVP("14.1", "verify gender pie chart title in bold/black font",	"Gender pie chart is not displayed with title 'Gender' in bold/black font", AppConstants.vFail);				
			fail++;
		}
			//verify pie chart legend
		
		try
		{
		WebElement legend=driver.findElement(By.id(excelRW.readProps(pageName,CatalogConstants.GENDERPIECHARTLEGEND)));
		List<WebElement> legendElements = ((legend.findElement(By.tagName(CatalogConstants.SVG))).findElements(By.tagName(CatalogConstants.G)));
		
		List<String> actualList=new LinkedList<String>();
		for(WebElement w:legendElements)
		{
			actualList.add(w.getText()); //preparing actual list
			System.out.println("actual********"+w.getText());
		}
	
		List<String> expectedList =new LinkedList<String>();
		
		String[] expected=propsRW.read(CatalogConstants.GENDERLEGENDELEMENTS).split(",");
		
		for(String s:expected)
		{
			System.out.println("expected********"+s);
			expectedList.add(s); //preparing expected list
		}
	
		int vpCount=1;
		for(int i=0;i<expectedList.size();i++)
		 {
			if(actualList.contains(expectedList.get(i))) //comparing actual and expected lists
			{
				 generateXML.logVP("14."+(++vpCount), "verify if Gender pie chart is displayed with legend of Gender group '"+expectedList.get(i)+" '",	"Gender pie chart is displayed with legend of Gender group "+expectedList.get(i), AppConstants.vPass);				
				 pass++;
			}
			else
			{
				 generateXML.logVP("14.2"+(++vpCount), "verify if Gender pie chart is displayed with legend of Gender group '"+expectedList.get(i)+" '",	"Gender pie chart is not displayed with legend of Gender group "+expectedList.get(i), AppConstants.vFail);				
				 fail++; 
			}
		 }
		} 
		catch(Exception e)
		{
			 generateXML.logVP("14.2" ,"verify if Gender pie chart is displayed with legend of Gender groups",	"Gender pie chart is not displayed with legend of Gender groups ", AppConstants.vFail);				
				fail++; 
		}
		
	}
	
	
	/**
	 * This method is used to verify values shown on age pie chart in product analytics screen
	 * Test method
	 * @throws JSONException 
	 * @throws Exception
	 */

	@Test
	public void test_B_6() throws InterruptedException, JSONException
	{
		
		//getting expected values from hbase
		propsRW = new PropertiesUtil(CatalogConstants.CATALOG_PROPERTIES);
		
		Map<String,String> ageAnalytics=new LinkedHashMap<String, String>();
		
		List<String> expectedList=new LinkedList<String>();
		
		
		String ph_analytics=hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.DERIVEDINFO, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.PH_ANALYTICS ,CatalogConstants.MAXVERSIONS);
		
		JSONObject json=new JSONObject(ph_analytics); //converting to json object to extract the dimension
		
		JSONArray array=json.getJSONArray(CatalogConstants.DIMENSIONS);
		JSONObject age=(JSONObject) array.get(0);  //extracting age dimension
		
		JSONObject ageDimensions= (JSONObject) age.get(CatalogConstants.GLOBALMAP); //extracting global map values for age
		
		JSONArray keyArray=ageDimensions.names();
		
		for(int i=0;i<keyArray.length();i++){
			ageAnalytics.put(keyArray.get(i).toString(), ageDimensions.get(keyArray.get(i).toString()).toString());
		}
		String temporary="";
		//preparing expected list
		for(String s:ageAnalytics.keySet()){
			String value=s+"\n"+ageAnalytics.get(s);
			temporary+=value+"\n";
			expectedList.add(value);
		}

		//calculating percentage values
		String a[]=new String[expectedList.size()];
		a=temporary.split("\n");
		
		Map<String,Integer> expectedPecentagesList=new LinkedHashMap<String,Integer>();
		int sum=0;
		for(int i=0;i<a.length;i=i+2)
		{
			expectedPecentagesList.put(a[i],Integer.parseInt(a[i+1]));
			sum+=Integer.parseInt(a[i+1]);
		}
		Map<String,String> finalList=new LinkedHashMap<String,String>();
		
		for(String str:expectedPecentagesList.keySet())
		{
			int temp=expectedPecentagesList.get(str);
			double result=(temp*100.00)/(sum);
			String finalResult=String.valueOf((Math.round(result)));
			finalList.put(str+"\n"+temp, finalResult+"%"); //format as displayed on the console
		}
	
		
		//getting actual values
		
		try
		{
		//fetching elements with title tag.validating hover tool tip
		
		List<WebElement> ageElements=(driver.findElements(By.xpath(excelRW.readProps(pageName,CatalogConstants.AGECHARTHOVER))));
		
		List<String> actualList=new LinkedList<String>();
		
		for(WebElement element:ageElements)
		{
			actualList.add(element.getAttribute(CatalogConstants.HOVERATTRIBUTE));
			
		}
		
		System.out.println("************************"+actualList+"**************************");
		System.out.print("hover******"+actualList);
		
		int vpCount=0;
		

		for(int i=0;i<expectedList.size();i++)
		{
				
		if(actualList.contains(expectedList.get(i)))
		{	
			generateXML.logVP("15."+(++vpCount), "verify " + expectedList.get(i)+  " tool tip displayed on hovering the percentages on the piechart","tool tip "+expectedList.get(i) +" is dispalyed ", AppConstants.vPass);				
			pass++;
				
		}
	
		else
		{
			generateXML.logVP("15."+(++vpCount), "verify " + expectedList.get(i)+  " tool tip displayed on hovering the percentages on the piechart","tool tip "+expectedList.get(i) +" is not dispalyed ", AppConstants.vFail);				
			fail++;
		
		}
		}
		}	
		catch(Exception e)
		{
			generateXML.logVP("15.1", "verify tool tip displayed on hovering the percentages on the piechart","tool tip is not dispalyed ", AppConstants.vFail);				
			fail++;
		}
		
	}
		/**
	 * This method is used to verify values shown on gender pie chart in product analytics screen
	 * Test method
	 * @throws JSONException 
	 * @throws Exception
	 */
	
	@Test
	public void test_B_7() throws InterruptedException, JSONException
	{
		
		//getting expected values from hbase
		propsRW = new PropertiesUtil(CatalogConstants.CATALOG_PROPERTIES);
		
		Map<String,String> genderAnalytics=new LinkedHashMap<String, String>();
		
		List<String> expectedList=new LinkedList<String>();
		
		
		String ph_analytics=hbaseUtil.getQualifierValue(CatalogConstants.PRODUCTINSIGHT, CatalogConstants.DERIVEDINFO, propsRW.read(CatalogConstants.VALIDPRODUCTID),CatalogConstants.PH_ANALYTICS ,CatalogConstants.MAXVERSIONS);
		
		JSONObject json=new JSONObject(ph_analytics); //converting to json object to extract the dimension
		
		JSONArray array=json.getJSONArray(CatalogConstants.DIMENSIONS);
		JSONObject gender=(JSONObject) array.get(1);  //extracting gender dimension
		
		JSONObject genderDimensions= (JSONObject) gender.get(CatalogConstants.GLOBALMAP); //extracting global map values for gender
		
		JSONArray keyArray=genderDimensions.names();
		
		for(int i=0;i<keyArray.length();i++){
			genderAnalytics.put(keyArray.get(i).toString(), genderDimensions.get(keyArray.get(i).toString()).toString());
		}
		String temporary="";
		//preparing expected list
		for(String s:genderAnalytics.keySet()){
			String value=s+"\n"+genderAnalytics.get(s);
			temporary+=value+"\n";
			expectedList.add(value);
		}

		//calculating percentage values
		String a[]=new String[expectedList.size()];
		a=temporary.split("\n");
		
		Map<String,Integer> expectedPecentagesList=new LinkedHashMap<String,Integer>();
		int sum=0;
		for(int i=0;i<a.length;i=i+2)
		{
			expectedPecentagesList.put(a[i],Integer.parseInt(a[i+1]));
			sum+=Integer.parseInt(a[i+1]);
		}
		Map<String,String> finalList=new LinkedHashMap<String,String>();
		
		for(String str:expectedPecentagesList.keySet())
		{
			int temp=expectedPecentagesList.get(str);
			double result=(temp*100.00)/(sum);
			String finalResult=String.valueOf((Math.round(result)));
			finalList.put(str+"\n"+temp, finalResult+"%"); //format as displayed on the console
		}
	
		System.out.println("******************************"+expectedList);
		//getting actual values
		
		try
		{
		//fetching elements with title tag.validating hover tool tip
		
		List<WebElement> genderElements=(driver.findElements(By.xpath(excelRW.readProps(pageName,CatalogConstants.GENDERCHARTHOVER))));
		
		List<String> actualList=new LinkedList<String>();
		
		for(WebElement element:genderElements)
		{
			actualList.add(element.getAttribute(CatalogConstants.HOVERATTRIBUTE));
			
		}
		
		System.out.print("hover******"+actualList);
		
		int vpCount=0;
		

		for(int i=0;i<expectedList.size();i++)
		{
				
		if(actualList.contains(expectedList.get(i)))
		{	
			generateXML.logVP("16."+(++vpCount), "verify " + expectedList.get(i)+  " tool tip displayed on hovering the percentages on the gender piechart","tool tip "+expectedList.get(i) +" is dispalyed ", AppConstants.vPass);				
			pass++;
				
		}
	
		else
		{
			generateXML.logVP("16."+(++vpCount), "verify " + expectedList.get(i)+  " tool tip displayed on hovering the percentages on the gender piechart","tool tip "+expectedList.get(i) +" is not dispalyed ", AppConstants.vFail);				
			fail++;
		
		}
		}
		}	
		catch(Exception e)
		{
			generateXML.logVP("16.1", "verify tool tip displayed on hovering the percentages on the gender piechart","tool tip is not dispalyed ", AppConstants.vFail);				
			fail++;
		}
		
	}
	/**
	 * This method is used to verify UI of product recommendations screen screen
	 * Test method
	 * @throws JSONException 
	 * @throws Exception
	 */

	@Test
	public void test_B_8() throws InterruptedException, JSONException
	{
		driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.LEFTMENUITEM_3))).click();
		
		String xpathExpression = excelRW.readProps(pageName, CatalogConstants.SEARCHSECTION_TITLE);
		
		String title= driver.findElement(By.xpath(xpathExpression)).getText();
		
		if(title.equalsIgnoreCase(propsRW.read(CatalogConstants.TITLE)))
		{
			generateXML.logVP("17", "Check if product Recommednations screen contains search section with title 'Search Product' title",	"search section exists in product Recommednations screen with title 'Search Product' title", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("17", "Check if product Recommendations screen contains search section with title 'Search Product' title",	"search section does not exist in product Recommednations screen with title 'Search Product' title", AppConstants.vFail);				
			fail++;
		}
	}
	
	/**
	 * This method is used to verify the UI of search Section in product Recommendations
	 * Test method
	 * @throws Exception
	
	 */
	
	@Test
	public void test_B_9() throws InterruptedException
	{
		
		
		
		//verify search section title
		try
		{
		String xpathExpression = excelRW.readProps(pageName, CatalogConstants.SEARCHSECTION_TITLE);
		
		String title= driver.findElement(By.xpath(xpathExpression)).getText();
		
		if(title.equalsIgnoreCase(propsRW.read(CatalogConstants.TITLE)))
		{
			generateXML.logVP("18.1", "verify if search section exists with title 'Search Product' title",	"search section exists with title 'Search Product' title", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("18.1", "verify if search section exists with title 'Search Product' title",	"search section doesnot exist with title 'Search Product' title", AppConstants.vFail);				
			fail++;
		}
		
		}
		catch(Exception e)
		{
			generateXML.logVP("18.1", "verify if search section exists with title 'Search Product' title",	"search section doesnot exist with title 'Search Product' title", AppConstants.vFail);				
			fail++;
		}
		
		//verify search section elements
		
		//verify customer id label
		try
		{
		
		String customerIdLabel=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.CUSTOMERIDLABEL))).getText();
		
		if(customerIdLabel.equalsIgnoreCase(propsRW.read(CatalogConstants.CUSTOMERIDLABEL)))
		{
			generateXML.logVP("18.2", "verify if customer id label  exists in the search section",	"customer id label exists", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("18.2", "verify if customer id label  exists in the search section",	"customer id label does not exists", AppConstants.vFail);				
			fail++;
		}
	
		//verify customer id text box
		
		String text=driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.CATALOGCUSTOMER))).getAttribute(CatalogConstants.TYPE);
		String placeHolder=driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.CATALOGCUSTOMER))).getAttribute(CatalogConstants.PLACEHOLDER);
	
		if(text.equalsIgnoreCase(propsRW.read(CatalogConstants.TYPE)) && placeHolder.equalsIgnoreCase(propsRW.read(CatalogConstants.PLACEHOLDER)))
		{
			
			generateXML.logVP("18.3", "verify if customer id text box exists with text optional inscribed in it",	"customer id text box exists with text 'optional'", AppConstants.vPass);				
			pass++;	
		
		}
		else
		{
			generateXML.logVP("18.3", "verify if customer id text box exists with text optional inscribed in it",	"customer id text box does not exists with text 'optional'", AppConstants.vFail);				
			fail++;	
		}
		}
		catch(Exception e)
		{	generateXML.logVP("18.3", "verify if customer id text box exists with text optional inscribed in it",	"customer id text box does not exists with text 'optional'", AppConstants.vFail);				
			fail++;	
			
		}
		
		//verify options drop down
		try
		{
		List<WebElement> dropDownElements=(driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHLABEL)))).findElements(By.tagName(excelRW.readProps(pageName,CatalogConstants.DROPDOWNATAG)));
	
		List<String> actualList=new LinkedList<String>();
		
		for(WebElement w:dropDownElements)
		{
			actualList.add(w.getText());  //preparing actual list of elements
			System.out.println(actualList+"************actual");
		}
	
		List<String> expectedList=new LinkedList<String>();
		
		expectedList.add(propsRW.read(CatalogConstants.SEARCHLABLE_PRODUCT));
		expectedList.add(propsRW.read(CatalogConstants.SEARCHLABLE_BRAND));
		expectedList.add(propsRW.read(CatalogConstants.SEARCHLABLE_KEYWORDS)); //preparing expected list
		
		System.out.println(expectedList+"************expected");
		int count=0;
		for(int i=0;i<expectedList.size();i++)
		{
			for(int j=0;j<actualList.size();j++)
			{
				if(expectedList.get(i).equalsIgnoreCase(actualList.get(j)))
				{
					count++;
				}
			}
		}
		
		System.out.println("count"+count);
		if(count==expectedList.size())
		{
			generateXML.logVP("18.4", "verify if options drop down contains Product Id,Brand Id,Keywords labels ",	"options drop down contains Product Id,Brand Id,Keywords labels", AppConstants.vPass);				
			pass++;	
		}
		
		else
		{
			generateXML.logVP("18.4", "verify if options drop down contains Product Id,Brand Id,Keywords labels ",	"options drop down does not contains Product Id,Brand Id,Keywords labels", AppConstants.vFail);				
			fail++;	
		}
		
		}
		catch(Exception e)
		{
			generateXML.logVP("18.4", "verify if options drop down contains Product Id,Brand Id,Keywords labels ",	"options drop down does not contains Product Id,Brand Id,Keywords labels", AppConstants.vFail);				
			fail++;	
		}
	
	//verify if product id label is selected by default
		try
		{
		Boolean result=false;
		List<WebElement> dropDownElements=(driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHLABEL)))).findElements(By.tagName(excelRW.readProps(pageName,CatalogConstants.DROPDOWNATAG)));
			for(WebElement labelName:dropDownElements)
		{
			if(labelName.getText().equalsIgnoreCase(propsRW.read(CatalogConstants.SEARCHLABLE_PRODUCT)))
				
			{
						
				if(labelName.getAttribute(excelRW.readProps(pageName, CatalogConstants.DROPDOWNATTRIBUTE)).equalsIgnoreCase(propsRW.read(CatalogConstants.SELECTED)))

				{
					result=true;
				}
					
			}
		}	
			System.out.println("result"+result);
			if(result==true)
				{
				
					generateXML.logVP("18.5", "verify if product id lable is shown in the options drop down",	"product id label is shown", AppConstants.vPass);				
						pass++;
					}
					
					else
					{
						generateXML.logVP("18.5", "verify if product id lable is shown in the options drop down",	"product id label is not shown", AppConstants.vFail);				
						fail++;
					}
		}
		catch(Exception e)
		{
			generateXML.logVP("18.5", "verify if product id lable is shown in the options drop down",	"product id label is not shown", AppConstants.vFail);				
			fail++;
		}
		}
	
	
	/**
	 * This method is used to verify the functionality of search Section in product Recommendations screen
	 * Test method
	 * @throws Exception
	
	 */
	
	@Test
	public void test_C_1() throws InterruptedException
	{
		//verify search functionality when only customer id is entered while product id is selected in the options dropdown and clicked on go button
		try
		{
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.CATALOGCUSTOMER))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.CATALOGCUSTOMER))).sendKeys(propsRW.read(CatalogConstants.VALIDCUSTOMERID));
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
		
		String errorMessage=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ALERT))).getText();
		
		if(errorMessage.equalsIgnoreCase(propsRW.read(CatalogConstants.ERRORMESSAGE_BLANK)))
		{
			generateXML.logVP("19", "verify search functionality when only customer id is entered while product id is selected in the options dropdown and clicked on go button",	"alert is displayed with message 'please enter productId' ", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("19", "verify search functionality when only customer id is entered while product id is selected in the options dropdown and clicked on go button",	"alert is not displayed ", AppConstants.vFail);				
			fail++;
		}
		
			driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ALERTBUTTON))).click();
		
		}
		catch(Exception e)
		{
			generateXML.logVP("19", "verify search functionality when only customer id is entered while product id is selected in the options dropdown and clicked on go button",	"alert is not displayed ", AppConstants.vFail);				
			fail++;
		}
		
	}
	
	/**
	 * This method is used to verify the functionality of search Section in product Recommendations screen
	 * Test method
	 * @throws Exception
	
	 */
	
	@Test
	public void test_C_2() throws InterruptedException
	{
		//verify search functionality when only customer id is entered while keywords is selected in the options dropdown and clicked on go button
		
		try
		{
			
				driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHLABEL))).sendKeys(propsRW.read(CatalogConstants.SEARCHLABLE_KEYWORDS));
				driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.CATALOGCUSTOMER))).clear();
				driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.CATALOGCUSTOMER))).sendKeys(propsRW.read(CatalogConstants.VALIDCUSTOMERID));
				driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
				
				String errorMessage=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ALERT))).getText();
				
				if(errorMessage.equalsIgnoreCase(propsRW.read(CatalogConstants.ERRORMESSAGE_BLANK_KEYWORDS)))
				{
					generateXML.logVP("20", "verify search functionality when only customer id is entered while Keywords is selected in the options dropdown and clicked on go button",	"alert is displayed with message 'please enter Keywords' ", AppConstants.vPass);				
					pass++;
				}
				
				else
				{
					generateXML.logVP("20", "verify search functionality when only customer id is entered while Keywords is selected in the options dropdown and clicked on go button",	"alert is not displayed ", AppConstants.vFail);				
					fail++;
				}
				
					driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ALERTBUTTON))).click();
		}
		catch(Exception e)
		{
			generateXML.logVP("20", "verify search functionality when only customer id is entered while Keywords is selected in the options dropdown and clicked on go button",	"alert is not displayed ", AppConstants.vFail);				
			fail++;
		}
	}
	
	/**
	 * 
	 * Test method
	 * @throws Exception
		This method is used to verify customer id text box is disabled or not
	 */
	
	@Test
	public void test_C_3() throws InterruptedException
	{
				//select brand id from options dropdown
				
		try
		{
				driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHLABEL))).sendKeys(propsRW.read(CatalogConstants.SEARCHLABLE_BRAND));
				
				//verify if customer id text box is disabled or not
				Select select = new Select(driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHLABEL))));
				select.selectByValue("brand");
				
				driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHSECTION_TITLE))).click();
				
				String disabled=driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.CATALOGCUSTOMER))).getAttribute(CatalogConstants.DISABLED);
				
				System.out.println("disabled"+disabled);
				
				if(disabled.equalsIgnoreCase(propsRW.read(CatalogConstants.DISABLED)))
				{
					generateXML.logVP("21", "verify if customer id text box is disabled or not when brand id is selected from the drop down",	"customer id text box is disabled", AppConstants.vPass);				
					pass++;
				}
				
				else
				{
					generateXML.logVP("21", "verify if customer id text box is disabled or not when brand id is selected from the drop down",	"customer id text box is not disabled", AppConstants.vFail);				
					fail++;
	
				}
		}
				catch(Exception e)
				{
					generateXML.logVP("21", "verify if customer id text box is disabled or not when brand id is selected from the drop down",	"customer id text box is not disabled", AppConstants.vFail);				
					fail++;
				}
		
	}
	
	/**
	 *This method is used to verify message displayed when invalid brand id/product id is entered and clicked on go
	 * Test method
	 * @throws Exception
	
	 */
	
	@Test
	public void test_C_4() throws InterruptedException
	{
		
		try
		{
		//selecting brand 
		driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHLABEL))).sendKeys(propsRW.read(CatalogConstants.SEARCHLABLE_BRAND));
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(propsRW.read(CatalogConstants.INVALIDPRODUCTID));;
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
		
		String errorMessage_brand=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ERRORMESSAGE_INVALIDID))).getText();
		
		
		
		if(errorMessage_brand.equalsIgnoreCase(propsRW.read(CatalogConstants.ERRORMESSAGE_INVALID_BRAND)))
		{
			generateXML.logVP("22.1", "verify search functionality when invalid brand id is entered",	"brand not found message is displayed ", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("22.1", "verify search functionality when invalid brand id is entered",	"brand not found message is not displayed ", AppConstants.vFail);				
			fail++;
		}
		}
		catch(Exception e)
		{
			generateXML.logVP("22.1", "verify search functionality when invalid brand id is entered",	"brand not found message is not displayed ", AppConstants.vFail);				
			fail++;
		}
		
		//selecting product id
		
		try
		{
		driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHLABEL))).sendKeys(propsRW.read(CatalogConstants.SEARCHLABLE_PRODUCT));
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(propsRW.read(CatalogConstants.INVALIDPRODUCTID));;
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
		
		String errorMessage_product=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ERRORMESSAGE_INVALIDID))).getText();
		
		if(errorMessage_product.equalsIgnoreCase(propsRW.read(CatalogConstants.ERRORMESSAGE_INVALIDID)))
		{
			generateXML.logVP("22.2", "verify search functionality when invalid product id is entered",	"product not found message is displayed ", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("22.2", "verify search functionality when invalid product id is entered",	"product not found message is not displayed ", AppConstants.vFail);				
			fail++;
		}
		
		}
		catch(Exception e)
		{
			generateXML.logVP("22.2", "verify search functionality when invalid product id is entered",	"product not found message is not displayed ", AppConstants.vFail);				
			fail++;
		}
		
	}
	
	
	/**
	 *This method is used to verify message displayed when invalid customer id is entered along with valid product id/ keyword
	 * Test method
	 * @throws Exception
	
	 */
	
	@Test
	public void test_C_5() throws InterruptedException
	
	{
		
		try
		{
		driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHLABEL))).sendKeys(propsRW.read(CatalogConstants.SEARCHLABLE_PRODUCT));
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(propsRW.read(CatalogConstants.VALIDPRODUCTID));;
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.CATALOGCUSTOMER))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.CATALOGCUSTOMER))).sendKeys(propsRW.read(CatalogConstants.INVALIDPRODUCTID)); //invalid customer id
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
		
		String errorMessage=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.ERRORMESSAGE_INVALIDID))).getText();
		
		
		if(errorMessage.equalsIgnoreCase(propsRW.read(CatalogConstants.ERRORMESSAGE_INVALID_CUSTOMER)))
		{
			generateXML.logVP("23", "verify search functionality when invalid customer id is entered along with valid product id",	"customer not found message is displayed ", AppConstants.vPass);				
			pass++;
		}
		
		else
		{
			generateXML.logVP("23", "verify search functionality when invalid customer id is entered along with valid product id",	"customer not found message is not displayed ", AppConstants.vFail);				
			fail++;
		}
		}
		catch(Exception e)
		{
			generateXML.logVP("23", "verify search functionality when invalid customer id is entered along with valid product id",	"customer not found message is not displayed ", AppConstants.vFail);				
			fail++;
		}
	
	}
	

	/**
	 *This method is used to verify Ui of product recommendations section when valid product id is entered
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_C_6() throws InterruptedException
	{
		
		try
		{
		
		driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.SEARCHLABEL))).sendKeys(propsRW.read(CatalogConstants.SEARCHLABLE_PRODUCT));
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.CATALOGCUSTOMER))).clear();
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(propsRW.read(CatalogConstants.VALIDPRODUCTID));
		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
		
		//verify UI of product recommendations screen when valid product id is entered
	
			//verify the titles and css
			
			List<String> expectedList=new LinkedList<String>(); //preparing expected list
		
			String[] expectedArray=propsRW.read(CatalogConstants.PRODUCTRECOMMENDATIONSLIST).split(",");
			
			for(String recommendation:expectedArray)
			{
				expectedList.add(recommendation);
			}
		
			//getting actual list
			
			List<String> actualList=new LinkedList<String>();
		
			List<WebElement> titles=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.PRODUCTRECOMMENDATIONSTITLE)));
			
			for(WebElement title:titles )
			{
	
				actualList.add(title.getText());
			}
		
			System.out.println(actualList+"***********************finalList last Tc");
			
			int vpCount=0;
			for(String s:actualList)
			{
			
			if(expectedList.contains(s))
			{
				
				WebElement titlecss=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CatalogConstants.TITLECSS)));
				
				String fontColor=titlecss.getCssValue(CatalogConstants.COLOR); //verify font color
				String fontWeight=titlecss.getCssValue(CatalogConstants.FONT_WEIGHT);
			
				
				
				if(fontColor.equalsIgnoreCase(propsRW.read(CatalogConstants.COLOR)) && fontWeight.equalsIgnoreCase(propsRW.read(CatalogConstants.FONT_WEIGHT)))
				{
					generateXML.logVP("24."+(++vpCount), "verify '" + s +  "' section is displayed with title in bold/black color " , s +" is dispalyed with title in bold/black color ", AppConstants.vPass);				
					pass++;
				}
				else
				{
					generateXML.logVP("24."+(++vpCount), "verify '" + s +  "' section is displayed with title in bold/black color " , s +" is not dispalyed with title in bold/black color ", AppConstants.vFail);				
					fail++;
			
				}
			}
		}
		
			//verify titles back ground color
			
			int vpCount1=vpCount;
			for(String s:actualList)
			{
			
			if(expectedList.contains(s))
			{
				
				WebElement titlecss=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CatalogConstants.TITLECSS)));
				
				String bgColor=titlecss.getCssValue(CatalogConstants.BACKGROUNDCOLOR); //verify font color
			
				if(bgColor.equalsIgnoreCase(propsRW.read(CatalogConstants.BACKGROUNDCOLOR)))
				{
					generateXML.logVP("24."+(++vpCount1), "verify '" + s +  "' section is displayed with title highlighted in blue color '" , s +"' section is dispalyed with title highlighted in blue color ", AppConstants.vPass);				
					pass++;
				}
				else
				{
					generateXML.logVP("24."+(++vpCount1), "verify '" + s +  "' section is displayed with title highlighted in blue color '" , s +"' section is not dispalyed with title highlighted in blue color ", AppConstants.vFail);				
					fail++;
			
				}
			}
			
		}
		}
		
		catch(Exception e)
		{
			generateXML.logVP("24", "verify product recommendations UI when valid product id is entered " ," product recommendations screen is not displayed with carousels  ", AppConstants.vFail);				
			fail++;
		}
		
		
	}

	

	/**
	 *This method is used to verify if products in the carousels are hyperlinks
	 * Test method
	 * @throws Exception
	
	 */
//	@Test
//	public void test_C_7(){
//		//*[@id="remove"]/div[-----------------]/div[2]/div/div/ul/li------ all li in particular car
//
//
//		//*[@id="remove"]/div[-----------------]/*[1]/div[1] -- key(header)
//
//		
//		Map<String,List<String>> finalResult=new LinkedHashMap<String, List<String>>();
//		List<String> productList=new LinkedList<String>();
//		List<WebElement> titles=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.PRODUCTRECOMMENDATIONSTITLE)));
//		List<WebElement> list = new LinkedList<WebElement>();
//		List<String> pnameList=new LinkedList<String>();
//		int count1=0;
//		int vpCount=0;
//		for(int i=1;i<=titles.size();i++){
//			int count=0;
//			String failed="";
//			
//			pnameList=new LinkedList<String>();
//			list=driver.findElements(By.xpath("//*[@id='remove']/div["+i+"]/*/*/*/ul/li/a/h4"));
//			for(WebElement e:list){
//			pnameList.add(e.getText());
//			e.click();
//			String name=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CatalogConstants.PRODUCTNAME))).getText();
//			driver.findElement(By.id("hider")).sendKeys(Keys.ESCAPE);
//			System.out.println("name**************"+name +"getText*************"+e.getText());
//			
//			if(e.getText().equalsIgnoreCase(name))
//			{
//			count++;
//			}
//			else
//			{
//				failed=failed+" "+e.getText();
//			}
//			}
//			//driver.findElement(By.id("close")).click();
//			
//			System.out.println("coumt***************"+count+" size*********"+pnameList.size());
//			if(count==pnameList.size())
//			{
//				generateXML.logVP("25."+ (++vpCount), "verify if product details page is displayed on clicking the products in '"+titles.get(count1).getText()+"' section " ,"product details page is displayed for all the elements", AppConstants.vPass);				
//									pass++;
//			}
//			
//			else
//			{
//				generateXML.logVP("25."+ ++(vpCount), "verify if product details page is displayed on clicking the products in '"+titles.get(count1).getText()+"' section " ,"product details page is not displayed for the products "+failed, AppConstants.vFail);				
//				fail++;
//			}
//			count1++;
//			finalResult.put(titles.get(i-1).getText(), pnameList);
//			//pnameList.clear();
//			//list.clear();
//		}
//		
//		
//		
//		for(String s1:finalResult.keySet()){
//			System.out.println("============================");
//			System.out.println("carname=-------"+s1);
//			List<String> l=finalResult.get(s1);
//			for(String text:l){
//				System.out.println("values===="+text);
//				
//			}
//			System.out.println("============================");
//		}
//		
//	}	
		/**
		 *This method is used to validate products displayed in suggested items section when valid product id is entered
		 * Test method
		 * @throws Exception
		
		 */
	
	@Test
	public void test_C_8()
	{
		//fetching expected list from the hbase

		LinkedHashMap<String,String> productNames=commonUtil.getProductNames(CatalogConstants.SUGGESTEDFORYOUFAMILTY);
//		propsRW = new PropertiesUtil(CatalogConstants.CATALOG_PROPERTIES);
//		driver.findElement(By.linkText(CatalogConstants.CATALOG_TAB_NAME)).click();
//		driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.LEFTMENUITEM_3))).click();
//		driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(propsRW.read(CatalogConstants.VALIDPRODUCTID));
//				driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
	
		//comparing actual values with the expected values
		
		List<WebElement> actualList=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.SUGGESTEDITEMS)));
		List<String> actualValues=new LinkedList<String>();
		
		for(WebElement value:actualList)	{
		actualValues.add(value.getText());
		System.out.println(value.getText());
			
		}
	
		int productCount=0;
		int productName=0;
		String productIds="";
		
		for(Map.Entry<String, String> entry: productNames.entrySet())
		{
	
			if(entry.getValue().equalsIgnoreCase(actualValues.get(productName)))
			{
				
				productCount++;
			}
			
			else
			{
				productIds=productIds+","+entry.getKey();
			}
			productName++;
			
		}	
	
		
		if(productCount==productNames.size())
		{
			generateXML.logVP("26" , "verify if products displayed in suggested items section match with the values in the hbase ","values shown on the console match with the values from the hbase", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("26" , "verify if products displayed in suggested items section match with the values in the hbase ","values shown on the console does not match with the values from the hbase for the products ids " + productIds, AppConstants.vFail);				
			fail++;
		}
	}	
	
	/**
	 *This method is used to validate products displayed in Also viewed section when valid product id is entered
	 * Test method
	 * @throws Exception
	
	 */

@Test
public void test_C_9()
{
	//fetching expected list from the hbase

	
			LinkedHashMap<String,String> productNames=commonUtil.getProductNamesbyCategory(CatalogConstants.ALSOVIEWEDFAMILY);
			
			//comparing actual values with the expected values
			
			List<WebElement> actualList=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.ALSOVIEWED)));
			List<String> actualValues=new LinkedList<String>();
			for(WebElement value:actualList)
			{
				actualValues.add(value.getText());
				
			}
		
			int productCount=0;
			int productName=0;
			String productIds="";
			
			for(Map.Entry<String, String> entry: productNames.entrySet())
			{
			
				if(entry.getValue().equalsIgnoreCase(actualValues.get(productName)))
				{
					
					productCount++;
				}
				
				else
				{
					productIds=productIds+","+entry.getKey();
				}
				productName++;
				
			}	
		
			
			if(productCount==productNames.size())
			{
				generateXML.logVP("27" , "verify if products displayed in Also Viewed section match with the values in the hbase ","values shown on the console match with the values from the hbase", AppConstants.vPass);				
				pass++;
			}
			else
			{
				generateXML.logVP("27" , "verify if products displayed in Also Viewed section match with the values in the hbase ","values shown on the console does not match with the values from the hbase for the products ids " + productIds, AppConstants.vFail);				
				fail++;
			}
}	

/**
 *This method is used to validate products displayed in Similar Products section when valid product id is entered
 * Test method
 * @throws Exception

 */

@Test
public void test_D_1()
{
//fetching expected list from the hbase

		LinkedHashMap<String,String> productNames=commonUtil.getProductNamesbyCategory(CatalogConstants.SIMILARPRODUCTSFAMILTY);
		
		//comparing actual values with the expected values
		
		List<WebElement> actualList=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.SIMILARPRODUCTS)));
		List<String> actualValues=new LinkedList<String>();
		for(WebElement value:actualList)
		{
			actualValues.add(value.getText());
			
		}
	
		int productCount=0;
		int productName=0;
		String productIds="";
		
		for(Map.Entry<String, String> entry: productNames.entrySet())
		{
		
			if(entry.getValue().equalsIgnoreCase(actualValues.get(productName)))
			{
				
				productCount++;
			}
			
			else
			{
				productIds=productIds+","+entry.getKey();
			}
			productName++;
			
		}	
	
		
		if(productCount==productNames.size())
		{
			generateXML.logVP("28" , "verify if products displayed in Similar Products section match with the values in the hbase ","values shown on the console match with the values from the hbase", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("28" , "verify if products displayed in Similar Products section match with the values in the hbase ","values shown on the console does not match with the values from the hbase for the products ids " + productIds, AppConstants.vFail);				
			fail++;
		}
}	

/**
 *This method is used to validate products displayed in Bought Together section when valid product id is entered
 * Test method
 * @throws Exception

 */

@Test
public void test_D_2()
{
//fetching expected list from the hbase

		LinkedHashMap<String,String> productNames=commonUtil.getProductNamesbyCategory(CatalogConstants.BOUGHTTOGETHERFAMILY);
		
		//comparing actual values with the expected values
		
		List<WebElement> actualList=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.BOUGHTTOGETHER)));
		List<String> actualValues=new LinkedList<String>();
		for(WebElement value:actualList)
		{
			actualValues.add(value.getText());
			
		}
	
		int productCount=0;
		int productName=0;
		String productIds="";
		
		for(Map.Entry<String, String> entry: productNames.entrySet())
		{
		
			if(entry.getValue().equalsIgnoreCase(actualValues.get(productName)))
			{
				
				productCount++;
			}
			
			else
			{
				productIds=productIds+","+entry.getKey();
			}
			productName++;
			
		}	
	
		
		if(productCount==productNames.size())
		{
			generateXML.logVP("29" , "verify if products displayed in Bought Together items section match with the values in the hbase ","values shown on the console match with the values from the hbase", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("29" , "verify if products displayed in Bought Together items section match with the values in the hbase ","values shown on the console does not match with the values from the hbase for the products ids " + productIds, AppConstants.vFail);				
			fail++;
		}
}	


	/**
	 *This method is used to verify functionality of prev/next buttons in the carousels
	 * Test method
	 * @throws Exception
	*/
	@Test
	public void test_D_3(){
		try
		{
		List<WebElement> titles=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.PRODUCTRECOMMENDATIONSTITLE)));
		int i=1;
		int count1=0;
		int vpCount=0;
		for(WebElement title: titles)
		{
			String className=driver.findElement(By.xpath("//*[@id='remove']/div["+i+"]/div[2]/*/a[1]")).getAttribute("class");
			
			if(className.contains("disabled"))
					{
				generateXML.logVP("30."+ ++(vpCount), "verify if prev button is disabled for first time '"+titles.get(count1).getText()+"' section " ,"prev button is disabled", AppConstants.vPass);				
				pass++;
					
					}
			else
			{
				generateXML.logVP("30."+ ++(vpCount), "verify if prev button is disabled for first time '"+titles.get(count1).getText()+"' section " ,"prev button is disabled", AppConstants.vFail);				
				fail++;
			}
			count1++;
			i++;
		}
		
		count1=0;
		i=1;
		int vpCount1=vpCount;
		for(WebElement title: titles)
		{
			List<WebElement> products =driver.findElements(By.xpath("//*[@id='remove']/div["+i+"]/*/*/*/ul/li/a/h4"));
				
			int noOfRightClicks=(int) (Math.floor(products.size()/5)+1);

			for(int j=0;j<=noOfRightClicks;j++){

			driver.findElement(By.xpath("//*[@id='remove']/div["+i+"]/div[2]/*/a[2]")).click();
				
		}
			
		String className=driver.findElement(By.xpath("//*[@id='remove']/div["+i+"]/div[2]/*/a[2]")).getAttribute(CatalogConstants.CLASSATTRIBUTE);	
	
		if(className.contains("disabled"))
		{
	generateXML.logVP("30."+ ++(vpCount), "verify if next button is disabled when no more products are available in '"+titles.get(count1).getText()+"' section " ,"next button button is disabled", AppConstants.vPass);				
	pass++;
		
		}
		else
	{
	generateXML.logVP("30."+ ++(vpCount), "verify if next button is disabled when no more products are available in '"+titles.get(count1).getText()+"' section " ,"next button button is disabled", AppConstants.vFail);				
	fail++;
	}
		count1++;
		i++;
		
	}
		}
		
		
		catch(Exception e)
		{
			
		}
	}
	
	/**
	 *This method is used to verify if options icon is available for suggested for you section
	 * Test method
	 * @throws Exception
	
	 */
	
	@Test
	public void test_D_4(){
		
		//verify if options icon is available or not
		
				
		String className=driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.OPTIONSICON))).getAttribute(CatalogConstants.CLASSATTRIBUTE);
		
		
		if(className.equalsIgnoreCase("options"))
		{
			generateXML.logVP("31", "verify if options icon is available in suggested for you section","options icon is available", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("31", "verify if options icon is available in suggested for you section","options icon is not available", AppConstants.vFail);				
			fail++;
		}
	}
	
	/**
	 *This method is used to verify trace option is available in the options drop down
	 * Test method
	 * @throws Exception
	
	 */
	
	@Test
	public void test_D_5(){
		
		try
		{
			
			String optionName="";
			String carouselName="";
			driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.OPTIONSICON))).click();
			Thread.sleep(3000);
			//driver.findElement(By.xpath(".//*[@id='options']")).click();
			
			optionName=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.OPTIONSDROPDOWN))).getText();
			carouselName=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.OPTIONSDROPDOWN))).getAttribute("data-carouselname");
		
			System.out.println("optioName**************"+optionName);
			System.out.println("carouselName****************"+carouselName);
		if(optionName.equalsIgnoreCase(CatalogConstants.TRACE) && carouselName.equalsIgnoreCase(CatalogConstants.SUGGESTEDITEMS) )
		{
			generateXML.logVP("32", "verify if trace option is available in the options icon in suggested for you section","trace option is available", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("32", "verify if trace option is available in the options icon in suggested for you section","trace option is not available", AppConstants.vFail);				
			fail++;
		}
		
		}
		catch(Exception e)
		{
			generateXML.logVP("32", "verify if trace option is available in the options icon in suggested for you section","trace option is not available", AppConstants.vFail);				
			fail++;
		}
	}
	
	/**
	 *This method is used to verify functionality of trace option
	 * Test method
	 * @throws InterruptedException 
	 * @throws Exception
	
	 */
	
	@Test
	public void test_D_6() throws InterruptedException{
		
		try
		{
//			propsRW = new PropertiesUtil(CatalogConstants.CATALOG_PROPERTIES);
//			driver.findElement(By.linkText(CatalogConstants.CATALOG_TAB_NAME)).click();
//			driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.LEFTMENUITEM_3))).click();
//			driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(propsRW.read(CatalogConstants.VALIDPRODUCTID));
//					driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
					driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.OPTIONSICON))).click();
					//driver.findElement(By.xpath("//div[div[text()='Suggested Items']]//a[@id='options']/img")).click();
					
					Thread.sleep(3000);
					//driver.findElement(By.xpath("//*[@id='root1']/li[text()='Trace'])/a")).click();
					WebElement sEle= driver.findElement(By.xpath("//div[div[text()='Suggested Items']]//ul[@id='root1']//a[text()='Trace']"));
					System.out.println("text"+sEle.getText());
					
					if (sEle.isEnabled()){
						System.out.println("Enabled, Clcking the item");
						JavascriptExecutor executor = (JavascriptExecutor)driver;
						executor.executeScript("arguments[0].click();", sEle);
						sEle.click();	
					}
					
			
		try
		{
			Thread.sleep(1000);
			WebElement traceSection=driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.TRACESECTION)));
			if(traceSection.isEnabled())
			{
			generateXML.logVP("33", "verify if user is navigated to trace section when 'Trace' option is selected  from the options drop down in suggested for you section","user is navigated to trace section", AppConstants.vPass);				
			pass++;
			}
		}
			catch(Exception e)
			{
			generateXML.logVP("33", "verify if user is navigated to trace section when 'Trace' option is selected  from the options drop down in suggested for you section","user is not navigated to trace section", AppConstants.vFail);				
			fail++;
			}
		}
		catch(Exception e)
		{
			generateXML.logVP("33", "verify if user is navigated to trace section when 'Trace' option is selected  from the options drop down in suggested for you section","user is not navigated to trace section", AppConstants.vFail);				
			fail++;
		}
		
	
	}
	
	/**
	 *This method is used to verify UI of trace section
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_D_7(){
		//verify trace section title
		try
		{
			String title=driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.TRACESECTIONHEADER))).getText();
			if(title.equalsIgnoreCase(propsRW.read(CatalogConstants.TRACESECTIONHEADER)))
			{
			generateXML.logVP("34.1", "verify trace section title","trace section is displayed with title 'Suggested Items: Trace' in bold/black font ", AppConstants.vPass);				
			pass++;
			}
			else
			{
				generateXML.logVP("34.1", "verify trace section title","trace section is not displayed with title 'Suggested Items: Trace' ", AppConstants.vFail);				
				fail++;
			}
		}
			catch(Exception e)
			{
			generateXML.logVP("34.1", "verify trace section title","trace section is not displayed with title 'Suggested Items: Trace' ", AppConstants.vFail);				
			fail++;
			}
		
		//verify trace section title css
		
		try
		{
			WebElement titlecss=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CatalogConstants.TITLECSS)));
			
			String fontColor=titlecss.getCssValue(CatalogConstants.COLOR); //verify font color
			String fontWeight=titlecss.getCssValue(CatalogConstants.FONT_WEIGHT);
		
			
			
			if(fontColor.equalsIgnoreCase(propsRW.read(CatalogConstants.COLOR)) && fontWeight.equalsIgnoreCase(propsRW.read(CatalogConstants.FONT_WEIGHT)))
			{
				generateXML.logVP("34.2", "verify  trace section title is displayed with title in bold/black color " , "title is dispalyed with title in bold/black color ", AppConstants.vPass);				
				pass++;
			}
			else
			{
				generateXML.logVP("34.2", "verify tace section title is displayed with title in bold/black color " , " title is not dispalyed with title in bold/black color ", AppConstants.vFail);				
				fail++;
		
			}
		
		
		}
     catch(Exception e)
     {
    	 generateXML.logVP("34.2", "verify tace section title is displayed with title in bold/black color " , " title is not dispalyed with title in bold/black color ", AppConstants.vFail);				
			fail++;
     }
		
		//verify title background color
		
		WebElement titlecss=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CatalogConstants.TITLECSS)));
		
		String bgColor=titlecss.getCssValue(CatalogConstants.BACKGROUNDCOLOR); //verify font color
	
		if(bgColor.equalsIgnoreCase(propsRW.read(CatalogConstants.BACKGROUNDCOLOR)))
		{
			generateXML.logVP("34.3", "verify if trace section title is higlighted in blue color " , "title is highlighted in blue color ", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("34.3", "verify if trace section title is higlighted in blue color " , " title is not not highlighted in blue color ", AppConstants.vFail);				
			fail++;
	
		}
		
	
		
		}
	
	
	/**
	 *This method is used to verify UI of strategy configuration pie chart in trace section
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_D_8(){
		
		//verify strategy configuration pie chart title
		try
		{
//			propsRW = new PropertiesUtil(CatalogConstants.CATALOG_PROPERTIES);
//			driver.findElement(By.linkText(CatalogConstants.CATALOG_TAB_NAME)).click();
//			driver.findElement(By.xpath(excelRW.readProps(pageName, CatalogConstants.LEFTMENUITEM_3))).click();
//			driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.SEARCHTEXTBOX))).sendKeys(propsRW.read(CatalogConstants.VALIDPRODUCTID));
//					driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.GOBUTTON))).click();
//					driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.OPTIONSICON))).click();
//					//driver.findElement(By.xpath("//div[div[text()='Suggested Items']]//a[@id='options']/img")).click();
//					
//					//driver.findElement(By.xpath("//*[@id='root1']/li[text()='Trace'])/a")).click();
//					WebElement sEle= driver.findElement(By.xpath("//div[div[text()='Suggested Items']]//ul[@id='root1']//a[text()='Trace']"));
//					System.out.println("text"+sEle.getText());
//					
//					if (sEle.isEnabled()){
//						System.out.println("Enabled, Clcking the item");
//						JavascriptExecutor executor = (JavascriptExecutor)driver;
//						executor.executeScript("arguments[0].click();", sEle);
//						sEle.click();	
//						
//					}						
		List<WebElement> titleList=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.TRACEPIECHARTITLES)));
		
		
		System.out.println("titles size"+titleList.size());
		WebElement ageChartTitlecss=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CatalogConstants.CHARTTITLECLASS)));
		
		String fontColor=ageChartTitlecss.getCssValue(excelRW.readProps(pageName, CatalogConstants.CHARTTILECOLOR)); //verify font color
		System.out.println("font color********"+fontColor+"**********");
		
		String fontWeight=ageChartTitlecss.getCssValue(excelRW.readProps(pageName, CatalogConstants.PIECHARTTILEWEIGHT));
		
		Boolean result=false;
		
		for(WebElement title:titleList)
		{
			System.out.println("chart title************"+title.getText());
			if(title.getText().equalsIgnoreCase(propsRW.read(CatalogConstants.STRATEGYPIECHARTTILE)) && fontColor.equalsIgnoreCase(propsRW.read(CatalogConstants.CHARTTILECOLOR)) && fontWeight.equalsIgnoreCase(propsRW.read(CatalogConstants.PIECHARTTILEWEIGHT)))
			{
				result=true;
			}
		}
		
		if(result==true)
		{
			generateXML.logVP("35.1", "verify if strategy configuration pie chart title is dispalyed  in bold/black font",	"strategy configuration pie chart is displayed with title 'Strategy Configuration' in bold/black font", AppConstants.vPass);				
			pass++;
		}
			else
			{
			generateXML.logVP("35.1", "verify if strategy configuration pie chart title is displayed in bold/black font",	"strategy configuration pie chart is not displayed with title 'Strategy Configuration' in bold/black font", AppConstants.vFail);				
			fail++;
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			generateXML.logVP("35.1", "verify if strategy configuration pie chart title is displayed in bold/black font",	"strategy configuration pie chart section is not displayed with title 'Strategy Configuration' in bold/black font", AppConstants.vFail);				
			fail++;
			
		}
		
		//verify pie chart legend
		
		try
		{
		
		WebElement legend=driver.findElement(By.id(excelRW.readProps(pageName,CatalogConstants.STRATEGYLEGEND)));
		
		List<WebElement> legendElements = ((legend.findElement(By.tagName(CatalogConstants.SVG))).findElements(By.tagName(CatalogConstants.G)));
		List<String> actualList=new LinkedList<String>();
		System.out.println("**************before"+legendElements.size());
		for(WebElement w:legendElements)
		{
			actualList.add(w.getText()); //preparing actual list
			
		}
	
		System.out.println(actualList.size()+"***********");
		List<String> expectedList =new LinkedList<String>();
		
		String[] expected=propsRW.read(CatalogConstants.STRATEGYLEGENDELEMENTS).split(",");
		
		for(String s:expected)
		{
			expectedList.add(s); //preparing expected list
		}
	
		

		int vpCount=1;
		
		for(int i=0;i<expectedList.size();i++)
		 {
			 
				 if(actualList.contains(expectedList.get(i))) //comparing actual and expected lists
				 {
					 generateXML.logVP("35."+(++vpCount), "verify if strategy configuration pie chart is displayed with legend '"+expectedList.get(i)+" '", "Strategy Configuration pie chart is displayed with legend  "+expectedList.get(i), AppConstants.vPass);				
						pass++; 
				 }
				 

					else
					{
						generateXML.logVP("35."+(++vpCount), "verify if strategy configuration pie chart is displayed with legend '"+expectedList.get(i)+" '", "Strategy Configuration pie chart is not displayed with legend  "+expectedList.get(i), AppConstants.vFail);				
						fail++;
					}
			 }
			
	
		}	
		catch(Exception e)
		{
	generateXML.logVP("35.2", "verify if strategy configuration pie chart is displayed with legend Also Viewed/Similar Items/Top Sellers/Ultimately Bought","legend is not displayed", AppConstants.vFail);				
			fail++;
		}
	}
		
	/**
	 *This method is used to verify UI of user/product specific pie chart in trace section
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_D_9(){
		
		//verify user/product specific pie chart title
		try
		{
		
		List<WebElement> titleList=driver.findElements(By.xpath(excelRW.readProps(pageName, CatalogConstants.TRACEPIECHARTITLES)));

		WebElement ageChartTitlecss=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CatalogConstants.CHARTTITLECLASS)));
		
		String fontColor=ageChartTitlecss.getCssValue(excelRW.readProps(pageName, CatalogConstants.CHARTTILECOLOR)); //verify font color
		System.out.println("font color********"+fontColor+"**********");
		
		String fontWeight=ageChartTitlecss.getCssValue(excelRW.readProps(pageName, CatalogConstants.PIECHARTTILEWEIGHT));
		
		Boolean result=false;
		
		for(WebElement title:titleList)
		{
			if(title.getText().equalsIgnoreCase(propsRW.read(CatalogConstants.USERPIECHARTTILE)) && fontColor.equalsIgnoreCase(propsRW.read(CatalogConstants.CHARTTILECOLOR)) && fontWeight.equalsIgnoreCase(propsRW.read(CatalogConstants.PIECHARTTILEWEIGHT)))
			{
				result=true;
			}
		}
		
		if(result==true)
		{
			generateXML.logVP("36.1", "verify if user/product specific pie chart title is displayed in bold/black font",	"user/product specific pie chart is displayed with title 'User/Product Specific' in bold/black font", AppConstants.vPass);				
			pass++;
		}
			else
			{
			generateXML.logVP("36.1", "verify if user/product specific pie chart title is displayed in bold/black font",	"user/product specific pie chart is not displayed with title 'User/Product Specific' in bold/black font", AppConstants.vFail);				
			fail++;
			}
		}
		catch(Exception e)
		{
			generateXML.logVP("36.1", "verify  user/product specific pie chart title in bold/black font",	" user/product specific pie chart section is not displayed with title ' user/product specific' in bold/black font", AppConstants.vFail);				
			fail++;
			
		}
		
		//verify pie chart legend
		
		try
		{
		
		WebElement legend=driver.findElement(By.id(excelRW.readProps(pageName,CatalogConstants.USERLEGEND)));
		
		List<WebElement> legendElements = ((legend.findElement(By.tagName(CatalogConstants.SVG))).findElements(By.tagName(CatalogConstants.G)));
		List<String> actualList=new LinkedList<String>();
		System.out.println("**************before"+legendElements.size());
		for(WebElement w:legendElements)
		{
			actualList.add(w.getText()); //preparing actual list
			
		}
	
		System.out.println(actualList.size()+"***********");
		List<String> expectedList =new LinkedList<String>();
		
		String[] expected=propsRW.read(CatalogConstants.USERLEGENDELEMENTS).split(",");
		
		for(String s:expected)
		{
			expectedList.add(s); //preparing expected list
		}
	
		

		int vpCount=1;
		
		for(int i=0;i<expectedList.size();i++)
		 {
			 
				 if(actualList.contains(expectedList.get(i))) //comparing actual and expected lists
				 {
					 generateXML.logVP("36."+(++vpCount), "verify if user/product specific pie chart is displayed with legend '"+expectedList.get(i)+" '", "user/product specific pie chart is displayed with legend  "+expectedList.get(i), AppConstants.vPass);				
						pass++; 
				 }
				 

					else
					{
						generateXML.logVP("36."+(++vpCount), "verify if user/product specific pie chart is displayed with legend '"+expectedList.get(i)+" '",	"user/product specific pie chart is not displayed with legend  "+expectedList.get(i), AppConstants.vFail);				
						fail++;
					}
			 }
			
	
		}	
		catch(Exception e)
		{
			generateXML.logVP("36.2", "verify if user/product specific pie chart is displayed with legend of Also Viewed/Top Sellers/Similar Items",	"legend is not displayed", AppConstants.vFail);				
			fail++;
		}
	}
	
	/**
	 *This method is used to verify back button
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_E_1(){
		
	//verify if back button is available or not	
		
		try
		{
				driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.BACKBUTTON)));
				generateXML.logVP("37.1", "verify if trace section has back button " , "back button is available ", AppConstants.vPass);				
				pass++;
		}
		catch(Exception e)
		{
			generateXML.logVP("37.1", "verify if trace section has back button " , "back button is not available ", AppConstants.vFail);				
			fail++;
		}
		
		//verify back button css.verify color
		
				WebElement backButtonCss=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CatalogConstants.BACKCSS)));
				
				String fontColor=backButtonCss.getCssValue(CatalogConstants.COLOR);
				System.out.println("font color back********"+fontColor);
				
				if(fontColor.equals(propsRW.read(CatalogConstants.BACKBUTTONCOLOR)))
				{
					generateXML.logVP("37.2", "verify if back button is shown with orange text " , "back button is shown with orange text ", AppConstants.vPass);				
					pass++;
				}
				else
				{
					generateXML.logVP("37.2", "verify if back button is shown with orange text " , "back button is not shown with orange text ", AppConstants.vFail);				
					fail++;
				}
				
				//verify back button cdd.back ground color
				
					String bgColor=backButtonCss.getCssValue(CatalogConstants.BACKGROUNDCOLOR);
					System.out.println("back bg color**********"+bgColor);
					if(bgColor.equals(propsRW.read(CatalogConstants.BACKBUTTONBGCOLOR)))
						{
						generateXML.logVP("37.3", "verify if back button is highlighted in grey " , "back button is highlighted in grey ", AppConstants.vPass);				
						pass++;
						}
					else
					{
						generateXML.logVP("37.4", "verify if back button is highlighted in grey " , "back button is not highlighted in grey ", AppConstants.vFail);				
						fail++;
					}
	}
	
	
	/**
	 *This method is used to validate values displayed in strategy configuration pie chart
	 * Test method
	 * @throws Exception
	*/
//	@Test
//	public void test_E_2()
//	{
//		//fetching expected values from hbase
//		
//		HashMap<String, Object> expectedMap =new LinkedHashMap<String, Object>();
//		expectedMap=hbaseUtil.getLatestRowKeyDetails(CatalogConstants.STRATEGY_CONFIGURATION, CatalogConstants.PARAMETER_DETAILSFAMILY, CatalogConstants.ROWKEY_STRAT1006, 1);
//		
//		List<String> expectedList=new LinkedList<String>();
//		
//		//converting values to percentages
//		
//		for(Entry e:expectedMap.entrySet())
//		{
//			int percentage=Math.round(Float.valueOf(e.getValue().toString()));
//			System.out.println("percentage*********"+percentage);
//		
//			if(e.getKey().toString().equalsIgnoreCase("smw"))
//			{
//				expectedList.add("Similar Items "+ percentage + percentage+"%");
//			}
//			else if(e.getKey().toString().equalsIgnoreCase("ubw"))
//			{
//				expectedList.add("Ultimately Bought "+ percentage + percentage+"%");
//			}
//			else if(e.getKey().toString().equalsIgnoreCase("tsw"))
//			{
//				expectedList.add("Top Sellers "+ percentage + percentage+"%");
//			}
//			else if(e.getKey().toString().equalsIgnoreCase("avw"))
//			{
//				expectedList.add("Also Viewed "+  percentage + percentage+"%");
//			}
//		}
//		
//		try
//		{
//		//fetching elements with title tag.validating hover tool tip
//		
//		List<WebElement> ageElements=(driver.findElements(By.xpath(excelRW.readProps(pageName,CatalogConstants.STRATEGYCHARTHOVER))));
//		
//		List<String> actualList=new LinkedList<String>();
//		
//		for(WebElement element:ageElements)
//		{
//			actualList.add(element.getAttribute(CatalogConstants.HOVERATTRIBUTE));
//			
//		}
//		
//		System.out.print("hover******"+actualList);
//		
//		int vpCount=0;
//		
//
//		for(int i=0;i<expectedList.size();i++)
//		{
//				
//		if(actualList.contains(expectedList.get(i)))
//		{	
//			generateXML.logVP("38."+(++vpCount), "verify " + expectedList.get(i)+  " tool tip displayed on hovering the percentages on the strategy configuration piechart","tool tip "+expectedList.get(i) +" is dispalyed ", AppConstants.vPass);				
//			pass++;
//				
//		}
//	
//		else
//		{
//			generateXML.logVP("38."+(++vpCount), "verify " + expectedList.get(i)+  " tool tip displayed on hovering the percentages on the strategy configuration piechart","tool tip "+expectedList.get(i) +" is not dispalyed ", AppConstants.vFail);				
//			fail++;
//		
//		}
//		}
//		}	
//		catch(Exception e)
//		{
//			generateXML.logVP("38.1", "verify tool tip displayed on hovering the percentages on the strategy configuration piechart","tool tip is not dispalyed ", AppConstants.vFail);				
//			fail++;
//		}
//		
//	
//	}
	
	/**
	 *This method is used to verify functionality of back button back button
	 * Test method
	 * @throws Exception
	
	 */
	@Test
	public void test_E_3()
	{
		try
		{
				driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.BACKBUTTON))).click();
				driver.findElement(By.id(excelRW.readProps(pageName, CatalogConstants.RECOMMENDATIONSPAGE)));  //verify recommendations page is shown/active
				generateXML.logVP("39", "verify functionality back button " , "up on clicking the back button user should be navigated to product recommendations section", AppConstants.vPass);				
				pass++;
		}
		catch(Exception e)
		{
			generateXML.logVP("39", "verify functionality back button " , "up on clicking the back button user should be navigated to product recommendations section", AppConstants.vFail);				
			fail++;
		}
	}
	/**
	 * This method is invoked after all test methods in Catalog.java
	 * are executed
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */
	@AfterClass
	public static void tearDownAfterClass() throws TransformerConfigurationException, TransformerException {	
		
		propsRW=new PropertiesUtil(CatalogConstants.CATALOG_PROPERTIES);


        AppConstants.notRunCount =   Integer.parseInt(propsRW.read(AppConstants.TOTAL_VERIFICATION_POINTS).trim())-AppConstants.passCount-AppConstants.failCount;                   

        //log header report counts in XML file
        generateXML.logHeaderReportCounts();
	

		//log header report counts in XML file
		//generateXML.logHeaderReportCounts(pass, fail, notRun);
		//Generate html report using xml created in test method
		//Report should be according to test case name, ex: data.html
		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH+AppConstants.DETAILED_REPORT_XSL;
		String outputHTML = AppConstants.DETAIL_REPORT_FOLDER+AppConstants.FORWARD_SLASH+CatalogConstants.CATALOG+AppConstants.DOT_HTML;
		generateReport.generateHTML(AppConstants.XML_FILE_PATH, inputXSL, outputHTML);

		System.out.println("Successfully generated the report");

		//log script in summary report xml file
		//generateXML.logScript(AppConstants.CATALOG_SCRIPT_NAME, outputHTML,  pass, fail, notRun);
        generateXML.logScript(AppConstants.LOGIN_SCRIPT_NAME, outputHTML);

		//Reset xml & properties files path to ""	
		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;
	
		//Set pass, fail and notrun count to zero
        AppConstants.passCount= 0;
        AppConstants.failCount = 0;
        AppConstants.notRunCount = 0;

		//Close the browser
		//driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}

	}
}
class MyComparator implements Comparator {
    Map map;
    public MyComparator(Map map) {
        this.map = map;
    }
    public int compare(Object o1, Object o2) {
        return ((String) map.get(o2)).compareTo((String) map.get(o1));
    }
}
