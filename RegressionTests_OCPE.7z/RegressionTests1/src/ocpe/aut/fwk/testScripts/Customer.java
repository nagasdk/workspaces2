package ocpe.aut.fwk.testScripts;

import static org.junit.Assert.fail;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.constants.CustomerConstants;
import ocpe.aut.fwk.constants.RuleConstants;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.HBaseUtil;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * This class is used for automating Customer Tab
 * @author sarda_kumar
 * 
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Customer {

	private static StringBuffer verificationErrors = new StringBuffer();

	private static WebDriver driver;
	static DesiredCapabilities capabilities = null;
	static FirefoxBinary ffBinary = null;
	static FirefoxProfile ffprofile = null;
	private static PropertiesUtil propsRW;
	private static GenerateXml generateXML;
	private static GenerateHTML generateReport;

	static int pass = 0, fail = 0, notRun = 0;

	private static PropertiesUtil propsRW_login;
	private static ExcelUtil excelRW;
	private static String pageName;
	private static HBaseUtil hBaseUtil;

	@BeforeClass
	public static void oneTimeSetUp() {
		// one-time initialization code

		File pathToFirefoxBinary = new File(AppConstants.PATH_TO_FIREFOX_BINARY);
		ffBinary = new FirefoxBinary(pathToFirefoxBinary);
		ProfilesIni profile = new ProfilesIni();
		ffprofile = profile.getProfile(AppConstants.FIREFOX_PROFILE_DEFAULT);
		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();
		proxy.setProxyAutoconfigUrl(AppConstants.PROXY_URL);
		capabilities = new DesiredCapabilities();
		capabilities.setCapability(CapabilityType.PROXY, proxy);

		driver = new FirefoxDriver(ffBinary, ffprofile, capabilities);

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(AppConstants.BASE_URL + AppConstants.LOGIN_URL);

		hBaseUtil = new HBaseUtil();
		generateXML = new GenerateXml();
		generateReport = new GenerateHTML();
		excelRW = new ExcelUtil();

		// Change the xml file path according to name of the script
		AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER
				+ AppConstants.FORWARD_SLASH + RuleConstants.RULES
				+ AppConstants.DOT_XML;
		AppConstants.PROPERTIES_FILE_PATH = CustomerConstants.CUSTOMER_PROPERTIES;

		// Sheet Name of excel from where the xpath values are fetched
		pageName = CustomerConstants.CUSTOMER_TAB;

		// Create a new XML file
		generateXML.createVPXML(CustomerConstants.CUSTOMER_SCRIPT_NAME);

		// Login
		/*
		 * Firefox browser gets opened with OCPE Login page, provide with
		 * username rg@gmail.com and click on submit button. After login, Data
		 * tab selected with it's first side menu highlighted
		 */

		/* Clear the User Name text box */
		String xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE,
				AppConstants.USER_NAME);
		driver.findElement(By.xpath(xpathExpression)).clear();

		propsRW_login = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);

		/*
		 * Get valid username from properties file ex: rg@gmail.com
		 */
		String userName = propsRW_login.read(AppConstants.VALID_USERNAME)
				.trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(userName);

		/* Clear the Password text box */
		xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE,
				AppConstants.PASSWORD);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/*
		 * Get valid password from properties file ex: Aham123+
		 */
		String password = propsRW_login.read(AppConstants.VALID_PASSWORD)
				.trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(password);

		/* Click on login button */
		xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE,
				AppConstants.LOGIN_SUBMIT);
		driver.findElement(By.xpath(xpathExpression)).click();

	}

	/**
	 * One time set up for each method annotated with @Test annotation
	 * 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {

	}

	/**
	 * This method is used to verify if user is able to navigate to customer tab
	 * after login Test method
	 * 
	 * @throws Exception
	 */

	@Test
	public void test_A_1() throws Exception {

		Thread.sleep(2000);
		// //verify if user is able to navigate to catalog tab
		driver.findElement(By.linkText(CustomerConstants.CUSTOMER_TAB_NAME))
				.click();
		String xpathExpression = ExcelUtil.readProps(pageName,
				CustomerConstants.TAB_CUSTOMER);
		String selectedTab = driver.findElement(By.xpath(xpathExpression))
				.getText();
		if (selectedTab.equals(CustomerConstants.CUSTOMER_TAB_NAME)) {
			generateXML
					.logVP("1",
							"Check if user is able to navigate to Customer tab after login",
							"User logs in successfully and navigates to Customer tab",
							AppConstants.vPass);
			pass++;
		} else {
			generateXML
					.logVP("1",
							"Check if user is able to navigate to catalog tab after login",
							"User logs in successfully and unable to navigates to Customer tab",
							AppConstants.vFail);
			fail++;
		}

	}

	/**
	 * This method is used to verify the UI of customer tab with title Search
	 * Customer
	 * 
	 * @throws Exception
	 */

	@Test
	public void test_A_2() throws InterruptedException {
		// driver.findElement(By.linkText(AppConstants.CATALOG_TAB_NAME)).click();
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		// verify search section is available or not
		String xpathExpression = ExcelUtil.readProps(pageName,
				CustomerConstants.SEARCH_SECTION_TITLE);
		String title = driver.findElement(By.xpath(xpathExpression)).getText();
		if (title.equalsIgnoreCase(propsRW
				.read(CustomerConstants.SEARCH_SECTION_TITLE))) {
			generateXML
					.logVP("2.1",
							"Check if search section exists with title 'Search Customer' title",
							"Search section exists with title 'Search Customer' ",
							AppConstants.vPass);
			pass++;
		}

		else {
			generateXML
					.logVP("2.1",
							"Check if search section exists with title 'Search Customer'",
							"search section doesnot exist with title 'Search Customer' ",
							AppConstants.vFail);
			fail++;
		}
		// verify if Summary section is highlighted or not
		String xpathExpression1 = ExcelUtil.readProps(pageName,
				CustomerConstants.MENU_DEFAULT);
		String selectedMenu = driver.findElement(By.xpath(xpathExpression1))
				.getText();
		if (selectedMenu.equals(propsRW.read(CustomerConstants.LEFTMENUITEM_1))) {
			generateXML
					.logVP("2.2",
							"verify if Summary left menu is highlighted by default or not",
							"Summary left menu is highlighted by default",
							AppConstants.vPass);
			pass++;
		} else {
			generateXML
					.logVP("2.2",
							"verify if Summary left menu is highlighted by default or not",
							"Summary left menu is not highlighted by default",
							AppConstants.vFail);
			fail++;
		}
		// verify left menu items

		String leftMenuItem1 = driver.findElement(
				By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.LEFTMENUITEM_1))).getText();
		String leftMenuItem2 = driver.findElement(
				By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.LEFTMENUITEM_2))).getText();
		String leftMenuItem3 = driver.findElement(
				By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.LEFTMENUITEM_3))).getText();
		String leftMenuItem4 = driver.findElement(
				By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.LEFTMENUITEM_4))).getText();

		String leftMenuItem5 = driver.findElement(
				By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.LEFTMENUITEM_5))).getText();

		String leftMenuItem6 = driver.findElement(
				By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.LEFTMENUITEM_6))).getText();

		String leftMenuItem7 = driver.findElement(
				By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.LEFTMENUITEM_7))).getText();
		//Verification Point- Verify whether left menu contains Summary
		if (leftMenuItem1.equalsIgnoreCase(propsRW
				.read(CustomerConstants.LEFTMENUITEM_1))
		) {

			generateXML
					.logVP("2.3",
							"Verify whether left menu item contains 'Summary'",
							"Leftmenu contains 'Summary'",
							AppConstants.vPass);
			pass++;
		}

		else {
			generateXML
					.logVP("2.3",
							"Verify whether left menu item contains 'Summary'",
							"Leftmenu does not contain 'Summary'",
							AppConstants.vFail);
			fail++;
		}
		
		
		//Verification Point- Verify whether left menu contains Customer Analytics
		if (leftMenuItem2.equalsIgnoreCase(propsRW
				.read(CustomerConstants.LEFTMENUITEM_2))
		) {

			generateXML
					.logVP("2.4",
							"Verify whether left menu item contains 'Customer Analytics'",
							"Leftmenu contains 'Customer Analytics'",
							AppConstants.vPass);
			pass++;
		}

		else {
			generateXML
					.logVP("2.4",
							"Verify whether left menu item contains 'Customer Analytics'",
							"Leftmenu does not contain 'Customer Analytics'",
							AppConstants.vFail);
			fail++;
		}
		
		
		//Verification Point- Verify whether left menu contains Recommendations
				if (leftMenuItem3.equalsIgnoreCase(propsRW
						.read(CustomerConstants.LEFTMENUITEM_3))
				) {

					generateXML
							.logVP("2.5",
									"Verify whether left menu item contains 'Recommendations'",
									"Leftmenu contains 'Recommendations'",
									AppConstants.vPass);
					pass++;
				}

				else {
					generateXML
							.logVP("2.5",
									"Verify whether left menu item contains 'Recommendations'",
									"Leftmenu does not contain 'Recommendations'",
									AppConstants.vFail);
					fail++;
				}
				
		
		
				//Verification Point- Verify whether left menu contains Purchased
				if (leftMenuItem4.equalsIgnoreCase(propsRW
						.read(CustomerConstants.LEFTMENUITEM_4))
				) {

					generateXML
							.logVP("2.6",
									"Verify whether left menu item contains 'Purchased'",
									"Leftmenu contains 'Purchased'",
									AppConstants.vPass);
					pass++;
				}

				else {
					generateXML
							.logVP("2.6",
									"Verify whether left menu item contains 'Purchased'",
									"Leftmenu does not contain 'Purchased'",
									AppConstants.vFail);
					fail++;
				}
				

				//Verification Point- Verify whether left menu contains Browsed
				if (leftMenuItem5.equalsIgnoreCase(propsRW
						.read(CustomerConstants.LEFTMENUITEM_5))
				) {

					generateXML
							.logVP("2.7",
									"Verify whether left menu item contains 'Browsed'",
									"Leftmenu contains 'Browsed'",
									AppConstants.vPass);
					pass++;
				}

				else {
					generateXML
							.logVP("2.7",
									"Verify whether left menu item contains 'Browsed'",
									"Leftmenu does not contain 'Browsed'",
									AppConstants.vFail);
					fail++;
				}
		
				//Verification Point- Verify whether left menu contains Email
				if (leftMenuItem6.equalsIgnoreCase(propsRW
						.read(CustomerConstants.LEFTMENUITEM_6))
				) {

					generateXML
							.logVP("2.8",
									"Verify whether left menu item contains 'Email'",
									"Leftmenu contains 'Email'",
									AppConstants.vPass);
					pass++;
				}

				else {
					generateXML
							.logVP("2.8",
									"Verify whether left menu item contains 'Email'",
									"Leftmenu does not contain 'Email'",
									AppConstants.vFail);
					fail++;
				}
		
				//Verification Point- Verify whether left menu contains Social
				if (leftMenuItem7.equalsIgnoreCase(propsRW
						.read(CustomerConstants.LEFTMENUITEM_7))
				) {

					generateXML
							.logVP("2.9",
									"Verify whether left menu item contains 'Social'",
									"Leftmenu contains 'Social'",
									AppConstants.vPass);
					pass++;
				}

				else {
					generateXML
							.logVP("2.9",
									"Verify whether left menu item contains 'Social'",
									"Leftmenu does not contain 'Social'",
									AppConstants.vFail);
					fail++;
				}
		
		
		
		
		
		
		
		/*if (leftMenuItem1.equalsIgnoreCase(propsRW
				.read(CustomerConstants.LEFTMENUITEM_1))
				&& leftMenuItem2.equalsIgnoreCase(propsRW
						.read(CustomerConstants.LEFTMENUITEM_2))
				&& leftMenuItem3.equalsIgnoreCase(propsRW
						.read(CustomerConstants.LEFTMENUITEM_3))

				&& leftMenuItem4.equalsIgnoreCase(propsRW
						.read(CustomerConstants.LEFTMENUITEM_4))
				&& leftMenuItem5.equalsIgnoreCase(propsRW
						.read(CustomerConstants.LEFTMENUITEM_5))
				&& leftMenuItem6.equalsIgnoreCase(propsRW
						.read(CustomerConstants.LEFTMENUITEM_6))

				&& leftMenuItem7.equalsIgnoreCase(propsRW
						.read(CustomerConstants.LEFTMENUITEM_7))

		) {

			generateXML
					.logVP("2.3",
							"verify if left menu items",
							"leftmenu contains Summary,Customer Analytics, Recommendations, Purchased, Browsed, Email, Social items",
							AppConstants.vPass);
			pass++;
		}

		else {
			generateXML
					.logVP("2.3",
							"verify if left menu items contains Summary,Customer Analytics, Recommendations, Purchased, Browsed, Email, Social items",
							"leftmenu does not contain Summary,Customer Analytics, Recommendations, Purchased, Browsed, Email, Social items",
							AppConstants.vFail);
			fail++;
		}*/

		// verify if left menu items are hyper links

		String tagName1 = driver.findElement(
				By.name((CustomerConstants.SUMMARY))).getTagName();
		String tagName2 = driver.findElement(
				By.name((CustomerConstants.CUSTOMER_ANALYTICS))).getTagName();
		String tagName3 = driver.findElement(
				By.name((CustomerConstants.RECOMMENDATIONS))).getTagName();

		String tagName4 = driver.findElement(
				By.name((CustomerConstants.PURCHASED))).getTagName();

		String tagName5 = driver.findElement(
				By.name((CustomerConstants.BROWSED))).getTagName();
		String tagName6 = driver
				.findElement(By.name((CustomerConstants.EMAIL))).getTagName();

		String tagName8 = driver.findElement(
				By.name((CustomerConstants.PURCHASED_PRODUCTS))).getTagName();
		String tagName9 = driver.findElement(
				By.name((CustomerConstants.VIEWED_ONLY_PRODUCTS))).getTagName();
		String tagName10 = driver.findElement(
				By.name((CustomerConstants.RECENT_VIEWS))).getTagName();
		String tagName11 = driver.findElement(
				By.name((CustomerConstants.ORDER_CONFIRMATION))).getTagName();
		String tagName12 = driver.findElement(
				By.name((CustomerConstants.ITEM_UNAVAILABLE))).getTagName();
		String tagName13 = driver.findElement(
				By.name((CustomerConstants.PRODUCT_RECOMMENDATION)))
				.getTagName();

		WebElement tagName7 = driver.findElement(By
				.xpath(excelRW.readProps(pageName, CustomerConstants.TAG_7)));
		String tag7 = tagName7.getAttribute("class");

		
		
		//Verification Point- Whether left menu item Summary is anchor or not
		if (tagName1.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)
			

		) {
			generateXML.logVP("2.10",
					"Verify if left menu item 'Summary' is hyperlink",
					"Leftmenu item 'Summary' is hyperlink", AppConstants.vPass);
			pass++;
		} else {
			generateXML.logVP("2.10",
					"Verify if left menu item 'Summary' is hyperlink",
					"Leftmenu item 'Summary' is not hyperlink", AppConstants.vFail);
			fail++;
		}
		
		//Verification Point- Whether left menu item Analytics is anchor or not
		if (tagName2.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)) {
			generateXML.logVP("2.11",
					"Verify if left menu item 'Analytics' is hyperlink",
					"Leftmenu item 'Analytics' is hyperlink", AppConstants.vPass);
			pass++;
		} else {
			generateXML.logVP("2.11",
					"Verify if left menu item 'Analytics' is hyperlink",
					"Leftmenu item 'Analytics' is not hyperlink",  AppConstants.vFail);
			fail++;
		}
		
		//Verification Point- Whether left menu item Recommendations is anchor or not
		if (
				 tagName3.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)

		) {
			generateXML.logVP("2.12",
					"Verify if left menu item 'Recommendations' is hyperlink",
					"Leftmenu item 'Recommendations' is hyperlink", AppConstants.vPass);
			pass++;
		} else {
			generateXML.logVP("2.12",
					"Verify if left menu item 'Recommendations' is hyperlink",
					"Leftmenu item 'Recommendations' is not hyperlink", AppConstants.vFail);
			fail++;
		}
		
		
		//Verification Point- Whether left menu item Purchased is anchor or not
				if (
						 tagName4.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)

				) {
					generateXML.logVP("2.13",
							"Verify if left menu item 'Purchased' is hyperlink",
							"Leftmenu item 'Purchased' is hyperlink", AppConstants.vPass);
					pass++;
				} else {
					generateXML.logVP("2.13",
							"Verify if left menu item 'Purchased' is hyperlink",
							"Leftmenu item 'Purchased' is not hyperlink", AppConstants.vFail);
					fail++;
				}
		
				//Verification Point- Whether left menu item Browsed is anchor or not
				if (
						 tagName5.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)

				) {
					generateXML.logVP("2.14",
							"Verify if left menu item 'Browsed' is hyperlink",
							"Leftmenu item 'Browsed' is hyperlink", AppConstants.vPass);
					pass++;
				} else {
					generateXML.logVP("2.14",
							"Verify if left menu item 'Browsed' is hyperlink",
							"Leftmenu item 'Browsed' is not hyperlink", AppConstants.vFail);
					fail++;
				}
		
		
				//Verification Point- Whether left menu item Email is anchor or not
				if (
						 tagName6.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)

				) {
					generateXML.logVP("2.15",
							"Verify if left menu item 'Email' is hyperlink",
							"Leftmenu item 'Email' is hyperlink", AppConstants.vPass);
					pass++;
				} else {
					generateXML.logVP("2.15",
							"Verify if left menu item 'Email' is hyperlink",
							"Leftmenu item 'Email' is not hyperlink", AppConstants.vFail);
					fail++;
				}
		
				//Verification Point- Whether left menu item Purchased is anchor or not
				if (
						 tagName8.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)

				) {
					generateXML.logVP("2.16",
							"Verify if left menu item 'Purchased' is hyperlink",
							"Leftmenu item 'Purchased' is hyperlink", AppConstants.vPass);
					pass++;
				} else {
					generateXML.logVP("2.16",
							"Verify if left menu item 'Purchased' is hyperlink",
							"Leftmenu item 'Purchased' is not hyperlink", AppConstants.vFail);
					fail++;
				}
		
		
				//Verification Point- Whether left menu item Viewed Only is anchor or not
				if (
						 tagName9.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)

				) {
					generateXML.logVP("2.17",
							"Verify if left menu item 'Viewed Only' is hyperlink",
							"Leftmenu item 'Viewed Only' is hyperlink", AppConstants.vPass);
					pass++;
				} else {
					generateXML.logVP("2.17",
							"Verify if left menu item 'Viewed Only' is hyperlink",
							"Leftmenu item 'Viewed Only' is not hyperlink", AppConstants.vFail);
					fail++;
				}
		
		
		
				//Verification Point- Whether left menu item Recent Views is anchor or not
				if (
						 tagName10.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)

				) {
					generateXML.logVP("2.18",
							"Verify if left menu item 'Recent Views' is hyperlink",
							"Leftmenu item 'Recent Views' is hyperlink", AppConstants.vPass);
					pass++;
				} else {
					generateXML.logVP("2.18",
							"Verify if left menu item 'Recent Views' is hyperlink",
							"Leftmenu item 'Recent Views' is not hyperlink", AppConstants.vFail);
					fail++;
				}
				
				//Verification Point- Whether left menu item Order Confirmation is anchor or not
				if (
						 tagName11.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)

				) {
					generateXML.logVP("2.19",
							"Verify if left menu item 'Order Confirmation'  is hyperlink",
							"Leftmenu item 'Order Confirmation'  is hyperlink", AppConstants.vPass);
					pass++;
				} else {
					generateXML.logVP("2.19",
							"Verify if left menu item 'Order Confirmation' is hyperlink",
							"Leftmenu item 'Order Confirmation'  is not hyperlink", AppConstants.vFail);
					fail++;
				}
				
				//Verification Point- Whether left menu item Item Unavailable is anchor or not
				if (
						 tagName12.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)

				) {
					generateXML.logVP("2.20",
							"Verify if left menu item 'Item Unavailable' is hyperlink",
							"Leftmenu item 'Item Unavailable' is hyperlink", AppConstants.vPass);
					pass++;
				} else {
					generateXML.logVP("2.20",
							"Verify if left menu item 'Item Unavailable' is hyperlink",
							"Leftmenu item 'Item Unavailable' is not hyperlink", AppConstants.vFail);
					fail++;
				}
				
				
				//Verification Point- Whether left menu item Product Recommendations is anchor or not
				if (
						 tagName13.equalsIgnoreCase(CustomerConstants.ANCHOR_TAG)

				) {
					generateXML.logVP("2.21",
							"Verify if left menu item 'Product Recommendations' is hyperlink",
							"Leftmenu item 'Product Recommendations' is hyperlink", AppConstants.vPass);
					pass++;
				} else {
					generateXML.logVP("2.21",
							"Verify if left menu item 'Product Recommendations' is hyperlink",
							"Leftmenu item 'Product Recommendations' is not hyperlink", AppConstants.vFail);
					fail++;
				}
				//Verification Point- Whether left menu item Social is disabled 
				if (
						tag7.equalsIgnoreCase(CustomerConstants.DISABLED)

				) {
					generateXML.logVP("2.22",
							"Verify if left menu item 'Social' is disabled",
							"Leftmenu item 'Social' is disabled", AppConstants.vPass);
					pass++;
				} else {
					generateXML.logVP("2.22",
							"Verify if left menu item 'Social' is disabled",
							"Leftmenu item 'Social' is not disabled", AppConstants.vFail);
					fail++;
				}
		
		
		
		
		
		
		
		
		
		
		// verify if orange color slide is shown on click of the left menu items

		List<WebElement> elements = driver.findElements((By.xpath(ExcelUtil
				.readProps(pageName, CustomerConstants.SLIDECOLOR))));
		int count = 0;

		for (int i = 0; i < elements.size(); i++) {
			elements.get(i).click();
			String classArray[] = elements.get(i).getAttribute(CustomerConstants.CLASS)
					.split(" ");
			for (String classElement : classArray)
				if (classElement
						.equalsIgnoreCase(CustomerConstants.SLIDECOLORCLASS)) {
					count++;
				}
			if (count == 16)
				break;
			Thread.sleep(1000);
		}
		System.out.println(count);
		if (count == 16) {
			generateXML
					.logVP("2.23",
							" Verify if on click leftmenu items are highlighted in grey with an orange slide next to it",
							" On click, left menu items are highlighted in grey with an orange slide next to it",
							AppConstants.vPass);
			pass++;
		}

		else {
			generateXML
					.logVP("2.23",
							" Verify if on click leftmenu items are highlighted in grey with an orange slide next to it",
							" On click, left menu items are not highlighted in grey with an orange slide next to it",
							AppConstants.vFail);
			fail++;
		}

	}

	/**
	 * This method is used to verify the UI of search Section Test method
	 * 
	 * @throws Exception
	 */

	@Test
	public void test_A_3() throws InterruptedException {


		// verify search section title
		driver.findElement(
				By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.LEFTMENUITEM_1))).click();

		String xpathExpression = ExcelUtil.readProps(pageName,
				CustomerConstants.CUSTOMER_SEARCH_SECTION_TITLE);

		String title = driver.findElement(By.xpath(xpathExpression)).getText();

		if (title
				.equalsIgnoreCase(propsRW.read(CustomerConstants.SEARCH_TITLE))) {
			generateXML
					.logVP("3.1",
							"Check if search section exists with title 'Search Customer'",
							" Search section exists with title 'Search Customer' ",
							AppConstants.vPass);
			pass++;
		}

		else {
			generateXML
					.logVP("3.1",
							"Check if search section exists with title 'Search Customer'",
							"Search section doesnot exist with title 'Search Customer'",
							AppConstants.vFail);
			fail++;
		}

		// verify search section elements

		try {
			Boolean result = false;
			String searchLable = driver.findElement(
					By.xpath(ExcelUtil.readProps(pageName,
							CustomerConstants.SEARCH_LABEL))).getText();
			if (searchLable.equalsIgnoreCase(propsRW
					.read(CustomerConstants.SERACH_LABLE_TEXT))) // verify label
			{
				result = true;
			}

			driver.findElement(By.id(ExcelUtil.readProps(pageName,
					CustomerConstants.SEARCH_TEXT_FIELD))); // verify texbox
			driver.findElement(By.id(ExcelUtil.readProps(pageName,
					CustomerConstants.GO_BUTTON))); // verify go button

			if (result == true) {
				generateXML
						.logVP("3.2",
								"Verify search section elements",
								" Search section consists of Customer Id label,text box and a go button next to it",
								AppConstants.vPass);
				pass++;

			}

			else {
				generateXML
						.logVP("3.2",
								"Verify search section elements",
								"Search section does not consists of Customer Id label,text box and a go button next to it",
								AppConstants.vFail);
				fail++;
			}

		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	/**
	 * This method is used to verify the search section of customer when no customer Id is entered
	 * @throws InterruptedException
	 */
	@Test
	public void test_A_4() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		driver.findElement(By.name(CustomerConstants.CUSTOMER_ANALYTICS)).click();
		driver.findElement(By.name(CustomerConstants.SUMMARY)).click();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).clear();

		driver.findElement(
				By.id(ExcelUtil.readProps(pageName, CustomerConstants.GO_BUTTON)))
				.click();

		String customerManadatory = driver.findElement(
				By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.CUSTOMER_MANDATORY_MESSAGE))).getText();
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.CUSTOMER_MANDATORY_OK))).click();
		if (customerManadatory.equalsIgnoreCase(propsRW
				.read(CustomerConstants.CUSTOMER_MANDATORY_MESSAGE))) {
			generateXML
					.logVP("4",
							"Verify search functionality when no Customer Id is entered",
							" 'Please enter Customer Id' message is displayed",
							AppConstants.vPass);
			pass++;

		} else {
			generateXML
			.logVP("4",
					"Verify search functionality when no Customer Id is entered",
					" 'Please enter Customer Id' message is  not displayed",
					AppConstants.vFail);
			fail++;

		}
	
	

}
	
	/**
	 * This method is used to verify the search section of customer when no customer Id is entered
	 * @throws InterruptedException
	 */
	@Test
	public void test_A_5() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		driver.findElement(By.name(CustomerConstants.CUSTOMER_ANALYTICS)).click();
		driver.findElement(By.name(CustomerConstants.SUMMARY)).click();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).clear();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).sendKeys((propsRW.read(CustomerConstants.CUSTOMER_INVALID_FORMAT)));
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName, CustomerConstants.GO_BUTTON)))
				.click();

		String customerManadatory = driver.findElement(
				By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.CUSTOMER_INVALID_FORMAT_MESSAGE))).getText();
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.CUSTOMER_INVALID_FORMAT_OK))).click();
		if (customerManadatory.equalsIgnoreCase(propsRW
				.read(CustomerConstants.CUSTOMER_INVALID_FORMAT_MESSAGE))) {
			generateXML
					.logVP("5",
							"Verify search functionality when invalid format of Customer Id is entered",
							" 'only alphanumeric and . _ - characters are allowed' message is displayed",
							AppConstants.vPass);
			pass++;

		} else {
			generateXML
			.logVP("5",
					"Verify search functionality when invalid format of Customer Id is entered",
					" 'only alphanumeric and . _ - characters are allowed' message is  not displayed",
					AppConstants.vFail);
			fail++;

		}
	}
	@Test
	public void test_A_6() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		driver.findElement(By.name(CustomerConstants.SUMMARY)).click();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).clear();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).sendKeys(
				propsRW.read(CustomerConstants.INVALID_CUSTOMERID));
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName, CustomerConstants.GO_BUTTON)))
				.click();

		String invalidCustomerIdResult = driver.findElement(
				By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.CUSTOMER_NOT_FOUND_PATH))).getText();
		if (invalidCustomerIdResult.equalsIgnoreCase(propsRW
				.read(CustomerConstants.CUSTOMER_NOT_FOUND_PATH))) {
			generateXML
					.logVP("6",
							"Verify search functionality when Invalid Customer Id is entered",
							" 'Customer Not Found' message is displayed",
							AppConstants.vPass);
			pass++;

		} else {
			generateXML
			.logVP("6",
					"Verify search functionality when Invalid Customer Id is entered",
					" 'Customer Not Found' message is  not displayed",
					AppConstants.vFail);
			fail++;

		}
	}
		
		

	
	
	
	
	
	@Test
	public void test_A_7() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		driver.findElement(By.name(CustomerConstants.CUSTOMER_ANALYTICS)).click();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).clear();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).sendKeys(
				propsRW.read(CustomerConstants.VALID_CUSTOMERID));
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName, CustomerConstants.GO_BUTTON)))
				.click();
		Thread.sleep(3000);
		
		List<WebElement> list=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ANA_HEADER)));

		int analyticsCount=0;
		for(WebElement webElement:list){
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.CATEGORY_ANALYTICS)){
			String categoryZoomText=driver.findElement(By.id(ExcelUtil.readProps(pageName, CustomerConstants.CATEGORY_ANALYTICS_ZOOM))).getText();
			if(categoryZoomText.equalsIgnoreCase(CustomerConstants.ZOOM)){
				analyticsCount++;
			}
			
		}
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.AGE_ANALYTICS)){
			analyticsCount++;
		}
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.PRICE_ANALYTICS)){
			analyticsCount++;
		}
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.GENDER_ANALYTICS)){
			analyticsCount++;
		}
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.BRAND_ANALYTICS)){
			String brandZoomText=driver.findElement(By.id(ExcelUtil.readProps(pageName, CustomerConstants.BRAND_ANALYTICS_ZOOM))).getText();
			if(brandZoomText.equalsIgnoreCase(CustomerConstants.ZOOM)){
				analyticsCount++;
			}
		}
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.MONETARY_ANALYTICS)){
			analyticsCount++;
		}
		
		
		}
		System.out.println(analyticsCount);
		if(analyticsCount==6){
			generateXML
			.logVP("7",
					"Verify Ui of Customer Analytics screen",
					" Customer Analytics screen is displayed with Category (and Zoom), Brand (and Zoom), Price, Age Analytics, Gender ,Monetary Analytics  ",
					AppConstants.vPass);
			pass++;
		}
		else{
			generateXML
			.logVP("7",
					"Verify Ui of Customer Analytics screen",
					" Customer Analytics screen is not displayed with Category (and Zoom), Brand (and Zoom), Price, Age Analytics, Gender ,Monetary Analytics  ",
					AppConstants.vFail);
			fail++;
		}

	}
		
	

	/**
	 * This method is used to Verify Category Analytics
	 * @throws InterruptedException
	 */
	@Test
	public void test_A_8() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		List<WebElement> titleList=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ANA_HEADER)));
		
		for(WebElement webElement:titleList){
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.CATEGORY_ANALYTICS)){
			
			WebElement categoryAnalytics=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(
					fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))
					&& bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))
					&& fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))
					){
				generateXML.logVP("8.1", "Verify Category Analytics pie chart title in bold/black font and green background color",	"Category Analytics Pie Chart is displayed with title 'Category Analytics' in bold/black font and green background color", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("8.1", "Verify Category Analytics pie chart title in bold/black font and green background color",	"Category Analytics Pie Chart is not displayed with title 'Category Analytics' in bold/black font and green background color", AppConstants.vFail);
				fail++;
			}
			
			//TO DO
			List<WebElement> lstWe=driver.findElement(By.xpath(".//*[@id='analytics1']")).findElement(By.tagName("svg")).findElement(By.tagName("g")).findElements(By.tagName("g"));
			//List<WebElement> lstWe = ((driver.findElement(By.tagName("svg"))).findElement(By.tagName("g"))).findElements(By.tagName("g"));
			
			for (WebElement webElement1 : lstWe) {		    	
				System.out.println("web ele text--"+webElement1.getText()+"-----"+webElement1.getTagName());
				System.out.println("name==="+webElement1.getAttribute("name"));
				System.out.println(webElement1.findElement(By.tagName("title")).getText());
			}
		}
		}

	}
		
	
	/**
	 * This method is used to Verify Age Analytics
	 * @throws InterruptedException
	 */
	@Test
	public void test_A_9() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		List<WebElement> titleList=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ANA_HEADER)));
		
		for(WebElement webElement:titleList){
		
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.AGE_ANALYTICS)){
			WebElement categoryAnalytics=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			
			String bgColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(
					fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))
					&& bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))
					&& fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))
					){
				generateXML.logVP("8.2", "Verify Age Analytics pie chart title in bold/black font and green background color",	"Age Analytics  Pie Chart is displayed with title 'Age Analytics' in bold/black font and green background color", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("8.2", "Verify Age Analytics  pie chart title in bold/black font and green background color",	"Age Analytics  Pie Chart is not displayed with title 'Age Analytics' in bold/black font and green background color", AppConstants.vFail);
				fail++;
			}
		}
		

		}

	}
	
	
	
	/**
	 * This method is used to Verify Price Analytics
	 * @throws InterruptedException
	 */
	@Test
	public void test_B_0() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		List<WebElement> titleList=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ANA_HEADER)));
		
		for(WebElement webElement:titleList){
		
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.PRICE_ANALYTICS)){
			WebElement categoryAnalytics=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			
			String bgColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(
					fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))
					&& bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))
					&& fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))
					){
				generateXML.logVP("8.3", "Verify Price Analytics pie chart title in bold/black font and green background color",	"Price Analytics  Pie Chart is displayed with title 'Price Analytics' in bold/black font and green background color", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("8.3", "Verify Price Analytics  pie chart title in bold/black font and green background color",	"Price Analytics  Pie Chart is not displayed with title 'Price Analytics' in bold/black font and green background color", AppConstants.vFail);
				fail++;
			}
		}
		

		}

	}
	
	
	
	/**
	 * This method is used to Verify Brand Analytics
	 * @throws InterruptedException
	 */
	@Test
	public void test_B_1() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		List<WebElement> titleList=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ANA_HEADER)));
		
		for(WebElement webElement:titleList){
	
		
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.BRAND_ANALYTICS)){
			WebElement categoryAnalytics=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(
					fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))
					&& bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))
					&& fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))
					){
				generateXML.logVP("8.4", "verify Brand Analytics pie chart title in bold/black font and green background color",	"Brand Analytics  Pie Chart is displayed with title 'Brand Analytics' in bold/black font and green background color", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("8.4", "Verify Brand Analytics  pie chart title in bold/black font and green background color",	"Brand Analytics  Pie Chart is not displayed with title 'Brand Analytics' in bold/black font and green background color", AppConstants.vFail);
				fail++;
			}
		}
		

		}

	}
	
	/**
	 * This method is used to Verify Gender Analytics
	 * @throws InterruptedException
	 */
	@Test
	public void test_B_2() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		List<WebElement> titleList=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ANA_HEADER)));
		
		for(WebElement webElement:titleList){
		
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.GENDER_ANALYTICS)){
			WebElement categoryAnalytics=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(
					fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))
					&& bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))
					&& fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))
					){
				generateXML.logVP("8.5", "Verify Gender Analytics pie chart title in bold/black font and green background color",	"Gender Analytics  Pie Chart is displayed with title 'Gender Analytics' in bold/black font and green background color", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("8.5", "Verify Gender Analytics  pie chart title in bold/black font and green background color",	"Gender Analytics  Pie Chart is not displayed with title 'Gender Analytics' in bold/black font and green background color", AppConstants.vFail);
				fail++;
			}
		}

		}

	}
	
	/**
	 * This method is used to Verify Monetary Analytics
	 * @throws InterruptedException
	 */
	@Test
	public void test_B_3() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		List<WebElement> titleList=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ANA_HEADER)));
		
		for(WebElement webElement:titleList){
		if(webElement.getText().equalsIgnoreCase(CustomerConstants.MONETARY_ANALYTICS)){
			WebElement categoryAnalytics=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=categoryAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(
					fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))
					&& bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))
					&& fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))
					){
				generateXML.logVP("8.6", "Verify Monetary Analytics pie chart title in bold/black font and green background color",	"Monetary Analytics  Pie Chart is displayed with title 'Monetary Analytics' in bold/black font and green background color", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("8.6", "verify Monetary Analytics  pie chart title in bold/black font and green background color",	"Monetary Analytics  Pie Chart is not displayed with title 'Monetary Analytics' in bold/black font and green background color", AppConstants.vFail);
				fail++;
			}
		}
		}

	}
	
	
	/**
	 * This method is used to verify Category Analytics Pie Chart UI
	 * @throws InterruptedException
	 * @throws JSONException 
	 */
	@Test
	public void test_B_4() throws InterruptedException, JSONException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		WebElement element=driver.findElement(By.id(ExcelUtil.readProps(pageName, CustomerConstants.CATEGORY_ANALYTICS_PIECHART)));
		String tag=element.findElement(By.tagName("svg")).getTagName();
		if(tag.equalsIgnoreCase("svg")){
			generateXML.logVP("8.7", "Verify Category Analytics pie chart is displayed",	"Category Analytics  Pie Chart is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("8.7", "Verify Category Analytics pie chart is displayed",	"Category Analytics Pie Chart is not displayed", AppConstants.vFail);
			fail++;
		}
		
		//Category Legend
		List<WebElement> categoryLegendFromUI=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.CATEGORY_ANALYTICS_LEGEND)));
		List<String> categoryLegendUIString = new ArrayList<String>();
		for(WebElement w:categoryLegendFromUI){
			//System.out.println("Category Legend=="+w.getText()+"------");
			categoryLegendUIString.add(w.getText());
		}
		//Brand Legend
		List<WebElement> brandLegendFromUI=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.BRAND_ANALYTICS_LEGEND)));
		List<String> brandLegendUIString = new ArrayList<String>();
		for(WebElement w:brandLegendFromUI){
			//System.out.println("Brand Legend==="+w.getText()+"------");
			brandLegendUIString.add(w.getText());
		}
		//Price Legend
		List<WebElement> priceLegendFromUI=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PRICE_ANALYTICS_LEGEND)));
		List<String> priceLegendUIString = new ArrayList<String>();
		for(WebElement w:priceLegendFromUI){
			//System.out.println("Price Legend==="+w.getText()+"------");
			priceLegendUIString.add(w.getText());
		}
		
		
		//Age Legend
		List<WebElement> ageLegendFromUI=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.AGE_ANALYTICS_LEGEND)));
		List<String> ageLegendUIString = new ArrayList<String>();
		for(WebElement w:ageLegendFromUI){
			//System.out.println("Age Legend"+w.getText()+"------");
			ageLegendUIString.add(w.getText());
		}
		//Gender Legend
		List<WebElement> genderLegendFromUI=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.GENDER_ANALYTICS_LEGEND)));
		List<String> genderLegendUIString = new ArrayList<String>();
		for(WebElement w:genderLegendFromUI){
			//System.out.println("Gender Legend=="+w.getText()+"------");
			genderLegendUIString.add(w.getText());
		}
		//Monetary Legend
		List<WebElement> monetaryLegendFromUI=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.MONETARY_ANALYTICS_LEGEND)));
		List<String> monetaryLegendUIString = new ArrayList<String>();
		for(WebElement w:monetaryLegendFromUI){
			//System.out.println("Monetary Legend==="+w.getText()+"------");
			monetaryLegendUIString.add(w.getText());
		}
		
		String jsonFromDB=hBaseUtil.getQualifierValue(CustomerConstants.CUSTOMER_INSIGHT_TABLE,CustomerConstants.DERIVED_INFO_CF,propsRW.read(CustomerConstants.VALID_CUSTOMERID), CustomerConstants.PH_ANALYTICS_CQ, 1);
		//System.out.println(jsonFromDB);
		JSONObject jsonObj=new JSONObject(jsonFromDB);
		JSONArray dimensions=jsonObj.getJSONArray("dimensions");
		Map<String,JSONObject> map=new HashMap<String, JSONObject>();
		//System.out.println(dimensions.length());
		Map<String,String> categoryIdCategoryName=new HashMap<String, String>();
		Map<String,String> categoryIdCategoryValue=new HashMap<String, String>();
		String a[];
		JSONObject globalMap;
		for(int i=0;i<dimensions.length();i++){
			//System.out.println(dimensions.get(i));
			JSONObject json=(JSONObject) dimensions.get(i);
			//System.out.println((json.getString("name")+"====="+json.getJSONObject("globalMap")));
			map.put(json.getString("name"),json.getJSONObject("globalMap"));
			globalMap=json.getJSONObject("globalMap");
			a=globalMap.getNames(globalMap);
			System.out.println(a.length);
			for(int j=0;j<a.length;j++){
				//System.out.println(a[j]+"****"+globalMap.get(a[j]));
				categoryIdCategoryValue.put(a[j], globalMap.get(a[j]).toString());
				String categoryNameFromDB="";
				//TODO 1
				//System.out.println("a[j]===>"+a[j]);
				//System.out.println("Name=====>"+json.getString("name"));
				if(json.getString("name").equalsIgnoreCase("CATEGORY")||json.getString("name").equalsIgnoreCase("MONITORY"))
				categoryNameFromDB=hBaseUtil.getQualifierValue(CustomerConstants.CATEGORY_INSIGHT_TABLE, CustomerConstants.CATEGORY_INFO_CF,a[j],CustomerConstants.DESC_CQ,1);
				
				if(json.getString("name").equalsIgnoreCase("BRAND"))
					categoryNameFromDB=hBaseUtil.getQualifierValue(CustomerConstants.SUPPLIER_CODE_MAPPING_TABLE, CustomerConstants.DESCRIPTION_CF,a[j],CustomerConstants.BRAND_NAME_CQ,1);
				if(!json.getString("name").equalsIgnoreCase("PRICE") ||!json.getString("name").equalsIgnoreCase("AGE")||!json.getString("name").equalsIgnoreCase("GENDER"))
				categoryIdCategoryName.put(a[j], categoryNameFromDB+"("+a[j]+")");
				else{
					//System.out.println("==="+a[j]+"==PRICE=="+globalMap.get(a[j]));
					categoryIdCategoryName.put(a[j], globalMap.get(a[j]).toString());
				}
				//System.out.println(a[j]+"^^^^"+categoryNameFromDB+"("+a[j]+")");
			}
			categoryIdCategoryName.put("0","OTHERS");
		}
		/*System.out.println("=======================categoryIdCategoryName===================");
		for(String s:categoryIdCategoryName.keySet()){
			System.out.println(s+"-->"+categoryIdCategoryName.get(s));
		}
		System.out.println("=======================================================");*/
		
/*		
		System.out.println("categoryIdCategoryValue=========");
		for(String s:categoryIdCategoryValue.keySet()){
			System.out.println(s+"-->"+categoryIdCategoryValue.get(s));
			System.out.println(s+"*****>"+categoryIdCategoryName.get(s));
		}
		System.out.println("===============");*/
		System.out.println("category"+categoryLegendUIString.size()+categoryLegendUIString);
		System.out.println("Brand"+brandLegendUIString.size()+brandLegendUIString);
		System.out.println("age"+ageLegendUIString.size()+ageLegendUIString);
		System.out.println("price"+priceLegendUIString.size()+priceLegendUIString);
		System.out.println("gender"+genderLegendUIString.size()+genderLegendUIString);
		System.out.println("monetary"+monetaryLegendUIString.size()+monetaryLegendUIString);
		int categoryCount=0,brandCount=0,ageCount=0,genderCount=0,monetaryCount=0,priceCount=0;
		int c=9;
		for (int i = 0; i < categoryLegendUIString.size(); i++) {
			if (categoryIdCategoryName.containsValue(categoryLegendUIString
					.get(i))) {
				generateXML.logVP("8."+(c++), "Verify legend of Category Pie Chart",	"Category Pie Chart Legend matches for legend  "+categoryLegendUIString.get(i), AppConstants.vPass);
				pass++;
			}
			else  {
				generateXML.logVP("8."+(c++), "Verify legend of Category Pie Chart",	"Category Pie Chart Legend does not matche for legend  "+categoryLegendUIString.get(i), AppConstants.vFail);
				fail++;
			}
		}
		
		Set<String> keySet=categoryIdCategoryName.keySet();
		for (int i = 0; i < brandLegendFromUI.size(); i++) {
			String passString="",failString="";
			for (String s : keySet) {
				if (categoryIdCategoryName.get(s).contains(
						brandLegendUIString.get(i))
						|| brandLegendUIString.get(i).contains(
								categoryIdCategoryName.get(s))) {
					passString+=brandLegendUIString.get(i);
					
				}
				else{
					failString+=brandLegendUIString.get(i);
					
				}
			}
			if(passString.length()>0){
				generateXML.logVP("8."+(c++), "Verify legend of Brand Pie Chart",	"Brand Pie Chart Legend matches for legend  "+brandLegendUIString.get(i), AppConstants.vPass);
				pass++;
			}
			else {
				generateXML.logVP("8."+(c++), "Verify legend of Brand Pie Chart",	"Brand Pie Chart Legend does not match for legend  "+brandLegendUIString.get(i), AppConstants.vFail);
				fail++;
			}

		}
		
		for (int i = 0; i < ageLegendFromUI.size(); i++) {
			String passString="",failString="";
			for (String s : keySet) {
				if (categoryIdCategoryName.get(s).contains(
						ageLegendUIString.get(i))
						|| ageLegendUIString.get(i).contains(
								categoryIdCategoryName.get(s))) {
					
					passString+=ageLegendUIString.get(i);
					
				}
				else{
					
					failString+=ageLegendUIString.get(i);
				}
			}
			if(passString.length()>0){
				generateXML.logVP("8."+(c++), "Verify legend of Age Pie Chart",	"Age Pie Chart Legend matches for legend  "+ageLegendUIString.get(i), AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("8."+(c++), "Verify legend of Age Pie Chart",	"Age Pie Chart Legend does not match for legend  "+ageLegendUIString.get(i), AppConstants.vFail);
				fail++;
			}
		}
		
		for (int i = 0; i < priceLegendFromUI.size(); i++) {
			String passString="",failString="";
			for (String s : keySet) {
				if (categoryIdCategoryName.get(s).contains(
						priceLegendUIString.get(i))
						|| priceLegendUIString.get(i).contains(
								categoryIdCategoryName.get(s))) {
					passString+=priceLegendUIString.get(i);
				}
				else{
					failString+=priceLegendUIString.get(i);
					
				}
			}
			if(passString.length()>0){
				generateXML.logVP("8."+(c++), "Verify legend of Price Pie Chart",	" Price Pie Chart Legend matches for legend  "+priceLegendUIString.get(i), AppConstants.vPass);
				pass++;
			}
			else {
				generateXML.logVP("8."+(c++), "Verify legend of Price Pie Chart",	" Price Pie Chart Legend does not match for legend  "+priceLegendUIString.get(i), AppConstants.vFail);
				fail++;
				
			}
		}
		
		for (int i = 0; i < monetaryLegendFromUI.size(); i++) {
			String passString="",failString="";
			for (String s : keySet) {
				if (categoryIdCategoryName.get(s).contains(
						monetaryLegendUIString.get(i))
						|| monetaryLegendUIString.get(i).contains(
								categoryIdCategoryName.get(s))) {
					passString+=monetaryLegendUIString.get(i);
				}
				else{
					failString+=monetaryLegendUIString.get(i);
					
				}
			}
			if(passString.length()>0){
				generateXML.logVP("8."+(c++), "Verify legend of Monetary Pie Chart",	" Monetary Pie Chart Legend matches for legend  "+monetaryLegendUIString.get(i), AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("8."+(c++), "Verify legend of Monetary Pie Chart",	" Monetary Pie Chart Legend does not match for legend  "+monetaryLegendUIString.get(i), AppConstants.vFail);
				fail++;
			}
		}
		for (int i = 0; i < genderLegendFromUI.size(); i++) {
			String passString="",failString="";
			for (String s : keySet) {
				if (categoryIdCategoryName.get(s).contains(
						genderLegendUIString.get(i))
						|| genderLegendUIString.get(i).contains(
								categoryIdCategoryName.get(s))) {
					passString+=genderLegendUIString.get(i);
					
					}
				else{
					failString+=genderLegendUIString.get(i);
			
					
				}
			}
			
			if(passString.length()>0){
				generateXML.logVP("8."+(c++), "Verify legend of Gender Pie Chart",	" Gender Pie Chart Legend matches for legend  "+genderLegendUIString.get(i), AppConstants.vPass);
				pass++;
			}
			else {
				generateXML.logVP("8."+(c++), "Verify legend of Gender Pie Chart",	" Gender Pie Chart Legend does not match for legend  "+genderLegendUIString.get(i), AppConstants.vFail);
				fail++;	
			}
		}
			
		
		

		
	}
	
	
	
	/**
	 * This method is used to Verify Brand Analytics Pie Chart UI
	 * @throws InterruptedException
	 */
	@Test
	public void test_B_5() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		WebElement element=driver.findElement(By.id(ExcelUtil.readProps(pageName, CustomerConstants.BRAND_ANALYTICS_PIECHART)));
		String tag=element.findElement(By.tagName("svg")).getTagName();
		if(tag.equalsIgnoreCase("svg")){
			generateXML.logVP("8.8", "Verify Brand Analytics pie chart is displayed",	"Brand Analytics  Pie Chart is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("8.8", "Verify brand Analytics pie chart is displayed",	"Brand Analytics Pie Chart is not displayed", AppConstants.vFail);
			fail++;
		}
	}
	
	/**
	 * This method is used to Verify Price Analytics Pie Chart UI
	 * @throws InterruptedException
	 */
	@Test
	public void test_B_6() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		WebElement element=driver.findElement(By.id(ExcelUtil.readProps(pageName, CustomerConstants.PRICE_ANALYTICS_PIECHART)));
		String tag=element.findElement(By.tagName("svg")).getTagName();
		if(tag.equalsIgnoreCase("svg")){
			generateXML.logVP("8.9", "Verify Price Analytics pie chart is displayed",	"Price Analytics  Pie Chart is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("8.9", "Verify Price Analytics pie chart is displayed",	"Price Analytics Pie Chart is not displayed", AppConstants.vFail);
			fail++;
		}
	}
	
	
	/**
	 * This method is used to Verify Age Analytics Pie Chart UI
	 * @throws InterruptedException
	 */
	@Test
	public void test_B_7() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		WebElement element=driver.findElement(By.id(ExcelUtil.readProps(pageName, CustomerConstants.AGE_ANALYTICS_PIECHART)));
		String tag=element.findElement(By.tagName("svg")).getTagName();
		if(tag.equalsIgnoreCase("svg")){
			generateXML.logVP("9.1", "Verify Age Analytics pie chart is displayed",	"Age Analytics  Pie Chart is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("9.1", "Verify Age Analytics pie chart is displayed",	"Age Analytics Pie Chart is not displayed", AppConstants.vFail);
			fail++;
		}
	}
	

	/**
	 * This method is used to Verify Gender Analytics Pie Chart UI
	 * @throws InterruptedException
	 */
	@Test
	public void test_B_8() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		WebElement element=driver.findElement(By.id(ExcelUtil.readProps(pageName, CustomerConstants.GENDER_ANALYTICS_PIECHART)));
		String tag=element.findElement(By.tagName("svg")).getTagName();
		if(tag.equalsIgnoreCase("svg")){
			generateXML.logVP("9.2", "Verify Gender Analytics pie chart is displayed",	"Gender Analytics  Pie Chart is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("9.2", "Verify Gender Analytics pie chart is displayed",	"Gender Analytics Pie Chart is not displayed", AppConstants.vFail);
			fail++;
		}
	}
	
	
	/**
	 * This method is used to Verify Monetary Analytics Pie Chart UI
	 * @throws InterruptedException
	 */
	@Test
	public void test_B_9() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		WebElement element=driver.findElement(By.id(ExcelUtil.readProps(pageName, CustomerConstants.MONETARY_ANALYTICS_PIECHART)));
		String tag=element.findElement(By.tagName(CustomerConstants.SVG)).getTagName();
		if(tag.equalsIgnoreCase(CustomerConstants.SVG)){
			generateXML.logVP("9.3", "Verify Monetary Analytics pie chart is displayed",	"Monetary Analytics  Pie Chart is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("9.3", "Verify Monetary Analytics pie chart is displayed",	"Monetary Analytics Pie Chart is not displayed", AppConstants.vFail);
			fail++;
		}
	}
	
	
	
	
	/**
	 * This method is used to Verify categoryZoom UI
	 * @throws InterruptedException
	 */
	@Test
	public void test_C_0() throws InterruptedException {
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		driver.findElement(By.id(ExcelUtil.readProps(pageName, CustomerConstants.CATEGORY_ANALYTICS_ZOOM))).click();
		String zoomAnalyticsTitle=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_ZOOM_HEADER_XPATH))).getText();
		
		WebElement brandZoomAnalytics=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
		String fontColor=brandZoomAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
		String bgColor=brandZoomAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
		String fontWeight=brandZoomAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
		
		
		if(zoomAnalyticsTitle.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_ZOOM_HEADER_XPATH))
				
				&&fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))
				&& bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))
				&& fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))
				){
			generateXML.logVP("10.1", "Verify whether Category Zoom Chart is displayed with header 'Zoom Analytics' and font bolder, color black and bg color as green",	"Category Zoom Chart is displayed with header 'Zoom Analytics'and font bolder, color black and bg color as green", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("10.1", "Verify whether Category Zoom Chart is displayed with header 'Zoom Analytics' and font bolder, color black and bg color as green",	"Category Zoom Chart is not displayed with header 'Zoom Analytics' and font bolder, color black and bg color as green", AppConstants.vFail);
			fail++;
		}
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.CLOSE))).click();
	}
	
	

	/**
	 * This method is used to Verify Brand Zoom UI
	 * @throws InterruptedException
	 */
	@Test
	public void test_C_1() throws InterruptedException {
		Thread.sleep(2000);
		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);
		driver.findElement(By.id(ExcelUtil.readProps(pageName, CustomerConstants.BRAND_ANALYTICS_ZOOM))).click();
		String zoomAnalyticsTitle=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_ZOOM_HEADER_XPATH))).getText();
		

		WebElement brandZoomAnalytics=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
		String fontColor=brandZoomAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
		String bgColor=brandZoomAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
		String fontWeight=brandZoomAnalytics.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
		
	
		if(zoomAnalyticsTitle.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_ZOOM_HEADER_XPATH))
				&&fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))
				&& bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))
				&& fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))
				){
			generateXML.logVP("10.2", "Verify whether Brand Zoom Chart is displayed with header 'Zoom Analytics' and font bolder, color black and bg color as green",	"Brand Zoom Chart is displayed with header 'Zoom Analytics' and font bolder, color black and bg color as green", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("10.2", "Verify whether Category Zoom Chart is displayed with header 'Zoom Analytics' and font bolder, color black and bg color as green",	"Brand Zoom Chart is not displayed with header 'Zoom Analytics' and font bolder, color black and bg color as green", AppConstants.vFail);
			fail++;
		}
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.CLOSE))).click();
	
		
	}
	
	/**
	 * This method is used to Verify Customer Recommendations UI
	 * @throws InterruptedException
	 * @throws IOException 
	 */
	@Test
	public void test_C_2() throws InterruptedException, IOException {
		System.out.println("In test CAse C_2");
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).clear();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).sendKeys(propsRW.read(CustomerConstants.VALID_CUSTOMERID));
		driver.findElement(By.name(CustomerConstants.RECOMMENDATIONS)).click();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName, CustomerConstants.GO_BUTTON)))
				.click();
		
		Thread.sleep(10000);
		try{
		String topPicksHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.TOP_PICKS_HEADER))).getText();
		System.out.println(topPicksHeader+"==topPicksHeader");
		if(topPicksHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.TOP_PICKS_HEADER))){
			generateXML.logVP("11.1", "Verify whether Recommendation carousel with header 'Top Picks' is displayed",	"Recommendation carousel with header 'Top Picks' is displayed ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("11.1", "Verify whether Recommendation carousel with header 'Top Picks' is displayed",	"Recommendation carousel with header 'Top Picks' is not displayed ", AppConstants.vFail);
			fail++;
		}
		
		try{
		String newArrivalsHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.NEW_ARRIVALS_HEADER))).getText();
		System.out.println("newArrivalsHeader=="+newArrivalsHeader);
		if(newArrivalsHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.NEW_ARRIVALS_HEADER))){
			generateXML.logVP("11.2", "Verify whether Recommendation carousel with header 'New Arrivals For You' is displayed",	"Recommendation carousel with header 'New Arrivals For You' is displayed ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("11.2", "Verify whether Recommendation carousel with header 'New Arrivals For You' is displayed",	"Recommendation carousel with header 'New Arrivals For You' is not displayed ", AppConstants.vFail);
			fail++;
		}
		
		
		try{
		String topOffersForYouHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.TOP_OFFERS_HEADER))).getText();
		System.out.println(topOffersForYouHeader+"==topOffersForYouHeader");
		if(topOffersForYouHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.TOP_OFFERS_HEADER))){
			generateXML.logVP("11.3", "Verify whether Recommendation carousel with header 'Top Offers For You' is displayed",	"Recommendation carousel with header 'Top Offers For You' is displayed ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("11.3", "Verify whether Recommendation carousel with header 'Top Offers For You' is displayed",	"Recommendation carousel with header 'Top Offers For You' is not displayed ", AppConstants.vFail);
			fail++;
		}
		
		
		try{
		String recommendedForYouInTopBrandsHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.RECOMMENDED_FOR_YOU_HEADER))).getText();
		System.out.println(recommendedForYouInTopBrandsHeader+"==recommendedForYouInTopBrandsHeader");
		if(recommendedForYouInTopBrandsHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.RECOMMENDED_FOR_YOU_HEADER))){
			generateXML.logVP("11.4", "Verify whether Recommendation carousel with header 'Recommended For You In Top Brands' is displayed",	"Recommendation carousel with header 'Recommended For You In Top Brands' is displayed ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("11.4", "Verify whether Recommendation carousel with header 'Recommended For You In Top Brands' is displayed",	"Recommendation carousel with header 'Recommended For You In Top Brands' is not displayed ", AppConstants.vFail);
			fail++;
		}
		try{
		String suggesstedForYouHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.SUGGESSTED_FOR_YOU_HEADER))).getText();
		System.out.println("suggesstedForYouHeader==="+suggesstedForYouHeader);
		if(suggesstedForYouHeader.contains(propsRW.read(CustomerConstants.SUGGESSTED_FOR_YOU_HEADER))){
			generateXML.logVP("11.5", "Verify whether Recommendation carousel with header 'Suggessted For You' is displayed",	"Recommendation carousel with header 'Suggessted For You' is displayed ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("11.5", "Verify whether Recommendation carousel with header 'Suggessted For You' is displayed",	"Recommendation carousel with header 'Suggessted For You' is not displayed ", AppConstants.vFail);
			fail++;
		}
		try{
		String bestSellersHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.BEST_SELLERS_HEADER))).getText();
		System.out.println("bestSellersHeader==="+bestSellersHeader);
		if(bestSellersHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.BEST_SELLERS_HEADER))){
			generateXML.logVP("11.6", "Verify whether Recommendation carousel with header 'Best Sellers' is displayed",	"Recommendation carousel with header 'Best Sellers' is displayed ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("11.6", "Verify whether Recommendation carousel with header 'Best Sellers' is displayed",	"Recommendation carousel with header 'Best Sellers' is not displayed ", AppConstants.vFail);
			fail++;
		}
		
		try{
		String  recommendedBrandsForYouHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.RECOMMEDED_BRANDS_HEADER))).getText();
		System.out.println("recommendedBrandsForYouHeader=="+recommendedBrandsForYouHeader);
		 if(recommendedBrandsForYouHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.RECOMMEDED_BRANDS_HEADER))){
				generateXML.logVP("11.7", "Verify whether Recommendation carousel with header 'Recommended Brands For You' is displayed",	"Recommendation carousel with header 'Recommended Brands For You' is displayed ", AppConstants.vPass);
				pass++;
			}
		}
		catch(Exception e){
			generateXML.logVP("11.7", "Verify whether Recommendation carousel with header 'Recommended Brands For You' is displayed",	"Recommendation carousel with header 'Recommended Brands For You' is not displayed ", AppConstants.vFail);
			fail++;
		}
		
		
		try{
		String bestSellersInCityHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.BEST_SELLERS_IN_CITY_HEADER))).getText();
		System.out.println("bestSellersInCityHeader==="+bestSellersInCityHeader);
		if(bestSellersInCityHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.BEST_SELLERS_IN_CITY_HEADER))){
			generateXML.logVP("11.8", "Verify whether Recommendation carousel with header 'Best Sellers In your City' is displayed",	"Recommendation carousel with header 'Best Sellers In your City' is displayed ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
		
			generateXML.logVP("11.8", "Verify whether Recommendation carousel with header 'Best Sellers In your City' is displayed",	"Recommendation carousel with header 'Best Sellers In your City' is not displayed ", AppConstants.vFail);
			fail++;
		}
		try{
		String replenishmentHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.REPLENISHMENT_HEADER))).getText();
		System.out.println("replenishmentHeader==="+replenishmentHeader);
		if(replenishmentHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.REPLENISHMENT_HEADER))){
			generateXML.logVP("11.9", "Verify whether Recommendation carousel with header 'Replenishment Recommendation' is displayed",	"Recommendation carousel with header 'Replenishment Recommendation' is displayed ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("11.9", "Verify whether Recommendation carousel with header 'Replenishment Recommendation' is displayed",	"Recommendation carousel with header 'Replenishment Recommendation' is not displayed ", AppConstants.vFail);
			fail++;
		}
		
		/*String url="http://blrkec241952d:8282/aham-console-web/aham/CatalogService/getProductDetails?productId=00880457000";
		HttpClient client = new DefaultHttpClient();
		HttpGet request = new HttpGet(url);
		request.addHeader("Accept-Language", "en");
		HttpResponse response = client.execute(request);
		HttpEntity entity = response.getEntity();
		// Get the response
		System.out.println(response.toString()+"==response");
		String line = "";StringBuffer buffer = new StringBuffer();
		BufferedReader rd = new BufferedReader(new InputStreamReader(entity.getContent(),
				Charset.forName("UTF-8")));
		
				while ((line = rd.readLine()) != null) {
					buffer.append(line);
				}
		
		String response1 = buffer.toString();*/
		
		//TODO
		//driver.findElement(By.className("grid-page-parent"));
		
	}

	/**
	 * This method is used to verify header of top Picks carousel (bold + green + black)
	 */
	@Test
	public void test_C_3(){
		WebElement topPicksHeader=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
		String fontColor=topPicksHeader.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
		String bgColor=topPicksHeader.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
		String fontWeight=topPicksHeader.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
		System.out.println(fontColor+"--"+fontWeight+"--"+bgColor);
		if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
			generateXML.logVP("11.10", "Verify whether 'Top Picks' recommendation Carousel is in black font ",	"'Top Picks' recommendation Carousel is displayed in black font ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("11.10", "Verify whether 'Top Picks' recommendation Carousel is in black font ",	"'Top Picks' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
			fail++;
		}
		
		if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
			generateXML.logVP("11.11", "Verify whether 'Top Picks' recommendation Carousel header background color is green ",	"'Top Picks' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("11.11", "Verify whether 'Top Picks' recommendation Carousel  header background color is green ",	"'Top Picks' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
			fail++;
		}

		if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
			generateXML.logVP("11.12", "Verify whether 'Top Picks' recommendation Carousel header is bold ",	"'Top Picks' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("11.12", "Verify whether 'Top Picks' recommendation Carousel  header is bold ",	"'Top Picks' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
			fail++;
		}
		
		
	}
	List<WebElement> titleList=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ANA_HEADER)));
	/**
	 * This method is used to verify header of top Picks carousel (bold + green + black)
	 */
	@Test
	public void test_C_4(){
		
		
		
		
		for(WebElement webElement:titleList){
			
			
		if(webElement.getText().equalsIgnoreCase(propsRW.read(CustomerConstants.TOP_PICKS_HEADER))){
			WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
				generateXML.logVP("11.13", "Verify whether 'Top Picks' recommendation Carousel is in black font ",	"'Top Picks' recommendation Carousel is displayed in black font ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.13", "Verify whether 'Top Picks' recommendation Carousel is in black font ",	"'Top Picks' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
				fail++;
			}
			
			if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
				generateXML.logVP("11.14", "Verify whether 'Top Picks' recommendation Carousel header background color is green ",	"'Top Picks' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.14", "Verify whether 'Top Picks' recommendation Carousel  header background color is green ",	"'Top Picks' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
				fail++;
			}

			if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
				generateXML.logVP("11.15", "Verify whether 'Top Picks' recommendation Carousel header is bold ",	"'Top Picks' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.15", "Verify whether 'Top Picks' recommendation Carousel  header is bold ",	"'Top Picks' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
				fail++;
			}
		}
		}
		
	}
	
	
	/**
	 * This method is used to verify header of top offers carousel (bold + green + black)
	 */
	@Test
	public void test_C_5(){
		
		
		
		
		for(WebElement webElement:titleList){
			
			
		if(webElement.getText().equalsIgnoreCase(propsRW.read(CustomerConstants.TOP_OFFERS_HEADER))){
			WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
				generateXML.logVP("11.16", "Verify whether 'Top Offers' recommendation Carousel is in black font ",	"'Top Offers' recommendation Carousel is displayed in black font ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.16", "Verify whether 'Top Offers' recommendation Carousel is in black font ",	"'Top Offers' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
				fail++;
			}
			
			if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
				generateXML.logVP("11.17", "Verify whether 'Top Offers' recommendation Carousel header background color is green ",	"'Top Offers' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.17", "Verify whether 'Top Offers' recommendation Carousel  header background color is green ",	"'Top Offers' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
				fail++;
			}

			if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
				generateXML.logVP("11.18", "Verify whether 'Top Offers' recommendation Carousel header is bold ",	"'Top Offers' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.18", "Verify whether 'Top Offers' recommendation Carousel  header is bold ",	"'Top Offers' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
				fail++;
			}
		}
		}
		
	}
	/**
	 * This method is used to verify header of new arrivals for you carousel (bold + green + black)
	 */
	@Test
	public void test_C_6(){
		
		
		
		
		for(WebElement webElement:titleList){
			
			
		if(webElement.getText().equalsIgnoreCase(propsRW.read(CustomerConstants.NEW_ARRIVALS_HEADER))){
			WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
				generateXML.logVP("11.19", "Verify whether 'New Arrivals For You' recommendation Carousel is in black font ",	"'New Arrivals For You' recommendation Carousel is displayed in black font ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.19", "Verify whether 'New Arrivals For You' recommendation Carousel is in black font ",	"'New Arrivals For You' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
				fail++;
			}
			
			if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
				generateXML.logVP("11.20", "Verify whether 'New Arrivals For You' recommendation Carousel header background color is green ",	"'New Arrivals For You' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.20", "Verify whether 'New Arrivals For You' recommendation Carousel  header background color is green ",	"'New Arrivals For You' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
				fail++;
			}

			if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
				generateXML.logVP("11.21", "Verify whether 'New Arrivals For You' recommendation Carousel header is bold ",	"'New Arrivals For You' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.21", "Verify whether 'New Arrivals For You' recommendation Carousel  header is bold ",	"'New Arrivals For You' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
				fail++;
			}
		}
		}
		
	}
	/**
	 * This method is used to verify header of Recommended For You In Top Brands carousel (bold + green + black)
	 */
	@Test
	public void test_C_7(){
		
		
		
		
		for(WebElement webElement:titleList){
			
			
		if(webElement.getText().equalsIgnoreCase(propsRW.read(CustomerConstants.RECOMMENDED_FOR_YOU_HEADER))){
			WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
				generateXML.logVP("11.22", "Verify whether 'Recommended For You In Top Brands' recommendation Carousel is in black font ",	"'Recommended For You In Top Brands' recommendation Carousel is displayed in black font ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.22", "Verify whether 'Recommended For You In Top Brands' recommendation Carousel is in black font ",	"'Recommended For You In Top Brands' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
				fail++;
			}
			
			if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
				generateXML.logVP("11.23", "Verify whether 'Recommended For You In Top Brands' recommendation Carousel header background color is green ",	"'Recommended For You In Top Brands' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.23", "Verify whether 'Recommended For You In Top Brands' recommendation Carousel  header background color is green ",	"'Recommended For You In Top Brands' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
				fail++;
			}

			if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
				generateXML.logVP("11.24", "Verify whether 'Recommended For You In Top Brands' recommendation Carousel header is bold ",	"'Recommended For You In Top Brands' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.24", "Verify whether 'Recommended For You In Top Brands' recommendation Carousel  header is bold ",	"'Recommended For You In Top Brandsu' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
				fail++;
			}
		}
		}
		
	}
	/**
	 * This method is used to verify header of Suggested For You carousel (bold + green + black)
	 */
	@Test
	public void test_C_8(){
		
		
		
		
		for(WebElement webElement:titleList){
			
			
		if(webElement.getText().contains(propsRW.read(CustomerConstants.SUGGESSTED_FOR_YOU_HEADER))){
			WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
				generateXML.logVP("11.25", "Verify whether 'Suggested For You' recommendation Carousel is in black font ",	"'Suggested For You' recommendation Carousel is displayed in black font ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.25", "Verify whether 'Suggested For You' recommendation Carousel is in black font ",	"'Suggested For You' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
				fail++;
			}
			
			if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
				generateXML.logVP("11.26", "Verify whether 'Suggested For You' recommendation Carousel header background color is green ",	"'Suggested For You' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.26", "Verify whether 'Suggested For You' recommendation Carousel  header background color is green ",	"'Suggested For You' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
				fail++;
			}

			if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
				generateXML.logVP("11.27", "Verify whether 'Suggested For You' recommendation Carousel header is bold ",	"'Suggested For You' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.27", "Verify whether 'Suggested For You' recommendation Carousel  header is bold ",	"'Suggested For Youu' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
				fail++;
			}
		}
		}
		
	}
	
	/**
	 * This method is used to verify header of Best Sellers carousel (bold + green + black)
	 */
	@Test
	public void test_C_9(){
		
		
		
		
		for(WebElement webElement:titleList){
			
			
		if(webElement.getText().contains(propsRW.read(CustomerConstants.BEST_SELLERS_HEADER))){
			WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
				generateXML.logVP("11.28", "Verify whether 'Best Sellers' recommendation Carousel is in black font ",	"'Best Sellers' recommendation Carousel is displayed in black font ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.28", "Verify whether 'Best Sellers' recommendation Carousel is in black font ",	"'Best Sellers' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
				fail++;
			}
			
			if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
				generateXML.logVP("11.29", "Verify whether 'Best Sellers' recommendation Carousel header background color is green ",	"'Best Sellers' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.29", "Verify whether 'Best Sellers' recommendation Carousel  header background color is green ",	"'Best Sellers' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
				fail++;
			}

			if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
				generateXML.logVP("11.30", "Verify whether 'Best Sellers' recommendation Carousel header is bold ",	"'Best Sellers' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.30", "Verify whether 'Best Sellers' recommendation Carousel  header is bold ",	"'Best Sellersu' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
				fail++;
			}
		}
		}
		
	}
	
	
	
	/**
	 * This method is used to verify header of Recommended Brands For You carousel (bold + green + black)
	 */
	@Test
	public void test_D_0(){
		
		
		
		
		for(WebElement webElement:titleList){
			
			
		if(webElement.getText().contains(propsRW.read(CustomerConstants.RECOMMEDED_BRANDS_HEADER))){
			WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
				generateXML.logVP("11.31", "Verify whether 'Recommended Brands For You' recommendation Carousel is in black font ",	"'Recommended Brands For You' recommendation Carousel is displayed in black font ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.31", "Verify whether 'Recommended Brands For You' recommendation Carousel is in black font ",	"'Recommended Brands For You' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
				fail++;
			}
			
			if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
				generateXML.logVP("11.32", "Verify whether 'Recommended Brands For You' recommendation Carousel header background color is green ",	"'Recommended Brands For You' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.32", "Verify whether 'Recommended Brands For You' recommendation Carousel  header background color is green ",	"'Recommended Brands For You' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
				fail++;
			}

			if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
				generateXML.logVP("11.33", "Verify whether 'Recommended Brands For You' recommendation Carousel header is bold ",	"'Recommended Brands For You' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.33", "Verify whether 'Recommended Brands For You' recommendation Carousel  header is bold ",	"'Recommended Brands For Youu' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
				fail++;
			}
		}
		}
		
	}
	
	
	/**
	 * This method is used to verify header of Best Sellers in Your City carousel (bold + green + black)
	 */
	@Test
	public void test_D_1(){
		
		
		
		
		for(WebElement webElement:titleList){
			
			
		if(webElement.getText().contains(propsRW.read(CustomerConstants.BEST_SELLERS_IN_CITY_HEADER))){
			WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
				generateXML.logVP("11.34", "Verify whether 'Best Sellers in Your City' recommendation Carousel is in black font ",	"'Best Sellers in Your City' recommendation Carousel is displayed in black font ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.34", "Verify whether 'Best Sellers in Your City' recommendation Carousel is in black font ",	"'Best Sellers in Your City' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
				fail++;
			}
			
			if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
				generateXML.logVP("11.35", "Verify whether 'Best Sellers in Your City' recommendation Carousel header background color is green ",	"'Best Sellers in Your City' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.35", "Verify whether 'Best Sellers in Your City' recommendation Carousel  header background color is green ",	"'Best Sellers in Your City' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
				fail++;
			}

			if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
				generateXML.logVP("11.36", "Verify whether 'Best Sellers in Your City' recommendation Carousel header is bold ",	"'Best Sellers in Your City' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.36", "Verify whether 'Best Sellers in Your City' recommendation Carousel  header is bold ",	"'Best Sellers in Your Cityu' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
				fail++;
			}
		}
		}
		
	}
	
	
	
	
	/**
	 * This method is used to verify header of Replenishment Recommendations carousel (bold + green + black)
	 */
	@Test
	public void test_D_2(){
		
		
		
		
		for(WebElement webElement:titleList){
			
			
		if(webElement.getText().contains(propsRW.read(CustomerConstants.REPLENISHMENT_HEADER))){
			WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
			String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
			String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
			String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
			
			if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
				generateXML.logVP("11.37", "Verify whether 'Replenishment Recommendations' recommendation Carousel is in black font ",	"'Replenishment Recommendations' recommendation Carousel is displayed in black font ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.37", "Verify whether 'Replenishment Recommendations' recommendation Carousel is in black font ",	"'Replenishment Recommendations' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
				fail++;
			}
			
			if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
				generateXML.logVP("11.38", "Verify whether 'Replenishment Recommendations' recommendation Carousel header background color is green ",	"'Replenishment Recommendations' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.38", "Verify whether 'Replenishment Recommendations' recommendation Carousel  header background color is green ",	"'Replenishment Recommendations' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
				fail++;
			}

			if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
				generateXML.logVP("11.39", "Verify whether 'Replenishment Recommendations' recommendation Carousel header is bold ",	"'Replenishment Recommendations' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("11.40", "Verify whether 'Replenishment Recommendations' recommendation Carousel  header is bold ",	"'Replenishment Recommendationsu' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
				fail++;
			}
		}
		}
		
	}
	//TODO
	@Test
	public void test_D_3() throws InterruptedException, JSONException{
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).clear();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).sendKeys(propsRW.read(CustomerConstants.VALID_CUSTOMERID));
		driver.findElement(By.name(CustomerConstants.RECOMMENDATIONS)).click();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName, CustomerConstants.GO_BUTTON)))
				.click();
		
		Thread.sleep(10000);
		// verify the products present in Top Picks Carousel

		List<WebElement> productIdsTemp = driver.findElements(By
				.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.TOP_PICKS_PRODUCT_IDS)));
		List<String> productIdsList = new ArrayList<String>();
		// String
		// result=hBaseUtil.getQualifierValue(CustomerConstants.USER_STRATEGIES_TABLE,
		// CustomerConstants.STRATEGIES_CF,propsRW.read(CustomerConstants.VALID_CUSTOMERID),
		// CustomerConstants.S1_CQ, 1);
		// System.out.println(result);
		for (WebElement webElement : productIdsTemp) {
			productIdsList.add(webElement.getAttribute("data-id"));
			// System.out.println("Product Id =="+webElement.getAttribute("data-id"));
		}

		String dbResult = hBaseUtil.getQualifierValue(
				CustomerConstants.USER_STRATEGIES_TABLE,
				CustomerConstants.STRATEGIES_CF,
				propsRW.read(CustomerConstants.VALID_CUSTOMERID),
				CustomerConstants.S1_CQ, 1);
		JSONObject jsonObject = new JSONObject(dbResult);
		org.json.JSONArray j = jsonObject.names();
		Map<String, Double> productsFromDB = new HashMap<String, Double>();
		for (int i = 0; i < j.length(); i++) {
			// System.out.println(j.get(i)+"::::"+jsonObject.get(j.get(i).toString()));
			productsFromDB.put(j.get(i).toString(), Double.parseDouble(String
					.valueOf(jsonObject.get(j.get(i).toString()))));
		}
		// System.out.println(entriesSortedByValues(productsFromDB));
		List<Entry<String, Double>> l = entriesSortedByValues(productsFromDB);
		List<String> dbPidList = new ArrayList<String>();
		Map<String, Double> productIdAndValuesFromDB = new HashMap<String, Double>();
		for (Entry s : l) {
			// System.out.println(s.getKey());
			dbPidList.add(s.getKey().toString());
			productIdAndValuesFromDB.put(s.getKey().toString(),
					Double.parseDouble(s.getValue().toString()));
		}
		int passCount = 0, failCount = 0;
		String failedProdIds = "", passedProdIds = "";
		for (int i = 0; i < productIdsList.size(); i++) {
			// System.out.println(productIdsList.get(i)+"=="+dbPidList.get(i));
			if (productIdsList.get(i).equals(dbPidList.get(i))) {
				passedProdIds += productIdsList.get(i) + "  ";
				++passCount;
			} else {
				failedProdIds += productIdsList.get(i) + "  ";
				++failCount;
			}

		}

		if (passCount == productIdsList.size()) {
			generateXML
					.logVP("11.41",
							"Verify whether product id count (max 50) present in Top Picks Carousel matches with db  ",
							"Product id count present in Top Picks Carousel match with db ",
							AppConstants.vPass);
			pass++;
		}

		if (passedProdIds.length() > 0) {
			generateXML
					.logVP("11.42",
							"Verifying the Product Ids that match with the one displayed in Carousal and DB list  ",
							"The following are the Product Ids that match both in Carousal and DB "
									+ passedProdIds, AppConstants.vPass);
			pass++;
		} else {
			generateXML
					.logVP("11.42",
							"Verifying the Product Ids that match with the one displayed in Carousal and DB list  ",
							"None of the Product Ids match both in Carousal and DB ",
							AppConstants.vFail);
			fail++;

		}

		if (failedProdIds.length() > 0) {
			generateXML
					.logVP("11.43",
							"Verifying the Product Ids that match with the one displayed in Carousal and DB list  ",
							"The following are the Product Ids that match do not match in Carousal and DB "
									+ failedProdIds, AppConstants.vFail);
			fail++;
		} else {
			generateXML
					.logVP("11.43",
							"Verifying the Product Ids that match with the one displayed in Carousal and DB list  ",
							"All the Product Ids match  in Carousal and DB "
									+ failedProdIds, AppConstants.vPass);
			pass++;
		}
		if (failCount == productIdsList.size()) {
			generateXML
					.logVP("11.44",
							"Verify whether product id count (max 50) present in Top Picks Carousel matches with db  ",
							"None of the Product id count present in Top Picks Carousel match with db ",
							AppConstants.vFail);
			fail++;
		}

		List<String> productNamesFromCarousel = new ArrayList<String>();
		for (String s : productIdAndValuesFromDB.keySet()) {
			productNamesFromCarousel.add(productIdAndValuesFromDB.get(s)
					.toString());
		}
		// fetch the names(front end) from the pids retrieved from front end and
		// compare
		String productNameFromDB = "";
		List<WebElement> productNames = driver
				.findElements(By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.TOP_PICKS_PRODUCT_NAMES)));
		// System.out.println("Product Names Size $$$$$===="+productNames.size());
		List<String> productNamesFromConsole = new ArrayList<String>();
		for (WebElement e : productNames) {
			productNamesFromConsole.add(e.getText());
		}
		// System.out.println("productNamesFromConsole Size$$$$=="+productNamesFromConsole.size());
		String passedProductNames = "", failedProductNames = "";
		int passNamesCount = 0, failNamesCount = 0;
		for (int i = 0; i < productIdsList.size(); i++) {
			productNameFromDB = hBaseUtil.getQualifierValue(
					CustomerConstants.PRODUCT_INSIGHT_TABLE,
					CustomerConstants.PRODUCT_DETAILS_CF, dbPidList.get(i),
					CustomerConstants.PRODUCT_NAME_CQ, 1);
			// System.out.println(dbPidList.get(i)+"-->"+productNameFromDB);
			if (productNameFromDB.equalsIgnoreCase(productNamesFromConsole
					.get(i))) {
				// System.out.println("productNameFromDB==>"+productNameFromDB+"==>productNamesFromConsole.get(i)==>"+productNamesFromConsole.get(i));
				passedProductNames += productNamesFromConsole.get(i);
				++passNamesCount;

			} else {
				++failNamesCount;
				failedProductNames += productNamesFromConsole.get(i);
			}
		}

		if (passNamesCount == productNamesFromConsole.size()) {
			generateXML
					.logVP("11.45",
							"Verify whether product names count (max 50) present in Top Picks Carousel matches with db  ",
							"Product names count present in Top Picks Carousel match with db ",
							AppConstants.vPass);
			pass++;
		} else {
			generateXML
					.logVP("11.45",
							"Verify whether product names count (max 50) present in Top Picks Carousel matches with db  ",
							"Product names count present in Top Picks Carousel does not match with db ",
							AppConstants.vFail);
			fail++;
		}

		if (passedProductNames.length() > 0) {
			generateXML
					.logVP("11.46",
							"Verifying the Product names that match with the one displayed in Carousal and DB list  ",
							"The following are the Product names that match both in Carousal and DB "
									+ passedProductNames, AppConstants.vPass);
			pass++;
		} else {
			generateXML
					.logVP("11.46",
							"Verifying the Product names that match with the one displayed in Carousal and DB list  ",
							"None of the Product names match both in Carousal and DB ",
							AppConstants.vFail);
			fail++;

		}

		if (failedProductNames.length() > 0) {
			generateXML
					.logVP("11.47",
							"Verifying the Product names that match with the one displayed in Carousal and DB list  ",
							"The following are the Product names that match do not match in Carousal and DB "
									+ failedProductNames, AppConstants.vFail);
			fail++;
		} else {
			generateXML
					.logVP("11.47",
							"Verifying the Product names that match with the one displayed in Carousal and DB list  ",
							"All the Product names match  in Carousal and DB ",
							AppConstants.vPass);
			pass++;
		}
		if (failNamesCount == productNamesFromConsole.size()) {
			generateXML
					.logVP("11.48",
							"Verify whether product names count (max 50) present in Top Picks Carousel matches with db  ",
							"None of the Product names count present in Top Picks Carousel match with db ",
							AppConstants.vFail);
			fail++;
		} else {
			generateXML
					.logVP("11.48",
							"Verify whether product names count (max 50) present in Top Picks Carousel matches with db  ",
							"All Product names count present in Top Picks Carousel  match with db ",
							AppConstants.vPass);
			pass++;
		}
		
		
		
		
	}
	
	
	
	
	//TODO
	@Test
	public void test_D_4() throws InterruptedException, JSONException{
/*		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).clear();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).sendKeys(propsRW.read(CustomerConstants.VALID_CUSTOMERID));
		driver.findElement(By.name(CustomerConstants.RECOMMENDATIONS)).click();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName, CustomerConstants.GO_BUTTON)))
				.click();
		
		Thread.sleep(10000);*/
		// verify the products present in New Arrivals For you Carousel

		List<WebElement> productIdsTemp = driver.findElements(By
				.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.NEW_ARRIVALS_FOR_YOU_PRODUCT_IDS)));
		List<String> productIdsList = new ArrayList<String>();
		for (WebElement webElement : productIdsTemp) {
			productIdsList.add(webElement.getAttribute("data-id"));
		}

		String dbResult = hBaseUtil.getQualifierValue(
				CustomerConstants.USER_STRATEGIES_TABLE,
				CustomerConstants.STRATEGIES_CF,
				propsRW.read(CustomerConstants.VALID_CUSTOMERID),
				CustomerConstants.S2_CQ, 1);
		JSONObject jsonObject = new JSONObject(dbResult);
		org.json.JSONArray j = jsonObject.names();
		Map<String, Double> productsFromDB = new HashMap<String, Double>();
		for (int i = 0; i < j.length(); i++) {
			productsFromDB.put(j.get(i).toString(), Double.parseDouble(String
					.valueOf(jsonObject.get(j.get(i).toString()))));
		}
		List<Entry<String, Double>> l = entriesSortedByValues(productsFromDB);
		List<String> dbPidList = new ArrayList<String>();
		Map<String, Double> productIdAndValuesFromDB = new HashMap<String, Double>();
		for (Entry s : l) {
			dbPidList.add(s.getKey().toString());
			productIdAndValuesFromDB.put(s.getKey().toString(),
					Double.parseDouble(s.getValue().toString()));
		}
		int passCount = 0, failCount = 0;
		String failedProdIds = "", passedProdIds = "";
		for (int i = 0; i < productIdsList.size(); i++) {
			// System.out.println(productIdsList.get(i)+"=="+dbPidList.get(i));
			if (productIdsList.get(i).equals(dbPidList.get(i))) {
				passedProdIds += productIdsList.get(i) + "  ";
				++passCount;
			} else {
				failedProdIds += productIdsList.get(i) + "  ";
				++failCount;
			}

		}

		if (passCount == productIdsList.size()) {
			generateXML
					.logVP("11.49",
							"Verify whether product id countpresent in New Arrivals For you Carousel matches with db  ",
							"Product id count present in New Arrivals For you Carousel match with db ",
							AppConstants.vPass);
			pass++;
		}

		if (passedProdIds.length() > 0) {
			generateXML
					.logVP("11.50",
							"Verifying the Product Ids that match with the one displayed in Carousal and DB list  ",
							"The following are the Product Ids that match both in Carousal and DB "
									+ passedProdIds, AppConstants.vPass);
			pass++;
		} else {
			generateXML
					.logVP("11.50",
							"Verifying the Product Ids that match with the one displayed in Carousal and DB list  ",
							"None of the Product Ids match both in Carousal and DB ",
							AppConstants.vFail);
			fail++;

		}

		if (failedProdIds.length() > 0) {
			generateXML
					.logVP("11.51",
							"Verifying the Product Ids that match with the one displayed in Carousal and DB list  ",
							"The following are the Product Ids that match do not match in Carousal and DB "
									+ failedProdIds, AppConstants.vFail);
			fail++;
		} else {
			generateXML
					.logVP("11.51",
							"Verifying the Product Ids that match with the one displayed in Carousal and DB list  ",
							"All the Product Ids match  in Carousal and DB "
									+ failedProdIds, AppConstants.vPass);
			pass++;
		}
		if (failCount == productIdsList.size()) {
			generateXML
					.logVP("11.52",
							"Verify whether product id count  present in New Arrivals For you Carousel matches with db  ",
							"None of the Product id count present in New Arrivals For you Carousel match with db ",
							AppConstants.vFail);
			fail++;
		}

		List<String> productNamesFromCarousel = new ArrayList<String>();
		for (String s : productIdAndValuesFromDB.keySet()) {
			productNamesFromCarousel.add(productIdAndValuesFromDB.get(s)
					.toString());
		}
		// fetch the names(front end) from the pids retrieved from front end and
		// compare
		String productNameFromDB = "";
		List<WebElement> productNames = driver
				.findElements(By.xpath(ExcelUtil.readProps(pageName,
						CustomerConstants.TOP_PICKS_PRODUCT_NAMES)));
		// System.out.println("Product Names Size $$$$$===="+productNames.size());
		List<String> productNamesFromConsole = new ArrayList<String>();
		for (WebElement e : productNames) {
			productNamesFromConsole.add(e.getText());
		}
		// System.out.println("productNamesFromConsole Size$$$$=="+productNamesFromConsole.size());
		String passedProductNames = "", failedProductNames = "";
		int passNamesCount = 0, failNamesCount = 0;
		for (int i = 0; i < productIdsList.size(); i++) {
			productNameFromDB = hBaseUtil.getQualifierValue(
					CustomerConstants.PRODUCT_INSIGHT_TABLE,
					CustomerConstants.PRODUCT_DETAILS_CF, dbPidList.get(i),
					CustomerConstants.PRODUCT_NAME_CQ, 1);
			// System.out.println(dbPidList.get(i)+"-->"+productNameFromDB);
			if (productNameFromDB.equalsIgnoreCase(productNamesFromConsole
					.get(i))) {
				// System.out.println("productNameFromDB==>"+productNameFromDB+"==>productNamesFromConsole.get(i)==>"+productNamesFromConsole.get(i));
				passedProductNames += productNamesFromConsole.get(i);
				++passNamesCount;

			} else {
				++failNamesCount;
				failedProductNames += productNamesFromConsole.get(i);
			}
		}

		if (passNamesCount == productNamesFromConsole.size()) {
			generateXML
					.logVP("11.53",
							"Verify whether product names count  present in New Arrivals For you Carousel matches with db  ",
							"Product names count present in New Arrivals For you Carousel match with db ",
							AppConstants.vPass);
			pass++;
		} else {
			generateXML
					.logVP("11.53",
							"Verify whether product names count  present in New Arrivals For you Carousel matches with db  ",
							"Product names count present in New Arrivals For you Carousel does not match with db ",
							AppConstants.vFail);
			fail++;
		}

		if (passedProductNames.length() > 0) {
			generateXML
					.logVP("11.54",
							"Verifying the Product names that match with the one displayed in Carousal and DB list  ",
							"The following are the Product names that match both in Carousal and DB "
									+ passedProductNames, AppConstants.vPass);
			pass++;
		} else {
			generateXML
					.logVP("11.54",
							"Verifying the Product names that match with the one displayed in Carousal and DB list  ",
							"None of the Product names match both in Carousal and DB ",
							AppConstants.vFail);
			fail++;

		}

		if (failedProductNames.length() > 0) {
			generateXML
					.logVP("11.55",
							"Verifying the Product names that match with the one displayed in Carousal and DB list  ",
							"The following are the Product names that match do not match in Carousal and DB "
									+ failedProductNames, AppConstants.vFail);
			fail++;
		} else {
			generateXML
					.logVP("11.55",
							"Verifying the Product names that match with the one displayed in Carousal and DB list  ",
							"All the Product names match  in Carousal and DB ",
							AppConstants.vPass);
			pass++;
		}
		if (failNamesCount == productNamesFromConsole.size()) {
			generateXML
					.logVP("11.56",
							"Verify whether product names count  present in New Arrivals For you Carousel matches with db  ",
							"None of the Product names count present in New Arrivals For you Carousel match with db ",
							AppConstants.vFail);
			fail++;
		} else {
			generateXML
					.logVP("11.56",
							"Verify whether product names count  present in New Arrivals For you Carousel matches with db  ",
							"All Product names count present in New Arrivals For you Carousel  match with db ",
							AppConstants.vPass);
			pass++;
		}
		
		
		
		
	}
	
	
	
	
	
	
	
	
	
	

	static <K, V extends Comparable<? super V>> List<Entry<K, V>> entriesSortedByValues(
			Map<K, V> map) {

		List<Entry<K, V>> sortedEntries = new ArrayList<Entry<K, V>>(
				map.entrySet());

		Collections.sort(sortedEntries, new Comparator<Entry<K, V>>() {
			@Override
			public int compare(Entry<K, V> e1, Entry<K, V> e2) {
				return e2.getValue().compareTo(e1.getValue());
			}
		});

		return sortedEntries;
	}
	public static void main(String a[]) throws JSONException{
		/*hBaseUtil=new HBaseUtil();
		String result=hBaseUtil.getQualifierValue("USER_STRATEGIES", "STRATEGIES","15203767", "S1", 1);
		System.out.println(result);
		JSONObject jsonObject=new JSONObject(result);
		org.json.JSONArray j=jsonObject.names();
		Map<String,Double> productsFromDB=new HashMap<String, Double>();
		for(int i=0;i<j.length();i++){
			//System.out.println(j.get(i)+"::::"+jsonObject.get(j.get(i).toString()));
			productsFromDB.put(j.get(i).toString(), Double.parseDouble(String.valueOf(jsonObject.get(j.get(i).toString()))));
		}*/
		//System.out.println(entriesSortedByValues(productsFromDB));
		//List<Entry<String, Double>> l=entriesSortedByValues(productsFromDB);
	/*	for(Entry s:l){
			System.out.println(s.getKey());
		}*/
		
		
		/*for(int k=0;k<entriesSortedByValues(productsFromDB).size();k++){
			System.out.println(entriesSortedByValues(productsFromDB));
		}*/
		
		
		//System.out.println(jsonObject.length());
		hBaseUtil=new HBaseUtil();
	String s=hBaseUtil.getQualifierValue("CUSTOMER_INSIGHT","DERIVED_INFO","15203767","PH_ANALYTICS",1);
	JSONObject j=new JSONObject(s);
	System.out.println(j);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * This method is used to verify whether 'Recent Purchases' carousel is displayed or not
	 * @throws InterruptedException 
	 * @throws JSONException 
	 */
	@Test
	public void test_D_5() throws InterruptedException, JSONException{
		
		driver.findElement(By.name(CustomerConstants.PURCHASED)).click();
		
		driver.findElement(
				By.name(CustomerConstants.PURCHASED_PRODUCTS))
				.click();
		driver.findElement(
				By.name(CustomerConstants.PURCHASED_PRODUCTS))
				.click();
		driver.findElement(
				By.name(CustomerConstants.PURCHASED_PRODUCTS))
				.click();
		
		Thread.sleep(3000);
		String purchasedProductsHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_HEADER))).getText();
		if(purchasedProductsHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.PURCHASED_PRODUCTS_HEADER))){
			generateXML.logVP("12.1", "Verify whether 'Recent Purchases' recommendation Carousel header is displayed or not ",	"'Recent Purchases' recommendation Carousel is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("12.1", "Verify whether 'Recent Purchases' recommendation Carousel header is displayed or not ",	"'Recent Purchases' recommendation Carousel is not displayed", AppConstants.vFail);
			fail++;
		}
		
		WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
		String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
		String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
		String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
		if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
			generateXML.logVP("12.2", "Verify whether 'Recommended For You In Top Brands' recommendation Carousel is in black font ",	"'Recommended For You In Top Brands' recommendation Carousel is displayed in black font ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("12.2", "Verify whether 'Recent Purchases' recommendation Carousel is in black font ",	"'Recent Purchases' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
			fail++;
		}
		
		if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
			generateXML.logVP("12.3", "Verify whether 'Recent Purchases' recommendation Carousel header background color is green ",	"'Recent Purchases' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("12.3", "Verify whether 'Recent Purchases' recommendation Carousel  header background color is green ",	"'Recent Purchases' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
			fail++;
		}

		if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
			generateXML.logVP("12.4", "Verify whether 'Recent Purchases' recommendation Carousel header is bold ",	"'Recent Purchases' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("12.4", "Verify whether 'Recent Purchases' recommendation Carousel  header is bold ",	"'Recent Purchases' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
			fail++;
		}
		
		//verify left and right arrows
		WebElement leftArrow=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_LEFT)));
		if(leftArrow !=null){
			generateXML.logVP("12.5", "Verify whether 'Recent Purchases' recommendation Carousel has left arrow ",	"'Recent Purchases' recommendation Carousel  has left arrow ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("12.5", "Verify whether 'Recent Purchases' recommendation Carousel  has left arrow ",	"'Recent Purchases' recommendation Carousel  does not have left arrow ",  AppConstants.vFail);
			fail++;
		}
		WebElement rightArrow=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT)));
		if(rightArrow !=null){
			generateXML.logVP("12.6", "Verify whether 'Recent Purchases' recommendation Carousel has right arrow ",	"'Recent Purchases' recommendation Carousel  has right arrow ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("12.6", "Verify whether 'Recent Purchases' recommendation Carousel  has right arrow ",	"'Recent Purchases' recommendation Carousel  does not have  right arrow ",  AppConstants.vFail);
			fail++;
		}
		List<WebElement> allProductsInCarousel=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_ALL)));
		//check whether left arrow is disabled initially
		String leftArrowClass=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_LEFT))).getAttribute(CustomerConstants.CLASS);
		if(leftArrowClass.contains("disabled")){
			generateXML.logVP("12.7", "Verify whether 'Recent Purchases' recommendation Carousel has Left arrow disabled Initially ",	
					"'Recent Purchases' recommendation Carousel  has  Left arrow disabled Initially ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("12.7", "Verify whether 'Recent Purchases' recommendation Carousel has Left arrow disabled Initially ",	
					"'Recent Purchases' recommendation Carousel  does not have Left arrow disabled Initially ", AppConstants.vFail);
			fail++;
		}
		String rightArrowClassAfterClick=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT))).getAttribute(CustomerConstants.CLASS);//if carousel size is less than 5 then right arrow must be disabled
		
		if(allProductsInCarousel.size()<=5){
			generateXML.logVP("12.8", "Verify whether 'Recent Purchases' recommendation Carousel has Right arrow disabled after reaching last product in carousel ",	
					"'Recent Purchases' recommendation Carousel  has  right arrow disabled when last product in carousel is reached ", AppConstants.vPass);
			pass++;
		}
		
		if(allProductsInCarousel.size()>5){
			generateXML.logVP("12.8", "Verify whether 'Recent Purchases' recommendation Carousel has Right arrow enabled as there are more than 5 items  in carousel ",	
					"'Recent Purchases' recommendation Carousel  has  right arrow enabled as there are more than 5 items ", AppConstants.vPass);
			pass++;
		
		
		int noOfRightClicks=(int) (Math.floor(allProductsInCarousel.size()/5)+1);
		for(int i=0;i<=noOfRightClicks;i++){
			
			driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT))).click();;
			Thread.sleep(2000);
		}
		
		//to verify whether right arrow is disabled when last product is reached in carousel
		rightArrowClassAfterClick=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT))).getAttribute(CustomerConstants.CLASS);//if carousel size is less than 5 then right arrow must be disabled

		if(rightArrowClassAfterClick.contains(CustomerConstants.DISABLED)){
			generateXML.logVP("12.9", "Verify whether 'Recent Purchases' recommendation Carousel has Right arrow disabled after reaching last product in carousel ",	
					"'Recent Purchases' recommendation Carousel  has  right arrow disabled when last product in carousel is reached ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("12.9", "Verify whether 'Recent Purchases' recommendation Carousel has Right arrow disabled after reaching last product in carousel ",	
					"'Recent Purchases' recommendation Carousel  has  right arrow is not disabled when last product in carousel is reached ", AppConstants.vFail);
			fail++;
		}
		}
		
		//Recent Purchases Product Ids from UI
		List<WebElement> recentPurchasesPidsFromUI=driver.findElements(By.xpath(excelRW.readProps(pageName, CustomerConstants.RECENT_PURCHASES_PIDS)));
		List<String> recentPurcproductIds=new ArrayList<String>();
		for(WebElement w:recentPurchasesPidsFromUI){
			System.out.println("PPP----"+w.getAttribute("data-id"));
			recentPurcproductIds.add(w.getAttribute("data-id"));
			
		}
		
		String recentPurchaesFromDB=hBaseUtil.getLatestRowKeyDetails(CustomerConstants.CUSTOMER_INSIGHT_TABLE, "PURCHASE_ACTIVITY", propsRW.read(CustomerConstants.VALID_CUSTOMERID), 1).toString();
		System.out.println("recentPurchaesFromDB==="+recentPurchaesFromDB);
		JSONObject recentPurchasesJSON=new JSONObject(recentPurchaesFromDB);
		 Iterator i=recentPurchasesJSON.keys();
		 List<String> pid=new ArrayList<String>();
		while(i.hasNext()){
			//TODO
			//TODO
			//TODO
			String productId=i.next().toString();
			System.out.println("pid---"+productId);
			System.out.println(recentPurchasesJSON.get(productId));
			System.out.println(recentPurchasesJSON.get(productId).toString().substring(0,productId.indexOf("_")).toString());
			
			
			pid.add(recentPurchasesJSON.get(productId).toString().substring(0,productId.indexOf("_")).toString());
			
			
		}
		//TODO IMP
	/*		for(){
				
			}*/
		
	}

	/**
	 * This method is used to verify whether 'Viewed Only Products' carousel is displayed or not
	 * @throws InterruptedException 
	 */
	@Test
	public void test_D_6() throws InterruptedException{
		
		
		driver.findElement(By.name(CustomerConstants.BROWSED)).click();
		
		driver.findElement(
				By.name( CustomerConstants.VIEWED_ONLY_PRODUCTS))
				.click();driver.findElement(
						By.name( CustomerConstants.VIEWED_ONLY_PRODUCTS))
						.click();
		driver.findElement(
				By.name( CustomerConstants.VIEWED_ONLY_PRODUCTS))
				.click();
		Thread.sleep(5000);
		String viewedOnlyProductsHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.VIEWED_ONLY_HEADER))).getText();
		
		if(viewedOnlyProductsHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.VIEWED_ONLY_HEADER))){
			generateXML.logVP("13.1", "Verify whether 'Viewed Only Products' recommendation Carousel header is displayed or not ",	"'Viewed Only Products' recommendation Carousel is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.1", "Verify whether 'Viewed Only Products' recommendation Carousel header is displayed or not ",	"'Viewed Only Products' recommendation Carousel not is displayed", AppConstants.vFail);
			fail++;
		}
		
		
		WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
		String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
		String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
		String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
		if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
			generateXML.logVP("13.2", "Verify whether 'Viewed Only Products' recommendation Carousel is in black font ",	"'Viewed Only Products' recommendation Carousel is displayed in black font ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.2", "Verify whether 'Viewed Only Products' recommendation Carousel is in black font ",	"'Viewed Only Products' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
			fail++;
		}
		
		if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
			generateXML.logVP("13.3", "Verify whether 'Viewed Only Products' recommendation Carousel header background color is green ",	"'Viewed Only Products' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.3", "Verify whether 'Viewed Only Products' recommendation Carousel  header background color is green ",	"'Viewed Only Products' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
			fail++;
		}

		if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
			generateXML.logVP("13.4", "Verify whether 'Viewed Only Products' recommendation Carousel header is bold ",	"'Viewed Only Products' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.4", "Verify whether 'Viewed Only Products' recommendation Carousel  header is bold ",	"'Viewed Only Products' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
			fail++;
		}
		
		//verify left and right arrows
		WebElement leftArrow=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_LEFT)));
		if(leftArrow !=null){
			generateXML.logVP("13.5", "Verify whether 'Viewed Only Products' recommendation Carousel has left arrow ",	"'Viewed Only Products' recommendation Carousel  has left arrow ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.5", "Verify whether 'Viewed Only Products' recommendation Carousel  has left arrow ",	"'Viewed Only Products' recommendation Carousel  does not have left arrow ",  AppConstants.vFail);
			fail++;
		}
		WebElement rightArrow=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT)));
		if(rightArrow !=null){
			generateXML.logVP("13.6", "Verify whether 'Viewed Only Products' recommendation Carousel has right arrow ",	"'Viewed Only Products' recommendation Carousel  has right arrow ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.6", "Verify whether 'Recent Purchases' recommendation Carousel  has right arrow ",	"'Viewed Only Products' recommendation Carousel  does not have  right arrow ",  AppConstants.vFail);
			fail++;
		}
		List<WebElement> allProductsInCarousel=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_ALL)));
		//check whether left arrow is disabled initially
		String leftArrowClass=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_LEFT))).getAttribute(CustomerConstants.CLASS);
		if(leftArrowClass.contains(CustomerConstants.DISABLED)){
			generateXML.logVP("13.7", "Verify whether 'Viewed Only Products' recommendation Carousel has Left arrow disabled Initially ",	
					"'Viewed Only Products' recommendation Carousel  has  Left arrow disabled Initially ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.7", "Verify whether 'Viewed Only Products' recommendation Carousel has Left arrow disabled Initially ",	
					"'Viewed Only Products' recommendation Carousel  does not have Left arrow disabled Initially ", AppConstants.vFail);
			fail++;
		}
		String rightArrowClassAfterClick=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT))).getAttribute(CustomerConstants.CLASS);//if carousel size is less than 5 then right arrow must be disabled
		
		if(allProductsInCarousel.size()<=5){
			generateXML.logVP("13.8", "Verify whether 'Viewed Only Products' recommendation Carousel has Right arrow disabled after reaching last product in carousel ",	
					"'Viewed Only Products' recommendation Carousel  has  right arrow disabled when last product in carousel is reached ", AppConstants.vPass);
			pass++;
		}
		
		if(allProductsInCarousel.size()>5){
			generateXML.logVP("13.8", "Verify whether 'Viewed Only Products' recommendation Carousel has Right arrow enabled as there are more than 5 items  in carousel ",	
					"'Viewed Only Products' recommendation Carousel  has  right arrow enabled as there are more than 5 items ", AppConstants.vPass);
			pass++;
		
		
		int noOfRightClicks=(int) (Math.floor(allProductsInCarousel.size()/5)+4);
		for(int i=0;i<=noOfRightClicks;i++){
			
			driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT))).click();;
			Thread.sleep(2000);
		}
		
		//to verify whether right arrow is disabled when last product is reached in carousel
		rightArrowClassAfterClick=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT))).getAttribute(CustomerConstants.CLASS);//if carousel size is less than 5 then right arrow must be disabled

		if(rightArrowClassAfterClick.contains(CustomerConstants.DISABLED)){
			generateXML.logVP("13.9", "Verify whether 'Viewed Only Products' recommendation Carousel has Right arrow disabled after reaching last product in carousel ",	
					"'Viewed Only Products' recommendation Carousel  has  right arrow disabled when last product in carousel is reached ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.9", "Verify whether 'Viewed Only Products' recommendation Carousel has Right arrow disabled after reaching last product in carousel ",	
					"'Viewed Only Products' recommendation Carousel  has  right arrow is not disabled when last product in carousel is reached ", AppConstants.vFail);
			fail++;
		}
		}
	
		
		//driver.findElement(By.name("Browsed")).click();
		/*driver.findElement(
				By.name( CustomerConstants.VIEWED_ONLY_PRODUCTS))
				.click();
		driver.findElement(
				By.name( CustomerConstants.VIEWED_ONLY_PRODUCTS))
				.click();
		driver.findElement(
				By.name( CustomerConstants.VIEWED_ONLY_PRODUCTS))
				.click();
		Thread.sleep(5000);*/
		/*String viewedOnlyProductsHeader=driver.findElement(By.xpath(excelRW.readProps(pageName, CustomerConstants.VIEWED_ONLY_HEADER))).getText();
		System.out.println(viewedOnlyProductsHeader+"in d4");
		if(viewedOnlyProductsHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.VIEWED_ONLY_HEADER))){
			generateXML.logVP("13.1", "Verify whether 'Viewed Only Products' recommendation Carousel header is displayed or not ",	"'Viewed Only Products' recommendation Carousel is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.1", "Verify whether 'Viewed Only Products' recommendation Carousel header is displayed or not ",	"'Viewed Only Products' recommendation Carousel not is displayed", AppConstants.vFail);
			fail++;
		}*/
		
	/*	WebElement header=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
		String fontColor=header.getCssValue(excelRW.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
		String bgColor=header.getCssValue(excelRW.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
		String fontWeight=header.getCssValue(excelRW.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
		if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
			generateXML.logVP("13.2", "Verify whether 'Viewed Only Products' recommendation Carousel is in black font ",	"'Viewed Only Products' recommendation Carousel is displayed in black font ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.2", "Verify whether 'Viewed Only Products' recommendation Carousel is in black font ",	"'Viewed Only Products' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
			fail++;
		}
		
		if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
			generateXML.logVP("13.3", "Verify whether 'Viewed Only Products' recommendation Carousel header background color is green ",	"'Viewed Only Products' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.3", "Verify whether 'Viewed Only Products' recommendation Carousel  header background color is green ",	"'Viewed Only Products' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
			fail++;
		}

		if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
			generateXML.logVP("13.4", "Verify whether 'Viewed Only Products' recommendation Carousel header is bold ",	"'Viewed Only Products' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("13.4", "Verify whether 'Viewed Only Products' recommendation Carousel  header is bold ",	"'Viewed Only Productsu' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
			fail++;
		}*/
		
	
	}
	
	
	/**
	 * This method is used to verify whether 'Recently Viewed Products' carousel is displayed or not
	 * @throws InterruptedException 
	 */
	@Test
	public void test_D_7() throws InterruptedException{
		
		//driver.findElement(By.name("Browsed")).click();
		driver.findElement(
				By.name( CustomerConstants.RECENT_VIEWS))
				.click();driver.findElement(
						By.name( CustomerConstants.RECENT_VIEWS))
						.click();
		Thread.sleep(3000);
		String recentViewedHeader=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.RECENT_VIEWS_HEADER))).getText();
		if(recentViewedHeader.equalsIgnoreCase(propsRW.read(CustomerConstants.RECENT_VIEWS_HEADER))){
			generateXML.logVP("14.1", "Verify whether 'Recently Viewed Products' recommendation Carousel header is displayed or not ",	"'Recently Viewed Products' recommendation Carousel is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("14.1", "Verify whether 'Recently Viewed Products' recommendation Carousel header is displayed or not ",	"'Recently Viewed Products' recommendation Carousel not is displayed", AppConstants.vFail);
			fail++;
		}
		
		WebElement header=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
		String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
		String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
		String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
		if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
			generateXML.logVP("14.2", "Verify whether 'Recently Viewed Products' recommendation Carousel is in black font ",	"'Viewed Only Products' recommendation Carousel is displayed in black font ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("14.2", "Verify whether 'Recently Viewed Products' recommendation Carousel is in black font ",	"'Recently Viewed Products' recommendation Carousel is not displayed in black font ",  AppConstants.vFail);
			fail++;
		}
		
		if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
			generateXML.logVP("14.3", "Verify whether 'Recently Viewed Products' recommendation Carousel header background color is green ",	"'Recently Viewed Products' recommendation Carousel  header background color is displayed in green ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("14.3", "Verify whether 'Recently Viewed Products' recommendation Carousel  header background color is green ",	"'Recently Viewed Products' recommendation Carousel  header background color is not displayed in green ",  AppConstants.vFail);
			fail++;
		}

		if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
			generateXML.logVP("14.4", "Verify whether 'Recently Viewed Products' recommendation Carousel header is bold ",	"'Recently Viewed Products' recommendation Carousel  header  is displayed in bold ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("14.4", "Verify whether 'Recently Viewed Products' recommendation Carousel  header is bold ",	"'Recently Viewed Productsu' recommendation Carousel  header is not displayed in bold ",  AppConstants.vFail);
			fail++;
		}
		
		//verify left and right arrows
				WebElement leftArrow=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_LEFT)));
				if(leftArrow !=null){
					generateXML.logVP("14.5", "Verify whether 'Recently Viewed Products' recommendation Carousel has left arrow ",	"'Recently Viewed Products' recommendation Carousel  has left arrow ", AppConstants.vPass);
					pass++;
				}
				else{
					generateXML.logVP("14.5", "Verify whether 'Recently Viewed Products' recommendation Carousel  has left arrow ",	"'Recently Viewed Products' recommendation Carousel  does not have left arrow ",  AppConstants.vFail);
					fail++;
				}
				WebElement rightArrow=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT)));
				if(rightArrow !=null){
					generateXML.logVP("14.6", "Verify whether 'Recently Viewed Products' recommendation Carousel has right arrow ",	"'Recently Viewed Products' recommendation Carousel  has right arrow ", AppConstants.vPass);
					pass++;
				}
				else{
					generateXML.logVP("14.6", "Verify whether 'Recent Purchases' recommendation Carousel  has right arrow ",	"'Recently Viewed Products' recommendation Carousel  does not have  right arrow ",  AppConstants.vFail);
					fail++;
				}
				List<WebElement> allProductsInCarousel=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_ALL)));
				//check whether left arrow is disabled initially
				String leftArrowClass=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_LEFT))).getAttribute(CustomerConstants.CLASS);
				if(leftArrowClass.contains("disabled")){
					generateXML.logVP("14.7", "Verify whether 'Recently Viewed Products' recommendation Carousel has Left arrow disabled Initially ",	
							"'Recently Viewed Products' recommendation Carousel  has  Left arrow disabled Initially ", AppConstants.vPass);
					pass++;
				}
				else{
					generateXML.logVP("14.7", "Verify whether 'Recently Viewed Products' recommendation Carousel has Left arrow disabled Initially ",	
							"'Recently Viewed Products' recommendation Carousel  does not have Left arrow disabled Initially ", AppConstants.vFail);
					fail++;
				}
				String rightArrowClassAfterClick=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT))).getAttribute(CustomerConstants.CLASS);//if carousel size is less than 5 then right arrow must be disabled
				
				if(allProductsInCarousel.size()<=5){
					generateXML.logVP("14.8", "Verify whether 'Recently Viewed Products' recommendation Carousel has Right arrow disabled after reaching last product in carousel ",	
							"'Recently Viewed Products' recommendation Carousel  has  right arrow disabled when last product in carousel is reached ", AppConstants.vPass);
					pass++;
				}
				
				if(allProductsInCarousel.size()>5){
					generateXML.logVP("14.8", "Verify whether 'Recent Purchases' recommendation Carousel has Right arrow enabled as there are more than 5 items  in carousel ",	
							"'Recently Viewed Products' recommendation Carousel  has  right arrow enabled as there are more than 5 items ", AppConstants.vPass);
					pass++;
				
				
				int noOfRightClicks=(int) (Math.floor(allProductsInCarousel.size()/5)+4);
				for(int i=0;i<=noOfRightClicks;i++){
					
					driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT))).click();;
					Thread.sleep(2000);
				}
				
				//to verify whether right arrow is disabled when last product is reached in carousel
				rightArrowClassAfterClick=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.PURCHASED_PRODUCTS_RIGHT))).getAttribute(CustomerConstants.CLASS);//if carousel size is less than 5 then right arrow must be disabled

				if(rightArrowClassAfterClick.contains(CustomerConstants.DISABLED)){
					generateXML.logVP("14.9", "Verify whether 'Recently Viewed Products' recommendation Carousel has Right arrow disabled after reaching last product in carousel ",	
							"'Recently Viewed Products' recommendation Carousel  has  right arrow disabled when last product in carousel is reached ", AppConstants.vPass);
					pass++;
				}
				else{
					generateXML.logVP("14.9", "Verify whether 'Recently Viewed Products' recommendation Carousel has Right arrow disabled after reaching last product in carousel ",	
							"'Recently Viewed Products' recommendation Carousel  has  right arrow is not disabled when last product in carousel is reached ", AppConstants.vFail);
					fail++;
				}
				}
			
				
		
		
		
		
		
		
		
		///////////////////////////
	
	}
	
	//TODO
	@Test
	public void test_D_8() throws InterruptedException{
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).clear();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName,
						CustomerConstants.SEARCH_TEXT_FIELD))).sendKeys(propsRW.read(CustomerConstants.VALID_CUSTOMERID));
		driver.findElement(By.name(CustomerConstants.RECOMMENDATIONS)).click();
		driver.findElement(
				By.id(ExcelUtil.readProps(pageName, CustomerConstants.GO_BUTTON)))
				.click();
		
		
/*		List<WebElement> noOfRecomm=driver.findElements(By.xpath(".//*[@class='grid-page-child']/div"));
		System.out.println("Total carousels==="+noOfRecomm.size());*/
		/*Thread.sleep(8000);*/
		
		Map<String,List<String>> finalResult=new LinkedHashMap<String, List<String>>();
		//List<String> productList=new LinkedList<String>();
		List<WebElement> titles=driver.findElements(By.xpath(".//*[@class='grid-page-child']/*/div[1]"));
		List<WebElement> list = new LinkedList<WebElement>();
		List<String> pnameList=new LinkedList<String>();
		System.out.println("Titles Size====="+titles.size());
		for(int i=1;i<=titles.size();i++){
			int count=0;
			String failed="";
			pnameList=new LinkedList<String>();
			list=driver.findElements(By.xpath(".//*[@class='grid-page-child']/div["+i+"]/*/*/*/ul/li/a/h4"));
			System.out.println("in loop size=="+list.size());
			for(WebElement e:list){
				
				pnameList.add(e.getText());
				e.click();
				//Thread.sleep(2000);
				driver.findElement(By.xpath(".//*[@class='overlay-container']")).click();
				String name=driver.findElement(By.xpath(".//*[@class='tablecontainer']//table//tr[1]/td[3]")).getText();
				
			

				//System.out.println("name**************"+name +"getText*************"+e.getText());
				if(e.getText().equalsIgnoreCase(name))
				{
					count++;
				}
				else
				{
					failed=failed+" "+e.getText();
				}
				//driver.findElement(By.xpath(".//*[@class='tablecontainer']//table//tr[1]/td[3]")).sendKeys(Keys.ESCAPE);
				driver.findElement(By.id("hider")).sendKeys(Keys.ESCAPE);
			}
			//driver.findElement(By.id("close")).click();
				int count1=0;
				int vpCount=0;
				System.out.println("coumt***************"+count+" size*********"+pnameList.size());
				if(count==pnameList.size())
				{
					generateXML.logVP("15."+ (++vpCount), "verify if product details page is displayed on clicking the products in '"+titles.get(count1).getText()+"' section " ,"product details page is displayed for all tge elements", AppConstants.vPass); 
					pass++;
				}
				else
				{
					generateXML.logVP("15."+ ++(vpCount), "verify if product details page is displayed on clicking the products in '"+titles.get(count1).getText()+"' section " ,"product details page is not displayed for the products "+failed, AppConstants.vFail); 
					fail++;
				}
				count1++;
				finalResult.put(titles.get(i-1).getText(), pnameList);
				//pnameList.clear();
				//list.clear();
		}
		
		
		
		
		
		for(String s1:finalResult.keySet()){
			System.out.println("============================");
			System.out.println("carname=-------"+s1);
			List<String> l=finalResult.get(s1);
			for(String text:l){
				System.out.println("values===="+text);
				
			}
			System.out.println("============================");
		}
		
		//verify if product names are hyperlinks
	}
	
	
	/**
	 * This method is to verify UI of Email -> Order Confirmation
	 * @throws InterruptedException 
	 */
	@Test
	public void test_D_9() throws InterruptedException{
		
		driver.findElement(
				By.name(CustomerConstants.EMAIL))
				.click();
		driver.findElement(
				By.name(CustomerConstants.ORDER_CONFIRMATION))
				.click();
		driver.findElement(
				By.name(CustomerConstants.ORDER_CONFIRMATION))
				.click();
		
		Thread.sleep(1000);
		
		String orderConfirmationTitle=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ORDER_CONFIRMATION_XPATH))).getText();				
		if(orderConfirmationTitle.equalsIgnoreCase(propsRW.read(CustomerConstants.ORDER_CONFIRMATION_XPATH))){
			generateXML.logVP("16.1", " Verify if Order Confirmation page is displayed with header 'Order Confirmation' " ,"Order Confirmation page is displayed with header 'Order Confirmation'", AppConstants.vPass); 
			pass++;
			
		}
		else{
			generateXML.logVP("16.1", " Verify if Order Confirmation page is displayed with header 'Order Confirmation' " ,"Order Confirmation page is not displayed with header 'Order Confirmation'", AppConstants.vFail); 
			fail++;
		}
		
		
		
		WebElement header=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ORDER_CONF_HEADER)));
		//.//*[@id='ModulesContent']/div[2]/div[3]/div[2]/*/*/*/div[1]
		//WebElement header=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
		String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
		String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
		String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
		System.out.println(fontColor+"--"+fontWeight+"---"+bgColor);
		if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
			generateXML.logVP("16.2", "Verify whether 'Order Confirmation' title is in black font ",	"'Order Confirmation' title in black font ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("16.2", "Verify whether 'Order Confirmation' title is not in black font ",	"'Order Confirmation' title in black font ", AppConstants.vFail);
			fail++;
		}
		
		if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
			generateXML.logVP("16.3", "Verify whether 'Order Confirmation'  header background color is green ",	"'Order Confirmation'   header background color is displayed in green ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("16.3", "Verify whether 'Order Confirmation'  header background color is green ",	"'Order Confirmation'   header background color is not displayed in green ", AppConstants.vFail);
			fail++;
		}

		if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
			generateXML.logVP("16.4", "Verify whether 'Order Confirmation'  header is bold ",	"'Order Confirmation'  header  is displayed in bold ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("16.4", "Verify whether 'Order Confirmation'  header is bold ",	"'Order Confirmation'  header  is not displayed in bold ", AppConstants.vFail);
			fail++;
		}
		//check whether order status is confirmed
		//WebElement el=driver.findElement(By.tagName(CustomerConstants.IFRAME));
		WebElement el=driver.findElement(By.xpath(".//*[@id='ModulesContent']/div[2]/div[3]/div[2]/div/div/div/div[2]/iframe"));
		driver.switchTo().frame(el);
		try{
		List<WebElement> list=driver.findElements(By.tagName(CustomerConstants.B));
		List<String> tags=new ArrayList<String>();
		for(WebElement webElement:list){
			System.out.println(webElement.getText()+"******TEXT");
		tags.add(webElement.getText());
		}
		System.out.println(tags.contains("Your order has been confirmed.")+"---->>Check");
		if(tags.contains(CustomerConstants.ORDER_STATUS_STRING)){
			generateXML.logVP("16.5", "Verify whether 'Order Confirmation'  status is 'Confirmed' ",	"'Order Confirmation'  status  is displayed as 'confirmed' ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("16.5", "Verify whether 'Order Confirmation'  status is 'Confirmed' ",	"'Order Confirmation'  status  is not displayed as 'confirmed' ", AppConstants.vFail);
			fail++;

		}
		
		/*String orderStatus=driver.findElement(By.xpath(".//table/tbody/tr/td/table[1]/tbody/tr[1]/td/p[2]/b")).getText();
		System.out.println("orderStatus=="+orderStatus);
		if(orderStatus.contains("confirmed")){
			generateXML.logVP("16.5", "Verify whether 'Order Confirmation'  status is 'Confirmed' ",	"'Order Confirmation'  status  is displayed as 'confirmed' ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("16.5", "Verify whether 'Order Confirmation'  status is 'Confirmed' ",	"'Order Confirmation'  status  is not displayed as 'confirmed' ", AppConstants.vFail);
			fail++;

		}*/
		
		//Check whether scroll bar is present or not
		try{
		String scroll=driver.findElement(By.tagName(CustomerConstants.IFRAME)).getAttribute(CustomerConstants.SCROLL);
		System.out.println("Scroll value=="+scroll);
		if(scroll.equalsIgnoreCase(CustomerConstants.YES)){
			generateXML.logVP("16.8", "Verify whether 'Order Confirmation'  page has scroll bar ",	"'Order Confirmation'  has  scroll bar' ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("16.8", "Verify whether 'Order Confirmation'  page has scroll bar ",	"'Order Confirmation'  has no scroll bar' ", AppConstants.vFail);
			fail++;

		}
		
		//check whether you might also like is present or not
		try{
		String title=driver.findElement(By.tagName(CustomerConstants.H2)).getText();
		System.out.println("You might car title====="+title);
		if(title.trim().contains(CustomerConstants.LIKE)){
			generateXML.logVP("16.9", "Verify whether 'Order Confirmation'  page 'You might also like' recommendation title ",	"'Order Confirmation'  has 'you might also like recommendations'' ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("16.9", "Verify whether 'Order Confirmation'  page 'You might also like' recommendation title ",	"'Order Confirmation'  does not have 'you might also like recommendations'' ", AppConstants.vFail);
			fail++;
		}
		
	}
	
	
	/**
	 * This method is to verify UI of Email -> Item Unavailable
	 * @throws InterruptedException 
	 */
	@Test
	public void test_E_0() throws InterruptedException{
		
		/*driver.findElement(
				By.name(CustomerConstants.EMAIL))
				.click();*/
		driver.findElement(
				By.name(CustomerConstants.ITEM_UNAVAILABLE))
				.click();
		driver.findElement(
				By.name(CustomerConstants.ITEM_UNAVAILABLE))
				.click();
		
		Thread.sleep(1000);
		
		String itemUnavailableTitle=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ITEM_UNAVAILABLE_XPATH))).getText();				
		System.out.println("Item Unavailable==="+itemUnavailableTitle);
		if(itemUnavailableTitle.equalsIgnoreCase(propsRW.read(CustomerConstants.ORDER_CONFIRMATION_XPATH))){
			generateXML.logVP("17.1", " Verify if Item Unavailable page is displayed with header 'Item Unavailable' " ,"Item Unavailable page is displayed with header 'Item Unavailable'", AppConstants.vPass); 
			pass++;
			
		}
		else{
			generateXML.logVP("17.1", " Verify if Item Unavailable page is displayed with header 'Item Unavailable' " ,"Item Unavailable page is not displayed with header 'Item Unavailable'", AppConstants.vFail); 
			fail++;
		}
		
		
		
		WebElement header=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ORDER_CONF_HEADER)));
		//.//*[@id='ModulesContent']/div[2]/div[3]/div[2]/*/*/*/div[1]
		//WebElement header=driver.findElement(By.cssSelector(excelRW.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_CLASS)));
		String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
		String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
		String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
		System.out.println(fontColor+"--"+fontWeight+"---"+bgColor);
		if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
			generateXML.logVP("17.2", "Verify whether 'Item Unavailable' title is in black font ",	"'Item Unavailable' title in black font ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("17.2", "Verify whether 'Item Unavailable' title is not in black font ",	"'Item Unavailable' title in black font ", AppConstants.vFail);
			fail++;
		}
		
		if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
			generateXML.logVP("17.3", "Verify whether 'Item Unavailable'  header background color is green ",	"'Item Unavailable'   header background color is displayed in green ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("17.3", "Verify whether 'Item Unavailable'  header background color is green ",	"'Item Unavailable'   header background color is not displayed in green ", AppConstants.vFail);
			fail++;
		}

		if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
			generateXML.logVP("17.4", "Verify whether 'Item Unavailable'  header is bold ",	"'Item Unavailable'  header  is displayed in bold ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("17.4", "Verify whether 'Item Unavailable'  header is bold ",	"'Item Unavailable'  header  is not displayed in bold ", AppConstants.vFail);
			fail++;
		}
		//   
		/*String orderStatus=driver.findElement(By.xpath(".//table/tbody/tr/td/table[1]/tbody/tr[1]/td/p[2]/b")).getText();
		System.out.println("orderStatus=="+orderStatus);
		if(orderStatus.contains("confirmed")){
			generateXML.logVP("16.5", "Verify whether 'Order Confirmation'  status is 'Confirmed' ",	"'Order Confirmation'  status  is displayed as 'confirmed' ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("16.5", "Verify whether 'Order Confirmation'  status is 'Confirmed' ",	"'Order Confirmation'  status  is not displayed as 'confirmed' ", AppConstants.vFail);
			fail++;

		}*/
		WebElement el=driver.findElement(By.tagName(CustomerConstants.IFRAME));
		driver.switchTo().frame(el);
		//Check whether scroll bar is present or not
		try{
		String scroll=driver.findElement(By.tagName(CustomerConstants.IFRAME)).getAttribute(CustomerConstants.SCROLL);
		System.out.println("Scroll value=="+scroll);
		if(scroll.equalsIgnoreCase(CustomerConstants.YES)){
			generateXML.logVP("16.6", "Verify whether 'Item Unavailable' page has scroll bar ",	"'Item Unavailable'  has  scroll bar' ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("16.6", "Verify whether 'Item Unavailable'  page has scroll bar ",	"'Item Unavailable'  has no scroll bar' ", AppConstants.vPass);
			pass++;

		}
		
		//check whether you might also like is present or not
		try{
		List<WebElement> allTags=driver.findElements(By.tagName(CustomerConstants.B));
		List<String> list=new ArrayList<String>();
		for(WebElement e:allTags){
			list.add(e.getText());
			System.out.println("ITEM UNAVIALABLE_____________"+e.getText());
			
		}
		if(list.contains(CustomerConstants.SUGGESTED_FOR_YOU_STRING)){
			generateXML.logVP("16.7", "Verify whether 'Item Unavailable'  page 'Suggested For You' recommendation title ",	"'Item Unavailable'  has 'Suggested For You recommendations'' ", AppConstants.vPass);
			pass++;
		}
		}
		catch(Exception e){
			generateXML.logVP("16.7", "Verify whether 'Item Unavailable'  page 'Suggested For You:' recommendation title ",	"'Item Unavailable'  does not have 'Suggested For You recommendations'' ", AppConstants.vFail);
			fail++;
		}
	}
	
	
	
	
	
	/**
	 * This method is to verify UI of Email -> Email Product Recommendation
	 * @throws InterruptedException 
	 */
	@Test
	public void test_E_1() throws InterruptedException{
		
		/*driver.findElement(
				By.name(CustomerConstants.EMAIL))
				.click();*/
		driver.findElement(
				By.name(CustomerConstants.PRODUCT_RECOMMENDATION))
				.click();
		driver.findElement(
				By.name(CustomerConstants.PRODUCT_RECOMMENDATION))
				.click();
		
		Thread.sleep(1000);
		
		String itemUnavailableTitle=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.EMAIL_PRODUCT_RECOMMENDATION_XPATH))).getText();				
		System.out.println("Email Product Recommendation==="+itemUnavailableTitle);
		if(itemUnavailableTitle.equalsIgnoreCase(propsRW.read(CustomerConstants.ORDER_CONFIRMATION_XPATH))){
			generateXML.logVP("18.1", " Verify if Email Product Recommendation page is displayed with header 'Email Product Recommendation' " ,"Email Product Recommendation page is displayed with header 'Email Product Recommendation'", AppConstants.vPass); 
			pass++;
			
		}
		else{
			generateXML.logVP("18.1", " Verify if Email Product Recommendation page is displayed with header 'Email Product Recommendation' " ,"Email Product Recommendation page is not displayed with header 'Email Product Recommendation'", AppConstants.vFail); 
			fail++;
		}
		
		WebElement header=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, CustomerConstants.ORDER_CONF_HEADER)));
		String fontColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_FONT_COLOR)); //Verify font color
		String bgColor=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_TITLE_BG_COLOR));
		String fontWeight=header.getCssValue(ExcelUtil.readProps(pageName, CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT));
		System.out.println(fontColor+"--"+fontWeight+"---"+bgColor);
		if(fontColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_FONT_COLOR))){
			generateXML.logVP("18.2", "Verify whether 'Email Product Recommendation' title is in black font ",	"'Email Product Recommendation' title in black font ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("18.2", "Verify whether 'Email Product Recommendation' title is not in black font ",	"'Email Product Recommendation' title in black font ", AppConstants.vFail);
			fail++;
		}
		
		if(bgColor.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_TITLE_BG_COLOR))){
			generateXML.logVP("18.3", "Verify whether 'Email Product Recommendation'  header background color is green ",	"'Email Product Recommendation'   header background color is displayed in green ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("18.3", "Verify whether 'Email Product Recommendation'  header background color is green ",	"'Email Product Recommendation'   header background color is not displayed in green ", AppConstants.vFail);
			fail++;
		}

		if(fontWeight.equalsIgnoreCase(propsRW.read(CustomerConstants.ANALYTICS_CHART_TITLE_FONTWEIGHT))){
			generateXML.logVP("18.4", "Verify whether 'Email Product Recommendation'  header is bold ",	"'Email Product Recommendation'  header  is displayed in bold ", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("18.4", "Verify whether 'Email Product Recommendation'  header is bold ",	"'Email Product Recommendation'  header  is not displayed in bold ", AppConstants.vFail);
			fail++;
		}
		WebElement el=driver.findElement(By.tagName(CustomerConstants.IFRAME));
		driver.switchTo().frame(el);
		//check whether questions is present
				try{
					List<WebElement> list=driver.findElements(By.tagName(CustomerConstants.B));
					List<String> tags=new ArrayList<String>();
					for(WebElement webElement:list){
					tags.add(webElement.getText());
					}
					System.out.println(tags.contains("Your order has been confirmed.")+"---->>Check");
					if(tags.contains(CustomerConstants.QUESTIONS)){
						generateXML.logVP("18.5", "Verify whether 'Email Product Recommendation'  page has Questions at the bottom ",	"'Email Product Recommendation' has Questions at bottom ", AppConstants.vPass);
						pass++;
					}
					}
					catch(Exception e){
						generateXML.logVP("18.5", "Verify whether 'Email Product Recommendation'  page has Questions at the bottom ",	"'Email Product Recommendation'  does not have Questions at bottom ", AppConstants.vFail);
						fail++;

					}
				
				//check for whether privacy is present
				
				try{
					List<WebElement> list=driver.findElements(By.tagName(CustomerConstants.B));
					List<String> tags=new ArrayList<String>();
					for(WebElement webElement:list){
					tags.add(webElement.getText());
					}
					if(tags.contains("Your privacy:")){
						generateXML.logVP("18.6", "Verify whether 'Email Product Recommendation'  page has Privacy at the bottom ",	"'Email Product Recommendation' has Privacy at bottom ", AppConstants.vPass);
						pass++;
					}
					}
					catch(Exception e){
						generateXML.logVP("18.6", "Verify whether 'Email Product Recommendation'  page has Privacy at the bottom ",	"'Email Product Recommendation'  does not have Privacy at bottom ", AppConstants.vFail);
						fail++;

					}
				//check whether  Recommendations For You is present or not
				try{
				String title=driver.findElement(By.tagName(CustomerConstants.H2)).getText();
				System.out.println("You might car title====="+title);
				if(title.trim().contains(CustomerConstants.RECOMMENDATIONS_STRING)){
					generateXML.logVP("18.7", "Verify whether 'Email Product Recommendation'  page ' Recommendations For You' recommendation title ",	"'Email Product Recommendation' has Recommendations For You recommendations'' ", AppConstants.vPass);
					pass++;
				}
				}
				catch(Exception e){
					generateXML.logVP("18.7", "Verify whether 'Email Product Recommendation'  page ' Recommendations For You' recommendation title ",	"'Email Product Recommendation' does not have ' Recommendations For You recommendations'' ", AppConstants.vFail);
					fail++;
				}
	}
	
	@Test
	public void test_E_2() throws InterruptedException{

		/*driver.findElement(
				By.name(CustomerConstants.SUMMARY))
				.click();*/
		//click the customer Analytics screen
		driver.findElement(By.name(CustomerConstants.CUSTOMER_ANALYTICS)).click();
		Thread.sleep(3000);
		List<WebElement> headersList=driver.findElements(By.xpath(".//*[@class='newheader']"));
		List<String> titles=new ArrayList<String>();
		for(WebElement e:headersList){
			titles.add(e.getText());
		}
		if(titles.contains(CustomerConstants.CATEGORY_ANALYTICS)){

			generateXML.logVP("19", "On random Clicks , and click of Customer Analytics verify whether Corresponding screen is shown ",	"Customer Analytics Screen is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("19", "On random Clicks , and click of Customer Analytics verify whether Corresponding screen is shown ",	"Customer Analytics Screen is not displayed", AppConstants.vFail);
			fail++;
		}
		/*//click of product Recommendation
		
		driver.findElement(
				By.name(CustomerConstants.RECOMMENDATIONS))
				.click();
		Thread.sleep(10000);
		List<WebElement> recommendationHeaders=driver.findElements(By.xpath(".//*[@class='newheader']"));
		List<String> titlesList=new ArrayList<String>();
		for(WebElement e:recommendationHeaders){
			titlesList.add(e.getText());
		}
		
		if(titlesList.contains("Top")||titlesList.contains("New")||titlesList.contains("Suggested")||titlesList.contains("Best")){

			generateXML.logVP("19.2", "On random Clicks , and click of Customer Recommendations verify whether Corresponding screen is shown ",	"Customer Recommendation Screen is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("19.2", "On random Clicks , and click of Customer Recommendation verify whether Corresponding screen is shown ",	"Customer Recommendation Screen is not displayed", AppConstants.vFail);
			fail++;
		}
		//click of purchased products
		driver.findElement(By.name("Purchased")).click();
		
		driver.findElement(
				By.name(CustomerConstants.PURCHASED_PRODUCTS))
				.click();
		Thread.sleep(3000);
		
		List<WebElement> purchasedProdHeader=driver.findElements(By.xpath(".//*[@class='newheader']"));
		List<String> purchaseProdTitles=new ArrayList<String>();
		for(WebElement e:purchasedProdHeader){
			purchaseProdTitles.add(e.getText());
		}
		
		if(purchaseProdTitles.contains("Purchases")){

			generateXML.logVP("19.3", "On random Clicks , and click of Purchased Products verify whether Corresponding screen is shown ",	"Purchased Products Screen is displayed", AppConstants.vPass);
			pass++;
		}
		else{
			generateXML.logVP("19.3", "On random Clicks , and click of Purchased Products verify whether Corresponding screen is shown ",	"Purchased Products Screen is not displayed", AppConstants.vFail);
			fail++;
		}
		
		//click of Viewed only
		
			driver.findElement(By.name("Browsed")).click();
		
			driver.findElement(
				By.name( CustomerConstants.VIEWED_ONLY_PRODUCTS))
				.click();
			Thread.sleep(3000);
			
			List<WebElement> viewedRecommHeader=driver.findElements(By.xpath(".//*[@class='newheader']"));
			List<String> viewedRecommTitles=new ArrayList<String>();
			for(WebElement e:viewedRecommHeader){
				viewedRecommTitles.add(e.getText());
			}
			
			if(viewedRecommTitles.contains("Viewed")){

				generateXML.logVP("19.4", "On random Clicks , and click of Viewed Only Products verify whether Corresponding screen is shown ",	"Viewed Only Products Screen is displayed", AppConstants.vPass);
				pass++;
			}
			else{
				generateXML.logVP("19.4", "On random Clicks , and click of Viewed Only Products verify whether Corresponding screen is shown ","Viewed Only Products Screen is not displayed", AppConstants.vFail);
				fail++;
			}*/
			
		
	}
	
	/**
	 * After executing each test method, this method is called
	 * 
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {

	}

	/**
	 * This method is invoked after all test methods in Data.java are executed
	 * 
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */
	@AfterClass
	public static void tearDownAfterClass()
			throws TransformerConfigurationException, TransformerException {

		propsRW = new PropertiesUtil(CustomerConstants.CUSTOMER_PROPERTIES);

		AppConstants.notRunCount = Integer.parseInt(propsRW.read(
				AppConstants.TOTAL_VERIFICATION_POINTS).trim())
				- AppConstants.passCount - AppConstants.failCount;

		// log header report counts in XML file
		generateXML.logHeaderReportCounts();

		// log header report counts in XML file
		// generateXML.logHeaderReportCounts(pass, fail, notRun);
		// Generate html report using xml created in test method
		// Report should be according to test case name, ex: data.html
		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH
				+ AppConstants.DETAILED_REPORT_XSL;
		String outputHTML = AppConstants.DETAIL_REPORT_FOLDER
				+ AppConstants.FORWARD_SLASH + CustomerConstants.CUSTOMER
				+ AppConstants.DOT_HTML;
		generateReport.generateHTML(AppConstants.XML_FILE_PATH, inputXSL,
				outputHTML);

		System.out.println("Successfully generated the report");

		// log script in summary report xml file
		// generateXML.logScript(AppConstants.CATALOG_SCRIPT_NAME, outputHTML,
		// pass, fail, notRun);
		generateXML.logScript(AppConstants.LOGIN_SCRIPT_NAME, outputHTML);

		// Reset xml & properties files path to ""
		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;

		// Set pass, fail and notrun count to zero
		AppConstants.passCount = 0;
		AppConstants.failCount = 0;
		AppConstants.notRunCount = 0;
		hBaseUtil=null;
		// Close the browser
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}

	}

}
