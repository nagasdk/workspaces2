package ocpe.aut.fwk.testScripts;

import static org.junit.Assert.*;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import ocpe.aut.fwk.constants.AdminConstants;
import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.util.CommonUtil;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Admin {
	private static StringBuffer verificationErrors = new StringBuffer();
	private static ExcelUtil excelRW;
	private static PropertiesUtil propsRW;
	private static GenerateXml generateXML;
	private static GenerateHTML generateReport;
	private static CommonUtil commonUtil;

	//	private static String pageName = AppConstants.LOGIN_PAGE;
	int sleepInterval = 2000;	//Sleep interval in milliseconds, 2000 milliseconds, i.e. 2seconds


	private static WebDriver driver;
	static DesiredCapabilities cap = null; static FirefoxBinary ffBinary = null; static FirefoxProfile ffprofile = null;


	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		// one-time initialization code   
		System.out.println("@BeforeClass - oneTimeSetUp");
		File  pathToFirefoxBinary = new File(AppConstants.PATH_TO_FIREFOX_BINARY);
		ffBinary = new FirefoxBinary(pathToFirefoxBinary);
		ProfilesIni profile = new ProfilesIni();		   		   
		ffprofile = profile.getProfile(AppConstants.FIREFOX_PROFILE_DEFAULT);
		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();		  		  
		proxy.setProxyAutoconfigUrl(AppConstants.PROXY_URL);	
		cap = new DesiredCapabilities();		  
		cap.setCapability(CapabilityType.PROXY, proxy);				

		driver = new FirefoxDriver(ffBinary,ffprofile,cap);		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(AppConstants.BASE_URL + AppConstants.LOGIN_URL);

		generateXML = new GenerateXml();		
		generateReport = new GenerateHTML();		
		excelRW = new ExcelUtil(); 
		commonUtil = new CommonUtil();

		//Change the xml file path according to name of the script
		AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER+AppConstants.FORWARD_SLASH+AdminConstants.ADMIN+AppConstants.DOT_XML;
		AppConstants.PROPERTIES_FILE_PATH = AdminConstants.ADMIN_PROPERTIES;		

		//Sheet Name of excel from where the xpath values are fetched
		//	pageName = AdminConstants.ADMIN_PAGE;

		//Create a new XML file
		generateXML.createVPXML(AdminConstants.ADMIN_SCRIPT_NAME);

		//Login
		/*Firefox browser gets opened with OCPE Login page, provide 
		 * with username rg@gmail.com and click on submit button.
		 * After login, Data tab selected with it's first side menu highlighted */

		/*Clear the User Name textbox*/
		String xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.USER_NAME);
		driver.findElement(By.xpath(xpathExpression)).clear();

		propsRW = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);

		/* Get valid username from properties file
		 * ex: rg@gmail.com*/
		String userName = propsRW.read(AppConstants.VALID_USERNAME).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(userName);


		/* Clear the Password textbox*/
		xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.PASSWORD);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid password from properties file
		 * ex: Aham123+*/
		String password = propsRW.read(AppConstants.VALID_PASSWORD).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(password);


		/*Click on login button*/
		xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.LOGIN_SUBMIT);		
		driver.findElement(By.xpath(xpathExpression)).click();

		/*Click on Admin button*/		
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();
	}

	/**
	 * Test Case 31294: Verify  Admin tab screen
	 * Admin screen   should have  three side menu tabs- User management , Role Management and Job Search
	 */
	@Test
	public void test_A_1() {
		//Refer admin.properties file
		propsRW = new PropertiesUtil(AdminConstants.ADMIN_PROPERTIES);

		//Get the user management side menu label from properties file
		String prop_userMgmt = propsRW.read(AdminConstants.MENU_USERMGMT);

		//xpath expression for User Management side menu tab
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//User Management side menu tab name fetched from the screen
		String menuUserMgmt = driver.findElement(By.cssSelector(xpathExpression)).getText();

		//Compare User Management side menu tab name taken from admin.properties file and the screen and log verification point
		if(prop_userMgmt.equals(menuUserMgmt)) {
			/* Set new element tag details */		
			generateXML.logVP( "1", "Verify  Admin tab screen-Admin screen side menu tab should have menu items- User Management , Role Management and Job Search", "Admin screen has side menu tab- User management", AppConstants.vPass);
		} else {
			generateXML.logVP("1", "Verify  Admin tab screen-Admin screen side menu tab should have menu items- User Management , Role Management and Job Search", "Admin screen does not have side menu tab- User management",AppConstants.vFail);		
		}


		//Get the role management side menu label from properties file
		String prop_roleMgmt = propsRW.read(AdminConstants.MENU_ROLEMGMT);

		//xpath expression for Role Management side menu tab
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_ROLEMGMT);		

		//Role Management side menu tab name fetched from the screen
		String menuRoleMgmt = driver.findElement(By.cssSelector(xpathExpression)).getText();

		//Compare Role Management side menu tab name taken from admin.properties file and the screen and log verification point
		if(prop_roleMgmt.equals(menuRoleMgmt)) {
			/* Set new element tag details */		
			generateXML.logVP( "1", "Verify  Admin tab screen-Admin screen side menu tab should have menu items- User Management , Role Management and Job Search", "Admin screen has side menu tab- Role management", AppConstants.vPass);
		} else {
			generateXML.logVP("1", "Verify  Admin tab screen-Admin screen side menu tab should have menu items- User Management , Role Management and Job Search", "Admin screen does not have side menu tab- Role management",AppConstants.vFail);		
		}


		//Get the job search side menu label from properties file
		String prop_jobSearch = propsRW.read(AdminConstants.MENU_JOBSEARCH);

		//xpath expression for User Management side menu tab
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_JOBSEARCH);		

		//User Management side menu tab name fetched from the screen
		String menuJobSearch = driver.findElement(By.cssSelector(xpathExpression)).getText();

		//Compare Role Management side menu tab name taken from admin.properties file and the screen and log verification point
		if(prop_jobSearch.equals(menuJobSearch)) {
			/* Set new element tag details */		
			generateXML.logVP( "1", "Verify  Admin tab screen-Admin screen side menu tab should have menu items- User Management , Role Management and Job Search", "Admin screen has side menu tab- Job Search", AppConstants.vPass);
		} else {
			generateXML.logVP("1", "Verify  Admin tab screen-Admin screen side menu tab should have menu items- User Management , Role Management and Job Search", "Admin screen does not have side menu tab- Job Search",AppConstants.vFail);
		}		

	}


	/**
	 * Test Case 31295: Verify default tab selected when Admin tab is clicked
	 * The User Management  tab should be selected as default and search User screen must be present
	 */
	@Test
	public void test_A_2() {

		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//Get the user management side menu label from properties file
		String prop_userMgmt = propsRW.read(AdminConstants.MENU_USERMGMT);

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_DEFAULT);		

		//Default selected menu item is fetched from the screen
		String menuUserMgmt = driver.findElement(By.xpath(xpathExpression)).getText();

		//Compare default selected side menu tab name taken from admin.properties file and the screen and log verification point
		if(prop_userMgmt.equals(menuUserMgmt)) {
			/* Set new element tag details */		
			generateXML.logVP( "2", "Verify  whether User Management side menu tab is selected by default or not", "User Management side menu tab is selected by default", AppConstants.vPass);
		} else {
			generateXML.logVP("2", "Verify  whether User Management side menu tab is selected by default or not", "User Management side menu tab is not selected by default",AppConstants.vFail);		
		}

		//Get the user management side menu label from properties file
		String prop_headerSearchUser = propsRW.read(AdminConstants.HEADER_SEARCHUSER);

		//xpath expression for User Management side menu tab
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.HEADER_SEARCHUSER);		

		//User Management side menu tab name fetched from the screen
		String headerSearchUser = driver.findElement(By.xpath(xpathExpression)).getText();

		//Compare User Management side menu tab name taken from admin.properties file and the screen and log verification point
		if(prop_headerSearchUser.equals(headerSearchUser)) {
			/* Set new element tag details */		
			generateXML.logVP( "2", "Verify UI of default selected 'User Management' tab", "Search User screen is displayed by default", AppConstants.vPass);
		} else {
			generateXML.logVP("2", "Verify UI of default selected 'User Management' tab", "Search User screen is not displayed by default",AppConstants.vFail);		
		}		

	}


	/**
	 * Test Case 31296: Verify User Management tab
	 * The User mangement tab should be displyed with Create user and Go buttons on right side
	 */
	@Test
	public void test_A_3() {

		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_DEFAULT);		

		//Click User Management menu item on the screen
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for Create User button
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_CREATEUSER);		

		//Compare default selected side menu tab name taken from admin.properties file and the screen and log verification point
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			/* Set new element tag details */		
			generateXML.logVP( "3", "Verify User Management tab", "Create User button is displayed", AppConstants.vPass);
		} else {
			generateXML.logVP("3", "Verify User Management tab", "Create User button is not displayed",AppConstants.vFail);		
		}

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_DEFAULT);		

		//Click User Management menu item on the screen
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for Create User button
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);		

		//Check whether Go button is displayed or not
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			/* Set new element tag details */		
			generateXML.logVP( "3", "Verify User Management tab", "Go button is displayed", AppConstants.vPass);
		} else {
			generateXML.logVP("3", "Verify User Management tab", "Go button is not displayed",AppConstants.vFail);		
		}

	}

	/**
	 * Test Case 31297: Verify default tab selected when clicked on User Mangement tab
	 *The search user should be default screen when clicked on User Mangement tab
	 */
	@Test
	public void test_A_4() {

		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//Get the header Search User text from properties file
		String prop_headerSearchUser = propsRW.read(AdminConstants.HEADER_SEARCHUSER);

		//xpath expression for header Search User text
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.HEADER_SEARCHUSER);		

		// Header 'Search User' text is fetched from the screen
		String headerSearchUser = driver.findElement(By.xpath(xpathExpression)).getText();

		//Compare  header 'Search User' text taken from admin.properties file and the screen and log verification point
		if(prop_headerSearchUser.equals(headerSearchUser)) {
			/* Set new element tag details */		
			generateXML.logVP( "4", "Verify default tab selected when clicked on User Mangement tab", "The search user is displayed when clicked on User Mangement tab", AppConstants.vPass);
		} else {
			generateXML.logVP("4", "Verify default tab selected when clicked on User Mangement tab", "The search user is not displayed when clicked on User Mangement tab",AppConstants.vFail);		
		}		

	}

	/**
	 * Test Case 31299: Verify Search section
	 * The search section should be displayed with User name /First Name /last Name text boxes, Role 
	 * and Status dropdown with 'Create User' and 'Go' buttons
	 */
	@Test
	public void test_A_5() throws InterruptedException{

		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for User Name text box
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_USERNAME);

		Thread.sleep(sleepInterval);

		driver.findElement(By.xpath(xpathExpression)).click();
		String attrName = driver.findElement(By.xpath(xpathExpression)).getAttribute(AdminConstants.NAME);


		//Get the User Name input tag's name attribute 
		//For Example : <input class=" text-fields-search" type="text" name="userName"/>
		String prop_userName = propsRW.read(AdminConstants.TXTBOX_USERNAME);


		//Compare  name attribute value taken from admin.properties file and the screen and log verification point
		if(prop_userName.equals(attrName)) {
			// Set new element tag details 		
			generateXML.logVP( "5", "Verify Search section", "The search section contains User Name text box", AppConstants.vPass);
		} else {
			generateXML.logVP("5", "Verify Search section", "The search section does not contain User Name text box ",AppConstants.vFail);		
		}		


		//xpath expression for First Name text box
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_FIRSTNAME);

		Thread.sleep(sleepInterval);

		driver.findElement(By.xpath(xpathExpression)).click();

		//Get the name attribute of First Name input field
		attrName = driver.findElement(By.xpath(xpathExpression)).getAttribute(AdminConstants.NAME);


		//Get the User Name input tag's name attribute 
		//For Example : <input class=" text-fields-search" type="text" name="userName"/>
		String prop_firstName = propsRW.read(AdminConstants.TXTBOX_FIRSTNAME);


		//Compare  name attribute value taken from admin.properties file and the screen and log verification point
		if(prop_firstName.equals(attrName)) {
			// Set new element tag details 		
			generateXML.logVP( "5", "Verify Search section", "The search section contains First Name text box", AppConstants.vPass);
		} else {
			generateXML.logVP("5", "Verify Search section", "The search section does not contain First Name text box ",AppConstants.vFail);		
		}		


		//xpath expression for First Name text box
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_LASTNAME);

		Thread.sleep(sleepInterval);

		driver.findElement(By.xpath(xpathExpression)).click();

		//Get the name attribute of First Name input field
		attrName = driver.findElement(By.xpath(xpathExpression)).getAttribute(AdminConstants.NAME);


		//Get the User Name input tag's name attribute 
		//For Example : <input class=" text-fields-search" type="text" name="userName"/>
		String prop_lastName = propsRW.read(AdminConstants.TXTBOX_LASTNAME);


		//Compare  name attribute value taken from admin.properties file and the screen and log verification point
		if(prop_lastName.equals(attrName)) {
			// Set new element tag details 		
			generateXML.logVP( "5", "Verify Search section", "The search section contains Last Name text box", AppConstants.vPass);
		} else {
			generateXML.logVP("5", "Verify Search section", "The search section does not contain Last Name text box ",AppConstants.vFail);		
		}		


		//xpath expression for Role dropdown
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.SELECT_ROLE);

		Thread.sleep(sleepInterval);

		driver.findElement(By.xpath(xpathExpression)).click();

		//Get the name attribute of Role dropdown
		attrName = driver.findElement(By.xpath(xpathExpression)).getAttribute(AdminConstants.NAME);


		//Get the Role select tag's name attribute 
		//For Example : <select class="text-fields-search" name="primaryRoleId">
		String prop_selectRole = propsRW.read(AdminConstants.SELECT_ROLE);


		//Compare  name attribute value taken from admin.properties file and the screen and log verification point
		if(prop_selectRole.equals(attrName)) {
			// Set new element tag details 		
			generateXML.logVP( "5", "Verify Search section", "The search section contains Role dropdown", AppConstants.vPass);
		} else {
			generateXML.logVP("5", "Verify Search section", "The search section does not contain Role dropdown",AppConstants.vFail);		
		}		


		//xpath expression for Status dropdown
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.SELECT_STATUS);



		driver.findElement(By.xpath(xpathExpression)).click();

		//Get the name attribute of Status dropdown
		attrName = driver.findElement(By.xpath(xpathExpression)).getAttribute(AdminConstants.NAME);


		//Get the Status select tag's name attribute 
		//For Example : <select class="text-fields-search" name="status">
		String prop_selectStatus = propsRW.read(AdminConstants.SELECT_STATUS);


		//Compare  name attribute value taken from admin.properties file and the screen and log verification point
		if(prop_selectStatus.equals(attrName)) {
			// Set new element tag details 		
			generateXML.logVP( "5", "Verify Search section", "The search section contains Status dropdown", AppConstants.vPass);
		} else {
			generateXML.logVP("5", "Verify Search section", "The search section does not Status dropdown",AppConstants.vFail);		
		}		

		Thread.sleep(sleepInterval);

	}

	/**
	 * Test Case 31305: Verify the functionality of 'Go' button
	 * The system shall validate the details entered by user upon 
	 * clicking Go button and should display the search results  applying 'and' search .
	 */
	@Test
	public void test_A_6() throws InterruptedException {
		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();


		/* Get valid user name from properties file
		 * ex: fin 
		 */
		String userName = propsRW.read(AdminConstants.VALID_USERNAME).trim();
		//xpath expression for User Name text box
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_USERNAME);
		driver.findElement(By.xpath(xpathExpression)).sendKeys(userName);

		/* Get valid first name from properties file
		 * ex: finc 
		 */
		String firstName = propsRW.read(AdminConstants.VALID_FIRSTNAME).trim();
		//xpath expression for First Name text box
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_FIRSTNAME);
		driver.findElement(By.xpath(xpathExpression)).sendKeys(firstName);

		/* Get valid last name from properties file
		 * ex: finc 
		 */
		String lastName = propsRW.read(AdminConstants.VALID_LASTNAME).trim();
		//xpath expression for Last Name text box
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_LASTNAME);
		//provide last name in the Last Name text box
		driver.findElement(By.xpath(xpathExpression)).sendKeys(lastName);


		//xpath expression for Role dropdown
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.SELECT_ROLE);
		String primaryRole = propsRW.read(AdminConstants.VALID_PRIMARYROLE);
		//Select a role from Role dropdown
		driver.findElement(By.xpath(xpathExpression)).sendKeys(primaryRole);

		//xpath expression for Status dropdown
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.SELECT_STATUS);
		String status = propsRW.read(AdminConstants.VALID_STATUS);
		//Select a status from Status dropdown
		driver.findElement(By.xpath(xpathExpression)).sendKeys(status);



		//xpath expression for button 'Go'
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);
		//Click on Go button
		driver.findElement(By.xpath(xpathExpression)).click();

		Thread.sleep(4000);

		//Get the values in the data table for user name, first name, last name, primary role and status 

		//xpath expression for data table result user name column
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.RESULT_USERNAME);
		String result_userName = driver.findElement(By.xpath(xpathExpression)).getText();

		//xpath expression for data table result first name column
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.RESULT_FIRSTNAME);
		String result_firstName = driver.findElement(By.xpath(xpathExpression)).getText();

		//xpath expression for data table result last name column
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.RESULT_LASTNAME);
		String result_lastName = driver.findElement(By.xpath(xpathExpression)).getText();

		//xpath expression for data table result primary role column
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.RESULT_PRIMARYROLE);
		String result_primaryRole = driver.findElement(By.xpath(xpathExpression)).getText();

		//xpath expression for data table result status column
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.RESULT_STATUS);
		String result_status = driver.findElement(By.xpath(xpathExpression)).getText();

		/* Compare the result (data in the table) with that of given search criteria */
		if(result_userName.contains(userName) && (result_firstName.contains(firstName))
				&& (result_lastName.contains(lastName) && (result_primaryRole.equalsIgnoreCase(primaryRole)
						&& (result_status.equals(status))))) {
			// Set new element tag details 		
			generateXML.logVP( "6", "Verify the functionality of 'Go' button", "The system validated the details entered by user upon clicking Go button and displayed the search results applying 'and' search .", AppConstants.vPass);
		} else {
			// Set new element tag details 		
			generateXML.logVP( "6", "Verify the functionality of 'Go' button", "The system validated the details entered by user upon clicking Go button and does not displayed the search results applying 'and' search .", AppConstants.vFail);	
		}


	}

	/**
	 * Test Case 31307: Verify search results
	 * The search results in the grid should have   
	 * User name /First Name /last Name/Primary Role / Status / Password / Retries / Delete  columns 
	 * displayed with  pagination as in wireframe
	 */
	@Test
	public void test_A_7() throws InterruptedException{

		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for User Name text box
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);

		Thread.sleep(sleepInterval);

		driver.findElement(By.xpath(xpathExpression)).click();

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_USER_HDR_1);
		String headerLabel = driver.findElement(By.xpath(xpathExpression)).getText();


		//Get the Search User table's header 1 i.e. User Name		
		String prop_header = propsRW.read(AdminConstants.TABLE_USER_HDR_1);

		if(headerLabel.equalsIgnoreCase(prop_header)) {
			// Set new element tag details 		
			generateXML.logVP( "7", "Verify search results", "The search results in the grid has User Name column", AppConstants.vPass);
		} else {
			generateXML.logVP( "7", "Verify search results", "The search results in the grid does not have User Name column", AppConstants.vFail);
		}

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_USER_HDR_2);
		headerLabel = driver.findElement(By.xpath(xpathExpression)).getText();


		//Get the Search User table's header 2 i.e. First Name		
		prop_header = propsRW.read(AdminConstants.TABLE_USER_HDR_2);

		if(headerLabel.equalsIgnoreCase(prop_header)) {
			// Set new element tag details 		
			generateXML.logVP( "7", "Verify search results", "The search results in the grid has First Name column", AppConstants.vPass);
		} else {
			generateXML.logVP( "7", "Verify search results", "The search results in the grid does not have First Name column", AppConstants.vFail);
		}

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_USER_HDR_3);
		headerLabel = driver.findElement(By.xpath(xpathExpression)).getText();


		//Get the Search User table's header 3 i.e. Last Name		
		prop_header = propsRW.read(AdminConstants.TABLE_USER_HDR_3);

		if(headerLabel.equalsIgnoreCase(prop_header)) {
			// Set new element tag details 		
			generateXML.logVP( "7", "Verify search results", "The search results in the grid has Last Name column", AppConstants.vPass);
		} else {
			generateXML.logVP( "7", "Verify search results", "The search results in the grid does not have Last Name column", AppConstants.vFail);
		}

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_USER_HDR_4);
		headerLabel = driver.findElement(By.xpath(xpathExpression)).getText();


		//Get the Search User table's header 4 i.e. Primary Role	
		prop_header = propsRW.read(AdminConstants.TABLE_USER_HDR_4);

		if(headerLabel.equalsIgnoreCase(prop_header)) {
			// Set new element tag details 		
			generateXML.logVP( "7", "Verify search results", "The search results in the grid has Primary Role column", AppConstants.vPass);
		} else {
			generateXML.logVP( "7", "Verify search results", "The search results in the grid does not have Primary Role column", AppConstants.vFail);
		}

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_USER_HDR_5);
		headerLabel = driver.findElement(By.xpath(xpathExpression)).getText();


		//Get the Search User table's header 5 i.e. Status	
		prop_header = propsRW.read(AdminConstants.TABLE_USER_HDR_5);

		if(headerLabel.equalsIgnoreCase(prop_header)) {
			// Set new element tag details 		
			generateXML.logVP( "7", "Verify search results", "The search results in the grid has Status column", AppConstants.vPass);
		} else {
			generateXML.logVP( "7", "Verify search results", "The search results in the grid does not have Status column", AppConstants.vFail);
		}

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_USER_HDR_6);
		headerLabel = driver.findElement(By.xpath(xpathExpression)).getText();


		//Get the Search User table's header 6 i.e. Password	
		prop_header = propsRW.read(AdminConstants.TABLE_USER_HDR_6);

		if(headerLabel.equalsIgnoreCase(prop_header)) {
			// Set new element tag details 		
			generateXML.logVP( "7", "Verify search results", "The search results in the grid has Password column", AppConstants.vPass);
		} else {
			generateXML.logVP( "7", "Verify search results", "The search results in the grid does not have Password column", AppConstants.vFail);
		}

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_USER_HDR_7);
		headerLabel = driver.findElement(By.xpath(xpathExpression)).getText();


		//Get the Search User table's header 7 i.e. Retries
		prop_header = propsRW.read(AdminConstants.TABLE_USER_HDR_7);

		if(headerLabel.equalsIgnoreCase(prop_header)) {
			// Set new element tag details 		
			generateXML.logVP( "7", "Verify search results", "The search results in the grid has Retries column", AppConstants.vPass);
		} else {
			generateXML.logVP( "7", "Verify search results", "The search results in the grid does not have Retries column", AppConstants.vFail);
		}

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_USER_HDR_8);
		headerLabel = driver.findElement(By.xpath(xpathExpression)).getText();


		//Get the Search User table's header 8 i.e. Delete
		prop_header = propsRW.read(AdminConstants.TABLE_USER_HDR_8);

		if(headerLabel.equalsIgnoreCase(prop_header)) {
			// Set new element tag details 		
			generateXML.logVP( "7", "Verify search results", "The search results in the grid has Delete column", AppConstants.vPass);
		} else {
			generateXML.logVP( "7", "Verify search results", "The search results in the grid does not have Delete column", AppConstants.vFail);
		}

		Thread.sleep(sleepInterval);

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_PREVIOUS);

		driver.findElement(By.xpath(xpathExpression)).click();

		Thread.sleep(sleepInterval);

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_NEXT);
		String strNext =  driver.findElement(By.xpath(xpathExpression)).getText();
		String prop_btn_next = propsRW.read(AdminConstants.BTN_NEXT);
		driver.findElement(By.xpath(xpathExpression)).click();


		Thread.sleep(sleepInterval);

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_PREVIOUS);
		String strPrevious =  driver.findElement(By.xpath(xpathExpression)).getText();
		String prop_btn_previous = propsRW.read(AdminConstants.BTN_PREVIOUS);		
		driver.findElement(By.xpath(xpathExpression)).click();
		if((strPrevious.equalsIgnoreCase(prop_btn_previous))
				&&	(strNext.equalsIgnoreCase(prop_btn_next))) {
			// Set new element tag details 		
			generateXML.logVP( "7", "Verify search results", "Pagination is displayed with Previous and Next buttons", AppConstants.vPass);
		} else {					
			generateXML.logVP( "7", "Verify search results", "Pagination is not displayed with Previous and Next buttons", AppConstants.vFail);
		}

		Thread.sleep(sleepInterval);	

	}

	/**
	 * Test Case 31308: Verify whether user can click on the arrow available next to  User Name title in the columns of Grid
	 * The arrow next to  User Name in the grid should be clickable and upon clicking - column values have to change in ascending(for up arrow) and  descending form (for down arrow )
	 */
	@Test
	public void test_A_8() {
		//Get xpath expression for the header User Name in the data table
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_USER_HDR_1);	

		//Get class attribute of user name column. It will be either sorting_asc for ascending or sorting_desc for descending 
		String ascDescClass = driver.findElement(By.xpath(xpathExpression)).getAttribute(AppConstants.CLASS);

		//xpath expression for user table
		String userTableXpath = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_USER);
		WebElement table =driver.findElement(By.xpath(userTableXpath));

		//get the column contents in a list		
		List<String> columnData = new ArrayList<String>();
		columnData = commonUtil.getColumnContents(table, 0); 

		//Pass the list and order of sorting to checkSorting() method that returns true or false
		boolean sortSuccess = commonUtil.checkSorting(columnData, AppConstants.ASCENDING);

		/* If class atribute's value is "sorting_asc" and checkSorting() method returns true, then data is sorted in ascending order */
		if(ascDescClass.equals(AdminConstants.SORTING_ASC) && sortSuccess) {
			generateXML.logVP( "8", "Verify whether user can click on the arrow available next to  User Name title in the columns of Grid", "The arrow next to  User Name in the grid is clickable and upon clicking - column values changed to ascending(for up arrow) order", AppConstants.vPass);
		} else {
			generateXML.logVP( "8", "Verify whether user can click on the arrow available next to  User Name title in the columns of Grid", "The arrow next to  User Name in the grid is clickable and upon clicking - column values not changed to ascending(for up arrow) order", AppConstants.vFail);
		}

		//Click on User Name  header for sorting in descending order
		driver.findElement(By.xpath(xpathExpression)).click();
		ascDescClass = driver.findElement(By.xpath(xpathExpression)).getAttribute(AppConstants.CLASS);

		//get the column contents in a list		
		columnData = commonUtil.getColumnContents(table, 0); 
		//Pass the list and order of sorting to checkSorting() method that returns true or false
		sortSuccess = commonUtil.checkSorting(columnData, AppConstants.DESCENDING);

		if(ascDescClass.equals(AdminConstants.SORTING_DESC) && sortSuccess) {
			generateXML.logVP( "8", "Verify whether user can click on the arrow available next to  User Name title in the columns of Grid", "The arrow next to  User Name in the grid is clickable and upon clicking - column values changed to descending(for down arrow) order", AppConstants.vPass);
		} else {
			generateXML.logVP( "8", "Verify whether user can click on the arrow available next to  User Name title in the columns of Grid", "The arrow next to  User Name in the grid is clickable and upon clicking - column values not changed to descending(for down arrow) order", AppConstants.vFail);
		}

	}	

	/**
	 * Test Case 31309: Verify User name is hyperlink in the results grid
	 * User name should be an hyperlink and upon clicking should open  edit User pop up  page
	 * @throws InterruptedException 
	 */
	@Test
	public void test_A_9() throws InterruptedException {
		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for button 'Go'
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);
		//Click on Go button
		driver.findElement(By.xpath(xpathExpression)).click();
		Thread.sleep(sleepInterval);
		//xpath expression for user name hyperlink in data table
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.USERNAME_HYPERLINK);
		driver.findElement(By.xpath(xpathExpression)).click();

		if(driver.findElement(By.xpath(xpathExpression)).getTagName().equals(AdminConstants.ANCHOR_TAGNAME)) {
			// Set new element tag details 		
			generateXML.logVP( "9", "Verify User name is hyperlink in the results grid", "User name is a hyperlink", AppConstants.vPass);
		} else {
			generateXML.logVP( "9", "Verify User name is hyperlink in the results grid", "User name is not a hyperlink", AppConstants.vFail);
		}

		//xpath expression for first name in data table
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.DATA_FIRSTNAME);
		driver.findElement(By.xpath(xpathExpression)).click();
		String userName = AdminConstants.EDIT + AppConstants.SPACE + driver.findElement(By.xpath(xpathExpression)).getText();

		//xpath expression for popup header which is opened on click of user name hyperlink
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_HEADER);
		String popup_header = driver.findElement(By.xpath(xpathExpression)).getText();

		Thread.sleep(sleepInterval);

		//xpath expression for cancel button in Edit user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_CANCEL);
		driver.findElement(By.xpath(xpathExpression)).click();

		if(popup_header.equals(userName)) {
			// Set new element tag details 		
			generateXML.logVP( "9", "Verify User name is hyperlink in the results grid", "Upon clicking on user name, edit User pop up page is opened", AppConstants.vPass);
		} else {
			generateXML.logVP( "9", "Verify User name is hyperlink in the results grid", "Upon clicking on user name, edit User pop up page is not opened", AppConstants.vFail);
		}

	}


	/**
	 * Test Case 31310: Verify whether the text saying 'showing  n/n records ' is displayed at the bottom of the screen
	 * The text saying 'showing  n/n records ' should be displayed at the bottom of the screen
	 */
	@Test
	public void test_B_1() {
		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for button 'Go'
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);
		//Click on Go button
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for first name in data table
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.PAGINATION_INFO);
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			// Set new element tag details 		
			generateXML.logVP( "10", "Verify whether the text saying 'showing  n/n records ' is displayed at the bottom of the screen", "The text saying 'showing  n/n records ' is displayed at the bottom of the screen", AppConstants.vPass);
		} else {
			generateXML.logVP( "10", "Verify whether the text saying 'showing  n/n records ' is displayed at the bottom of the screen", "The text saying 'showing  n/n records ' is not displayed at the bottom of the screen", AppConstants.vFail);
		}

	}

	/**
	 * Test Case 31311: Verify whether' no of rows per page' drop down is available for the user 
	 * to set and view results at the bottom of the page
	 * The ' no of rows per page' drop down should be available for the user to set and view results at the bottom of the page
	 * @throws InterruptedException 
	 */
	@Test
	public void test_B_2() throws InterruptedException {
		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for button 'Go'
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);
		//Click on Go button
		driver.findElement(By.xpath(xpathExpression)).click();

		Thread.sleep(sleepInterval);

		//xpath expression for show entries dropdown above the data table
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.ROWSPERPAGE_DROPDOWN);
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			// Set new element tag details 		
			generateXML.logVP( "11", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the top of the page", "The ' no of rows per page' drop down is available for the user to set and view results at the top of the page", AppConstants.vPass);
		} else {
			generateXML.logVP( "11", "Verify whether' no of rows per page' drop down is available for the user to set and view results at the top of the page", "The ' no of rows per page' drop down is not available for the user to set and view results at the top of the page", AppConstants.vFail);
		}

	}

	/**
	 * Test Case 31312: Verify Pagination-Previous and next buttons 
	 * The pagination  'Previous' and 'Next'  buttons  should be displayed as in wireframe
	 */
	@Test
	public void test_B_3() {

		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for button 'Go'
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);
		//Click on Go button
		driver.findElement(By.xpath(xpathExpression)).click();

		//Previous button
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_PREVIOUS);		

		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			// Set new element tag details 		
			generateXML.logVP( "12", "Verify Pagination-Previous and next buttons", "The pagination  'Previous' button is displayed as in wireframe", AppConstants.vPass);
		} else {
			generateXML.logVP( "12", "Verify Pagination-Previous and next buttons", "The pagination  'Previous'  button is not displayed as in wireframe", AppConstants.vFail);
		}

		//Next button
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_NEXT);
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			// Set new element tag details 		
			generateXML.logVP( "12", "Verify Pagination-Previous and next buttons", "The pagination  'Next' button is displayed as in wireframe", AppConstants.vPass);
		} else {
			generateXML.logVP( "12", "Verify Pagination-Previous and next buttons", "The pagination  'Next'  button is not displayed as in wireframe", AppConstants.vFail);
		}

	}


	/**
	 * Test Case 31313: Verify Pagination-Previous button by clicking on it 
	 * The pagination  'Previous' button should be disabled and upon clicking 'Previous' button ,system should not perform any action
	 * @throws InterruptedException 
	 */
	@Test
	public void test_B_4() throws InterruptedException {
		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for button 'Go'
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);
		//Click on Go button
		driver.findElement(By.xpath(xpathExpression)).click();
		Thread.sleep(sleepInterval);
		//Previous button
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_PREVIOUS);		

		/*Get the pagination text saying 'showing  n/n records ' before and after clicking the Previous button
		    If both are same, then no action is performed */
		String textXpath = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.PAGINATION_INFO);
		String beforeText = driver.findElement(By.xpath(textXpath)).getText();
		driver.findElement(By.xpath(xpathExpression)).click();
		String afterText = driver.findElement(By.xpath(textXpath)).getText();

		if(beforeText.equals(afterText)) {
			// Set new element tag details 		
			generateXML.logVP( "13", "Verify Pagination-Previous button by clicking on it", "The pagination  'Previous' button is disabled and upon clicking 'Previous' button ,system could not perform any action", AppConstants.vPass);
		} else {
			generateXML.logVP( "13", "Verify Pagination-Previous button by clicking on it", "The pagination  'Previous' button is not disabled and upon clicking 'Previous' button ,system performs an action", AppConstants.vFail);
		}
	}

	/**
	 * Test Case 31314: Verify Pagination-next button clicking on it 
	 * The pagination  'next' button should be disabled and upon clicking 'next ' button ,system should not perform any action
	 *//*
	@Test
	public void test_B_5() {
		Click on Admin button		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for button 'Go'
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);
		//Click on Go button
		driver.findElement(By.xpath(xpathExpression)).click();


		String textXpath = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.PAGINATION_INFO);
		String afterText =  driver.findElement(By.xpath(textXpath)).getText();
		String[] arr1 = afterText.split("of ");
		String[] arr2 = arr1[1].split(" entries");
		int count = Integer.parseInt(arr2[0]);


		//xpath expression for first name in data table
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.ROWSPERPAGE_SELECTED);
		afterText =  driver.findElement(By.xpath(xpathExpression)).getAttribute("value");
		System.out.println(afterText);
		//Next button
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_NEXT);		
		driver.findElement(By.xpath(xpathExpression)).click();

		if(beforeText.equals(afterText)) {
			// Set new element tag details 		
			generateXML.logVP( "14", "Verify Pagination-next button clicking on it", "The pagination  'next' button is disabled and upon clicking 'next' button ,system could not perform any action", AppConstants.vPass);
		} else {
			generateXML.logVP( "14", "Verify Pagination-next button clicking on it", "The pagination  'next' button should be disabled and upon clicking 'next' button ,system performs an action", AppConstants.vFail);
		}
	}*/

	/**
	 * Test Case 31317: Verify Edit User  pop up page
	 * The Edit User  pop up should be displayed with User Name /First Name /last Name/Email/Roles/Primary Role and Status fields with cancel/Reset password and save buttons
	 * @throws InterruptedException 
	 */
	@Test
	public void test_B_6() throws InterruptedException {

		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for button 'Go'
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);
		//Click on Go button
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for user name hyperlink in data table
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.USERNAME_HYPERLINK);
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for Edit user popup
		/*	 xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_EDITUSER);
		 WebElement webElement = driver.findElement(By.xpath(xpathExpression));*/
		//xpath expression for popup header which is opened on click of user name hyperlink
		/*xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_HEADER);
		String popup_header = driver.findElement(By.xpath(xpathExpression)).getText();*/

		Thread.sleep(sleepInterval);

		//xpath expression for user name text box in edit user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_USERNAME);
		driver.findElement(By.xpath(xpathExpression)).click();

		//If user name text box is displayed then Verification point is passed otherwise it's failed
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "User Name field is displayed in Edit user popup", AppConstants.vPass);
		} else {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "User Name field is not displayed in Edit user popup", AppConstants.vFail);
		}

		//xpath expression for first name text box in edit user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_FIRSTNAME);
		driver.findElement(By.xpath(xpathExpression)).click();
		//If first name text box is displayed then Verification point is passed otherwise it's failed
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "First Name field is displayed in Edit user popup", AppConstants.vPass);
		} else {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "First Name field is not displayed in Edit user popup", AppConstants.vFail);
		}

		//xpath expression for last name text box in edit user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_LASTNAME);
		driver.findElement(By.xpath(xpathExpression)).click();
		//If last name text box is displayed then Verification point is passed otherwise it's failed
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "Last Name field is displayed in Edit user popup", AppConstants.vPass);
		} else {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "Last Name field is not displayed in Edit user popup", AppConstants.vFail);
		}

		//xpath expression for Roles dropdown in edit user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_ROLES);
		driver.findElement(By.xpath(xpathExpression)).click();
		//If Roles dropdown is displayed then Verification point is passed otherwise it's failed
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "Roles field is displayed in Edit user popup", AppConstants.vPass);
		} else {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "Roles field is not displayed in Edit user popup", AppConstants.vFail);
		}

		//xpath expression for Primary Role dropdown in edit user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_PRIMARYROLE);
		driver.findElement(By.xpath(xpathExpression)).click();
		//If Primary Role dropdown is displayed then Verification point is passed otherwise it's failed
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "Primary Role field is displayed in Edit user popup", AppConstants.vPass);
		} else {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "Primary Role field is not displayed in Edit user popup", AppConstants.vFail);
		}

		//xpath expression for Status dropdown in edit user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_STATUS);
		driver.findElement(By.xpath(xpathExpression)).click();
		//If  Status dropdown is displayed then Verification point is passed otherwise it's failed
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "Status field is displayed in Edit user popup", AppConstants.vPass);
		} else {
			generateXML.logVP( "15", "Verify Edit User  pop up page", "Status field is not displayed in Edit user popup", AppConstants.vFail);
		} 

	}


	/**
	 * Test Case 31318: Verify User Name
	 * The User  Name text  box should be read only
	 */
	@Test
	public void test_B_7() {
		//xpath expression for user name text box in edit user popup
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_USERNAME);
		if(driver.findElement(By.xpath(xpathExpression)).getAttribute(AppConstants.READONLY).equalsIgnoreCase(AppConstants.TRUE)) {
			generateXML.logVP( "16", "Verify User Name", "The User  Name text  box is read only", AppConstants.vPass);
		} else {
			generateXML.logVP( "16", "Verify User Name", "The User  Name text  box not read only, it is editable", AppConstants.vFail);
		}

		//XPATH EXPRESSION FOR cANCEL BUTTON
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_CANCEL);
		//Click on Cancel button
		driver.findElement(By.xpath(xpathExpression)).click();

	}

	/**
	 * Test Case 31321: Verify  Primary Role dropdown
	 * The Primary Role field should be a dropdown and upon clicking it ,
	 * all selected Roles from Roles multi-select dropdown should be displayed
	 * @throws InterruptedException 
	 */
	@Test
	public void test_B_8() throws InterruptedException {
		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for button 'Go'
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);
		//Click on Go button
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for user name hyperlink in data table
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.USERNAME_HYPERLINK);
		driver.findElement(By.xpath(xpathExpression)).click();

		Thread.sleep(sleepInterval);

		/*
		 * Get the selected roles from Roles multi-select dropdown and put them in a list
		 */
		List<String> selectedRoles = new ArrayList<String>(); 
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_SELECTED_ROLES);
		driver.findElement(By.xpath(xpathExpression)).click();
		List<WebElement> lstSelectedRoles = driver.findElement(By.xpath(xpathExpression)).findElements(By.tagName(AppConstants.INPUT));
		for(WebElement webElement : lstSelectedRoles) {			
			if((null != webElement.getAttribute(AppConstants.CHECKED)) && 
					(webElement.getAttribute(AppConstants.CHECKED).equalsIgnoreCase(AppConstants.TRUE))) {
				selectedRoles.add(webElement.getAttribute(AppConstants.ID));
			}			
		}		

		//xpath expression for Primary Role dropdown in edit user popup
		List<String> primaryRoles = new ArrayList<String>(); 
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_PRIMARYROLE);
		driver.findElement(By.xpath(xpathExpression)).click();

		List<WebElement> lstPrimaryRoles = driver.findElement(By.xpath(xpathExpression)).findElements(By.tagName(AppConstants.OPTION));		
		for(WebElement wbElemnt : lstPrimaryRoles) {		
			primaryRoles.add(wbElemnt.getText());					
		}

		int count = 0;
		//If both the lists are of same size then compare the contents, otherwise test case is failed
		if(selectedRoles.size()== primaryRoles.size()) {
			for(int i=0;i<selectedRoles.size();i++) {			
				if(selectedRoles.get(i).equals(primaryRoles.get(i))) {
					count++;
				}			
			}	//end of for loop

			/* If count is equal to selectRoles or primaryRoles size,
			    then all the elements in both the lists are equal. Hence, test case is passed.
			    Otherwise test case is failed 
			 */
			if(count == selectedRoles.size()) {
				generateXML.logVP( "17", "Verify  Primary Role dropdown", "All selected Roles from Roles multi-select dropdown are displayed in Primary Role dropdown", AppConstants.vPass);
			} else {
				generateXML.logVP( "17", "Verify  Primary Role dropdown", "All selected Roles from Roles multi-select dropdown are not displayed in Primary Role dropdown", AppConstants.vFail);
			}

		} else {
			generateXML.logVP( "17", "Verify  Primary Role dropdown", "All selected Roles from Roles multi-select dropdown are not displayed in Primary Role dropdown", AppConstants.vFail);
		}

	}


	/**
	 * Test Case 31322: Verify Role field
	 * The Role field should be a list of all available roles and checkboxes inorder to select any role
	 */
	@Test
	public void test_B_9() {
		/*
		 * Get the list of check boxes and corresponding roles from Roles multi-select dropdown
		 */
		int count = 0;
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_SELECTED_ROLES);
		driver.findElement(By.xpath(xpathExpression)).click();
		List<WebElement> lstOfRoles = driver.findElement(By.xpath(xpathExpression)).findElements(By.tagName(AppConstants.INPUT));

		/*
		 *  Ex: <input id="Admin" class="secondary" type="checkbox" checked="" value="1" name="secondaryRoleId">
		 *  For each and every input field in Role multi-select, check whether input field is displayed or not, 
		 *  check for type="checkbox" attribute and id attribute's value.
		 *  If all the above conditions are satisfied, increment count.
		 */
		for(WebElement webElement : lstOfRoles) {			
			if((webElement.isDisplayed()) 
					&& (null != webElement.getAttribute(AppConstants.TYPE)) 
					&& (webElement.getAttribute(AppConstants.TYPE).equalsIgnoreCase(AppConstants.CHECKBOX))
					&& (null != webElement.getAttribute(AppConstants.ID))
					&& (!AppConstants.BLANK_STRING.equals(webElement.getAttribute(AppConstants.ID)))
					) {
				count++;
			}			
		}		

		/*
		 * If above conditions are satisfied for all the list of roles
		 * available in Roles multi-select, then the verification point is passed
		 */
		if(count == lstOfRoles.size()) {
			generateXML.logVP( "18", "Verify Role field", "The Role field is a list of all available roles and checkboxes inorder to select any role", AppConstants.vPass);
		} else {
			generateXML.logVP( "18", "Verify Role field", "The Role field does not have list of all available roles and checkboxes inorder to select any role", AppConstants.vFail);
		}		

	}


	/**
	 * Test Case 31323: Verify Status dropdown
	 * The Status  field should be a dropdown box and upon clicking it ,Active/Inactive should be displayed and by default what ever the user status is it should be selected
	 * @throws InterruptedException 
	 */
	@Test
	public void test_C_1() throws InterruptedException {
		Thread.sleep(sleepInterval);
		//xpath expression for Status dropdown in edit user popup
		String  xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_STATUS);

		//List of available status in the dropdown
		List<WebElement> lstOfStatus = driver.findElement(By.xpath(xpathExpression)).findElements(By.tagName(AppConstants.OPTION));		

		Object[] actual = new Object[lstOfStatus.size()]; 
		Object[] expected=new Object[2];
		int i=0;
		String selectedStatus = AppConstants.BLANK_STRING;
		for(WebElement wbElemnt : lstOfStatus) {		
			actual[i] = (wbElemnt.getText());		
			i++;
			if((null != wbElemnt.getAttribute("selected")) &&
					(wbElemnt.getAttribute("selected").equals(AppConstants.TRUE))) {
				selectedStatus = wbElemnt.getText().trim();
			}
		}	
		expected[0] = AdminConstants.ACTIVE;
		expected[1] = AdminConstants.INACTIVE;

		int count = 0;
		/*If actual and expected arrays size are same, then compare the contents of both the arrays
		 * Otherwise, verification point is failed
		 */		
		if(actual.length == expected.length) {
			//Comparing the contents of both the arrays actual and expected
			for(int j=0;j<actual.length;j++) {			
				if(actual[j].equals(expected[j])) {
					count++;
				}			
			}	//end of for loop

			/*If all the contents in both the arrays are equal, 
			 * then verification point is passed, otherwise, it is failed */
			if(count == expected.length) {
				generateXML.logVP( "19", "Verify Status dropdown", "The Status field is a dropdown box and upon clicking it ,Active/Inactive options are displayed", AppConstants.vPass);
			} else {
				generateXML.logVP( "19", "Verify Status dropdown", "The Status is a dropdown box and upon clicking it ,Active/Inactive options are not displayed", AppConstants.vFail);
			}
		} else {
			generateXML.logVP( "19", "Verify Status dropdown", "The Status is a dropdown box and upon clicking it ,Active/Inactive options are not displayed", AppConstants.vFail);
		}

		//XPath expression for Cancel button
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_CANCEL);
		//Click on Cancel button
		driver.findElement(By.xpath(xpathExpression)).click();

		Thread.sleep(sleepInterval);

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_COL_STATUS);
		String tableColStatus = driver.findElement(By.xpath(xpathExpression)).getText();

		if(tableColStatus.equals(selectedStatus)) {
			generateXML.logVP( "19", "Verify Status dropdown", "By default what ever the user status is, it is selected", AppConstants.vPass);
		} else {
			generateXML.logVP( "19", "Verify Status dropdown", "By default what ever the user status is, it is not selected", AppConstants.vFail);
		}
	}

	/**
	 * Test Case 31325: Verify the functionality of 'Cancel' button
	 * Upon clicking cancel button ,the system should cancel the editing user  and navigate back to Search User screen
	 * @throws InterruptedException 
	 */
	@Test
	public void test_C_2() throws InterruptedException {
		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for button 'Go'
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);
		//Click on Go button
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for user name hyperlink in data table
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.USERNAME_HYPERLINK);
		driver.findElement(By.xpath(xpathExpression)).click();

		Thread.sleep(sleepInterval);

		//XPath expression for Cancel button
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_CANCEL);
		//Click on Cancel button
		driver.findElement(By.xpath(xpathExpression)).click();

		Thread.sleep(sleepInterval);

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.FORM_SEARCH_USER);
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "20", "Verify the functionality of 'Cancel' button", "Upon clicking cancel button ,the system cancelled the editing user popup and navigated back to Search User screen", AppConstants.vPass);
		} else {
			generateXML.logVP( "20", "Verify the functionality of 'Cancel' button", "Upon clicking cancel button ,the system cancelled the editing user popup but not navigated back to Search User screen", AppConstants.vFail);
		}
	}

	/**
	 * Test Case 31326: Verify the functionality of 'Reset Password' button
	 * Upon clicking Reset Password button ,the system should open a pop up where user can reset the password
	 * @throws InterruptedException 
	 */
	@Test
	public void test_C_3() throws InterruptedException {
		/*Click on Admin button*/		
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ADMIN);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//xpath expression for selected side menu
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT);		

		//Default selected menu item is fetched from the screen
		driver.findElement(By.cssSelector(xpathExpression)).click();

		//xpath expression for button 'Go'
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO);
		//Click on Go button
		driver.findElement(By.xpath(xpathExpression)).click();
		Thread.sleep(sleepInterval);
		//xpath expression for user name hyperlink in data table
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.USERNAME_HYPERLINK);
		driver.findElement(By.xpath(xpathExpression)).click();

		Thread.sleep(sleepInterval);

		//XPath expression for Reset Password button
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_RESET_PWD);
		//Click on Reset Password button
		driver.findElement(By.xpath(xpathExpression)).click();

		//XPath expression for Password reset popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_RESETPWD);
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "21", "Verify the functionality of 'Reset Password' button", "Upon clicking Reset Password button ,the system opens a pop up where password reset message displayed", AppConstants.vPass);
		} else {
			generateXML.logVP( "21", "Verify the functionality of 'Reset Password' button", "Upon clicking Reset Password button ,the system does not open a pop up where password reset message displayed", AppConstants.vFail);
		}

		Thread.sleep(sleepInterval);

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_RESETPWD_OK);
		driver.findElement(By.xpath(xpathExpression)).click();

	}

	/**
	 * Test Case 31327: Verify the functionality of 'Close' button on top right corner of pop up
	 * Upon clicking close button ,the system should close edit user pop up and naviagte to Search User page
	 * @throws InterruptedException 
	 */
	@Test
	public void test_C_4() throws InterruptedException {

		//XPath expression for close button.i.e. X button at right top of the popup
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_CLOSE);
		//Click on X button
		driver.findElement(By.xpath(xpathExpression)).click();

		Thread.sleep(sleepInterval);

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.FORM_SEARCH_USER);
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "22", "Verify the functionality of 'Close' button on top right corner of pop up", "Upon clicking close button ,the system closed edit user pop up and naviagted to Search User page", AppConstants.vPass);
		} else {
			generateXML.logVP( "22", "Verify the functionality of 'Close' button on top right corner of pop up", "Upon clicking close button ,the system does not clos edit user pop up and not naviagted to Search User page", AppConstants.vFail);
		}

	}

	/**
	 * Test Case 31328: Verify user can able to navigate successfully to Create User page Clicking on Create User button  in the right menu
	 * The user should be able to navigate successfully to Create User page Clicking on Create User button  in the right menu
	 * @throws InterruptedException 
	 */
	@Test
	public void test_C_5() {
		//XPath expression for Create User button
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_CREATEUSER);
		//Click on Create User button
		driver.findElement(By.xpath(xpathExpression)).click();

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.FORM_CREATEUSER);
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "23", "Verify user can able to navigate successfully to Create User page Clicking on Create User button  in the right menu", "The user is able to navigate successfully to Create User page by clicking on Create User button in the right menu", AppConstants.vPass);
		} else {
			generateXML.logVP( "23", "Verify user can able to navigate successfully to Create User page Clicking on Create User button  in the right menu", "The user is not able to navigate to Create User page by clicking on Create User button in the right menu", AppConstants.vFail);
		}		

	}

	/**
	 * Test Case 31329: Verify User Name
	 * The User Name text  box should allow alphanumeric  only in email format
	 * @throws InterruptedException 
	 */
	@Test
	public void test_C_6() throws InterruptedException {		
		//Click on 'Create User' popup to get focus
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.FORM_CREATEUSER);
		driver.findElement(By.xpath(xpathExpression)).click();			

		//Get the user name to be entered in User Name text box, user name with special characters
		String prop_invalid_username = propsRW.read(AdminConstants.INVALID_USERNAME1);		

		String userNameXpath = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_USERNAME);
		//enter the invalid user name in User Name text box
		driver.findElement(By.xpath(userNameXpath)).sendKeys(prop_invalid_username);		

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.ERRMSG_CREATEUSER_UNAME);

		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "24", "Verify User Name", "The User Name text  box allows alphanumeric along with  . _ - and @ characters", AppConstants.vPass);
		} else {
			generateXML.logVP( "24", "Verify User Name", "The User Name text  box allows alphanumeric along with special characters other than . _ - and @ characters", AppConstants.vFail);
		}

		//Click on OK button in error message "only alphanumeric and . _ - and @ characters are allowed" popup.
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_POPUP_BTN_OK);
		driver.findElement(By.xpath(xpathExpression)).click();

		//Wait for some time to get the focus from error message popup to Create User page
		Thread.sleep(sleepInterval);

		//Get the user name to be entered in User Name text box, user name not in email format
		prop_invalid_username = propsRW.read(AdminConstants.INVALID_USERNAME2);		

		//enter the invalid user name in User Name text box
		driver.findElement(By.xpath(userNameXpath)).clear();
		driver.findElement(By.xpath(userNameXpath)).sendKeys(prop_invalid_username);

		//xpath expression for first name text box in create user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_FIRSTNAME);
		driver.findElement(By.xpath(xpathExpression)).sendKeys(propsRW.read(AdminConstants.FIRST_NAME));

		//xpath expression for last name text box in create user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_LASTNAME);
		driver.findElement(By.xpath(xpathExpression)).sendKeys(propsRW.read(AdminConstants.LAST_NAME));

		//xpath expression for email text box in create user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_POPUP_EMAIL);
		driver.findElement(By.xpath(xpathExpression)).sendKeys(propsRW.read(AdminConstants.EMAIL));

		//xpath expression for email text box in create user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_POPUP_ROLE_ADMIN);
		driver.findElement(By.xpath(xpathExpression)).click();		 

		//Click on Create button
		String btnCreateXpath = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_CREATE);
		driver.findElement(By.xpath(btnCreateXpath)).click();	
		WebElement element = driver.findElement(By.xpath(userNameXpath));

		Thread.sleep(sleepInterval);
		/*
		 * After entering invalid email format in user name field and click on 'Create' button,
		 * focus should go to user name text box. The same is verified in the below if condition
		 */
		if(element.equals(driver.switchTo().activeElement())) {
			generateXML.logVP( "24", "Verify User Name", "The User Name text  box allows alphanumeric only in email format", AppConstants.vPass); 
		} else {
			generateXML.logVP( "24", "Verify User Name", "The User Name text  box does not allow alphanumeric only in email format", AppConstants.vFail);
		}

	}

	/**
	 * Test Case 31331: Verify Role field in create user screen
	 * The Role field is a list of all available roles and checkboxes inorder to select any role
	 * @throws InterruptedException 
	 */
	@Test
	public void test_C_7() throws InterruptedException {		

		/*
		 * Get the list of check boxes and corresponding roles from Roles multi-select dropdown
		 */
		int count = 0;
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.POPUP_SELECTED_ROLES);
		driver.findElement(By.xpath(xpathExpression)).click();
		List<WebElement> lstOfRoles = driver.findElement(By.xpath(xpathExpression)).findElements(By.tagName(AppConstants.INPUT));

		/*
		 *  Ex: <input id="Admin" class="secondary" type="checkbox" checked="" value="1" name="secondaryRoleId">
		 *  For each and every input field in Role multi-select, check whether input field is displayed or not, 
		 *  check for type="checkbox" attribute and id attribute's value.
		 *  If all the above conditions are satisfied, increment count.
		 */
		for(WebElement webElement : lstOfRoles) {			
			if((webElement.isDisplayed()) 
					&& (null != webElement.getAttribute(AppConstants.TYPE)) 
					&& (webElement.getAttribute(AppConstants.TYPE).equalsIgnoreCase(AppConstants.CHECKBOX))
					&& (null != webElement.getAttribute(AppConstants.ID))
					&& (!AppConstants.BLANK_STRING.equals(webElement.getAttribute(AppConstants.ID)))
					) {
				count++;
			}			
		}		

		/*
		 * If above conditions are satisfied for all the list of roles
		 * available in Roles multi-select, then the verification point is passed
		 */
		if(count == lstOfRoles.size()) {
			generateXML.logVP( "25", "Verify Role field", "The Role field is a list of all available roles and checkboxes inorder to select any role", AppConstants.vPass);
		} else {
			generateXML.logVP( "25", "Verify Role field", "The Role field does not have list of all available roles and checkboxes inorder to select any role", AppConstants.vFail);
		}		

		//Click on cancel button
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_POPUP_BTN_CANCEL);
		driver.findElement(By.xpath(xpathExpression)).click();	
	}

	/**
	 * Test Case 31332: Verify the functionality of 'Create' button
	 * The system shall validate the details entered by user upon clicking Save button and create the User
	 * @throws InterruptedException 
	 */
	@Test
	public void test_C_8() throws InterruptedException {		

		//Click on 'Create User' button
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_CREATEUSER);
		driver.findElement(By.xpath(xpathExpression)).click();			

		Thread.sleep(sleepInterval);

		//Get the user name to be entered in User Name text box, user name with special characters
		String prop_invalid_username = propsRW.read(AdminConstants.INVALID_USERNAME1);		

		String userNameXpath = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_USERNAME);
		//enter the invalid user name in User Name text box
		driver.findElement(By.xpath(userNameXpath)).sendKeys(prop_invalid_username);		

		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.ERRMSG_CREATEUSER_UNAME);
		boolean errMsgDisplayed = false;
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			errMsgDisplayed = true;
		}

		//Click on OK button in error message "only alphanumeric and . _ - and @ characters are allowed" popup.
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_POPUP_BTN_OK);
		driver.findElement(By.xpath(xpathExpression)).click();

		//Wait for some time to get the focus from error message popup to Create User page
		Thread.sleep(sleepInterval);

		//Get the user name to be entered in User Name text box, user name not in email format
		prop_invalid_username = propsRW.read(AdminConstants.INVALID_USERNAME2);		

		//enter the invalid user name in User Name text box
		driver.findElement(By.xpath(userNameXpath)).clear();
		driver.findElement(By.xpath(userNameXpath)).sendKeys(prop_invalid_username);

		//xpath expression for first name text box in edit user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_FIRSTNAME);
		driver.findElement(By.xpath(xpathExpression)).sendKeys(propsRW.read(AdminConstants.FIRST_NAME));

		//xpath expression for last name text box in create user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_LASTNAME);
		driver.findElement(By.xpath(xpathExpression)).sendKeys(propsRW.read(AdminConstants.LAST_NAME));

		//xpath expression for email text box in create user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_POPUP_EMAIL);
		driver.findElement(By.xpath(xpathExpression)).sendKeys(propsRW.read(AdminConstants.EMAIL));

		//xpath expression for ROLE in create user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_POPUP_ROLE_ADMIN);
		driver.findElement(By.xpath(xpathExpression)).click();		 

		//Click on Create button
		String btnCreateXpath = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_CREATE);
		driver.findElement(By.xpath(btnCreateXpath)).click();	
		WebElement element = driver.findElement(By.xpath(userNameXpath));

		Thread.sleep(sleepInterval);
		boolean isEmailFormat = false;
		/*
		 * After entering invalid email format in user name field and click on 'Create' button,
		 * focus should go to user name text box. The same is verified in the below if condition
		 */
		if(element.equals(driver.switchTo().activeElement())) {
			isEmailFormat = true;
		} 	

		//enter the valid user name in User Name text box, proper user name with email format
		driver.findElement(By.xpath(userNameXpath)).clear();
		driver.findElement(By.xpath(userNameXpath)).sendKeys(propsRW.read(AdminConstants.EMAIL));	

		//Click on Create button
		driver.findElement(By.xpath(btnCreateXpath)).click();	

		//xpath expression for success message popup in create user popup
		xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_USER_SUCCESS);
		String exprectedSuccessMsg = propsRW.read(AdminConstants.CREATE_USER_SUCCESS_MSG)+ propsRW.read(AdminConstants.EMAIL);
		if(errMsgDisplayed && 
				isEmailFormat &&
				driver.findElement(By.xpath(xpathExpression)).isDisplayed()
				&& (driver.findElement(By.xpath(xpathExpression)).getText().equals(exprectedSuccessMsg))) {
			generateXML.logVP( "26", "Verify the functionality of 'Create' button", "The system validated the details entered by user upon clicking Create button and error message is displayed as expected", AppConstants.vPass);
		} else {
			generateXML.logVP( "26", "Verify the functionality of 'Create' button", "The system validated the details entered by user upon clicking Create button and error message is not displayed as expected", AppConstants.vFail);
		}

		//Click on OK button in success message popup of create user
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_POPUP_SUCCESSMSG_BTN_OK))).click();	

		//Click on  User Management side menu
		driver.findElement(By.cssSelector(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_USERMGMT))).click();	

		/* Get valid user name from properties file
		 * ex: pavani@gmail.com 
		 */
		String userName = propsRW.read(AdminConstants.EMAIL).trim();
		//Enter valid user name in User Name text box
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_USERNAME))).sendKeys(userName);

		//Click on Go button
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO))).click();

		//Data table result user name column
		String result_userName = driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.RESULT_USERNAME))).getText();

		//Data table result first name column
		String result_firstName = driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.RESULT_FIRSTNAME))).getText();

		//Data table result last name column
		String result_lastName = driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.RESULT_LASTNAME))).getText();

		//Data table result primary role column
		String result_primaryRole = driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.RESULT_PRIMARYROLE))).getText();

		//Data table result status column
		String result_status = driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.RESULT_STATUS))).getText();

		/* Compare the result (data in the table) with that of given search criteria */
		if(result_userName.contains(userName) && (result_firstName.contains(propsRW.read(AdminConstants.FIRST_NAME)))
				&& (result_lastName.contains(propsRW.read(AdminConstants.LAST_NAME))
						&& (result_status.equals(AdminConstants.ACTIVE)))) {
			// Set new element tag details 		
			generateXML.logVP( "26", "Verify the functionality of 'Create' button", "User is created successfully", AppConstants.vPass);
		} else {
			// Set new element tag details 		
			generateXML.logVP( "26", "Verify the functionality of 'Create' button", "User is not created", AppConstants.vFail);	
		}

	}

	/**
	 * Test Case 31333: Verify the functionality of 'Cancel' button
	 * Upon clicking cancel button ,the system should cancel the editing User and navigate back to Search User screen
	 * @throws InterruptedException 
	 */
	@Test
	public void test_C_9() throws InterruptedException {		

		Thread.sleep(sleepInterval);		

		//Click on Create button
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_CREATEUSER))).click();	

		//Click on 'Create User' popup to get focus
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.FORM_CREATEUSER))).click();	
		Thread.sleep(sleepInterval);		

		//Click on cancel button in Create user popup
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.CREATE_POPUP_BTN_CANCEL))).click();
		//Verify whether Search User screen is displayed or not
		String xpathExpression = excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.FORM_SEARCH_USER);			
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "27", "Verify the functionality of 'Cancel' button", "Upon clicking cancel button ,the system cancelled the Create User popup and navigated back to Search User screen", AppConstants.vPass);
		} else {
			generateXML.logVP( "27", "Verify the functionality of 'Cancel' button", "Upon clicking cancel button ,the system does not cancel the Create User popup and navigate back to Search User screen", AppConstants.vFail);
		}			
	}

	/**
	 * Test Case 31334: Verify the functionality of Delete User
	 * Upon clicking delete icon after searching for the particular user ,the system should display a message 
	 * asking for confirmation if yes then delete the user and search screen should be displayed 
	 * else search screen should be displayed
	 * @throws InterruptedException 
	 */
	@Test
	public void test_D_1() throws InterruptedException {

		/* Get valid user name from properties file which is in email format
		 * ex: newUser@gmail.com 
		 */
		String userName = propsRW.read(AdminConstants.EMAIL).trim();
		//Provide user name in User Name text box
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_USERNAME))).sendKeys(userName);

		/* Get valid first name from properties file and provide it in First Name text box
		 * ex: finc 
		 */	
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_FIRSTNAME))).sendKeys(propsRW.read(AdminConstants.FIRST_NAME));

		/* Get valid last name from properties file and provide it in Last Name text box
		 * ex: finc 
		 */
		String lastName = propsRW.read(AdminConstants.VALID_LASTNAME).trim();

		//provide last name in the Last Name text box
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_LASTNAME))).sendKeys(propsRW.read(AdminConstants.LAST_NAME));

		String primaryRole = propsRW.read(AdminConstants.ADMIN_ROLE);
		//Select Admin role from Role dropdown
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.SELECT_ROLE))).sendKeys(primaryRole);

		String status = propsRW.read(AdminConstants.VALID_STATUS);
		//Select a status from Status dropdown
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.SELECT_STATUS))).sendKeys(status);

		//Click on Go button
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO))).click();

		Thread.sleep(sleepInterval);

		//Click on delete button
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_DELETE))).click();

		//Get delete confirmation message
		String deleteConfirmMsg = driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.DELETE_CONFIRM_MSG))).getText();
		String expectedMsg = propsRW.read(AdminConstants.DELETE_CONFIRM_MSG)+propsRW.read(AdminConstants.EMAIL).trim()+AppConstants.QUESTION_MARK;

		//If expected and actual confirmation messages are same then verification point is passed otherwise it is falied
		if(expectedMsg.equals(deleteConfirmMsg)) {
			generateXML.logVP( "28", "Verify the functionality of Delete User", "Upon clicking delete icon after searching for the particular user ,the system displayed expected message asking for confirmation to delete", AppConstants.vPass);
		} else {
			generateXML.logVP( "28", "Verify the functionality of Delete User", "Upon clicking delete icon after searching for the particular user ,the system does not displayed expected message asking for confirmation to delete", AppConstants.vFail);
		}

		//Get Cancel button xpath expression and Click on it
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_CANCEL_DEL_CONFIRM))).click();

		if(driver.findElement(By.xpath(
				excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.FORM_SEARCH_USER))).isDisplayed()) {
			generateXML.logVP( "28", "Verify the functionality of Delete User", "Upon clicking delete icon after searching for the particular user ,the system displayed expected message asking for confirmation to delete. On click of 'Cancel' button in confirmation popup, Search User screen is displayed", AppConstants.vPass);
		} else{
			generateXML.logVP( "28", "Verify the functionality of Delete User", "Upon clicking delete icon after searching for the particular user ,the system displayed expected message asking for confirmation to delete. On click of 'Cancel' button in confirmation popup, Search User screen is not displayed", AppConstants.vFail);
		}

		//Click on delete button
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_DELETE))).click();

		//Get OK button xpath expression and Click on it
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_OK_DEL_CONFIRM))).click();

		String delSuccessMsg = driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.DEL_SUCCESS_MSG))).getText();
		if(delSuccessMsg.equals(propsRW.read(AdminConstants.DEL_SUCCESS_MSG))) {
			generateXML.logVP( "28", "Verify the functionality of Delete User", "On click of 'OK' button in confirmation popup, 'User Deleted Successfully!' message is displayed", AppConstants.vPass);
		} else {
			generateXML.logVP( "28", "Verify the functionality of Delete User", "On click of 'OK' button in confirmation popup, 'User Deleted Successfully!' message is not displayed", AppConstants.vFail);
		}

		Thread.sleep(sleepInterval);

		//Click on OK button in popup having message "User Deleted Successfully!"
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_OK_DEL_SUCCESS))).click();

		Thread.sleep(sleepInterval);

		/* Get valid user name from properties file which is in email format and click on 'GO' button.
		 * ex: newUser@gmail.com 
		 * As user is deleted, "No data available in table" message is displayed
		 */	
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_USERNAME))).clear();
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_USERNAME))).sendKeys(userName);

		//Click on Go button
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_GO))).click();
		Thread.sleep(sleepInterval);
		//Check whether the deleted user is present in the data table on the screen or not
		String actualMsg = driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.NO_DATA_MSG))).getText();
		if(actualMsg.equals(propsRW.read(AdminConstants.NO_DATA_MSG))) {
			generateXML.logVP( "28", "Verify the functionality of Delete User", "User deleted successfully", AppConstants.vPass);
		} else {
			generateXML.logVP( "28", "Verify the functionality of Delete User", "User not deleted successfully", AppConstants.vFail);
		}		

	}

	/**
	 * Test Case 31336: Verify default tab selected when clicked onRole Mangement tab
	 * The Search Role should be default option when clicked on Role Mangement tab
	 */
	@Test
	public void test_D_2() {
		//Click on Role Management side menu tab				
		driver.findElement(By.cssSelector(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_ROLEMGMT))).click();

		if(driver.findElement(By.cssSelector(
				excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_ROLEMGMT))).isDisplayed()) {
			generateXML.logVP( "29", "Verify Role Management tab", "Search role screen is displayed on right side when Role Management tab is selected", AppConstants.vPass);
		} else {
			generateXML.logVP( "29", "Verify Role Management tab", "Search role screen is not displayed on right side when Role Management tab is selected", AppConstants.vFail);
		}
	}

	/**
	 * Test Case 31338: Verify Search section
	 * The search section should be displayed with Role name /Created date /End date text boxes,Create Role and 'Go' buttons
	 * @throws InterruptedException 
	 */
	@Test
	public void test_D_3() throws InterruptedException {
		//Click on Role Management side menu tab				
		driver.findElement(By.cssSelector(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.MENU_ROLEMGMT))).click();

		//Click on Role Name text box				
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_ROLENAME))).click();

		Thread.sleep(sleepInterval);
		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_ROLENAME))).isDisplayed()) {
			generateXML.logVP( "30", "Verify Search section", "Role Name text box is displayed on Search role screen", AppConstants.vPass);
		} else {
			generateXML.logVP( "30", "Verify Search section", "Role Name text box is not displayed on Search role screen", AppConstants.vFail);
		}

		//Click on Created Date text box				
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_STARTDATE))).click();

		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_STARTDATE))).isDisplayed()) {
			generateXML.logVP( "30", "Verify Search section", "Created Date text box is displayed on Search role screen", AppConstants.vPass);
		} else {
			generateXML.logVP( "30", "Verify Search section", "Created Date text box is not displayed on Search role screen", AppConstants.vFail);
		}

		//Click on End Date text box				
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_ENDDATE))).click();

		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TXTBOX_ENDDATE))).isDisplayed()) {
			generateXML.logVP( "30", "Verify Search section", "End Date text box is displayed on Search role screen", AppConstants.vPass);
		} else {
			generateXML.logVP( "30", "Verify Search section", "End Date text box is not displayed on Search role screen", AppConstants.vFail);
		}

		//Check whether 'Create Role' button is displayed or not
		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_CREATEROLE))).isDisplayed()) {
			generateXML.logVP( "30", "Verify Search section", "'Create Role' button is displayed on Search role screen", AppConstants.vPass);
		} else {
			generateXML.logVP( "30", "Verify Search section", "'Create Role' button is not displayed on Search role screen", AppConstants.vFail);
		}

		//Check whether 'Go' button is displayed or not
		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ROLE_GO))).isDisplayed()) {
			generateXML.logVP( "30", "Verify Search section", "'Go' button is displayed on Search role screen", AppConstants.vPass);
		} else {
			generateXML.logVP( "30", "Verify Search section", "'Go' button is not displayed on Search role screen", AppConstants.vFail);
		}
	}

	/**
	 * Test Case 31342: Verify the functionality of 'Go' button
	 * The system shall validate the details entered by user upon clicking Go button and should display the search results  applying 'and' search .
	 */
	@Test
	public void test_D_4() {
		//Click on go button
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.BTN_ROLE_GO))).click();
		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_ROLE))).isDisplayed()) {
			generateXML.logVP( "31", "Verify the functionality of 'Go' button", "Search results are displayed in a table", AppConstants.vPass);
		} else {
			generateXML.logVP( "31", "Verify the functionality of 'Go' button", "Search results are not displayed in a table", AppConstants.vFail);
		}
	}

	/**
	 * Test Case 31344: Verify search results
	 * The search results in the grid should have Role Name  /Created By and Role Description and Delete columns displayed with delete icons and pagination as in wireframe
	 */
	@Test
	public void test_D_5() {
		// Verifying the table header names Role Name, Created By, Role Description and Delete
		// Verifying the table header name Role Name
		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_ROLE_HDR_1))).getText().
				equals(propsRW.read(AdminConstants.TABLE_ROLE_HDR_1))) {
			generateXML.logVP( "32", "Verify search results", "Search results grid contains 'Role Name' column", AppConstants.vPass);
		} else {
			generateXML.logVP( "32", "Verify search results", "Search results grid does not contain 'Role Name' column", AppConstants.vFail);
		} 
		// Verifying the table header name Created By
		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_ROLE_HDR_2))).getText().
				equals(propsRW.read(AdminConstants.TABLE_ROLE_HDR_2))) {
			generateXML.logVP( "32", "Verify search results", "Search results grid contains 'Created By' column", AppConstants.vPass);
		} else {
			generateXML.logVP( "32", "Verify search results", "Search results grid does not contain 'Created By' column", AppConstants.vFail);
		}
		// Verifying the table header name Role Description
		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_ROLE_HDR_3))).getText().
				equals(propsRW.read(AdminConstants.TABLE_ROLE_HDR_3))) {
			generateXML.logVP( "32", "Verify search results", "Search results grid contains 'Role Description' column", AppConstants.vPass);
		} else {
			generateXML.logVP( "32", "Verify search results", "Search results grid does not contain 'Role Description' column", AppConstants.vFail);
		}
		// Verifying the table header name Delete
		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_ROLE_HDR_4))).getText().
				equals(propsRW.read(AdminConstants.TABLE_ROLE_HDR_4))) {
			generateXML.logVP( "32", "Verify search results", "Search results grid contains 'Delete' column", AppConstants.vPass);
		} else {
			generateXML.logVP( "32", "Verify search results", "Search results grid does not contain 'Delete' column", AppConstants.vFail);
		}
		// Verifying the pagination, Previous button is displayed or not
		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_ROLE_BTN_PRE))).
				isDisplayed()) {
			generateXML.logVP( "32", "Verify search results", "Search results grid contains Previous button for pagination", AppConstants.vPass);
		} else {
			generateXML.logVP( "32", "Verify search results", "Search results grid does not contain Previous button for pagination", AppConstants.vFail);
		}
		// Verifying the pagination, Next button is displayed or not
		if(driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_ROLE_BTN_NEXT))).
				isDisplayed()) {
			generateXML.logVP( "32", "Verify search results", "Search results grid contains Next button for pagination", AppConstants.vPass);
		} else {
			generateXML.logVP( "32", "Verify search results", "Search results grid does not contain Next button for pagination", AppConstants.vFail);
		}		

	}

	/**
	 * Test Case 31346: Verify whether user can click on the arrow available next to  Role Name, Created By and Role Description title in the columns of Grid
	 * The arrow next to  Role Name, Created By and Role Description in the grid should be clickable and upon clicking - column values have to change in ascending(for up arrow) and  descending form (for down arrow )
	 * @throws InterruptedException 
	 */
	@Test
	public void test_D_6() throws InterruptedException {		
		ascDescRoleTableColumns (AdminConstants.TABLE_ROLE_HDR_1, 0);
		
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_ROLE_HDR_2))).click();
		Thread.sleep(sleepInterval);
		ascDescRoleTableColumns (AdminConstants.TABLE_ROLE_HDR_2, 1);
		
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_ROLE_HDR_3))).click();
		Thread.sleep(sleepInterval);
		ascDescRoleTableColumns (AdminConstants.TABLE_ROLE_HDR_3, 2);
	}	

	/**
	 * This method verifies whether sorting data in a particular column is working or not
	 * @param headerXpath
	 * @param columnPosition
	 */
	public void ascDescRoleTableColumns( String headerXpath, int columnPosition) {

		//Get class attribute of role name column. It will be either sorting_asc for ascending or sorting_desc for descending 
		String ascDescClass = driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, headerXpath))).getAttribute(AppConstants.CLASS);

		String columnHeader = driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, headerXpath))).getText();

		//Role table WebElement
		WebElement table =driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, AdminConstants.TABLE_ROLE_BODY)));

		//get the column contents in a list		
		List<String> columnData = new ArrayList<String>();
		columnData = commonUtil.getColumnContents(table,columnPosition); 
		for(int i=0;i<columnData.size(); i++) {
			System.out.println("Before asc ----- "+columnData.get(i));
		}

		//Pass the list and order of sorting to checkSorting() method that returns true or false
		boolean sortSuccess = commonUtil.checkSorting(columnData, AppConstants.ASCENDING);

		/* If class atribute's value is "sorting_asc" and checkSorting() method returns true, then data is sorted in ascending order */
		if((ascDescClass.equals(AdminConstants.SORTING_ASC) || (ascDescClass.equals(AdminConstants.SORTING))) && sortSuccess) {
			generateXML.logVP( "33", "Verify whether user can click on the arrow available next to  "+columnHeader+" title in the columns of Grid", "The arrow next to  "+columnHeader+" title in the grid is clickable and upon clicking - column values changed to ascending(for up arrow) order", AppConstants.vPass);
		} else {
			generateXML.logVP( "33", "Verify whether user can click on the arrow available next to  "+columnHeader+" title in the columns of Grid", "The arrow next to  "+columnHeader+" title in the grid is clickable and upon clicking - column values not changed to ascending(for up arrow) order", AppConstants.vFail);
		}	

		//Click on Role Name  header for sorting in descending order
		driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, headerXpath))).click();
		ascDescClass = driver.findElement(By.xpath(excelRW.readProps(AdminConstants.ADMIN_PAGE, headerXpath))).getAttribute(AppConstants.CLASS);
		for(int i=0;i<columnData.size(); i++) {
			System.out.println("Before desc ----- "+columnData.get(i));
		}
		//get the column contents in a list		
		columnData = commonUtil.getColumnContents(table, columnPosition); 
		//Pass the list and order of sorting to checkSorting() method that returns true or false
		sortSuccess = commonUtil.checkSorting(columnData, AppConstants.DESCENDING);		

		if((ascDescClass.equals(AdminConstants.SORTING_DESC) || (ascDescClass.equals(AdminConstants.SORTING)))&& sortSuccess) {
			generateXML.logVP( "33", "Verify whether user can click on the arrow available next to  "+columnHeader+" title in the columns of Grid", "The arrow next to  "+columnHeader+" title in the grid is clickable and upon clicking - column values changed to descending(for down arrow) order", AppConstants.vPass);
		} else {
			generateXML.logVP( "33", "Verify whether user can click on the arrow available next to  "+columnHeader+" title in the columns of Grid", "The arrow next to  "+columnHeader+" title in the grid is clickable and upon clicking - column values not changed to descending(for down arrow) order", AppConstants.vFail);
		}	


	}

	/**
	 * After class where detailed report generation is done 
	 * and some static variables are assigned "" or 0 based on the
	 * type
	 * @throws Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {

		AppConstants.notRunCount = 	 Integer.parseInt(propsRW.read(AppConstants.TOTAL_VERIFICATION_POINTS).trim())-AppConstants.passCount-AppConstants.failCount;		

		//log header report counts in XML file
		generateXML.logHeaderReportCounts();
		//Generate html report using xml created in test method
		//Report should be according to test case name, ex: data.html
		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH+AppConstants.DETAILED_REPORT_XSL;
		String outputHTML = AppConstants.DETAIL_REPORT_FOLDER+AppConstants.FORWARD_SLASH+AdminConstants.ADMIN+AppConstants.DOT_HTML;
		generateReport.generateHTML(AppConstants.XML_FILE_PATH, inputXSL, outputHTML);

		System.out.println("Successfully generated the report");

		//log script in summary report xml file
		generateXML.logScript(AdminConstants.ADMIN_SCRIPT_NAME, outputHTML);

		//Reset xml & properties files path to ""	
		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;

		//Set pass, fail and notrun count to zero
		AppConstants.passCount= 0;
		AppConstants.failCount = 0;
		AppConstants.notRunCount = 0;

		//Close the browser
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}


}
