/**
 * 
 */
package ocpe.aut.fwk.testScripts;

import static ocpe.aut.fwk.constants.AppConstants.*;
import static ocpe.aut.fwk.testScripts.support.ReportLogger.logTestEndResults;
import static org.junit.Assert.*;

import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.pages.HomePage;
import ocpe.aut.fwk.pages.HomePage.ChangePasswordDiv.RPErrorMessageDiv;
import ocpe.aut.fwk.pages.LoginPage;
import ocpe.aut.fwk.pages.HomePage.ChangePasswordDiv;
import ocpe.aut.fwk.testScripts.support.OCPETestWatcher;
import ocpe.aut.fwk.util.DriverFactory;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

/**
 * @author arindam_r
 * 
 */
public class LandingPage {

	private static WebDriver driver;

	private static PropertiesUtil propsRW;

	private static HomePage homePage;

	private static GenerateXml xmlWriter;

	@Rule
	public OCPETestWatcher ocpeTestWatcher;

	public LandingPage() {
		ocpeTestWatcher = new OCPETestWatcher(xmlWriter, propsRW,
				HOME_PASS_PROPERTIES, HOME_FAIL_PROPERTIES);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		driver = DriverFactory.FIREFOX.get();
		homePage = new HomePage(driver, new LoginPage(driver));

		// Change the xml file path according to name of the script
		AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER
				+ AppConstants.FORWARD_SLASH + AppConstants.HOME
				+ AppConstants.DOT_XML;

		xmlWriter = new GenerateXml();
		xmlWriter.createVPXML(HOME_SCRIPT_NAME);
		propsRW = new PropertiesUtil(HOME_PROPERTIES);

		AppConstants.PROPERTIES_FILE_PATH = AppConstants.HOME_PROPERTIES;
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		logTestEndResults(xmlWriter, propsRW, HOME, HOME_SCRIPT_NAME);
		driver.quit();
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		homePage = homePage.get();
	}

	@Test
	public void test_25() {
		ChangePasswordDiv changePasswordDiv = homePage.changePassword();
		assertNotNull(changePasswordDiv);
	}

	/*@Test
	public void test_26() {
		ChangePasswordDiv changePasswordDiv = homePage.changePassword();
		assertTrue(changePasswordDiv.readTitle().contains(
				propsRW.read(AppConstants.RP_TITLE)));
	}

	@Test
	public void test_27() {
		RPErrorMessageDiv errorMessageDiv = homePage.changePassword()
				.typeOldPassword(EMPTY_STRING).updateExpectingFailure();
		assertTrue(errorMessageDiv.readErrorMessage().contains("Old Password"));
	}*/

}
