package ocpe.aut.fwk.testScripts;

import static ocpe.aut.fwk.constants.APITabConstants.HEADER_AHAM_API_EXPLORER;
import static ocpe.aut.fwk.constants.APITabConstants.IFRAME_SERVICES_API;
import static ocpe.aut.fwk.constants.APITabConstants.IFRAME_SERVICES_HEADER_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.LINK_PRODUCTS;
import static ocpe.aut.fwk.constants.APITabConstants.LINK_USERS;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_ALSO_VIEWED_ITEMS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_ALSO_VIEWED_ITEMS_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_ALSO_VIEWED_ITEMS_RESPONSE;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_ALSO_VIEWED_ITEMS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_RESPONSE;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_RESPONSE;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_OPEN_COMMERCE_DATA_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_OPEN_COMMERCE_DATA_QUERY;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_OPEN_COMMERCE_DATA_RESPONSE;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_OPEN_COMMERCE_DATA_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PRODUCT_ANALYTICS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PRODUCT_ANALYTICS_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PRODUCT_ANALYTICS_RESPONSE;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PRODUCT_ANALYTICS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PRODUCT_DETAILS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PRODUCT_DETAILS_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PRODUCT_DETAILS_RESPONSE;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PRODUCT_DETAILS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PROMOTIONS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PROMOTIONS_PARTNUMBER;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PROMOTIONS_RESPONSE;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_PROMOTIONS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_SIMILAR_PRODUCTS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_SIMILAR_PRODUCTS_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_SIMILAR_PRODUCTS_RESPONSE;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_SIMILAR_PRODUCTS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_SUGGESTED_ITEMS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_SUGGESTED_ITEMS_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_SUGGESTED_ITEMS_RESPONSE;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_SUGGESTED_ITEMS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_TOP_SELLING_ITEMS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_TOP_SELLING_ITEMS_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_TOP_SELLING_ITEMS_RESPONSE;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_TOP_SELLING_ITEMS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_RESPONSE;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_TRYITOUT;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETLOCATION_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETLOCATION_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETLOCATION_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETLOCATION_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETLOCATION_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETHIERARCHY_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETHIERARCHY_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETHIERARCHY_LEVEL;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETHIERARCHY_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETHIERARCHY_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETHIERARCHY_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETHIERARCHY_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_GETPROMOTIONS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_GETPROMOTIONS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_GETPROMOTIONS_TYPE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_GETPROMOTIONS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_GETPROMOTIONS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_GETPROMOTIONS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_GETPROMOTIONS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_CUSTOMERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_TYPE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_CHANNEL;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_COMPAREID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_INITIATORUSERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_COMPAREID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_CHANNEL;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARERATINGS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARERATINGS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARERATINGS_INITIATORUSERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARERATINGS_COMPAREID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARERATINGS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARERATINGS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETUSERDETAILS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETUSERDETAILS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETUSERDETAILS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETUSERDETAILS_CHANNEL;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETUSERDETAILS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETUSERDETAILS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARES_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARES_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARES_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARES_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARES_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERNAME;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYNAMES_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYNAMES_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYNAMES_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYNAMES_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYNAMES_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_COUNT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_CHANNEL;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_STRATEGYID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_CHANNEL;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETPURCHASEDITEMS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETPURCHASEDITEMS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETPURCHASEDITEMS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETPURCHASEDITEMS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETPURCHASEDITEMS_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETPURCHASEDITEMS_CHANNEL;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETPURCHASEDITEMS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETPURCHASEDITEMS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETVIEWEDONLYITEMS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETVIEWEDONLYITEMS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETVIEWEDONLYITEMS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETVIEWEDONLYITEMS_COLUMNFAMILY;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETVIEWEDONLYITEMS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETVIEWEDONLYITEMS_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETVIEWEDONLYITEMS_CHANNEL;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETVIEWEDONLYITEMS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETVIEWEDONLYITEMS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETFRIENDSBIRTHDAYS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETFRIENDSBIRTHDAYS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETFRIENDSBIRTHDAYS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETFRIENDSBIRTHDAYS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETFRIENDSBIRTHDAYS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_AHAMFACEBOOKLOGIN_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_AHAMFACEBOOKLOGIN_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_AHAMFACEBOOKLOGIN_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_AHAMFACEBOOKLOGIN_ACCESSTOKEN;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_AHAMFACEBOOKLOGIN_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_POST_USERS_AHAMFACEBOOKLOGIN_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETRETURNITEMS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETRETURNITEMS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETRETURNITEMS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETRETURNITEMS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETRETURNITEMS_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETRETURNITEMS_CHANNEL;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETRETURNITEMS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETRETURNITEMS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_INITIATORUSERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_COMPAREID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETGUESTUSERBROWSED_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETGUESTUSERBROWSED_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETGUESTUSERBROWSED_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETGUESTUSERBROWSED_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETGUESTUSERBROWSED_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETGUESTUSERBROWSED_CHANNEL;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETGUESTUSERBROWSED_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETGUESTUSERBROWSED_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_STRATEGYID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_CHANNEL;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_PRODUCTS;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LAYOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETUSERCLUSTERINFO_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETUSERCLUSTERINFO_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETUSERCLUSTERINFO_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETUSERCLUSTERINFO_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETUSERCLUSTERINFO_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETLOCATIONFROMIP_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETLOCATIONFROMIP_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETLOCATIONFROMIP_USERIP;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETLOCATIONFROMIP_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETLOCATIONFROMIP_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPVIEWEDSOURCES_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPVIEWEDSOURCES_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPVIEWEDSOURCES_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPVIEWEDSOURCES_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPVIEWEDSOURCES_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETMYANALYTICS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETMYANALYTICS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETMYANALYTICS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETMYANALYTICS_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETMYANALYTICS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETMYANALYTICS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPCATEGORIES_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPCATEGORIES_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPCATEGORIES_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPCATEGORIES_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPCATEGORIES_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.USERS_GET_USERS_GETTOPCATEGORIES_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_ALGONAME;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETSUMMARY_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETSUMMARY_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETSUMMARY_TYPE;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETSUMMARY_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.STRATEGY_GET_STRATEGY_GETSUMMARY_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_BUTTON;
import static ocpe.aut.fwk.constants.APITabConstants.SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_ANCHOR;
import static ocpe.aut.fwk.constants.APITabConstants.SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY;
import static ocpe.aut.fwk.constants.APITabConstants.SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_CHANNEL;
import static ocpe.aut.fwk.constants.APITabConstants.SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_TRYITOUT;
import static ocpe.aut.fwk.constants.APITabConstants.SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_RESPONSE;

import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_ID_VALID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_ID_INVALID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_CATALOGHIERARCHY_LEVEL;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETPROMOTIONS_TYPE;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETCLUSTERRECOMMENDATIONS_TYPE;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERNAME;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETINTENTBASEDRECOMMENDATIONS_COUNT;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETSUGGESTEDITEMSFORYOU_PRODUCTID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETSTRATEGIESFORUSERBYSHELF_STRATEGYID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETPURCHASEDITEMS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETVIEWEDONLYITEMS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETVIEWEDONLYITEMS_COLUMNFAMILY;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETREPLENISHMENTRECOMMENDATIONS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETREPLENISHMENTRECOMMENDATIONS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETFRIENDSBIRTHDAYS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_POSTAHAMFACEBOOKLOGIN_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_POSTAHAMFACEBOOKLOGIN_ACCESSTOKEN;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETRETURNITEMS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_INITIATORUSERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_COMPAREID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETGUESTUSERBROWSED_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_STRATEGYID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_PRODUCTS;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LAYOUT;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETUSERCLUSTERINFO_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETBEHAVIORFORCUSTOMER360_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETLOCATIONFROMIP_USERIP;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETLOCATIONFROMIP_USERIP_INVALID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETMYANALYTICS_USERID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_USERS_GETTOPCATEGORIES_USERID;

import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_LOCATION;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_CATALOGHIERARCHY;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETPROMOTIONS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETCLUSTERRECOMMENDATIONS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_INSERTSOCIALCOMPAREPRODUCTS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_INSERTSOCIALCOMPARERATINGS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETSOCIALCOMPAREPRODUCTS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETSOCIALCOMPARERATINGS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETUSERDETAILS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETSOCIALCOMPARES;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETSTRATEGYNAMES;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETSTRATEGYRECOMMENDATIONS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETINTENTBASEDRECOMMENDATIONS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETSUGGESTEDITEMSFORYOU;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETSTRATEGIESFORUSERBYSHELF;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETPURCHASEDITEMS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETVIEWEDONLYITEMS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETREPLENISHMENTRECOMMENDATIONS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETFRIENDSBIRTHDAYS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_POSTAHAMFACEBOOKLOGIN;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETRETURNITEMS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETGUESTUSERBROWSED;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETUSERCLUSTERINFO;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETBEHAVIORFORCUSTOMER360;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETLOCATIONFROMIP;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETTOPVIEWEDCATEGORIES;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETTOPVIEWEDSOURCES;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETMYANALYTICS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_USERS_GETTOPCATEGORIES;

import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS_INVALID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME_INVALID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME_INVALID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_GETTRACEANALYTICS_PRODUCT_ID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_GETTRACEANALYTICS_PRODUCT_ID_INVALID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_GETTRACEANALYTICS_ALGONAME;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_GETTRACEANALYTICS_ALGONAME_INVALID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_GETTRACEANALYTICS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME_INVALID;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_GETSTRATEGYANALYTICS_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_GETSUMMARY_TYPE;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_STRATEGY_GETSUMMARY_TYPE_INVALID;

import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_STRATEGY_INSERTALGORITHMPARAMETERS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_STRATEGY_FETCHALGORITHMPARAMETERS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_STRATEGY_GETTRACEANALYTICS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_STRATEGY_GETSTRATEGYANALYTICS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_STRATEGY_GETSUMMARY;

import static ocpe.aut.fwk.constants.APITabConstants.INPUT_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY;
import static ocpe.aut.fwk.constants.APITabConstants.INPUT_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY_INVALID;

import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT;

import static ocpe.aut.fwk.constants.APITabConstants.COMMON_SERVICES_MODE;
import static ocpe.aut.fwk.constants.APITabConstants.COMMON_SERVICES_LIMIT;
import static ocpe.aut.fwk.constants.APITabConstants.COMMON_SERVICES_CHANNEL;

import static ocpe.aut.fwk.constants.APITabConstants.PRODUCT_ID_INVALID;
import static ocpe.aut.fwk.constants.APITabConstants.PRODUCT_ID_VALID;
import static ocpe.aut.fwk.constants.APITabConstants.QUERY_OPEN_COMMERCE_DATA_INVALID;
import static ocpe.aut.fwk.constants.APITabConstants.QUERY_OPEN_COMMERCE_DATA_VALID;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_ALSO_VIEWED_ITEMS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_BOUGHT_TOGETHER_ITEMS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_COMPLETE_THE_LOOK_ITEMS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_READ_OPEN_COMMERCE_DATA;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_SIMILAR_PRODUCTS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_SUGGESTED_ITEMS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_TOP_SELLING_ITEMS;
import static ocpe.aut.fwk.constants.APITabConstants.RESPONSE_ULTIMATELY_BOUGHT_ITEMS;

import static ocpe.aut.fwk.constants.AppConstants.vFail;
import static ocpe.aut.fwk.constants.AppConstants.vPass;
import static ocpe.aut.fwk.constants.AppConstants.API_TAB;
import static ocpe.aut.fwk.constants.AppConstants.API_TAB_PROPERTIES;

import static org.junit.Assert.fail;

import java.io.File;
import java.util.concurrent.TimeUnit;

import ocpe.aut.fwk.constants.APITabConstants;
import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class APITab {

	private static PropertiesUtil propsRW;
	private static PropertiesUtil propsAPITab;
	private static GenerateXml generateXML;
	private static WebDriver driver;
	private static GenerateHTML generateReport;
	private static DesiredCapabilities cap = null; 
	private static FirefoxBinary ffBinary = null; 
	private static FirefoxProfile ffprofile = null;
	private static StringBuffer verificationErrors = new StringBuffer();
	private static int pass= 0, fail = 0, notRun = 0;
	private static int cpCount = 0;
	
	/**
	 * @throws java.lang.Exception
	 */
	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		File  pathToFirefoxBinary = new File(AppConstants.PATH_TO_FIREFOX_BINARY);
		ffBinary = new FirefoxBinary(pathToFirefoxBinary);
		ProfilesIni profile = new ProfilesIni();		   		   
		ffprofile = profile.getProfile(AppConstants.FIREFOX_PROFILE_DEFAULT);
		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();		  		  
		proxy.setProxyAutoconfigUrl(AppConstants.PROXY_URL);	
		cap = new DesiredCapabilities();		  
		cap.setCapability(CapabilityType.PROXY, proxy);	

	// Change the XML file path according to name of the script
		AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER+AppConstants.FORWARD_SLASH+AppConstants.API_TAB+AppConstants.DOT_XML;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.API_TAB_PROPERTIES;

		generateXML = new GenerateXml();		
		generateReport = new GenerateHTML();
		
	// Create a new XML file
		generateXML.createVPXML(AppConstants.API_TAB);

	// Utility classes that reads the excel sheet and properties files
		propsRW = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);
		propsAPITab = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		driver = new FirefoxDriver(ffBinary, ffprofile,cap);		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();	
		driver.get(AppConstants.BASE_URL + AppConstants.LOGIN_URL);	
		
	// Login
		String xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE, AppConstants.USER_NAME);
		driver.findElement(By.xpath(xpathExpression)).clear();

		propsRW = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);
		String userName = propsRW.read(AppConstants.VALID_USERNAME).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(userName);

		xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE, AppConstants.PASSWORD);
		driver.findElement(By.xpath(xpathExpression)).clear();

		String password = propsRW.read(AppConstants.VALID_PASSWORD).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(password);

		xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE, AppConstants.LOGIN_SUBMIT);		
		driver.findElement(By.xpath(xpathExpression)).click();
		
		driver.findElement(By.linkText("API")).click();
		
		
	}

	/**
	 * @throws java.lang.Exception
	 */
	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		notRun = Integer.parseInt(propsAPITab.read(
			AppConstants.TOTAL_VERIFICATION_POINTS).trim())-pass-fail;		
		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH+AppConstants.DETAILED_REPORT_XSL;
		String outputHTML = AppConstants.DETAIL_REPORT_FOLDER+AppConstants.FORWARD_SLASH+AppConstants.DATA+AppConstants.DOT_HTML;
		generateReport.generateHTML(AppConstants.XML_FILE_PATH, inputXSL, outputHTML);
        AppConstants.notRunCount =  Integer.parseInt(propsRW.read(
    		AppConstants.TOTAL_VERIFICATION_POINTS).trim())-AppConstants.passCount-AppConstants.failCount;                   

	// Log script in summary report XML file
		generateXML.logScript(AppConstants.DATA_SCRIPT_NAME, outputHTML);
        generateXML.logHeaderReportCounts();
        generateXML.logScript(AppConstants.LOGIN_SCRIPT_NAME, outputHTML);

    // Reset XML & properties files path	
		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;

    // Set pass, fail and not run count to zero
        AppConstants.passCount= 0;
        AppConstants.failCount = 0;
        AppConstants.notRunCount = 0;
        
	// Close the browser
        Thread.sleep(2000);
        driver.close();
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	/**
	 * @throws java.lang.Exception
	 */
	@Before
	public void setUp() throws Exception {
		WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);
	}

	/**
	 * @throws java.lang.Exception
	 */
	@After
	public void tearDown() throws Exception {
		driver.switchTo().defaultContent();
	}

	@Test
	public void test_00() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/

		String heading = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_HEADER_ANCHOR))).getText();
		if(HEADER_AHAM_API_EXPLORER.equals(heading)) {
			generateXML.logVP(""+cpCount, "Check whether AHAM API Explorer page is loaded?", "Successfully loaded", vPass);
		}else {
			generateXML.logVP(""+cpCount, "Check whether AHAM API Explorer page is loaded?", "Page not loaded", vFail);
		}

		/*driver.switchTo().defaultContent();*/
	}
	
	// getProductDetails service
	@Test
	public void test_products_01() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_PRODUCTS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, PRODUCTS_GET_PRODUCT_DETAILS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_DETAILS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_DETAILS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_DETAILS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_DETAILS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(PRODUCT_ID_VALID))) {
			generateXML.logVP(++cpCount+"", "Check getProductDetails service fetched valid response for existing productId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getProductDetails service fetched valid response for existing productId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_DETAILS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_DETAILS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_DETAILS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_DETAILS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(PRODUCT_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getProductDetails service fetched invalid response for non existing productId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getProductDetails service fetched invalid response for non existing productId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getSuggestedItems service
	@Test
	public void test_products_02() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_PRODUCTS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, PRODUCTS_GET_SUGGESTED_ITEMS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SUGGESTED_ITEMS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SUGGESTED_ITEMS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SUGGESTED_ITEMS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SUGGESTED_ITEMS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_SUGGESTED_ITEMS))) {
			generateXML.logVP(++cpCount+"", "Check getSuggestedItems service fetched valid response for given productId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSuggestedItems service fetched valid response for given productId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SUGGESTED_ITEMS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SUGGESTED_ITEMS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SUGGESTED_ITEMS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SUGGESTED_ITEMS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(PRODUCT_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getSuggestedItems service fetched invalid response for non existing productId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSuggestedItems service fetched invalid response for non existing productId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getProductAnalytics service
	@Test
	public void test_products_03() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_PRODUCTS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, PRODUCTS_GET_PRODUCT_ANALYTICS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_ANALYTICS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_ANALYTICS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_ANALYTICS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_ANALYTICS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(PRODUCT_ID_VALID))) {
			generateXML.logVP(++cpCount+"", "Check getProductAnalytics service fetched valid response for given productId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getProductAnalytics service fetched valid response for given productId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_ANALYTICS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_ANALYTICS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_ANALYTICS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PRODUCT_ANALYTICS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(PRODUCT_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getProductAnalytics service fetched invalid response for non existing productId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getProductAnalytics service fetched invalid response for non existing productId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getPromotions service
	@Test
	public void test_products_04() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_PRODUCTS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, PRODUCTS_GET_PROMOTIONS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_PARTNUMBER))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_PARTNUMBER))).sendKeys(propsAPITab.read(PRODUCT_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(PRODUCT_ID_VALID))) {
			generateXML.logVP(++cpCount+"", "Check getPromotions service fetched valid response for given productId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getPromotions service fetched valid response for given productId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_PARTNUMBER))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_PARTNUMBER))).sendKeys(propsAPITab.read(PRODUCT_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(PRODUCT_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getPromotions service fetched invalid response for non existing productId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getPromotions service fetched invalid response for non existing productId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getBoughtTogetherItems service
	@Test
	public void test_products_05() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_PRODUCTS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_BOUGHT_TOGETHER_ITEMS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_BOUGHT_TOGETHER_ITEMS))) {
			generateXML.logVP(++cpCount+"", "Check getBoughtTogetherItems service fetched valid response for given productId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getBoughtTogetherItems service fetched valid response for given productId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_PARTNUMBER))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_PARTNUMBER))).sendKeys(propsAPITab.read(PRODUCT_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_PROMOTIONS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(PRODUCT_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getBoughtTogetherItems service fetched invalid response for non existing productId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getBoughtTogetherItems service fetched invalid response for non existing productId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getOpenCommerceData service
	@Test
	public void test_products_06() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_PRODUCTS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, PRODUCTS_GET_OPEN_COMMERCE_DATA_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_OPEN_COMMERCE_DATA_QUERY))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_OPEN_COMMERCE_DATA_QUERY))).sendKeys(propsAPITab.read(QUERY_OPEN_COMMERCE_DATA_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_OPEN_COMMERCE_DATA_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_OPEN_COMMERCE_DATA_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_READ_OPEN_COMMERCE_DATA))) {
			generateXML.logVP(++cpCount+"", "Check getOpenCommerceData service fetched valid response for given productId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getOpenCommerceData service fetched valid response for given productId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_OPEN_COMMERCE_DATA_QUERY))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_OPEN_COMMERCE_DATA_QUERY))).sendKeys(propsAPITab.read(QUERY_OPEN_COMMERCE_DATA_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_OPEN_COMMERCE_DATA_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_OPEN_COMMERCE_DATA_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(QUERY_OPEN_COMMERCE_DATA_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getOpenCommerceData service fetched invalid response for non existing productId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getOpenCommerceData service fetched invalid response for non existing productId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getAlsoViewedItems service
	@Test
	public void test_products_07() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_PRODUCTS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, PRODUCTS_GET_ALSO_VIEWED_ITEMS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ALSO_VIEWED_ITEMS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ALSO_VIEWED_ITEMS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ALSO_VIEWED_ITEMS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ALSO_VIEWED_ITEMS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_ALSO_VIEWED_ITEMS))) {
			generateXML.logVP(++cpCount+"", "Check getAlsoViewedItems service fetched valid response for given productId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getAlsoViewedItems service fetched valid response for given productId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ALSO_VIEWED_ITEMS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ALSO_VIEWED_ITEMS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ALSO_VIEWED_ITEMS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ALSO_VIEWED_ITEMS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(PRODUCT_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getAlsoViewedItems service fetched invalid response for non existing productId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getAlsoViewedItems service fetched invalid response for non existing productId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getUltimatelyBoughtItems service
	@Test
	public void test_products_08() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_PRODUCTS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_ULTIMATELY_BOUGHT_ITEMS))) {
			generateXML.logVP(++cpCount+"", "Check getUltimatelyBoughtItems service fetched valid response for given productId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getUltimatelyBoughtItems service fetched valid response for given productId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_ULTIMATELY_BOUGHT_ITEMS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(PRODUCT_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getUltimatelyBoughtItems service fetched invalid response for non existing productId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getUltimatelyBoughtItems service fetched invalid response for non existing productId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getCompleteTheLookItems service
	@Test
	public void test_products_09() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_PRODUCTS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_COMPLETE_THE_LOOK_ITEMS))) {
			generateXML.logVP(++cpCount+"", "Check getCompleteTheLookItems service fetched valid response for given productId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getCompleteTheLookItems service fetched valid response for given productId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_COMPLETE_THE_LOOK_ITEMS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(PRODUCT_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getCompleteTheLookItems service fetched invalid response for non existing productId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getCompleteTheLookItems service fetched invalid response for non existing productId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getSimilarProducts service
	@Test
	public void test_products_10() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_PRODUCTS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, PRODUCTS_GET_SIMILAR_PRODUCTS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SIMILAR_PRODUCTS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SIMILAR_PRODUCTS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SIMILAR_PRODUCTS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SIMILAR_PRODUCTS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_SIMILAR_PRODUCTS))) {
			generateXML.logVP(++cpCount+"", "Check getSimilarProducts service fetched valid response for given productId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSimilarProducts service fetched valid response for given productId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SIMILAR_PRODUCTS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SIMILAR_PRODUCTS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SIMILAR_PRODUCTS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_SIMILAR_PRODUCTS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(PRODUCT_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getSimilarProducts service fetched invalid response for non existing productId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSimilarProducts service fetched invalid response for non existing productId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getTopSellingItems service
	@Test
	public void test_products_11() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_PRODUCTS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, PRODUCTS_GET_TOP_SELLING_ITEMS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_TOP_SELLING_ITEMS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_TOP_SELLING_ITEMS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_TOP_SELLING_ITEMS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_TOP_SELLING_ITEMS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_TOP_SELLING_ITEMS))) {
			generateXML.logVP(++cpCount+"", "Check getTopSellingItems service fetched valid response for given productId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getTopSellingItems service fetched valid response for given productId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_TOP_SELLING_ITEMS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_TOP_SELLING_ITEMS_PRODUCTID))).sendKeys(propsAPITab.read(PRODUCT_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_TOP_SELLING_ITEMS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			PRODUCTS_GET_TOP_SELLING_ITEMS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(PRODUCT_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getTopSellingItems service fetched invalid response for non existing productId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getTopSellingItems service fetched invalid response for non existing productId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
/*******************************************************************************
 * 	Users Service API - Start
 ******************************************************************************/
	
	//getLocation service
	@Test
	public void test_users_01() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETLOCATION_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATION_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATION_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATION_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATION_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_LOCATION))) {
			generateXML.logVP(++cpCount+"", "Check getLocation service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getLocation service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATION_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATION_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATION_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATION_RESPONSE)));
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getLocation service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getLocation service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getHierarchy service
	@Test
	public void test_users_02() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETHIERARCHY_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_LEVEL))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_LEVEL))).sendKeys(propsAPITab.read(INPUT_USERS_CATALOGHIERARCHY_LEVEL));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_CATALOGHIERARCHY))) {
			generateXML.logVP(++cpCount+"", "Check getHierarchy service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getHierarchy service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_LEVEL))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_LEVEL))).sendKeys(propsAPITab.read(INPUT_USERS_CATALOGHIERARCHY_LEVEL));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETHIERARCHY_RESPONSE)));
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getHierarchy service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getHierarchy service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getPromotions service
	@Test
	public void test_users_03() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_POST_USERS_GETPROMOTIONS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_TYPE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_TYPE))).sendKeys(propsAPITab.read(INPUT_USERS_GETPROMOTIONS_TYPE));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		Select mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETPROMOTIONS))) {
			generateXML.logVP(++cpCount+"", "Check getPromotions service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getPromotions service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_TYPE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_TYPE))).sendKeys(propsAPITab.read(INPUT_USERS_GETPROMOTIONS_TYPE));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_INVALID));
		mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_GETPROMOTIONS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getPromotions service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getPromotions service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getClusterRecommendations service
	@Test
	public void test_users_04() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_CUSTOMERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_CUSTOMERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_TYPE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_TYPE))).sendKeys(propsAPITab.read(INPUT_USERS_GETCLUSTERRECOMMENDATIONS_TYPE));
		Select mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		Select channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETCLUSTERRECOMMENDATIONS))) {
			generateXML.logVP(++cpCount+"", "Check getClusterRecommendations service fetched valid response for given customerId and type?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getClusterRecommendations service fetched valid response for given customerId and type?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_CUSTOMERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_CUSTOMERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_TYPE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_TYPE))).sendKeys(propsAPITab.read(INPUT_USERS_GETCLUSTERRECOMMENDATIONS_TYPE));
		mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETCLUSTERRECOMMENDATIONS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getClusterRecommendations service fetched invalid response for non existing customerId and type?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getClusterRecommendations service fetched invalid response for non existing customerId and type?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//insertSocialCompareProducts service
	@Test
	public void test_users_05() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID))).sendKeys(propsAPITab.read(
				INPUT_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_INSERTSOCIALCOMPAREPRODUCTS))) {
			generateXML.logVP(++cpCount+"", "Check insertSocialCompareProducts service inserts data successfully?", "Inserted data successfully", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check insertSocialCompareProducts service inserts data successfully?", "Data insertion failed", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID))).sendKeys(propsAPITab.read(
				INPUT_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPAREPRODUCTS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check insertSocialCompareProducts service should not insert invalid records?", "Invalid records not inserted", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check insertSocialCompareProducts service should not insert invalid records?", "Invalid records inserted", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//insertSocialCompareRatings service
	@Test
	public void test_users_06() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_COMPAREID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_COMPAREID))).sendKeys(propsAPITab.read(
				INPUT_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_INSERTSOCIALCOMPARERATINGS))) {
			generateXML.logVP(++cpCount+"", "Check insertSocialCompareRatings service inserts data successfully?", "Inserted data successfully", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check insertSocialCompareRatings service inserts data successfully?", "Data insertion failed", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_COMPAREID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_COMPAREID))).sendKeys(propsAPITab.read(
				INPUT_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_INSERTSOCIALCOMPARERATINGS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check insertSocialCompareRatings service should not insert invalid records?", "Invalid records not inserted", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check insertSocialCompareRatings service should not insert invalid records?", "Invalid records inserted", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getSocialCompareProducts service
	@Test
	public void test_users_07() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_INITIATORUSERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_INITIATORUSERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_COMPAREID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_COMPAREID))).sendKeys(
				propsAPITab.read(INPUT_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID));
		Select mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		Select channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETSOCIALCOMPAREPRODUCTS))) {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareProducts service fetched valid response for given users?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareProducts service fetched valid response for given users?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_INITIATORUSERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_INITIATORUSERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_COMPAREID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_COMPAREID))).sendKeys(
				propsAPITab.read(INPUT_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID));
		mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPAREPRODUCTS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareProducts service fetched invalid response for non existing users?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareProducts service fetched invalid response for non existing users?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getSocialCompareRatings service
	@Test
	public void test_users_08() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETSOCIALCOMPARERATINGS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_INITIATORUSERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_INITIATORUSERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_COMPAREID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_COMPAREID))).sendKeys(
				propsAPITab.read(INPUT_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETSOCIALCOMPARERATINGS))) {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareRatings service fetched valid response for given users?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareRatings service fetched valid response for given users?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_INITIATORUSERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_INITIATORUSERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_COMPAREID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_COMPAREID))).sendKeys(
				propsAPITab.read(INPUT_USERS_INSERTSOCIALCOMPAREPRODUCTS_COMPAREID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARERATINGS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareRatings service fetched invalid response for non existing users?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareRatings service fetched invalid response for non existing users?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getUserDetails service
	@Test
	public void test_users_09() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETUSERDETAILS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERDETAILS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERDETAILS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		Select channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERDETAILS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERDETAILS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERDETAILS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETUSERDETAILS))) {
			generateXML.logVP(++cpCount+"", "Check getUserDetails service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getUserDetails service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERDETAILS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERDETAILS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_INVALID));
		channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERDETAILS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERDETAILS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERDETAILS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getUserDetails service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getUserDetails service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getSocialCompares service
	@Test
	public void test_users_10() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETSOCIALCOMPARES_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARES_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARES_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARES_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARES_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETSOCIALCOMPARES))) {
			generateXML.logVP(++cpCount+"", "Check getSocialCompares service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSocialCompares service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARES_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARES_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARES_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARES_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getSocialCompares service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSocialCompares service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//postInsertSocialCompareProducts service
	@Test
	public void test_users_11() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERNAME))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERNAME))).sendKeys(
				propsAPITab.read(INPUT_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERNAME));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS))) {
			generateXML.logVP(++cpCount+"", "Check postInsertSocialCompareProducts service inserts data successfully?", "Inserted data successfully", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check postInsertSocialCompareProducts service inserts data successfully?", "Data insertion failed", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERNAME))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERNAME))).sendKeys(
				propsAPITab.read(INPUT_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_USERNAME));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_POSTINSERTSOCIALCOMPAREPRODUCTS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check postInsertSocialCompareProducts service should not insert invalid records?", "Invalid records not inserted", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check postInsertSocialCompareProducts service should not insert invalid records?", "Invalid records not inserted", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getStrategyNames service
	@Test
	public void test_users_12() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETSTRATEGYNAMES_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYNAMES_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYNAMES_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYNAMES_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYNAMES_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETSTRATEGYNAMES))) {
			generateXML.logVP(++cpCount+"", "Check getStrategyNames service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getStrategyNames service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYNAMES_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYNAMES_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYNAMES_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYNAMES_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getStrategyNames service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getStrategyNames service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getStrategyRecommendations service
	@Test
	public void test_users_13() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETSTRATEGYRECOMMENDATIONS))) {
			generateXML.logVP(++cpCount+"", "Check getStrategyRecommendations service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getStrategyRecommendations service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getStrategyRecommendations service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getStrategyRecommendations service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getIntentBasedRecommendations service
	@Test
	public void test_users_14() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_COUNT))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_COUNT))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETINTENTBASEDRECOMMENDATIONS_COUNT));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETINTENTBASEDRECOMMENDATIONS))) {
			generateXML.logVP(++cpCount+"", "Check getIntentBasedRecommendations service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getIntentBasedRecommendations service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_COUNT))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_COUNT))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETINTENTBASEDRECOMMENDATIONS_COUNT));
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETINTENTBASEDRECOMMENDATIONS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getIntentBasedRecommendations service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getIntentBasedRecommendations service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getSuggestedItemsForYou service
	@Test
	public void test_users_15() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_PRODUCTID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETSUGGESTEDITEMSFORYOU_PRODUCTID));
		Select mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		Select channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETSUGGESTEDITEMSFORYOU))) {
			generateXML.logVP(++cpCount+"", "Check getSuggestedItemsForYou service fetched valid response for given users?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSuggestedItemsForYou service fetched valid response for given users?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_PRODUCTID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETSUGGESTEDITEMSFORYOU_PRODUCTID));
		mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSUGGESTEDITEMSFORYOU_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getSuggestedItemsForYou service fetched invalid response for non existing users?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSuggestedItemsForYou service fetched invalid response for non existing users?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getStrategiesForUserByShelf service
	@Test
	public void test_users_16() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_VALID));
		Select strategyId = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_STRATEGYID))));
		strategyId.selectByVisibleText(propsAPITab.read(INPUT_USERS_GETSTRATEGIESFORUSERBYSHELF_STRATEGYID));
		Select mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		Select channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETSTRATEGIESFORUSERBYSHELF))) {
			generateXML.logVP(++cpCount+"", "Check getStrategiesForUserByShelf service fetched valid response for given users?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getStrategiesForUserByShelf service fetched valid response for given users?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_INVALID));
		strategyId = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_STRATEGYID))));
		strategyId.selectByVisibleText(propsAPITab.read(INPUT_USERS_GETSTRATEGIESFORUSERBYSHELF_STRATEGYID));
		mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGIESFORUSERBYSHELF_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getStrategiesForUserByShelf service fetched invalid response for non existing users?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getStrategiesForUserByShelf service fetched invalid response for non existing users?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getPurchasedItems service
	@Test
	public void test_users_17() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETPURCHASEDITEMS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_GETPURCHASEDITEMS_USERID));
		Select mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		Select channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETPURCHASEDITEMS))) {
			generateXML.logVP(++cpCount+"", "Check getPurchasedItems service fetched valid response for given users?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getPurchasedItems service fetched valid response for given users?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_USERID))).sendKeys(propsAPITab.read(INPUT_USERS_ID_INVALID));
		mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETPURCHASEDITEMS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getPurchasedItems service fetched invalid response for non existing users?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getPurchasedItems service fetched invalid response for non existing users?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	
	//getViewedOnlyItems service
	@Test
	public void test_users_18() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETVIEWEDONLYITEMS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETVIEWEDONLYITEMS_USERID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_COLUMNFAMILY))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_COLUMNFAMILY))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETVIEWEDONLYITEMS_COLUMNFAMILY));

		Select mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		Select channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETVIEWEDONLYITEMS))) {
			generateXML.logVP(++cpCount+"", "Check getViewedOnlyItems service fetched valid response for given users?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getViewedOnlyItems service fetched valid response for given users?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_COLUMNFAMILY))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_COLUMNFAMILY))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETVIEWEDONLYITEMS_COLUMNFAMILY));

		mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETVIEWEDONLYITEMS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getViewedOnlyItems service fetched invalid response for non existing users?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getViewedOnlyItems service fetched invalid response for non existing users?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getReplenishmentRecommendations service
	@Test
	public void test_users_19() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETREPLENISHMENTRECOMMENDATIONS_USERID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_MODE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_MODE))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETREPLENISHMENTRECOMMENDATIONS_MODE));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETREPLENISHMENTRECOMMENDATIONS))) {
			generateXML.logVP(++cpCount+"", "Check getReplenishmentRecommendations service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getReplenishmentRecommendations service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_MODE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_MODE))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETREPLENISHMENTRECOMMENDATIONS_MODE));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETREPLENISHMENTRECOMMENDATIONS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getReplenishmentRecommendations service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getReplenishmentRecommendations service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getFriendsBirthdays service
	@Test
	public void test_users_20() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETFRIENDSBIRTHDAYS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETFRIENDSBIRTHDAYS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETFRIENDSBIRTHDAYS_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETFRIENDSBIRTHDAYS_USERID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETFRIENDSBIRTHDAYS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETFRIENDSBIRTHDAYS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETFRIENDSBIRTHDAYS))) {
			generateXML.logVP(++cpCount+"", "Check getFriendsBirthdays service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getFriendsBirthdays service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETFRIENDSBIRTHDAYS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETFRIENDSBIRTHDAYS_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETFRIENDSBIRTHDAYS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETFRIENDSBIRTHDAYS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getFriendsBirthdays service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getFriendsBirthdays service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//postAhamFacebookLogin service
	@Test
	public void test_users_21() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_POST_USERS_AHAMFACEBOOKLOGIN_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_POSTAHAMFACEBOOKLOGIN_USERID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_ACCESSTOKEN))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_ACCESSTOKEN))).sendKeys(
				propsAPITab.read(INPUT_USERS_POSTAHAMFACEBOOKLOGIN_ACCESSTOKEN));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_POSTAHAMFACEBOOKLOGIN))) {
			generateXML.logVP(++cpCount+"", "Check postAhamFacebookLogin service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check postAhamFacebookLogin service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_POSTAHAMFACEBOOKLOGIN_USERID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_ACCESSTOKEN))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_ACCESSTOKEN))).sendKeys(
				propsAPITab.read(INPUT_USERS_POSTAHAMFACEBOOKLOGIN_ACCESSTOKEN));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_POST_USERS_AHAMFACEBOOKLOGIN_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check postAhamFacebookLogin service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check postAhamFacebookLogin service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getReturnItems service
	@Test
	public void test_users_22() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETRETURNITEMS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETRETURNITEMS_USERID));
		Select mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		Select channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETRETURNITEMS))) {
			generateXML.logVP(++cpCount+"", "Check getReturnItems service fetched valid response for given users?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getReturnItems service fetched valid response for given users?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_ID_INVALID));
		mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETRETURNITEMS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getReturnItems service fetched invalid response for non existing users?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getReturnItems service fetched invalid response for non existing users?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getSocialCompareConsolidatedRatings service
	@Test
	public void test_users_23() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_INITIATORUSERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_INITIATORUSERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_INITIATORUSERID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_COMPAREID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_COMPAREID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_COMPAREID));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS))) {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareConsolidatedRatings service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareConsolidatedRatings service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_INITIATORUSERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_INITIATORUSERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_COMPAREID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_COMPAREID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_COMPAREID));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSOCIALCOMPARECONSOLIDATEDRATINGS_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareConsolidatedRatings service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSocialCompareConsolidatedRatings service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getGuestUserBrowsed service
	@Test
	public void test_users_24() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETGUESTUSERBROWSED_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETGUESTUSERBROWSED_USERID));
		Select mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		Select channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETGUESTUSERBROWSED))) {
			generateXML.logVP(++cpCount+"", "Check getGuestUserBrowsed service fetched valid response for given users?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getGuestUserBrowsed service fetched valid response for given users?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_ID_INVALID));
		mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETGUESTUSERBROWSED_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getGuestUserBrowsed service fetched invalid response for non existing users?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getGuestUserBrowsed service fetched invalid response for non existing users?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getStrategyRecommendationsEmail service
	@Test
	public void test_users_25() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_USERID));
		Select strategyId = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_STRATEGYID))));
		strategyId.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		Select mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		Select channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_PRODUCTS))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_PRODUCTS))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_PRODUCTS));
		Select layout = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LAYOUT))));
		layout.selectByVisibleText(propsAPITab.read(INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LAYOUT));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL))) {
			generateXML.logVP(++cpCount+"", "Check getStrategyRecommendationsEmail service fetched valid response for given users?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getStrategyRecommendationsEmail service fetched valid response for given users?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_ID_INVALID));
		strategyId = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_STRATEGYID))));
		strategyId.selectByVisibleText(propsAPITab.read(INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_STRATEGYID));
		mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_PRODUCTS))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_PRODUCTS))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_PRODUCTS));
		layout = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LAYOUT))));
		layout.selectByVisibleText(propsAPITab.read(INPUT_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_LAYOUT));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETSTRATEGYRECOMMENDATIONSEMAIL_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getStrategyRecommendationsEmail service fetched invalid response for non existing users?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getStrategyRecommendationsEmail service fetched invalid response for non existing users?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getUserClusterInfo service
	@Test
	public void test_users_26() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETUSERCLUSTERINFO_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERCLUSTERINFO_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERCLUSTERINFO_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETUSERCLUSTERINFO_USERID));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERCLUSTERINFO_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERCLUSTERINFO_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETUSERCLUSTERINFO))) {
			generateXML.logVP(++cpCount+"", "Check getUserClusterInfo service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getUserClusterInfo service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERCLUSTERINFO_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERCLUSTERINFO_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_ID_INVALID));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERCLUSTERINFO_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETUSERCLUSTERINFO_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getUserClusterInfo service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getUserClusterInfo service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getBehaviorForCustomer360 service
	@Test
	public void test_users_27() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETBEHAVIORFORCUSTOMER360_USERID));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETBEHAVIORFORCUSTOMER360))) {
			generateXML.logVP(++cpCount+"", "Check getBehaviorForCustomer360 service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getBehaviorForCustomer360 service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_ID_INVALID));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETBEHAVIORFORCUSTOMER360_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getBehaviorForCustomer360 service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getBehaviorForCustomer360 service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getLocationfromIP service
	@Test
	public void test_users_28() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETLOCATIONFROMIP_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATIONFROMIP_USERIP))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATIONFROMIP_USERIP))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETLOCATIONFROMIP_USERIP));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATIONFROMIP_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATIONFROMIP_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETLOCATIONFROMIP))) {
			generateXML.logVP(++cpCount+"", "Check getLocationfromIP service fetched valid response for given userIP?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getLocationfromIP service fetched valid response for given userIP?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATIONFROMIP_USERIP))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATIONFROMIP_USERIP))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETLOCATIONFROMIP_USERIP_INVALID));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATIONFROMIP_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETLOCATIONFROMIP_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getLocationfromIP service fetched invalid response for non existing userIP?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getLocationfromIP service fetched invalid response for non existing userIP?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getTopViewedCategories service
	@Test
	public void test_users_29() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_ANCHOR))).click();
		
	// Valid Input	
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPVIEWEDCATEGORIES_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETTOPVIEWEDCATEGORIES))) {
			generateXML.logVP(++cpCount+"", "Check getTopViewedCategories service fetched valid response for given limit?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getTopViewedCategories service fetched valid response for given limit?", "Fetched invalid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getTopViewedSources service
	@Test
	public void test_users_30() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETTOPVIEWEDSOURCES_ANCHOR))).click();
		
	// Valid Input	
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPVIEWEDSOURCES_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPVIEWEDSOURCES_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPVIEWEDSOURCES_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETTOPVIEWEDSOURCES))) {
			generateXML.logVP(++cpCount+"", "Check getTopViewedSources service fetched valid response for given limit?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getTopViewedSources service fetched valid response for given limit?", "Fetched invalid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//getMyAnalytics service
	@Test
	public void test_users_31() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETMYANALYTICS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETMYANALYTICS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETMYANALYTICS_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETMYANALYTICS_USERID));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETMYANALYTICS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETMYANALYTICS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETMYANALYTICS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETMYANALYTICS))) {
			generateXML.logVP(++cpCount+"", "Check getMyAnalytics service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getMyAnalytics service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}

		// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETMYANALYTICS_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETMYANALYTICS_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_ID_INVALID));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETMYANALYTICS_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETMYANALYTICS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETMYANALYTICS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getMyAnalytics service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getMyAnalytics service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getTopCategories service
	@Test
	public void test_users_32() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, USERS_GET_USERS_GETTOPCATEGORIES_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPCATEGORIES_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPCATEGORIES_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_GETTOPCATEGORIES_USERID));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPCATEGORIES_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPCATEGORIES_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPCATEGORIES_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_USERS_GETTOPCATEGORIES))) {
			generateXML.logVP(++cpCount+"", "Check getTopCategories service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getTopCategories service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}

		// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPCATEGORIES_USERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPCATEGORIES_USERID))).sendKeys(
				propsAPITab.read(INPUT_USERS_ID_INVALID));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPCATEGORIES_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPCATEGORIES_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			USERS_GET_USERS_GETTOPCATEGORIES_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(INPUT_USERS_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getTopCategories service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getTopCategories service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
/*******************************************************************************
 * 	Users Service API - End
 ******************************************************************************/

	//getSearchedAndUltimatelyBought service
	@Test
	public void test_search_01() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY))).sendKeys(
				propsAPITab.read(INPUT_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY));
		Select mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		Select limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		Select channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT))) {
			generateXML.logVP(++cpCount+"", "Check getSearchedAndUltimatelyBought service fetched valid response for given searchKey?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSearchedAndUltimatelyBought service fetched valid response for given searchKey?", "Fetched invalid response", vFail);
		}
		
	// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY))).sendKeys(
				propsAPITab.read(INPUT_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY_INVALID));
		mode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_MODE))));
		mode.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_MODE));
		limit = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_LIMIT))));
		limit.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_LIMIT));
		channel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_CHANNEL))));
		channel.selectByVisibleText(propsAPITab.read(COMMON_SERVICES_CHANNEL));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			SEARCH_GET_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_RESPONSE)));
		
		/*System.out.println("response:" + response);
		System.out.println("response:" + response.getText());*/
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_SEARCH_GETSEARCHEDANDULTIMATELYBOUGHT_SEARCHKEY_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getSearchedAndUltimatelyBought service fetched invalid response for non existing searchKey?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSearchedAndUltimatelyBought service fetched invalid response for non existing searchKey?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
/*******************************************************************************
 * 	Strategy Service API - Start
 ******************************************************************************/
	
	//insertAlgorithmParameters service
	@Test
	public void test_strategy_01() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_STRATEGY_INSERTALGORITHMPARAMETERS))) {
			generateXML.logVP(++cpCount+"", "Check insertAlgorithmParameters service inserts valid data with given inputs?", "Inserted data successfully", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check insertAlgorithmParameters service fetched valid response for given userId?", "Data insertion failed", vFail);
		}

		// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS))).clear();
			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS))).sendKeys(
					propsAPITab.read(INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_PARAMETERS_INVALID));
			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME))).clear();
			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME))).sendKeys(
					propsAPITab.read(INPUT_STRATEGY_INSERTALGORITHMPARAMETERS_ALGORITHMNAME_INVALID));

			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_TRYITOUT))).click();
			response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				STRATEGY_POST_STRATEGY_INSERTALGORITHMPARAMETERS_RESPONSE)));
		
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(RESPONSE_STRATEGY_INSERTALGORITHMPARAMETERS))) {
			generateXML.logVP(++cpCount+"", "Check insertAlgorithmParameters service should not insert invalid records?", "Invalid records not inserted", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check insertAlgorithmParameters service should not insert invalid records?", "Invalid records inserted", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
	//fetchAlgorithmParameters service
	@Test
	public void test_strategy_02() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_STRATEGY_FETCHALGORITHMPARAMETERS))) {
			generateXML.logVP(++cpCount+"", "Check fetchAlgorithmParameters service fetched valid response for given userId?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check fetchAlgorithmParameters service fetched valid response for given userId?", "Fetched invalid response", vFail);
		}

		// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME_INVALID));

		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_FETCHALGORITHMPARAMETERS_RESPONSE)));
		
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_STRATEGY_FETCHALGORITHMPARAMETERS_ALGORITHMNAME_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check fetchAlgorithmParameters service fetched invalid response for non existing userId?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check fetchAlgorithmParameters service fetched invalid response for non existing userId?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getTraceAnalytics service
	@Test
	public void test_strategy_03() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_PRODUCTID))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETTRACEANALYTICS_PRODUCT_ID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_ALGONAME))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_ALGONAME))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETTRACEANALYTICS_ALGONAME));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_MODE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_MODE))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETTRACEANALYTICS_MODE));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_STRATEGY_GETTRACEANALYTICS))) {
			generateXML.logVP(++cpCount+"", "Check getTraceAnalytics service fetched valid response with given parameters?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getTraceAnalytics service fetched valid response with given parameters?", "Fetched invalid response", vFail);
		}

		// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_PRODUCTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_PRODUCTID))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETTRACEANALYTICS_PRODUCT_ID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_ALGONAME))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_ALGONAME))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETTRACEANALYTICS_ALGONAME_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_MODE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_MODE))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETTRACEANALYTICS_MODE));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETTRACEANALYTICS_RESPONSE)));
		
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_STRATEGY_GETTRACEANALYTICS_PRODUCT_ID_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getTraceAnalytics service fetched invalid response with invalid parameters?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getTraceAnalytics service fetched invalid response with invalid parameters?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getStrategyAnalytics service
	@Test
	public void test_strategy_04() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_MODE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_MODE))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETSTRATEGYANALYTICS_MODE));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_STRATEGY_GETSTRATEGYANALYTICS))) {
			generateXML.logVP(++cpCount+"", "Check getStrategyAnalytics service fetched valid response with given parameters?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getStrategyAnalytics service fetched valid response with given parameters?", "Fetched invalid response", vFail);
		}

		// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_MODE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_MODE))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETSTRATEGYANALYTICS_MODE));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSTRATEGYANALYTICS_RESPONSE)));
		
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_STRATEGY_GETSTRATEGYANALYTICS_ALGONAME_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getStrategyAnalytics service fetched invalid response with invalid parameters?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getStrategyAnalytics service fetched invalid response with invalid parameters?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}

	//getSummary service
	@Test
	public void test_strategy_05() {
		/*WebElement iFrame = driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
		driver.switchTo().frame(iFrame);*/
		
		driver.findElement(By.xpath(
			ExcelUtil.readProps(AppConstants.API_TAB, LINK_USERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(
			AppConstants.API_TAB, STRATEGY_GET_STRATEGY_GETSUMMARY_ANCHOR))).click();
		
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSUMMARY_TYPE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSUMMARY_TYPE))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETSUMMARY_TYPE));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSUMMARY_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSUMMARY_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsAPITab.read(RESPONSE_STRATEGY_GETSUMMARY))) {
			generateXML.logVP(++cpCount+"", "Check getSummary service fetched valid response with given parameters?", "Fetched valid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSummary service fetched valid response with given parameters?", "Fetched invalid response", vFail);
		}

		// Invalid Input
		response = null;
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSUMMARY_TYPE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSUMMARY_TYPE))).sendKeys(
				propsAPITab.read(INPUT_STRATEGY_GETSUMMARY_TYPE_INVALID));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSUMMARY_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			STRATEGY_GET_STRATEGY_GETSUMMARY_RESPONSE)));
		
		if(response.getText() != null && !response.getText().contains(propsAPITab.read(INPUT_STRATEGY_GETSUMMARY_TYPE_INVALID))) {
			generateXML.logVP(++cpCount+"", "Check getSummary service fetched invalid response with invalid parameters?", "Fetched invalid response", vPass);
		}else {
			generateXML.logVP(++cpCount+"", "Check getSummary service fetched invalid response with invalid parameters?", "Fetched valid response", vFail);
		}
		
		/*driver.switchTo().defaultContent();*/
	}
	
/*******************************************************************************
 * 	Strategy Service API - End
 ******************************************************************************/
	
	@Test
	public void test_Clusters_01() throws InterruptedException{
		/*WebElement iFrame = driver.findElement(By.xpath(
		ExcelUtil.readProps(AppConstants.API_TAB, IFRAME_SERVICES_API)));
	driver.switchTo().frame(iFrame);*/
		
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_ANCHOR))).click();
	
// Valid Input	
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
		APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_BRANDID))).clear();
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
		APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_BRANDID))).sendKeys(propsRW.read(APITabConstants.BRAND_Id_VALID));
	
	/**selecting from drop down list**/
	Select select = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_MODE))));
	//select.deselectAll();
	select.selectByVisibleText("Light");
	
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
		APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_TRYITOUT))).click();
	
	WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
		APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_RESPONSE)));
	
	if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.BRAND_Id_RESULT_LIGHT))) {
	
		generateXML.logVP("101", "Check  brandTopSellers fetched valid response for existing brandId in light mode?", "Fetched valid response", vPass);
	}else {
		
		generateXML.logVP("101", "Check brandTopSellers service fetched valid response for existing brandId in light mode?", "Fetched invalid response", vFail);
	}
	
// valid input full mode
	

	select.selectByVisibleText("Full");
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_TRYITOUT))).click();
	response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_RESPONSE)));
	
	if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.BRAND_Id_RESULT_FULL))) {
		
		generateXML.logVP("102", "Check  brandTopSellers fetched valid response for existing brandId in full mode?", "Fetched valid response", vPass);
	}else {
		
		generateXML.logVP("102", "Check brandTopSellers service fetched valid response for existing brandId in full mode?", "Fetched invalid response", vFail);
	}
	
	
	
// Invalid Input
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_BRANDID))).clear();
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_BRANDID))).sendKeys(propsRW.read(APITabConstants.BRAND_Id_INVALID));
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_TRYITOUT))).click();
	response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_BRANDTOPSELLERS_RESPONSE)));
	
	if(response.getText() != null && response.getText().contains("[]")) {
		
		generateXML.logVP("103", "Check brandTopSellers service fetched invalid response for non existing brandId?", "Fetched invalid response", vPass);
	}else {
		generateXML.logVP("103", "Check brandTopSellers service fetched invalid response for non existing brandId?", "Fetched valid response", vFail);
	}

	}
	/* UI automation test case for Clusters getAllSegments
	 * 
	 */
	@Test
	public void test_Clusters_02() throws InterruptedException{
		
propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_GET_ALLSEGMENTS_ANCHOR))).click();
	
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_ALLSEGMENTS_CLUSTERTYPE))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_ALLSEGMENTS_CLUSTERTYPE))).sendKeys(propsRW.read(APITabConstants.CLUSTERTYPE_VALID));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_GET_ALLSEGMENTS_TRYITOUT))).click();
			
			WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_GET_ALLSEGMENTS_RESPONSE)));
		
			
			if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.CLUSTERTYPE_VALID_RESULT))) {
			
				generateXML.logVP("104", "Check  getAllSegments fetched valid response for existing clusterType?", "Fetched valid response", vPass);
			}else {
				
				generateXML.logVP("104", "Check getAllSegments service fetched valid response for existing clusterType?", "Fetched invalid response", vFail);
			}
			
//INVALID
			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_GET_ALLSEGMENTS_CLUSTERTYPE))).clear();
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_GET_ALLSEGMENTS_CLUSTERTYPE))).sendKeys(propsRW.read(APITabConstants.CLUSTERTYPE_INVALID));
				
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_ALLSEGMENTS_TRYITOUT))).click();
				response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_ALLSEGMENTS_RESPONSE)));
				
				if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.CLUSTERTYPE_INVALID_RESULT))) {
					
					generateXML.logVP("105", "Check getAllSegments service fetched invalid response for non existing clusterType?", "Fetched invalid response", vPass);
				}else {
					generateXML.logVP("105", "Check getAllSegments service fetched invalid response for non existing clusterType?", "Fetched valid response", vFail);
				}	
		
		
	}
	
	/* UI automation test case for Clusters getCombinedClusterRecommendations
	 * 
	 */
	@Test
	public void test_Clusters_03() throws InterruptedException{
    propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.GET_COMBINEDCLUSTERRECOMMENDATIONS_ANCHOR))).click();
	
	// Valid Input	
			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.GET_COMBINEDCLUSTERRECOMMENDATIONS_CLUSTERID))).clear();
			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.GET_COMBINEDCLUSTERRECOMMENDATIONS_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.CLUSTERID_VALID));
			
			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.GET_COMBINEDCLUSTERRECOMMENDATIONS_TRYITOUT))).click();
				
				WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.GET_COMBINEDCLUSTERRECOMMENDATIONS_RESPONSE)));
				
				if(response.getText() != null && response.getText().contains("[]")) {
				
					generateXML.logVP("106", "Check combinedClusterrecommendation service fetched invalid response for non existing clusterid?", "Fetched invalid response", vPass);
				}else {
					
					generateXML.logVP("106", "Check combinedClusterrecommendation service fetched invalid response for non existing clusterid?", "Fetched valid response", vFail);
				}
	
	
		
	}
	
	/* UI automation test case for Clusters search segment
	 * 
	 */
	@Test
	public void test_Clusters_04() throws InterruptedException{
	
	}
	
	/* UI automation test case for Clusters get Affinity details
	 * 
	 */
	@Test
	public void test_Clusters_05() throws InterruptedException{
propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_GET_AFFINITYDETAILS_ANCHOR))).click();
	
	// Valid Input
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_AFFINITYDETAILS_SEGMENTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_AFFINITYDETAILS_SEGMENTID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_VALID));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_GET_AFFINITYDETAILS_TRYITOUT))).click();
			
			WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_GET_AFFINITYDETAILS_RESPONSE)));
			if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.SEGMENTID_AFFINITY_RESULT))) {
				
				generateXML.logVP("107", "Check segmentAffinityResult service fetched valid response for existing segment id ?", "Fetched invalid response", vPass);
			}else {
				
				generateXML.logVP("107", "Check segmentAffinityResult service fetched valid response existing segment id?", "Fetched valid response", vFail);
			}
			
	//Invalid
			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_GET_AFFINITYDETAILS_SEGMENTID))).clear();
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_GET_AFFINITYDETAILS_SEGMENTID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_INVALID));
				
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_AFFINITYDETAILS_TRYITOUT))).click();
					
				 response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_AFFINITYDETAILS_RESPONSE)));
				 
				 if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.SEGMENT_AFFINITY_INVALID_RESULT))) {
						
						generateXML.logVP("108", "Check segmentAffinityResult service fetched invalid response for non existing segment id ?", "Fetched invalid response", vPass);
					}else {
						
						generateXML.logVP("108", "Check segmentAffinityResult service fetched invalid response for non existing segment id?", "Fetched valid response", vFail);
					} 
			
			
	
	}
	
	/* UI automation test case for Clusters get cluster analytics
	 * 
	 */
	@Test
	public void test_Clusters_06() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_GET_CLUSTERANALYTICS_ANCHOR))).click();
	
	//valid
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_CLUSTERANALYTICS_SEGMENTID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_CLUSTERANALYTICS_SEGMENTID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_VALID));
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_GET_CLUSTERANALYTICS_TRYITOUT))).click();
			
			WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_GET_CLUSTERANALYTICS_RESPONSE)));
			if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.SEGMENTID_ANALYTICS_RESULT))) {
				
				generateXML.logVP("109", "Check segmentAnalyticsResult service fetched valid response for existing segment id ?", "Fetched invalid response", vPass);
			}else {
				
				generateXML.logVP("109", "Check segmentAnalyticsResult service fetched valid response existing segment id?", "Fetched valid response", vFail);
			}
			//Invalid
			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_GET_CLUSTERANALYTICS_SEGMENTID))).clear();
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_GET_CLUSTERANALYTICS_SEGMENTID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_INVALID));
				
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_CLUSTERANALYTICS_TRYITOUT))).click();
					
				 response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_CLUSTERANALYTICS_RESPONSE)));
				 
				 if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.SEGMENT_ANALYTICS_INVALID_RESULT))) {
					
						generateXML.logVP("110", "Check segmentAnalyticsResult service fetched invalid response for non existing segment id ?", "Fetched invalid response", vPass);
					}else {
						
						generateXML.logVP("110", "Check segmentAnalyticsResult service fetched invalid response for non existing segment id?", "Fetched valid response", vFail);
					} 	
			
			
	}
	
	/* UI automation test case for Clusters top sellers
	 * 
	 */
	@Test
	public void test_Clusters_07() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_GET_TOPSELLERS_ANCHOR))).click();
	
// Valid Input	
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
		APITabConstants.CLUSTERS_GET_TOPSELLERS_CLUSTERID))).clear();
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
		APITabConstants.CLUSTERS_GET_TOPSELLERS_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_VALID));
	
	/**selecting from drop down list**/
	Select select = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_TOPSELLERS_MODE))));
	//select.deselectAll();
	select.selectByVisibleText("Light");
	
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
		APITabConstants.CLUSTERS_GET_TOPSELLERS_TRYITOUT))).click();
	
	WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
		APITabConstants.CLUSTERS_GET_TOPSELLERS_RESPONSE)));
	
	if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.SEGMENT_TOPSELLERS_RESULT_LIGHT))) {
		
		generateXML.logVP("111", "Check  TopSellers fetched valid response for existing segmentId in light mode?", "Fetched valid response", vPass);
	}else {
		
		generateXML.logVP("111", "Check TopSellers service fetched valid response for existing segmentId in light mode?", "Fetched invalid response", vFail);
	}

	
	
	
// Invalid Input
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_TOPSELLERS_CLUSTERID))).clear();
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_TOPSELLERS_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_INVALID));
	driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_TOPSELLERS_TRYITOUT))).click();
	response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_GET_TOPSELLERS_RESPONSE)));
	
	if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.SEGMENT_TOPSELLERS_INVALID_RESULT))) {
		
		generateXML.logVP("113", "Check TopSellers service fetched invalid response for non existing segmentId?", "Fetched invalid response", vPass);
	}else {
		generateXML.logVP("113", "Check TopSellers service fetched invalid response for non existing segmentId?", "Fetched valid response", vFail);
	}
	}
	
	/* UI automation test case for Clusters clusters
	 * 
	 */
	@Test
	public void test_Clusters_08() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_CLUSTERS_ANCHOR))).click();
	// Valid Input	
		
		/**selecting from drop down list**/
		Select selectType = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CLUSTERS_CLUSTERTYPE))));
		//select.deselectAll();
		selectType.selectByVisibleText("Price");
		
		Select selectMode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CLUSTERS_MODE))));
		//select.deselectAll();
		selectMode.selectByVisibleText("Light");
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
			APITabConstants.CLUSTERS_CLUSTERS_TRYITOUT))).click();
		
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CLUSTERS_RESPONSE)));
		
		if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.CLUSTERS_VALID_RESULT_LIGHT))) {
			
			generateXML.logVP("114", "Check  CLusters fetched valid response for existing clustertype in light mode?", "Fetched valid response", vPass);
		}else {
			
			generateXML.logVP("114", "Check TopSellers service fetched valid response for existing clustertype in light mode?", "Fetched invalid response", vFail);
		}
		
	//valid input full mode 
		
		selectMode.selectByVisibleText("Full");
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CLUSTERS_TRYITOUT))).click();
			
			 response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_CLUSTERS_RESPONSE)));
			 
			 if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.CLUSTERS_VALID_RESULT_FULL))) {
				 
					generateXML.logVP("115", "Check  CLusters fetched valid response for existing clustertype in full mode?", "Fetched valid response", vPass);
				}else {
					
					generateXML.logVP("115", "Check TopSellers service fetched valid response for existing clustertype in full mode?", "Fetched invalid response", vFail);
				}	 
			//invalid input
			 driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_CLUSTERS_ALGONAME))).sendKeys(propsRW.read(APITabConstants.CLUSTER_INVALID_ALGONAME));
			 driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_CLUSTERS_TRYITOUT))).click();
			 response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_CLUSTERS_RESPONSE)));
			 if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.CLUSTER_INVALID_RESULT))) {
				
					generateXML.logVP("116", "Check  CLusters fetched invalid response for non existing algoname in full mode?", "Fetched valid response", vPass);
				}else {
					
					generateXML.logVP("116", "Check CLusters service fetched invalid response for non existing algoname in full mode?", "Fetched invalid response", vFail);
				}	
	}
	
	/* UI automation test case for Clusters getclusterdetails
	 * 
	 */
	@Test
	public void test_Clusters_09() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_GET_CLUSTERDETAILS_ANCHOR))).click();
	// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_GET_CLUSTERDETAILS_CLUSTERID))).clear();
			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_GET_CLUSTERDETAILS_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_VALID));
			
			driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_GET_CLUSTERDETAILS_TRYITOUT))).click();
				
				WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_CLUSTERDETAILS_RESPONSE)));
			
				 if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.CLUSTERDETAILS_VALID_RESULT))) {
						
						generateXML.logVP("117", "Check  Clusters fetched valid response for  existing cluster id ?", "Fetched valid response", vPass);
					}else {
						
						generateXML.logVP("117", "Check  Clusters fetched valid response for  existing cluster id ?", "Fetched invalid response", vFail);
					}	
				 
	//INVALID Input
				 driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
							APITabConstants.CLUSTERS_GET_CLUSTERDETAILS_CLUSTERID))).clear();
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
							APITabConstants.CLUSTERS_GET_CLUSTERDETAILS_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_INVALID));
						
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
								APITabConstants.CLUSTERS_GET_CLUSTERDETAILS_TRYITOUT))).click();
				
				response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_CLUSTERDETAILS_RESPONSE))); 
				
				 if(response.getText() != null && 
						 response.getText().contains(propsRW.read(APITabConstants.CLUSTERDETAILS_INVALID_RESULT1)) &&
						 response.getText().contains(propsRW.read(APITabConstants.CLUSTERDETAILS_INVALID_RESULT2))) {
					 
						generateXML.logVP("118", "Check  Clusters getClusterDetails fetched invalid response for  non-existing cluster id ?", "Fetched valid response", vPass);
					}else {
						
						generateXML.logVP("118", "Check  Clusters getClusterDetails fetched invalid response for  non-existing cluster id ?", "Fetched invalid response", vFail);
					}	
			
		
	}
	/* UI automation test case for Clusters similarusers
	 * 
	 */
	@Test
	public void test_Clusters_10() throws InterruptedException{
propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_GET_SIMILARUSERS_ANCHOR))).click();
		// Valid Input	
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_SIMILARUSERS_USERID))).clear();
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_SIMILARUSERS_USERID))).sendKeys(propsRW.read(APITabConstants.USERID_VALID));
					
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
							APITabConstants.CLUSTERS_GET_SIMILARUSERS_TRYITOUT))).click();
						
				WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
								APITabConstants.CLUSTERS_GET_SIMILARUSERS_RESPONSE)));
					
				if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.SIMILARUSER_VALID_RESULT))) {
							
								generateXML.logVP("119", "Check  Clusters getSimilarUsers fetched valid response for  existing user id ?", "Fetched valid response", vPass);
					}else {
								
								generateXML.logVP("119", "Check  Clusters getSimilarUsers fetched valid response for  existing user id ?", "Fetched invalid response", vFail);
						}
				// InValid Input	
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_SIMILARUSERS_USERID))).clear();
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_GET_SIMILARUSERS_USERID))).sendKeys(propsRW.read(APITabConstants.USERID_INVALID));
					
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
							APITabConstants.CLUSTERS_GET_SIMILARUSERS_TRYITOUT))).click();
						
				 response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
								APITabConstants.CLUSTERS_GET_SIMILARUSERS_RESPONSE)));
					
				if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.SIMILARUSER_INVALID_RESULT))) {
							
								generateXML.logVP("120", "Check  Clusters getSimilarUsers fetched invalid response for  non-existing user id ?", "Fetched valid response", vPass);
					}else {
								
								generateXML.logVP("120", "Check  Clusters getSimilarUsers fetched invalid response for  non-existing user id ?", "Fetched invalid response", vFail);
						}
		
	}
	
	/* UI automation test case for Clusters frequentlyBoughtTogether
	 * 
	 */
	@Test
	public void test_Clusters_11() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_FREQBOUGHTTOGETHER_ANCHOR))).click();
		// Valid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_FREQBOUGHTTOGETHER_CLUSTERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_FREQBOUGHTTOGETHER_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_VALID));
			
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_FREQBOUGHTTOGETHER_TRYITOUT))).click();
				
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_FREQBOUGHTTOGETHER_RESPONSE)));
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.FREQBOUGHT_VALID_RESULT1)) &&
				response.getText().contains(propsRW.read(APITabConstants.FREQBOUGHT_VALID_RESULT2))) {
			
			generateXML.logVP("121", "Check  Clusters frequentlyBoughtTogether fetched valid response for  existing cluster id ?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("121", "Check  Clusters frequentlyBoughtTogether fetched valid response for  existing cluster id ?", "Fetched invalid response", vFail);
			}
		// InValid Input	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_FREQBOUGHTTOGETHER_CLUSTERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_FREQBOUGHTTOGETHER_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_INVALID));
			
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_FREQBOUGHTTOGETHER_TRYITOUT))).click();
				
		 response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_FREQBOUGHTTOGETHER_RESPONSE)));
			
		if(response.getText() != null && response.getText().contains(propsRW.read(APITabConstants.FREQBOUGHT_INVALID_RESULT1))) {
			
						generateXML.logVP("122", "Check  Clusters frequentlyBoughtTogether fetched invalid response for  non-existing cluster id ?", "Fetched valid response", vPass);
			}else {
						
						generateXML.logVP("122", "Check  Clusters frequentlyBoughtTogether fetched invalid response for  non-existing cluster id ?", "Fetched invalid response", vFail);
				}

		
		
	}
	/* UI automation test case for Clusters clusterRecommendations
	 * 
	 */
	@Test
	public void test_Clusters_12() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_RECOMMENDATIONS_ANCHOR))).click();
		
		//valid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONS_CLUSTERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONS_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_VALID));
		Select selectMode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONS_MODE))));
		//select.deselectAll();
		selectMode.selectByVisibleText("Full");
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONS_TRYITOUT))).click();
			
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_RECOMMENDATIONS_RESPONSE)));
		if(response.getText() != null && 
			response.getText().contains(propsRW.read(APITabConstants.RECOMMENDATIONS_VALID_RESULT1)) ) {
		
		generateXML.logVP("123", "Check  Clusters recommendations fetched valid response for  existing cluster id ?", "Fetched valid response", vPass);
		}else {
		
		generateXML.logVP("123", "Check  Clusters recommendations fetched valid response for  existing cluster id ?", "Fetched invalid response", vFail);
		}
		
		//valid
		Select selectChannel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONS_CHANNEL))));
		//select.deselectAll();
		selectChannel.selectByVisibleText("Store");
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONS_TRYITOUT))).click();
			
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_RECOMMENDATIONS_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.RECOMMENDATIONS_VALID_RESULT2)) ) {
			
			generateXML.logVP("124", "Check  Clusters recommendations fetched valid response for  existing cluster id ?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("124", "Check  Clusters recommendations fetched valid response for  existing cluster id ?", "Fetched invalid response", vFail);
			}
		
		//invalid
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONS_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONS_TRYITOUT))).click();
		
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONS_RESPONSE)));
	
		if(response.getText() != null && 
			response.getText().contains(propsRW.read(APITabConstants.RECOMMENDATIONS_INVALID_RESULT)) ) {
			
		generateXML.logVP("125", "Check  Clusters recommendations fetched invalid response for  non-existing cluster id ?", "Fetched valid response", vPass);
		}else {
		
		generateXML.logVP("125", "Check  Clusters recommendations fetched invalid response for  non-existing cluster id ?", "Fetched invalid response", vFail);
		}
	}
	
	/* UI automation test case for Clusters charts
	 * 
	 */
	@Test
	public void test_Clusters_13() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_CHARTS_ANCHOR))).click();
		
		//valid
		Select selectType = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CHARTS_CLUSTERTYPE))));
	
		selectType.selectByVisibleText("Price");
		Select selectMode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CHARTS_MODE))));
	
		selectMode.selectByVisibleText("Light");
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CHARTS_TRYITOUT))).click();
			
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_CHARTS_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.CHARTS_VALID_RESULT1)) ) {
				
			generateXML.logVP("126", "Check  Clusters charts fetched valid response for  existing cluster type ?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("126", "Check  Clusters charts fetched valid response for  existing cluster type ?", "Fetched invalid response", vFail);
			}
		
		//valid
		selectType.selectByVisibleText("Brand");
		selectMode.selectByVisibleText("Light");
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CHARTS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CHARTS_RESPONSE)));
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.CHARTS_VALID_RESULT2)) ) {
			
			generateXML.logVP("127", "Check  Clusters charts fetched valid response for  existing cluster type ?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("127", "Check  Clusters charts fetched valid response for  existing cluster type ?", "Fetched invalid response", vFail);
			}
		
		//invalid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CHARTS_ALGONAME))).sendKeys(propsRW.read(APITabConstants.CHARTS_INVALID_ALGONAME));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CHARTS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CHARTS_RESPONSE)));
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.CHARTS_INVALID_RESULT)) ) {
			
			generateXML.logVP("128", "Check  Clusters charts fetched invalid response for  non-existing cluster type ?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("128", "Check  Clusters charts fetched invalid response for  non-existing cluster type ?", "Fetched invalid response", vFail);
			}
		
	}
	
	/* UI automation test case for recommendation rule
	 * 
	 */
	@Test
	public void test_Clusters_14() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_RECOMMENDATIONRULE_ANCHOR))).click();
		//INvalid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONRULE_CLUSTERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONRULE_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RECOMMENDATIONRULE_TRYITOUT))).click();
			
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_RECOMMENDATIONRULE_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.RECOMMENDATIONRULE_INVALID_RESULT)) ) {
			
			generateXML.logVP("129", "Check  Clusters recommendation rule fetched invalid response for  non-existing cluster id ?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("129", "Check  Clusters recommendation rule fetched invalid response for  non-existing cluster id ?", "Fetched invalid response", vFail);
			}
		
		
		
	}
	/* UI automation test case for get all jobs
	 * 
	 */
	@Test
	public void test_Clusters_15() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_JOBDETAILS_ANCHOR))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILS_TRYITOUT))).click();
			
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_JOBDETAILS_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.JOBDETAILS_VALID_RESULT1)) &&
				response.getText().contains(propsRW.read(APITabConstants.JOBDETAILS_VALID_RESULT2))) {
			
			generateXML.logVP("130", "Check  Clusters jobdetails fetched valid response?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("130", "Check  Clusters jobdetails fetched valid response ?", "Fetched invalid response", vFail);
			}
	//INVALID
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILS_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.JOBDETAILS_INVALID_RESULT))) {
			
			generateXML.logVP("131", "Check  Clusters jobdetails fetched invalid response?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("131", "Check  Clusters jobdetails fetched invalid response ?", "Fetched invalid response", vFail);
			}
		
		
	}
	
	
	/* UI automation test case for get aspiring brands
	 * 
	 */
	@Test
	public void test_Clusters_16() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_ASPIRINGBRANDS_ANCHOR))).click();
		//valid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_ASPIRINGBRANDS_BRANDID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_ASPIRINGBRANDS_BRANDID))).sendKeys(propsRW.read(APITabConstants.BRANDID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_ASPIRINGBRANDS_LIMIT))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_ASPIRINGBRANDS_LIMIT))).sendKeys("2");
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_ASPIRINGBRANDS_TRYITOUT))).click();
		
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_ASPIRINGBRANDS_RESPONSE)));
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.ASPIRINGBRANDS_VALID_RESULT))) {
			
			generateXML.logVP("132", "Check  Clusters aspiringBrands fetched valid response for existing brand id?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("132", "Check  Clusters aspiringBrands fetched valid response for existing brand id?", "Fetched invalid response", vFail);
			}
		
		//Invalid
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_ASPIRINGBRANDS_BRANDID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_ASPIRINGBRANDS_BRANDID))).sendKeys(propsRW.read(APITabConstants.BRANDID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_ASPIRINGBRANDS_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_ASPIRINGBRANDS_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.ASPIRINGBRANDS_INVALID_RESULT))) {
			generateXML.logVP("133", "Check  Clusters aspiringBrands fetched invalid response for non-existing brand id?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("133", "Check  Clusters aspiringBrands fetched invalid response for non-existing brand id?", "Fetched invalid response", vFail);
			}
		
	}
	
	
	/* UI automation test case for get categoryMatrix
	 * 
	 */
	@Test
	public void test_Clusters_17() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_RELATEDCATEGORIESMATRIX_ANCHOR))).click();
		//valid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIESMATRIX_CATEGORYID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIESMATRIX_CATEGORYID))).sendKeys(propsRW.read(APITabConstants.CATEGORYID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIESMATRIX_TRYITOUT))).click();
		
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIESMATRIX_RESPONSE)));
		
		if(response.getText() != null && 
				!response.getText().contains(propsRW.read(APITabConstants.RELATEDCATEGORIESMATRIX_INVALID_RESULT)) ) {
			
			generateXML.logVP("134", "Check  Clusters relatedCategoryMatrix fetched valid response existing category id?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("134", "Check  Clusters relatedCategoryMatrix fetched valid response existing category id?", "Fetched invalid response", vFail);
			}
		
		//Invalid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIESMATRIX_CATEGORYID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIESMATRIX_CATEGORYID))).sendKeys(propsRW.read(APITabConstants.CATEGORYID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIESMATRIX_TRYITOUT))).click();
		 response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
					APITabConstants.CLUSTERS_RELATEDCATEGORIESMATRIX_RESPONSE)));
		 
		 if(response.getText() != null && 
					response.getText().contains(propsRW.read(APITabConstants.RELATEDCATEGORIESMATRIX_INVALID_RESULT)) ) {
				
				generateXML.logVP("135", "Check  Clusters relatedCategoryMatrix fetched invalid response non-existing category id?", "Fetched valid response", vPass);
				}else {
				
				generateXML.logVP("135", "Check  Clusters relatedCategoryMatrix fetched invalid response non-existing category id?", "Fetched invalid response", vFail);
				} 
		
	}
	
	/* UI automation test case for get jobdetails by id
	 * 
	 */
	@Test
	public void test_Clusters_18() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_JOBDETAILSBYID_ANCHOR))).click();
		
		//valid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_JOBID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_JOBID))).sendKeys(propsRW.read(APITabConstants.JOBID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_TRYITOUT))).click();
		
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.JOBDETAILSBYID_VALID_RESULT)) ) {
			
			generateXML.logVP("136", "Check  Clusters jobdetails fetched valid response existing jobid id?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("136", "Check  Clusters jobdetails fetched valid response existing jobid id?", "Fetched invalid response", vFail);
			}
		//valid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_JOBID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_JOBID))).sendKeys(propsRW.read(APITabConstants.JOBID_VALID1));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.JOBDETAILSBYID_VALID_RESULT1)) ) {
			
			generateXML.logVP("137", "Check  Clusters jobdetails fetched valid response existing jobid id?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("137", "Check  Clusters jobdetails fetched valid response existing jobid id?", "Fetched invalid response", vFail);
			}
		
		//INVALID
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_JOBID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_JOBID))).sendKeys(propsRW.read(APITabConstants.JOBID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_JOBDETAILSBYID_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.JOBDETAILSBYID_INVALID_RESULT)) ) {
			
			generateXML.logVP("138", "Check  Clusters jobdetails fetched invalid response non existing jobid id?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("138", "Check  Clusters jobdetails fetched invalid response non-existing jobid id?", "Fetched invalid response", vFail);
			}
		
		
	}
	/* UI automation test case for get customer RFM
	 * 
	 */
	@Test
	public void test_Clusters_19() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_CUSTOMERRFM_ANCHOR))).click();
		
		
		//valid
		
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CUSTOMERRFM_TRYITOUT))).click();
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CUSTOMERRFM_RESPONSE)));
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.CUSTOMERRFM_VALID_RESULT)) ) {
			
			generateXML.logVP("139", "Check  Clusters customerRFM fetched valid response ?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("139", "Check  Clusters customerRFM fetched invalid response?", "Fetched invalid response", vFail);
			}
		
		
		
		
	}
	/* UI automation test case for get cluster related categories
	 * 
	 */
	@Test
	public void test_Clusters_20() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_RELATEDCATEGORIES_ANCHOR))).click();
		
		
		//valid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIES_CATID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIES_CATID))).sendKeys(propsRW.read(APITabConstants.CATEGORYID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIES_TRYITOUT))).click();
		
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIES_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.RELATEDCATEGORIES_VALID_RESULT1)) ) {
			
			generateXML.logVP("140", "Check  Clusters relatedcategories fetched valid response existing categoryID id?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("140", "Check  Clusters relatedcategories fetched valid response existing categoryID id?", "Fetched invalid response", vFail);
			}
		//valid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIES_CATID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIES_CATID))).sendKeys(propsRW.read(APITabConstants.CATEGORYID_VALID1));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIES_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_RELATEDCATEGORIES_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.RELATEDCATEGORIES_VALID_RESULT2)) ) {
			
			generateXML.logVP("141", "Check  Clusters relatedcategories fetched valid response existing categoryID id?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("141","Check  Clusters relatedcategories fetched valid response existing categoryID id?", "Fetched invalid response", vFail);
			}
		//INVALID
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_RELATEDCATEGORIES_CATID))).clear();
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_RELATEDCATEGORIES_CATID))).sendKeys(propsRW.read(APITabConstants.CATEGORYID_INVALID));
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_RELATEDCATEGORIES_TRYITOUT))).click();
				response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_RELATEDCATEGORIES_RESPONSE)));
				
				if(response.getText() != null && 
						response.getText().contains(propsRW.read(APITabConstants.RELATEDCATEGORIES_INVALID_RESULT)) ) {
				
					generateXML.logVP("142", "Check   Clusters relatedcategories fetched invalid response non existing categoryID id?", "Fetched valid response", vPass);
					}else {
					
					generateXML.logVP("142", "Check   Clusters relatedcategories fetched invalid response non-existing categoryID id?", "Fetched invalid response", vFail);
					}
		
	}
	
	/* UI automation test case for get Clusters topviewed
	 * 
	 */
	@Test
	public void test_Clusters_21() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_TOPVIEWED_ANCHOR))).click();
		
		
		//valid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_CLUSTERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_VALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_TRYITOUT))).click();
		
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.TOPVIEWED_RESULT)) ) {
			
			generateXML.logVP("143", "Check  Clusters topviewed fetched valid response existing cluster id?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("143", "Check  Clusters topviewed fetched valid response existing cluster id?", "Fetched invalid response", vFail);
			}
		//valid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_CLUSTERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_VALID));
		
		Select selectMode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_MODE))));
	
		selectMode.selectByVisibleText("Full");
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.TOPVIEWED_RESULT)) ) {
			
			generateXML.logVP("144", "Check  Clusters topviewed fetched valid response existing cluster id?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("144", "Check  Clusters topviewed fetched valid response existing cluster id?", "Fetched invalid response", vFail);
			}
		//invalid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_CLUSTERID))).clear();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_INVALID));
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_TRYITOUT))).click();
		response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_TOPVIEWED_RESPONSE)));
		
		if(response.getText() != null && 
				response.getText().contains(propsRW.read(APITabConstants.TOPVIEWED_RESULT)) ) {
		
			generateXML.logVP("145", "Check   Clusters topviewed fetched invalid response non existing cluster id?", "Fetched valid response", vPass);
			}else {
			
			generateXML.logVP("145", "Check   Clusters topviewed fetched invalid response non-existing cluster id?", "Fetched invalid response", vFail);
			}
		
	}
	
	/* UI automation test case for get Clusters social recommendations
	 * 
	 */
	@Test
	public void test_Clusters_22() throws InterruptedException{
propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CLUSTERS))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_ANCHOR))).click();
		//valid
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_CLUSTERID))).clear();
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_VALID));
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_TRYITOUT))).click();
				
				WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_RESPONSE)));
				
				if(response.getText() != null && 
						response.getText().contains(propsRW.read(APITabConstants.SOCIALRECOMMENDATION_RESULT)) ) {
					
					generateXML.logVP("146", "Check  Clusters social-recommendations fetched valid response existing cluster id?", "Fetched valid response", vPass);
					}else {
					
					generateXML.logVP("146", "Check  Clusters social-recommendations fetched valid response existing cluster id?", "Fetched invalid response", vFail);
					}
				
		//valid
				Select selectMode = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_MODE))));
			
				selectMode.selectByVisibleText("Full");
				Select selectChannel = new Select(driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_CHANNEL))));
				
				selectChannel.selectByVisibleText("Store");
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_TRYITOUT))).click();
				response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_RESPONSE)));
				
				if(response.getText() != null && 
						response.getText().contains(propsRW.read(APITabConstants.SOCIALRECOMMENDATION_RESULT)) ) {
				
					generateXML.logVP("147", "Check  Clusters social-recommendations fetched valid response existing cluster id?", "Fetched valid response", vPass);
					}else {
					
					generateXML.logVP("147", "Check  Clusters social-recommendations fetched valid response existing cluster id?", "Fetched invalid response", vFail);
					}
		//invalid
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_CLUSTERID))).clear();
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_CLUSTERID))).sendKeys(propsRW.read(APITabConstants.SEGMENTID_INVALID));
				driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
						APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_TRYITOUT))).click();
				 response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
							APITabConstants.CLUSTERS_SOCIALRECOMMENDATIONS_RESPONSE)));
				 
				 
				 if(response.getText() != null && 
							response.getText().contains(propsRW.read(APITabConstants.SOCIALRECOMMENDATION_RESULT)) ) {
					
						generateXML.logVP("148", "Check   Clusters social-recommendations fetched invalid response non existing cluster id?", "Fetched valid response", vPass);
						}else {
						
						generateXML.logVP("148", "Check   Clusters social-recommendations fetched invalid response non-existing cluster id?", "Fetched invalid response", vFail);
						}
				
				
	}
	
	/* UI automation test case for get Clusters social recommendations
	 * 
	 */
	@Test
	public void test_Clusters_23() throws InterruptedException{
		propsRW = new PropertiesUtil(AppConstants.API_TAB_PROPERTIES);
		
		//Thread.sleep(4000);
	
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.LINK_CONFIGURATION))).click();
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB, APITabConstants.CLUSTERS_CONFIGURATIONREAD_ANCHOR))).click();
		//valid
		driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CONFIGURATIONREAD_TRYITOUT))).click();
		
		WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(AppConstants.API_TAB,
				APITabConstants.CLUSTERS_CONFIGURATIONREAD_RESPONSE)));
		
		 if(response.getText() != null && 
					response.getText().contains(propsRW.read(APITabConstants.CONFIGURATION_READ_RESULT)) ) {
			 	System.out.println("fgf");
				generateXML.logVP("149", "Check   Clusters configuration read fetched valid response ?", "Fetched valid response", vPass);
				}else {
				
				generateXML.logVP("149", "Check   Clusters configuration fetched valid response ?", "Fetched invalid response", vFail);
				}
		
		
		
		
	}
	
	
	
}