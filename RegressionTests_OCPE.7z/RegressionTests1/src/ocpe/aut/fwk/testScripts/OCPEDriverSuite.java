package ocpe.aut.fwk.testScripts;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.IOOperations;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;;
/**
 * Driver Suite in which required test scripts are called
 * @author Devalanka_Pavani
 *
 */
@RunWith(Suite.class)
@SuiteClasses({Admin.class}) 
public class OCPEDriverSuite {
	public static IOOperations  createDirectory;
	public static String detailReportPath,summaryReportPath;
	public static String xmlFolder;
	public static GenerateXml generateXML;

	/**
	 * All the one time initializations of Suite class are done in this method
	 * For ex: Report folder structure needs to be created before executing the suite
	 * 
	 */
	@BeforeClass
	public static void oneTimeSetUp() {
		System.out.println("Report folder structure creation in Suite, one time execution");
		
		//Reports time stamp folder format
		DateFormat df = new SimpleDateFormat(AppConstants.ddMMMYYYY_HHmm);   

		//Create report structure
		//<Report main folder>\ddMMMYYYY_HHmm\DetailedReports\xml
		createDirectory = new IOOperations();
		/*summaryReportPath=createDirectory.createTimeStampFolder(df.format(new Date()));	
		detailReportPath = createDirectory.createTimeStampFolder(df.format(new Date())+AppConstants.FORWARD_SLASH+AppConstants.DETAILED_REPORTS);		
		xmlFolder = createDirectory.createTimeStampFolder(df.format(new Date())+AppConstants.FORWARD_SLASH+AppConstants.DETAILED_REPORTS
				+AppConstants.FORWARD_SLASH+AppConstants.XML);*/
		
		AppConstants.SUMMARY_REPORT_FOLDER = createDirectory.createTimeStampFolder(df.format(new Date()));	
		AppConstants.DETAIL_REPORT_FOLDER = createDirectory.createTimeStampFolder(df.format(new Date())+AppConstants.FORWARD_SLASH+AppConstants.DETAILED_REPORTS);		
		AppConstants.XML_FOLDER = createDirectory.createTimeStampFolder(df.format(new Date())+AppConstants.FORWARD_SLASH+AppConstants.DETAILED_REPORTS
				+AppConstants.FORWARD_SLASH+AppConstants.XML);
		
		
		//Generate summary report.xml
		AppConstants.SUMMARY_REPORT_XML_FILE_PATH = AppConstants.XML_FOLDER + AppConstants.FORWARD_SLASH + AppConstants.ELE_SUMMARYREPORT+AppConstants.DOT_XML;
		generateXML = new GenerateXml();
		generateXML.createSummaryXML();
	}

	/**
	 * This is the test method in suite
	 * 
	 */
	@Test
	public void test() {
		System.out.println("Suite Executed Sucesfully");
	}
	
	/**
	 * This method is invoked after all the test scripts in the suite are executed.
	 * SummaryReport.html is created in this method
	 */
	@AfterClass
	public static void afterSuite() {
		//Log total tcs, vps, pass, fail counts for the entire suite
		generateXML.logSummaryReportHeaderSection();
		GenerateHTML generateReport = new GenerateHTML();
		try {
			generateReport.generateHTML(AppConstants.SUMMARY_REPORT_XML_FILE_PATH, AppConstants.SUMMARY_REPORT_XSL, AppConstants.SUMMARY_REPORT_FOLDER+AppConstants.FORWARD_SLASH+AppConstants.SUMMARY_REPORT+AppConstants.DOT_HTML);
		} catch (TransformerConfigurationException e) {			
			e.printStackTrace();
		} catch (TransformerException e) {		
			e.printStackTrace();
		}
		
		//Reset summary report xml path
		AppConstants.SUMMARY_REPORT_XML_FILE_PATH = AppConstants.BLANK_STRING;
	}

}
