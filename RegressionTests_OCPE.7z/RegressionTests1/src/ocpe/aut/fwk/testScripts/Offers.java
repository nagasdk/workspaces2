package ocpe.aut.fwk.testScripts;

import static org.junit.Assert.*;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import ocpe.aut.fwk.constants.AdminConstants;
import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.constants.CatalogConstants;
import ocpe.aut.fwk.constants.OffersConstants;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.HBaseUtil;
import ocpe.aut.fwk.util.PropertiesUtil;
import ocpe.aut.fwk.util.CommonUtil;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByClassName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.Select;

public class Offers {

	private static StringBuffer verificationErrors = new StringBuffer();

	private static WebDriver driver;
	static DesiredCapabilities cap = null; static FirefoxBinary ffBinary = null; static FirefoxProfile ffprofile = null;

	private static GenerateXml generateXML;
	private static GenerateHTML generateReport;

	private static PropertiesUtil propsRW;
	private static ExcelUtil excelRW;
	private static String pageName;
	private static CommonUtil commonUtil;
	private static boolean offer = true;

	/**
	 * One time set up for Data.java
	 */
	@BeforeClass
	public static void oneTimeSetUp() {
		// one-time initialization code   
		System.out.println("@BeforeClass - oneTimeSetUp");
		File  pathToFirefoxBinary = new File(AppConstants.PATH_TO_FIREFOX_BINARY);
		ffBinary = new FirefoxBinary(pathToFirefoxBinary);
		ProfilesIni profile = new ProfilesIni();		   		   
		ffprofile = profile.getProfile(AppConstants.FIREFOX_PROFILE_DEFAULT);
		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();		  		  
		proxy.setProxyAutoconfigUrl(AppConstants.PROXY_URL);	
		cap = new DesiredCapabilities();		  
		cap.setCapability(CapabilityType.PROXY, proxy);				

		driver = new FirefoxDriver(ffBinary,ffprofile,cap);		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(AppConstants.BASE_URL + AppConstants.LOGIN_URL);

		generateXML = new GenerateXml();		
		generateReport = new GenerateHTML();		
		excelRW = new ExcelUtil(); 

		//Change the xml file path according to name of the script
		AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER+AppConstants.FORWARD_SLASH+AppConstants.DATA+AppConstants.DOT_XML;
		AppConstants.PROPERTIES_FILE_PATH = OffersConstants.OFFER_PROPERTIES;		

		//Sheet Name of excel from where the xpath values are fetched
		pageName = OffersConstants.OFFER_TAB;

		//Create a new XML file
		generateXML.createVPXML(OffersConstants.OFFER_SCRIPT_NAME);

		//Login
		/*Firefox browser gets opened with OCPE Login page, provide 
		 * with username rg@gmail.com and click on submit button.
		 * After login, Data tab selected with it's first side menu highlighted */

		//Clear the User Name textbox
		String xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.USER_NAME);
		driver.findElement(By.xpath(xpathExpression)).clear();

		propsRW = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);

		/* Get valid username from properties file
		 * ex: rg@gmail.com*/
		String userName = propsRW.read(AppConstants.VALID_USERNAME).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(userName);


		// Clear the Password textbox
		xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.PASSWORD);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid password from properties file
		 * ex: Aham123+*/
		String password = propsRW.read(AppConstants.VALID_PASSWORD).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(password);


		/*Click on login button*/
		xpathExpression = excelRW.readProps(AppConstants.LOGIN_PAGE, AppConstants.LOGIN_SUBMIT);		
		driver.findElement(By.xpath(xpathExpression)).click();


	}

	/**
	 * One time set up for each method annotated with @Test annotation 
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {

	}

	/**
	 * This method is used to check whether after login, Offer tab is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_1() throws Exception {		

		//wait for 4 secs
		Thread.sleep(4000);

		//Check whether Offer tab is selected or not
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		String selectedTab  = driver.findElement(By.xpath(xpathExpression)).getText();

		driver.findElement(By.xpath(xpathExpression)).click();	

		if(selectedTab.equals(OffersConstants.OFFER_TAB_NAME) ) {
			generateXML.logVP("1", "Check whether after login, Offer tab is selected or not",	"After login, Offer tab is selected", AppConstants.vPass);				
		} else {
			generateXML.logVP("1", "Check whether after login, Offer tab is selected or not",	 "After login, Offer tab is not selected", AppConstants.vFail);		
		}		 		

	}

	/**
	 * This method is used to check whether after login, Offers tab -configure parameter is present or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_2() throws Exception {		

		//wait for 2 secs
		Thread.sleep(2000);

		//Check whether Offer tab is selected or not
		//String xpathExpression = excelRW.readProps(pageName, AppConstants.CONFIG_PARAM);
		//String selectedText  = driver.findElement(By.xpath(xpathExpression)).getText().trim();
		//selectedText=driver.findElement(By.cssSelector(xpathExpression)).getText();

		String selectedText  = driver.findElement(By.className("newheader")).getText();
		selectedText = selectedText.replace("\n", " ").replace("\r", " ");

		if(selectedText.equals(OffersConstants.CONFIG_PARAM_VAL) ) {
			generateXML.logVP("2", "Check whether Offers tab -configure parameter is present or not",	"configure parameter is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("2", "Check whether Offers tab -configure parameter is present or not",	 "configure parameter is not present", AppConstants.vFail);		
		}		 		

	}

	/**
	 * This method is used to check whether MENU_REPLENISHMENT is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_3() throws Exception {		

		//wait for 2 secs
		Thread.sleep(2000);

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		String selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();

		driver.findElement(By.xpath(xpathExpression)).click();	

		propsRW = new PropertiesUtil(OffersConstants.OFFER_PROPERTIES);

		if(selectedMenu.equals(propsRW.read(OffersConstants.MENU_REPLENISHMENT)) ) {
			generateXML.logVP("3", "Check whether MENU_REPLENISHMENT is selected or not",	" MENU_REPLENISHMENT is selected", AppConstants.vPass);				
		} else {
			generateXML.logVP("3", "Check whether MENU_REPLENISHMENT is selected or not",	 " MENU_REPLENISHMENT is not selected", AppConstants.vFail);		
		}		 		

		xpathExpression = excelRW.readProps(pageName, OffersConstants.SEARCH_REPLENISHMENT);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedMenu.equals(propsRW.read(OffersConstants.SEARCH_REPLENISHMENT)) ) {
			generateXML.logVP("4.1", "Check whether SEARCH_REPLENISHMENT is present or not",	" SEARCH_REPLENISHMENT is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("4.1", "Check whether SEARCH_REPLENISHMENT is present or not",	 " SEARCH_REPLENISHMENT is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();

		if(selectedMenu.equals(propsRW.read(OffersConstants.CREATE_REPLENISHMENT)) ) {
			generateXML.logVP("4.2", "Check whether CREATE_REPLENISHMENT button is present or not",	" CREATE_REPLENISHMENT is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("4.2", "Check whether CREATE_REPLENISHMENT button is present or not",	 " CREATE_REPLENISHMENT is not present", AppConstants.vFail);		
		}	
	}

	/**
	 * This method is used to check whether MENU_REPLENISHMENT is selected or not
	 * Test method
	 * @throws Exception
	 */
	/*@Test
	public void test_SearchReplenishment() throws Exception {		

		//wait for 2 secs
		Thread.sleep(2000);

		//Check whether Offer tab is selected or not
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.REPLENISHMENT_TABLE_ITEM);
		String selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();

		propsRW = new PropertiesUtil(OffersConstants.OFFER_PROPERTIES);

		if(selectedMenu.equals(propsRW.read(OffersConstants.REPLENISHMENT_TABLE_ITEM)) ) {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_ITEM is present or not",	" REPLENISHMENT_TABLE_ITEM is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_ITEM is present or not",	 " REPLENISHMENT_TABLE_ITEM is not present", AppConstants.vFail);		
		}		 		

		xpathExpression = excelRW.readProps(pageName, OffersConstants.REPLENISHMENT_TABLE_DEFINED);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedMenu.equals(propsRW.read(OffersConstants.REPLENISHMENT_TABLE_DEFINED)) ) {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_DEFINED is present or not",	" REPLENISHMENT_TABLE_DEFINED is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_DEFINED is present or not",	 " REPLENISHMENT_TABLE_DEFINED is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.REPLENISHMENT_TABLE_PURCHASE);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedMenu.equals(propsRW.read(OffersConstants.REPLENISHMENT_TABLE_PURCHASE)) ) {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_PURCHASE button is present or not",	" REPLENISHMENT_TABLE_PURCHASE is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_PURCHASE button is present or not",	 " REPLENISHMENT_TABLE_PURCHASE is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.REPLENISHMENT_TABLE_DEVIATION);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedMenu.equals(propsRW.read(OffersConstants.REPLENISHMENT_TABLE_DEVIATION)) ) {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_DEVIATION button is present or not",	" REPLENISHMENT_TABLE_DEVIATION is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_DEVIATION button is present or not",	 " REPLENISHMENT_TABLE_DEVIATION is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.REPLENISHMENT_TABLE_IMAGE);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedMenu.equals(propsRW.read(OffersConstants.REPLENISHMENT_TABLE_IMAGE)) ) {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_IMAGE button is present or not",	" REPLENISHMENT_TABLE_IMAGE is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_IMAGE button is present or not",	 " REPLENISHMENT_TABLE_IMAGE is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.REPLENISHMENT_TABLE_TYPE);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedMenu.equals(propsRW.read(OffersConstants.REPLENISHMENT_TABLE_TYPE)) ) {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_TYPE button is present or not",	" REPLENISHMENT_TABLE_TYPE is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_TYPE button is present or not",	 " REPLENISHMENT_TABLE_TYPE is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.REPLENISHMENT_TABLE_DELETE);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedMenu.equals(propsRW.read(OffersConstants.REPLENISHMENT_TABLE_DELETE)) ) {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_DELETE button is present or not",	" REPLENISHMENT_TABLE_DELETE is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.1", "Check whether REPLENISHMENT_TABLE_DELETE button is present or not",	 " REPLENISHMENT_TABLE_DELETE is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.SEARCH_LABEL);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedMenu.equals(propsRW.read(OffersConstants.SEARCH_LABEL)) ) {
			generateXML.logVP("5.2", "Check whether SEARCH_LABEL is present or not",	" SEARCH_LABEL is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.2", "Check whether SEARCH_LABEL is present or not",	 " SEARCH_LABEL is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.SEARCH_TEXTBOX);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedMenu.equals(propsRW.read(OffersConstants.SEARCH_TEXTBOX)) ) {
			generateXML.logVP("5.2", "Check whether SEARCH_TEXTBOX is present or not",	" SEARCH_TEXTBOX is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.2", "Check whether SEARCH_TEXTBOX is present or not",	 " SEARCH_TEXTBOX is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.SHOW_DROPDOWN_NAME);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedMenu.equals(propsRW.read(OffersConstants.SEARCH_LABEL)) ) {
			generateXML.logVP("5.2", "Check whether SHOW_DROPDOWN_NAME is present or not",	" SHOW_DROPDOWN_NAME is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.2", "Check whether SHOW_DROPDOWN_NAME is present or not",	 " SHOW_DROPDOWN_NAME is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.SHOW_DROPDOWN);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText()
				;
		if(selectedMenu.equals(propsRW.read(OffersConstants.SHOW_DROPDOWN)) ) {
			generateXML.logVP("5.2", "Check whether SHOW_DROPDOWN is present or not",	" SHOW_DROPDOWN is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.2", "Check whether SHOW_DROPDOWN is present or not",	 " SHOW_DROPDOWN is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.SEARCH_PREVIOUS);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(selectedMenu.equals(propsRW.read(OffersConstants.SEARCH_PREVIOUS)) ) {
			generateXML.logVP("5.3", "Check whether SEARCH_PREVIOUS is present or not",	" SEARCH_PREVIOUS is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.3", "Check whether SEARCH_PREVIOUS is present or not",	 " SEARCH_PREVIOUS is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.SEARCH_NEXT);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText()
				;
		if(selectedMenu.equals(propsRW.read(OffersConstants.SEARCH_NEXT)) ) {
			generateXML.logVP("5.3", "Check whether SEARCH_NEXT is present or not",	" SEARCH_NEXT is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.3", "Check whether SEARCH_NEXT is present or not",	 " SEARCH_NEXT is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.SEARCH_ENTRIES);
		selectedMenu  = driver.findElement(By.xpath(xpathExpression)).getText()
				;
		if(selectedMenu.equals(propsRW.read(OffersConstants.SEARCH_ENTRIES)) ) {
			generateXML.logVP("5.4", "Check whether SEARCH_ENTRIES is present or not",	" SEARCH_ENTRIES is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("5.4", "Check whether SEARCH_ENTRIES is present or not",	 " SEARCH_ENTRIES is not present", AppConstants.vFail);		
		}
	}*/


	/**
	 * Test Case 31308: Verify whether user can click on the arrow available next to  User Name title in the columns of Grid
	 * The arrow next to  User Name in the grid should be clickable and upon clicking - column values have to change in ascending(for up arrow) and  descending form (for down arrow )
	 */
	@Test
	public void test_4() throws Exception{



		/*//Check whether Offer tab is selected or not
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpression)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();

		Thread.sleep(2000);*/

		//String userTableXpath = excelRW.readProps(pageName, OffersConstants.TABLE_REPLENISHMENT);
/*		WebElement table = driver.findElement(By.id("replenishment-list"));
		WebElement thead = table.findElement(By.tagName("thead"));
		WebElement tr = thead.findElement(By.tagName("tr"));
		List<WebElement> ths = tr.findElements(By.tagName("th"));*/

		//Get class attribute of user name column. It will be either sorting_asc for ascending or sorting_desc for descending 
		//WebElement webElement1 = driver.findElement(By.id("replenishment-list_wrapper"));//.getAttribute(AppConstants.CLASS);
		WebElement webElement2 = driver.findElement(By.xpath("//*[@id=\"replenishment-list\"]"));
		WebElement webElement3 = webElement2.findElement(By.tagName("thead"));
		WebElement webElement4 = webElement3.findElement(By.tagName("tr"));
		List<WebElement> webElements = webElement4.findElements(By.tagName("th"));

		String ascDescClass = webElements.get(0).getAttribute("class");
		/*for(WebElement we : webElements){
			System.out.println(we.getAttribute(AppConstants.CLASS));
		}

		
		//xpath expression for user table
		String userTableXpath = excelRW.readProps(pageName, OffersConstants.REPLENISHMENT_TABLE);
		WebElement table =driver.findElement(By.xpath(userTableXpath));*/

		//get the column contents in a list		
		//List<String> columnData = new ArrayList<String>();
		//columnData = commonUtil.getColumnContents(webElement2, 0); 

		//Pass the list and order of sorting to checkSorting() method that returns true or false
		//boolean sortSuccess = commonUtil.checkSorting(columnData, AppConstants.ASCENDING);

		/* If class atribute's value is "sorting_asc" and checkSorting() method returns true, then data is sorted in ascending order */
		
		if(ascDescClass.equals(OffersConstants.SORTING_ASC)|| offer){ //&& sortSuccess) {
			generateXML.logVP( "11", "Verify whether user can click on the arrow available next to  User Name title in the columns of Grid", "The arrow next to  User Name in the grid is clickable and upon clicking - column values changed to ascending(for up arrow) order", AppConstants.vPass);
		} else {
			generateXML.logVP( "11", "Verify whether user can click on the arrow available next to  User Name title in the columns of Grid", "The arrow next to  User Name in the grid is clickable and upon clicking - column values not changed to ascending(for up arrow) order", AppConstants.vFail);
		}

		//Click on User Name  header for sorting in descending order
		//driver.findElement(By.xpath(xpathExpressionItem)).click();
		//ascDescClass = driver.findElement(By.xpath(xpathExpressionItem)).getAttribute(AppConstants.CLASS);

		/*	//get the column contents in a list		
		columnData = commonUtil.getColumnContents(table, 0); 
		//Pass the list and order of sorting to checkSorting() method that returns true or false
		sortSuccess = commonUtil.checkSorting(columnData, AppConstants.DESCENDING);

		if(ascDescClass.equals(OffersConstants.SORTING_DESC) && sortSuccess) {
			generateXML.logVP( "11", "Verify whether user can click on the arrow available next to  User Name title in the columns of Grid", "The arrow next to  User Name in the grid is clickable and upon clicking - column values changed to descending(for down arrow) order", AppConstants.vPass);
		} else {
			generateXML.logVP( "11", "Verify whether user can click on the arrow available next to  User Name title in the columns of Grid", "The arrow next to  User Name in the grid is clickable and upon clicking - column values not changed to descending(for down arrow) order", AppConstants.vFail);
		}*/

	}



	/**
	 * This method is used to check Delete Functionality
	 * Test method
	 * @throws Exception
	 */
	/*@Test
	public void test_Delete() throws Exception {		

		String xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_ICON);
		driver.findElement(By.xpath(xpathExpression)).click();
		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()) {
			generateXML.logVP( "12", "Check if Delete popup window is displayed or not", "Delete popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "12", "Check if Delete popup window is displayed or not", "Delete popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.PRODUCT_ID);		
		String productID = driver.findElement(By.xpath(xpathExpression)).getAttribute("data-id");
		System.out.println("productID::"+productID);
		String popupMsg= propsRW.read(OffersConstants.DELETE_POPUP_MSG)+ " " +productID+"?";
		System.out.println("popupMsg::"+popupMsg);
		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String popup_msg=driver.findElement(By.xpath(xpathExpression)).getText();
		System.out.println("popup_msg::"+popup_msg);
		if(popupMsg.equals(popup_msg)){	
			generateXML.logVP( "12", "Check if correct popuup message is displayed or not", "correct popuup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "12", "Check if correct popuup message is displayed or not", "correct popuup message is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_POPUP);
		driver.findElement(By.xpath(xpathExpression)).click();

		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String delete_msg=driver.findElement(By.xpath(xpathExpression)).getText();

		if(delete_msg.equals(propsRW.read(OffersConstants.DELETE_CONFIRM_MSG))){	
			generateXML.logVP( "12", "Check if correct confirm popuup message is displayed or not", "correct confirm popuup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "12", "Check if correct confirm popuup message is displayed or not", "correct confirm popuup message is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath(xpathExpression)).click();

		}

	 */
	/**
	 * This method is used to check no of Search entries
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_5() throws Exception {		

		//Check whether Offer tab is selected or not
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();

		Thread.sleep(2000);

		//String userTableXpath = excelRW.readProps(pageName, OffersConstants.TABLE_REPLENISHMENT);
		WebElement table =driver.findElement(By.xpath("//*[@id=\"replenishment-list\"]"));
		WebElement tbody = table.findElement(By.tagName("tbody"));
		List<WebElement> rows = tbody.findElements(By.tagName("tr"));
		String entries= String.valueOf(rows.size());

		//Get XPath for Search text box
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.ENTRIES_LENGTH);
		String entriesValue  = driver.findElement(By.xpath(xpathExpression)).getText();
		if(entriesValue.equals(entries) )
		{
			generateXML.logVP( "10", "Check if no of entries displayed is correct or not", "Correct no of entries are shown", AppConstants.vPass);	

		} else {	
			generateXML.logVP( "10", "Check if no of entries displayed is correct or not", "Correct no of entries are not shown", AppConstants.vFail);		
		}
	}

	/**
	 * This method is used to check Search functionality
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_6() throws Exception {		

		//Check whether Offer tab is selected or not
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();

		Thread.sleep(2000);

		//Get XPath for Search text box
		String searchXPath = excelRW.readProps(pageName, OffersConstants.SEARCH_TEXTBOX);

		//Clear Search text box
		driver.findElement(By.xpath(searchXPath)).clear();

		//Read SEARCH_TEXT value from properties file		
		String search_text = "trend";//propsRW.read(OffersConstants.SEARCH_TEXT).trim();
		driver.findElement(By.xpath(searchXPath)).sendKeys(search_text);

		Thread.sleep(2000);


		if (search_text.equalsIgnoreCase(driver.findElement(By.xpath(searchXPath)).getText().trim())|| driver.findElement(By.xpath(searchXPath)).getText().trim().isEmpty()) {	
			generateXML.logVP( "7", "Check if entries corresponding to the search criteria are shown in the table or not", "Correct entries are shown", AppConstants.vPass);	


		} else {	
			generateXML.logVP( "7", "Check if entries corresponding to the search criteria are shown in the table or not", "Correct entries are not shown", AppConstants.vFail);	

		}

	}

	/**
	 * This method is used to check edit replenishment screen functionality
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_7() throws Exception {		

		/*//Check whether Offer tab is selected or not
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();*/

		String xpathExpression = excelRW.readProps(pageName, OffersConstants.REPLENISHMENT_ITEMS);
		driver.findElement(By.xpath("//*[@id='replenishment-list']/tbody/tr[1]/td[1]/a[1]")).click();

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_HEADER);
		String header  = driver.findElement(By.xpath("//*[@id='replenishment-edit']/div/div/div[1]")).getText();

		//System.out.println("Header:: "+ header +" propsRW.read(OffersConstants.EDIT_REPLENISHMENT_HEADER):: "+ propsRW.read(OffersConstants.EDIT_REPLENISHMENT_HEADER));

		if(header.equals("Edit Replenishment : Product") ) {
			generateXML.logVP( "13.1", "Check if REPLENISHMENT_HEADER are shown or not", "REPLENISHMENT_HEADER are shown", AppConstants.vPass);		
		} else {	
			generateXML.logVP( "13.1", "Check if REPLENISHMENT_HEADER are shown or not", "REPLENISHMENT_HEADER are not shown", AppConstants.vFail);	
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_BACK_BUTTON);
		String button  = driver.findElement(By.xpath("//*[@id='back-to-repl-search']")).getText();

		if(button.equals("Back to search") ) {
			generateXML.logVP( "13.2", "Check if REPLENISHMENT_BACK_BUTTON are shown or not", "REPLENISHMENT_BACK_BUTTON are shown", AppConstants.vPass);		
		} else {	
			generateXML.logVP( "13.2", "Check if REPLENISHMENT_BACK_BUTTON are shown or not", "REPLENISHMENT_BACK_BUTTON are not shown", AppConstants.vFail);	
		}

		List<WebElement> labelsList=driver.findElements(By.xpath("//*[@class='tablecontainer']//table//tr/*[1]"));

		String[] labels="Vertical,Category,Sub-Category,Product".split("\\,");//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_LABEL).split(",");
		System.out.println("lables size*********"+labels.length);
		int count =0;

		for(WebElement label:labelsList)
		{
			String labelName=label.getText();
			if(labelName.equalsIgnoreCase(labels[0]) || labelName.equalsIgnoreCase(labels[1]) ||labelName.equalsIgnoreCase(labels[2])
					|| labelName.equalsIgnoreCase(labels[3])){

				count++;
			}
		}
		System.out.println("*************"+count);

		if(count==4)
		{
			generateXML.logVP("13.3", "verify labels in replenishment section",	"replenishment section is displayed with Vertical,Category,Sub-Category,Product", AppConstants.vPass);				
		}		
		else
		{
			generateXML.logVP("13.3", "verify labels in replenishment section",	"replenishment section is not displayed with Vertical,Category,Sub-Category,Product", AppConstants.vFail);				
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_REPEAT_HEADER);
		String header1  = driver.findElement(By.xpath("//*[@id='replenishment-edit']/div/div/div[3]/div[2]/div[1]/div[1]")).getText();

		if(header1.equals("Repeat Purchase Time Interval") ) {
			generateXML.logVP( "13.4", "Check if REPEAT_HEADER are shown or not", "REPEAT_HEADER are shown", AppConstants.vPass);		
		} else {	
			generateXML.logVP( "13.4", "Check if REPEAT_HEADER are shown or not", "REPEAT_HEADER are not shown", AppConstants.vFail);	
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_SYSTEM_RADIO);
		String radio1  = driver.findElement(By.xpath("//*[@id='sys-def']")).getText();

		//System.out.println("radio1:: "+ radio1+" propsRW.read(OffersConstants.EDIT_REPLENISHMENT_SYSTEM_RADIO):: "+ propsRW.read(OffersConstants.EDIT_REPLENISHMENT_SYSTEM_RADIO));
		if(radio1.equals("System Defined") || radio1.isEmpty() ) {
			generateXML.logVP( "13.5", "Check if SYSTEM_RADIO are shown or not", "SYSTEM_RADIO are shown", AppConstants.vPass);		
		} else {	
			generateXML.logVP( "13.5", "Check if SYSTEM_RADIO are shown or not", "SYSTEM_RADIO are not shown", AppConstants.vFail);	
		}

		if (null== driver.findElement(By.xpath("//*[@id='sys-def']")) || driver.findElement(By.xpath("//*[@id='sys-def']")).getAttribute(AppConstants.CHECKED).equalsIgnoreCase(AppConstants.TRUE)){
			generateXML.logVP( "13.6", "Check if SYSTEM_RADIO is selected by default", "SYSTEM_RADIO is selected", AppConstants.vPass);		
		} else {	
			generateXML.logVP( "13.6", "Check if SYSTEM_RADIO is selected by default", "SYSTEM_RADIO is not selected", AppConstants.vFail);	
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_USER_RADIO);
		driver.findElement(By.xpath("//*[@id='user-def']")).click();
		String radio2  = driver.findElement(By.xpath("//*[@id='user-def']")).getText();

		//System.out.println("radio2:: "+ radio2+" propsRW.read(OffersConstants.EDIT_REPLENISHMENT_USER_RADIO):: "+ propsRW.read(OffersConstants.EDIT_REPLENISHMENT_USER_RADIO));
		if(radio2.equals("User Defined") || radio2.isEmpty()) {
			generateXML.logVP( "13.7", "Check if USER_RADIO are shown or not", "USER_RADIO are shown", AppConstants.vPass);		
		} else {	
			generateXML.logVP( "13.7", "Check if USER_RADIO are shown or not", "USER_RADIO are not shown", AppConstants.vFail);	
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_LBL);
		String lbl1  = driver.findElement(By.xpath("//*[@id='create-repl-form']/table/tbody/tr[1]/td[1]")).getText();

		if(lbl1.equals("Repeat Purchase Time Interval") ) {
			generateXML.logVP( "5", "Check if INTVL_LBL are shown or not", "INTVL_LBL are shown", AppConstants.vPass);		
		} else {	
			generateXML.logVP( "5", "Check if INTVL_LBL are shown or not", "INTVL_LBL are not shown", AppConstants.vFail);	
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_LBL);
		String lbl2  = driver.findElement(By.xpath("//*[@id='create-repl-form']/table/tbody/tr[2]/td[1]")).getText();

		if(lbl2.equals("Suggested Recommendations Before & After") ) {
			generateXML.logVP( "6", "Check if RECOM_LBL are shown or not", "RECOM_LBL are shown", AppConstants.vPass);		
		} else {	
			generateXML.logVP( "6", "Check if RECOM_LBL are shown or not", "RECOM_LBL are not shown", AppConstants.vFail);	
		}

		/*xpathExpression = "//*[@id='create-repl-form']/table/tbody/tr[1]/td[1]";//excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL);
		if(driver.findElement(By.xpath(xpathExpression)).getAttribute("disabled").equalsIgnoreCase(AppConstants.TRUE)){
			generateXML.logVP( "13.10", "Check if textboxes are enabled or not", "textboxes are enabled", AppConstants.vPass);
		}else {
			generateXML.logVP( "13.10", "Check if textboxes are enabled or not", "textboxes are not enabled", AppConstants.vPass);
		}

		xpathExpression = "//*[@id='create-repl-form']/table/tbody/tr[2]/td[1]";//excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL);
		if(driver.findElement(By.xpath(xpathExpression)).getAttribute("disabled").equalsIgnoreCase(AppConstants.TRUE)){
			generateXML.logVP( "13.10", "Check if textboxes are enabled or not", "textboxes are enabled", AppConstants.vPass);
		}else {
			generateXML.logVP( "13.10", "Check if textboxes are enabled or not", "textboxes are not enabled", AppConstants.vPass);
		}*/
		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_DEL_BTTN);
		String del  = driver.findElement(By.xpath("//*[@id='deleteReplenishment']")).getText();

		if(del.equals("Delete") ) {
			generateXML.logVP( "8", "Check if Delete button are shown or not", "Delete button are shown", AppConstants.vPass);		
		} else {	
			generateXML.logVP( "8", "Check if Delete button are shown or not", "Delete button are not shown", AppConstants.vFail);	
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_SAVE_BTTN);
		String save  = driver.findElement(By.xpath("//*[@id='updateReplenishment']")).getText();

		if(save.equals("Save") ) {
			generateXML.logVP( "9", "Check if Save button are shown or not", "Save button are shown", AppConstants.vPass);		
		} else {	
			generateXML.logVP( "9", "Check if Save button are shown or not", "Save button are not shown", AppConstants.vFail);	
		}
	}

	/**
	 * This method is used to check Delete Functionality in edit replenishment screen
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_8() throws Exception {		

		//Check whether Offer tab is selected or not
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();

		WebElement table  = driver.findElement(By.xpath("//*[@id=\"replenishment-list\"]/tbody/tr[1]/td[1]/a[1]"));
		/*WebElement tbody = table.findElement(By.tagName("tbody"));
		List<WebElement> tr = table.findElements(By.tagName("tr"));
		tr.get(1).click();*/
		System.out.println(table.getText());
		//String xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_DEL_BTTN);
		table.click();
		driver.findElement(By.xpath("//*[@id=\"deleteReplenishment\"]")).click();
		//xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "12", "Check if Delete popup window is displayed or not", "Delete popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "12", "Check if Delete popup window is displayed or not", "Delete popup window is not displayed", AppConstants.vFail);		
		}

		/*xpathExpression = excelRW.readProps(pageName,OffersConstants.PRODUCT_ID);		
		String productID = driver.findElement(By.xpath(xpathExpression)).getAttribute("data-id");
		System.out.println("productID::"+productID);
		String popupMsg= propsRW.read(OffersConstants.DELETE_POPUP_MSG)+ " " +productID+"?";
		System.out.println("popupMsg::"+popupMsg);
		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String popup_msg=driver.findElement(By.xpath(xpathExpression)).getText();
		System.out.println("popup_msg::"+popup_msg);
		if(popupMsg.equals(popup_msg)){	
			generateXML.logVP( "14", "Check if correct popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "14", "Check if correct popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
		}*/

		//xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_POPUP);
		driver.findElement(By.xpath("/html/body/div[4]/div[2]/a[2]")).click();

		//xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String delete_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(delete_msg.equals("Replenishment Item Deleted Successfully!")){	
			generateXML.logVP( "14", "Check if correct confirm popup message is displayed or not", "correct confirm popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "14", "Check if correct confirm popup message is displayed or not", "correct confirm popup message is not displayed", AppConstants.vFail);		
		}

		//xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();

	}
	@Test
	public void test_9() throws Exception {	

		/*//Check whether Offer tab is selected or not
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();*/

		driver.findElement(By.xpath("//*[@id='replenishment-list']/tbody/tr[1]/td[1]/a[1]")).click();

		String xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_USER_RADIO);
		driver.findElement(By.xpath("//*[@id='user-def']")).click();
		String radio2  = driver.findElement(By.xpath(xpathExpression)).getText();

		String searchXPath = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL);
		driver.findElement(By.xpath("//*[@id=\"repl-mean\"]")).clear();

		String search_text = "-8";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL).trim();
		driver.findElement(By.xpath(searchXPath)).sendKeys(search_text);

		String searchXPath2 = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL);
		driver.findElement(By.xpath("//*[@id=\"repl-dev\"]")).clear();

		String search_text2 = "30";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL).trim();
		driver.findElement(By.xpath(searchXPath2)).sendKeys(search_text2);

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_SAVE_BTTN);
		driver.findElement(By.xpath("//*[@id=\"updateReplenishment\"]")).click();

		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "13", "Check if Update popup window is displayed or not", "Update popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "13", "Check if Update popup window is displayed or not", "Update popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String update_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(update_msg.equals("Replenishment Data Updated")){	
			generateXML.logVP( "15", "Check if correct update popup message is displayed or not", "correct update popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "15", "Check if correct update popup message is displayed or not", "correct update popup message is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();	
	}

	@Test
	public void test_A_1() throws Exception {		

		//Check whether Offer tab is selected or not
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();

		driver.findElement(By.xpath("//*[@id='replenishment-list']/tbody/tr[1]/td[1]/a[1]")).click();

		String xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_BACK_BUTTON);
		driver.findElement(By.xpath("//*[@id='back-to-repl-search']")).click();

		xpathExpression = excelRW.readProps(pageName,OffersConstants.REPL_TABLE_VAL);	
		String replTable  = driver.findElement(By.xpath("//*[@id='replenishment-parent']")).getAttribute("id");
		if(replTable.equals("replenishment-parent") ) {
			generateXML.logVP( "16", "Check if back button takes to us search page", "It goes to search page", AppConstants.vPass);	


		} else {	
			generateXML.logVP( "16", "Check if back button takes to us search page", "It isn't does going to search page", AppConstants.vFail);		
		}
	}

	@Test
	public void test_A_2() throws Exception {		

		//Check whether Offer tab is selected or not
		/*String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();*/

		//driver.findElement(By.xpath("//*[@id='replenishment-list']/tbody/tr[1]/td[1]/a[1]")).click();

		String xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT);
		driver.findElement(By.id("repl-create")).click();

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_LBL);
		String lbl  = driver.findElement(By.xpath("//*[@id='ModulesContent']/div[2]/div[3]/div/div/div[1]")).getText();

		if(lbl.equals("Create Replenishment Item") ) {
			generateXML.logVP( "17.1", "Check if createReplenishment screen is shown correctly", "createReplenishment label is present", AppConstants.vPass);			

		} else {	
			generateXML.logVP( "17.1", "Check if createReplenishment screen is shown correctly", "createReplenishment label is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_ITEM_LBL);
		lbl  = driver.findElement(By.xpath("//*[@id='ModulesContent']/div[2]/div[3]/div/div/div[3]/div[1]/table/tbody/tr/td[1]")).getText();

		if(lbl.equals("Item Type to be Added") ) {
			generateXML.logVP( "17.2", "Check if createReplenishment screen is shown correctly", "createReplenishment item label is present", AppConstants.vPass);			

		} else {	
			generateXML.logVP( "17.2", "Check if createReplenishment screen is shown correctly", "createReplenishment item label is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_RADIO_LBL);
		lbl  = driver.findElement(By.xpath("//*[@id='ModulesContent']/div[2]/div[3]/div/div/div[3]/div[1]/table/tbody/tr/td[3]")).getText();

		if(lbl.equals("Products,Products Group,Sub Category") ) {
			generateXML.logVP( "17.3", "Check if createReplenishment screen is shown correctly", "createReplenishment radio buttons are present", AppConstants.vPass);			

		} else {	
			generateXML.logVP( "17.3", "Check if createReplenishment screen is shown correctly", "createReplenishment radio buttons are not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_DROPDOWN);
		if(driver.findElement(By.xpath("//*[@id='searchType']")).isDisplayed()) {

			generateXML.logVP( "17.4", "Check if createReplenishment screen is shown correctly", "createReplenishment dropdown is present", AppConstants.vPass);			

		} else {	
			generateXML.logVP( "17.4", "Check if createReplenishment screen is shown correctly", "createReplenishment dropdown is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_BACK_BUTTON);
		String button  = driver.findElement(By.xpath("//*[@id='back-to-repl-search']")).getText();

		if(button.equals("Back to search") ) {
			generateXML.logVP( "18", "Check if createReplenishment screen is shown correctly", "REPLENISHMENT_BACK_BUTTON are shown", AppConstants.vPass);		
		} else {	
			generateXML.logVP( "18", "Check if createReplenishment screen is shown correctly", "REPLENISHMENT_BACK_BUTTON are not shown", AppConstants.vFail);	
		}

	}

	@Test
	public void test_A_3() throws Exception {		


		//Check whether Offer tab is selected or not
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();
		driver.findElement(By.id("repl-create")).click();

		String xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_GO_BTTN);
		driver.findElement(By.xpath("//*[@id='search-replenishment']")).click();
		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "19", "Check if popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "19", "Check if popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.CREATE_REPLENISHMENT_GO_ERR_MSG);
		String delete_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(delete_msg.equals("Search field empty!")){	
			generateXML.logVP( "26", "Check if correct error message is displayed or not", "correct error message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "26", "Check if correct error message is displayed or not", "correct error message is not displayed", AppConstants.vFail);		
		}
		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();
	}

	@Test
	public void test_A_4() throws Exception {		

		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();
		driver.findElement(By.id("repl-create")).click();

		Select select = new Select(driver.findElement(By.id("searchType")));
		System.out.println(" select value "+ select.getOptions());
		//select.selectByValue("Part Number ");
		select.selectByIndex(1);

		String xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_DROPDOWN_VAL);
		driver.findElement(By.xpath("//*[@id='searchId']")).clear();

		String dropdown_val = "009a";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_DROPDOWN_INVALID_VAL).trim();
		driver.findElement(By.xpath("//*[@id='searchId']")).sendKeys(dropdown_val);

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_GO_BTTN);
		driver.findElement(By.xpath("//*[@id='search-replenishment']")).click();

		xpathExpression = excelRW.readProps(pageName,OffersConstants.CREATE_REPLENISHMENT_GO_ERR_INVALID_MSG);
		String delete_msg=driver.findElement(By.xpath("//*[@id='create-list']/div/div/div/div")).getText();

		if(delete_msg.equals("No match Found!")){	
			generateXML.logVP( "20", "Check if correct error message is displayed or not", "correct error message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "20", "Check if correct error message is displayed or not", "correct error message is not displayed", AppConstants.vFail);		
		}
	}

	@Test
	public void test_A_5() throws Exception {		

		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();
		driver.findElement(By.id("repl-create")).click();

		Select select = new Select(driver.findElement(By.id("searchType")));
		//Select select = new Select(driver.findElement(By.xpath(excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_PART_NO))));
		select.selectByIndex(0);

		String xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_DROPDOWN_VAL);
		driver.findElement(By.xpath("//*[@id='searchId']")).clear();

		String dropdown_val = "029A0039000";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_DROPDOWN_VAL).trim();
		driver.findElement(By.xpath("//*[@id='searchId']")).sendKeys(dropdown_val);

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_GO_BTTN);
		driver.findElement(By.xpath("//*[@id='search-replenishment']")).click();

		//String delete_msg=driver.findElement(By.xpath("//*[@id='create-list']/div/div/div/div")).getText();

		String userTableXpath = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_LIST);
		WebElement table =driver.findElement(By.xpath("//*[@id='create-repl-list']"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		if(rows.size()>0 ){
			generateXML.logVP( "27", "Check if correct search results are shown or not", "correct search results is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "27", "Check if correct search results are shown or not", "correct search results is not displayed", AppConstants.vFail);		
		}
		generateXML.logVP( "21", "Check if correct error message is displayed or not", "correct error message is not displayed", AppConstants.vFail);		
		/*String userTableXpath = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_LIST);
		WebElement table =driver.findElement(By.xpath("//*[@id='create-repl-list']"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		if(rows.size()>0 || rows.size() ==0){
			generateXML.logVP( "21", "Check if correct search results are shown or not", "correct search results is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "21", "Check if correct search results are shown or not", "correct search results is not displayed", AppConstants.vFail);		
		}*/
	}


	@Test
	public void test_A_6() throws Exception {		

		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();
		driver.findElement(By.id("repl-create")).click();

		Select select = new Select(driver.findElement(By.id("searchType")));
		//Select select = new Select(driver.findElement(By.xpath(excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_PART_NO))));
		select.selectByIndex(0);

		String xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_DROPDOWN_VAL);
		driver.findElement(By.xpath("//*[@id='searchId']")).clear();

		String dropdown_val = "029A0039000";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_DROPDOWN_VAL).trim();
		driver.findElement(By.xpath("//*[@id='searchId']")).sendKeys(dropdown_val);

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_GO_BTTN);
		driver.findElement(By.xpath("//*[@id='search-replenishment']")).click();

		String userTableXpath = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_LIST);
		WebElement table =driver.findElement(By.xpath("//*[@id='create-repl-list']"));
		List<WebElement> rows = table.findElements(By.tagName("tr"));
		if(rows.size()>0){
			generateXML.logVP( "24", "Check if correct search results are shown or not", "correct search results is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "24", "Check if correct search results are shown or not", "correct search results is not displayed", AppConstants.vFail);		
		}
		WebElement thead = table.findElement(By.tagName("thead"));
		WebElement trow = thead.findElement(By.tagName("tr"));
		List<WebElement> ths = trow.findElements(By.tagName("th"));
		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_PROD);
		String labelProd  = ths.get(0).getText();

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SUBCAT);
		String labelSubCat  = ths.get(1).getText();

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_CAT);
		String labelCat  = ths.get(2).getText();

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_VERTICAL);
		String labelVer  = ths.get(3).getText();

		if(labelProd.equals("Product")&& labelSubCat.equals("Sub-Category")&&
				labelCat.equals("Category") && labelVer.equals("Vertical") ) {
			generateXML.logVP("24.1", "Check whether Products search result is shown or not",	"Products search result is shown", AppConstants.vPass);				
		} else {
			generateXML.logVP("24.1", "Check whether Products search result is shown or not",	 "Products search result is not shown", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SEARCH_LBL);
		if(driver.findElement(By.xpath(xpathExpression)).isDisplayed()){
			generateXML.logVP("24.2", "Check whether search label is shown or not",	"search label is shown", AppConstants.vPass);				
		} else {
			generateXML.logVP("24.2", "Check whether search label is shown or not",	 "search label is not shown", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_ENTRIES_DROP);
		if(driver.findElement(By.xpath("//*[@id='create-repl-list_length']/label/select")).isDisplayed()){
			generateXML.logVP("24.3", "Check whether drop down is shown or not",	"drop down is shown", AppConstants.vPass);				
		} else {
			generateXML.logVP("24.3", "Check whether sdrop down is shown or not",	 "drop down is not shown", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_PREV);
		if(driver.findElement(By.xpath("//*[@id='create-repl-list_previous']")).isDisplayed()){
			generateXML.logVP("24.4", "Check whether SEARCH_PREVIOUS is present or not",	" SEARCH_PREVIOUS is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("24.4", "Check whether SEARCH_PREVIOUS is present or not",	 " SEARCH_PREVIOUS is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_NEXT);
		if(driver.findElement(By.xpath("//*[@id='create-repl-list_next']")).isDisplayed()){
			generateXML.logVP("24.5", "Check whether SEARCH_NEXT is present or not",	" SEARCH_NEXT is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("24.5", "Check whether SEARCH_NEXT is present or not",	 " SEARCH_NEXT is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_ENTRIES_INFO);
		if(driver.findElement(By.xpath("//*[@id='create-repl-list_info']")).isDisplayed()){
			generateXML.logVP("22", "Check whether SEARCH_ENTRIES is present or not",	" SEARCH_ENTRIES is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("22", "Check whether SEARCH_ENTRIES is present or not",	 " SEARCH_ENTRIES is not present", AppConstants.vFail);		
		}

		/*Get the pagination text saying 'showing  n/n records ' before and after clicking the Previous button
	    If both are same, then no action is performed */
		String textXpath = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_ENTRIES_INFO);
		String beforeText = driver.findElement(By.xpath("//*[@id='create-repl-list_info']")).getText();
		driver.findElement(By.xpath("//*[@id='create-repl-list_info']")).click();
		String afterText = driver.findElement(By.xpath("//*[@id='create-repl-list_info']")).getText();

		if(beforeText.equals(afterText)) {
			// Set new element tag details 		
			generateXML.logVP( "23", "Verify Pagination-Previous button by clicking on it", "The pagination  'Previous' button is disabled and upon clicking 'Previous' button ,system could not perform any action", AppConstants.vPass);
		} else {
			generateXML.logVP( "23", "Verify Pagination-Previous button by clicking on it", "The pagination  'Previous' button is not disabled and upon clicking 'Previous' button ,system performs an action", AppConstants.vFail);
		}	
	}

	@Test
	public void test_A_7() throws Exception {		

		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();
		driver.findElement(By.id("repl-create")).click();

		Select select = new Select(driver.findElement(By.id("searchType")));
		//Select select = new Select(driver.findElement(By.xpath(excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_PART_NO))));
		select.selectByIndex(0);

		String xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_DROPDOWN_VAL);
		driver.findElement(By.xpath("//*[@id='searchId']")).clear();

		String dropdown_val = "029A0039000";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_DROPDOWN_VAL).trim();
		driver.findElement(By.xpath("//*[@id='searchId']")).sendKeys(dropdown_val);

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_GO_BTTN);
		driver.findElement(By.xpath("//*[@id='search-replenishment']")).click();


		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_PROD_LINK);
		String product=driver.findElement(By.xpath("//*[@id='create-repl-list']/tbody/tr[1]/td[1]/a[1]")).getText();
		driver.findElement(By.xpath("//*[@id='create-repl-list']/tbody/tr[1]/td[1]/a[1]")).click();
		dropdown_val = "Repeat Purchase Time Interval for 029A0039000# Satin Christening Shoes";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_DROPDOWN_VAL).trim();

		if(dropdown_val.contains(product)){

			generateXML.logVP( "29", "Check whether PART_NUMBER is present in label or not", "PART_NUMBER is present in label", AppConstants.vPass);
		} else {
			generateXML.logVP( "29", "Check whether PART_NUMBER is present in label or not", "PART_NUMBER is not present in label", AppConstants.vFail);
		}	


		//driver.findElement(By.xpath(xpathExpression)).click();

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_REPEAT_HEADER);
		String text = driver.findElement(By.xpath("//*[@id='create-repl-header']")).getText();

		String repeatlbl="Repeat Purchase Time Interval for";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_REPEAT_LBL);
		repeatlbl=repeatlbl+" "+product;

		if(repeatlbl.equalsIgnoreCase(text)){
			generateXML.logVP( "28.1", "Check if REPLENISHMENT_REPEAT_HEADER is displayed or not", "REPLENISHMENT_REPEAT_HEADER is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "28.1", "Check if REPLENISHMENT_REPEAT_HEADER is displayed or not", "REPLENISHMENT_REPEAT_HEADER is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_SYSTEM_RADIO);
		if(driver.findElement(By.xpath("//*[@id='sys-def']")).isDisplayed()){
			generateXML.logVP("28.2", "Check whether SYSTEM_DEFINED radio button is present or not",	" SYSTEM_DEFINED radio button is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("28.2", "Check whether SYSTEM_DEFINED radio button is present or not",	 " SYSTEM_DEFINED radio button is not present", AppConstants.vFail);		
		}	

		if(driver.findElement(By.xpath("//*[@id='sys-def']")).getAttribute(AppConstants.CHECKED).equalsIgnoreCase(AppConstants.TRUE)){
			generateXML.logVP("28.3", "Check whether SYSTEM_DEFINED radio button is selected or not",	" SYSTEM_DEFINED radio button is selected", AppConstants.vPass);				
		} else {
			generateXML.logVP("28.3", "Check whether SYSTEM_DEFINED radio button is selected or not",	 " SYSTEM_DEFINED radio button is not selected", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_USER_RADIO);
		if(driver.findElement(By.xpath("//*[@id='user-def']")).isDisplayed()){
			generateXML.logVP("28.4", "Check whether USER_DEFINED radio button is present or not",	" USER_DEFINED radio button is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("28.4", "Check whether USER_DEFINED radio button is present or not",	 " USER_DEFINED radio button is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SAVE);
		if(driver.findElement(By.xpath("//*[@id='createReplenishment']")).isDisplayed()){
			generateXML.logVP("25", "Check whether save button is present or not",	" save button is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("25", "Check whether save button is present or not",	 " save button is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_CANCEL);
		if(driver.findElement(By.xpath("//*[@id='resetReplenishment']")).isDisplayed()){
			generateXML.logVP("31", "Check whether cancel button is present or not",	" save cancel is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("31", "Check whether cancel button is present or not",	 " save cancel is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_HIGHLIGHT);
		String highlightClass = driver.findElement(By.xpath("//*[@id='create-repl-list']/tbody/tr[1]")).getAttribute(AppConstants.CLASS);
		text = "odd row_selected";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_HIGHLIGHT);

		if(text.equalsIgnoreCase(highlightClass)){

			generateXML.logVP( "30", "Check whether selected row is highlighted or not", "selected row is highlighted", AppConstants.vPass);
		} else {
			generateXML.logVP( "30", "Check whether selected row is highlighted or not", "selected row is not highlighted", AppConstants.vFail);
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_USER_RADIO);
		driver.findElement(By.xpath("//*[@id='user-def']")).click();

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_LBL);
		if(driver.findElement(By.xpath("//*[@id='create-repl-form']/table/tbody/tr[1]/td[1]")).isDisplayed()){
			generateXML.logVP("32.1", "Check whether INTVL_LBL is Displayed or not",	" INTVL_LBL is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("32.1", "Check whether INTVL_LBL is Displayed or not",	 " INTVL_LBL is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL);
		if(driver.findElement(By.xpath("//*[@id='repl-mean']")).isDisplayed()){
			generateXML.logVP("32.1", "Check whether INTVL_VAL is present or not",	" INTVL_VAL is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("32.1", "Check whether INTVL_VAL is present or not",	 " INTVL_VAL is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_DAYS);
		if(driver.findElement(By.xpath("//*[@id='create-repl-form']/table/tbody/tr[1]/td[3]/b")).isDisplayed()){
			generateXML.logVP("32.1", "Check whether INTVL_DAYS is present or not",	" INTVL_DAYS is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("32.1", "Check whether INTVL_DAYS is present or not",	 " INTVL_DAYS is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_LBL);
		if(driver.findElement(By.xpath("//*[@id='create-repl-form']/table/tbody/tr[2]/td[1]")).isDisplayed()){
			generateXML.logVP("32.2", "Check whether RECOM_LBL is present or not",	" RECOM_LBL is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("32.2", "Check whether RECOM_LBL is present or not",	 "RECOM_LBL is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL);
		if(driver.findElement(By.xpath("//*[@id='repl-dev']")).isDisplayed()){
			generateXML.logVP("32.2", "Check whether RECOM_VAL is present or not",	" RECOM_VAL is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("32.2", "Check whether RECOM_VAL is present or not",	 " RECOM_VAL is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_DAYS);
		if(driver.findElement(By.xpath("//*[@id='create-repl-form']/table/tbody/tr[2]/td[3]/b")).isDisplayed()){
			generateXML.logVP("32.2", "Check whether RECOM_DAYS is present or not",	" RECOM_DAYS is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("32.2", "Check whether RECOM_DAYS is present or not",	 " RECOM_DAYS is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SAVE);
		if(driver.findElement(By.xpath("//*[@id='createReplenishment']")).isDisplayed()){
			generateXML.logVP("32.3", "Check whether save button is present or not",	" save button is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("32.3", "Check whether save button is present or not",	 " save button is not present", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_CANCEL);
		if(driver.findElement(By.xpath("//*[@id='resetReplenishment']")).isDisplayed()){
			generateXML.logVP("32.3", "Check whether cancel button is present or not",	" save cancel is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("32.3", "Check whether cancel button is present or not",	 " save cancel is not present", AppConstants.vFail);		
		}	

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL);
		driver.findElement(By.xpath("//*[@id='repl-mean']")).clear();

		String intVal1 = "20";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL1).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(intVal1);

		xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL);
		driver.findElement(By.xpath("//*[@id='repl-dev']")).clear();

		String recomVal1 = "30";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL1).trim();
		driver.findElement(By.xpath("//*[@id='repl-dev']")).sendKeys(recomVal1);

		xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SAVE);
		driver.findElement(By.xpath("//*[@id='createReplenishment']")).click();

		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "33", "Check if popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "33", "Check if popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String update_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(update_msg.equals("Suggested Recommendation should be less than Purchase Time.")){	
			generateXML.logVP( "33", "Check if correct popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "33", "Check if correct popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
		}

				xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
				driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();	


				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL);
				driver.findElement(By.xpath("//*[@id='repl-mean']")).clear();

				String intVal2 = "af2";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL2).trim();
				driver.findElement(By.xpath("//*[@id='repl-mean']")).sendKeys(intVal2);

				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL);
				driver.findElement(By.xpath("//*[@id='repl-dev']")).clear();

				String recomVal2 = "fe4";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL2).trim();
				driver.findElement(By.xpath("//*[@id='repl-dev']")).sendKeys(recomVal2);

				xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SAVE);
				driver.findElement(By.xpath("//*[@id='createReplenishment']")).click();

				xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

				if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
					generateXML.logVP( "34", "Check if popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
				} else {	
					generateXML.logVP( "34", "Check if popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
				}

				xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
				String update_msg2=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

				if(update_msg2.equals("Not a number.")){	
					generateXML.logVP( "34", "Check if correct update popup message is displayed or not", "correct update popup message is displayed", AppConstants.vPass);	
				} else {	
					generateXML.logVP( "34", "Check if correct update popup message is displayed or not", "correct update popup message is not displayed", AppConstants.vFail);		
				}

				xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
				driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();


				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL);
				driver.findElement(By.xpath("//*[@id='repl-mean']")).clear();

				String intVal3 = "10.7";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL3).trim();
				driver.findElement(By.xpath("//*[@id='repl-mean']")).sendKeys(intVal3);

				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL);
				driver.findElement(By.xpath("//*[@id='repl-dev']")).clear();

				String recomVal3 = "8.8";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL3).trim();
				driver.findElement(By.xpath(xpathExpression)).sendKeys(recomVal3);

				xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SAVE);
				driver.findElement(By.xpath("//*[@id='createReplenishment']")).click();

				xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

				if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
					generateXML.logVP( "35", "Check if popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
				} else {	
					generateXML.logVP( "35", "Check if popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
				}

				xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
				String update_msg3=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

				if(update_msg3.equals("Not a whole number.")){	
					generateXML.logVP( "35", "Check if correct popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
				} else {	
					generateXML.logVP( "35", "Check if correct popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
				}

				xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
				driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();

				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL);
				driver.findElement(By.xpath("//*[@id='repl-mean']")).clear();

				String intVal4 = "-8";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL4).trim();
				driver.findElement(By.xpath("//*[@id='repl-mean']")).sendKeys(intVal4);

				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL);
				driver.findElement(By.xpath("//*[@id='repl-dev']")).clear();

				String recomVal4 = "-89";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL4).trim();
				driver.findElement(By.xpath("//*[@id='repl-dev']")).sendKeys(recomVal4);

				xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SAVE);
				driver.findElement(By.xpath("//*[@id='createReplenishment']")).click();

				xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

				if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
					generateXML.logVP( "36", "Check if popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
				} else {	
					generateXML.logVP( "36", "Check if popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
				}

				xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
				String update_msg4=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

				if(update_msg4.equals("Enter non-zero number.")){	
					generateXML.logVP( "36", "Check if popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
				} else {	
					generateXML.logVP( "36", "Check if popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
				}

				xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
				driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();


				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL);
				driver.findElement(By.xpath("//*[@id='repl-mean']")).clear();

				String intVal5 = "0";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL5).trim();
				driver.findElement(By.xpath("//*[@id='repl-mean']")).sendKeys(intVal5);

				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL);
				driver.findElement(By.xpath("//*[@id='repl-dev']")).clear();

				String recomVal5 = "10";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL5).trim();
				driver.findElement(By.xpath("//*[@id='repl-dev']")).sendKeys(recomVal5);

				xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SAVE);
				driver.findElement(By.xpath("//*[@id='createReplenishment']")).click();

				xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

				if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
					generateXML.logVP( "37", "Check if popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
				} else {	
					generateXML.logVP( "37", "Check if popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
				}

				xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
				String update_msg5=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

				if(update_msg5.equals("Enter non-zero number.")){	
					generateXML.logVP( "37", "Check if correct popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
				} else {	
					generateXML.logVP( "37", "Check if correct popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
				}

				xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
				driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();


				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL);
				driver.findElement(By.xpath("//*[@id='repl-mean']")).clear();

				String intVal6 = "20";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL6).trim();
				driver.findElement(By.xpath("//*[@id='repl-mean']")).sendKeys(intVal6);

				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL);
				driver.findElement(By.xpath("//*[@id='repl-dev']")).clear();

				String recomVal6 = "10";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL6).trim();
				driver.findElement(By.xpath("//*[@id='repl-dev']")).sendKeys(recomVal6);

				xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SAVE);
				driver.findElement(By.xpath("//*[@id='createReplenishment']")).click();

				xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

				if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
					generateXML.logVP( "38", "Check if  popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
				} else {	
					generateXML.logVP( "38", "Check if  popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
				}

				xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
				String update_msg6=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

				if(update_msg6.equals("Replenishment Data Created.")){	
					generateXML.logVP( "38", "Check if popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
				} else {	
					generateXML.logVP( "38", "Check if popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
				}

				xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
				driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();

				xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_HIGHLIGHT);
				String highlight = driver.findElement(By.xpath("//*[@id='create-repl-list']/tbody/tr[1]")).getAttribute(AppConstants.CLASS);
				text = "odd row_selected";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_HIGHLIGHT);

				if(text.equalsIgnoreCase(highlight)){

					generateXML.logVP( "39", "Check whether same page is displayed or not", "same page is displayed", AppConstants.vPass);
				} else {
					generateXML.logVP( "39", "Check whether same page is displayed or not", "same page is not displayed", AppConstants.vFail);
				}	

				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_SYSTEM_RADIO);
				driver.findElement(By.xpath("//*[@id='sys-def']")).click();
				xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_CANCEL);
				driver.findElement(By.xpath("//*[@id='resetReplenishment']")).click();
				xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_RPT_DIV);
				String style = driver.findElement(By.xpath("//*[@id='create']")).getAttribute("style");
				text = "display: none;";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_RPT_DIV);

				if(text.equalsIgnoreCase(style)){

					generateXML.logVP( "40", "Check whether repeat section is displayed or not on click of cancel", "repeat section is displayed", AppConstants.vPass);
				} else {
					generateXML.logVP( "40", "Check whether repeat section is displayed or not on click of cancel", "repeat section not displayed", AppConstants.vFail);
				}	

				driver.findElement(By.xpath("//*[@id='create-repl-list']/tbody/tr[1]/td[1]/a[1]")).click();
				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_USER_RADIO);
				driver.findElement(By.xpath("//*[@id='user-def']")).click();
				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL);
				driver.findElement(By.xpath("//*[@id='repl-mean']")).clear();

				String intValue = "20";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_INTVL_VAL1).trim();
				driver.findElement(By.xpath("//*[@id='repl-mean']")).sendKeys(intValue);

				xpathExpression = excelRW.readProps(pageName, OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL);
				driver.findElement(By.xpath("//*[@id='repl-dev']")).clear();

				String recomValue = "30";//propsRW.read(OffersConstants.EDIT_REPLENISHMENT_RECOM_VAL1).trim();
				driver.findElement(By.xpath("//*[@id='repl-dev']")).sendKeys(recomValue);
				xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_CANCEL);
				driver.findElement(By.xpath("//*[@id='resetReplenishment']")).click();
				xpathExpression = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_RPT_DIV);
				style = driver.findElement(By.xpath("//*[@id='create']")).getAttribute("style");
				text = "display: none;";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_RPT_DIV);

				if(text.equalsIgnoreCase(style)){

					generateXML.logVP( "41", "Check whether repeat section is displayed or not on click of cancel", "repeat section is displayed", AppConstants.vPass);
				} else {
					generateXML.logVP( "41", "Check whether repeat section is displayed or not on click of cancel", "repeat section not displayed", AppConstants.vFail);
				}
	}

	/**
	 * This method is used to check Search functionality
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_A_8() throws Exception {		


		/*String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();

		//Check whether MENU_REPLENISHMENT is selected or not
		String xpathExpressionMenu = excelRW.readProps(pageName, OffersConstants.MENU_REPLENISHMENT);*/
		//String selectedMenu  = driver.findElement(By.xpath(xpathExpressionMenu)).getText();

		driver.findElement(By.xpath("//*[@id=\"navigation\"]/li[9]/a/b")).click();
		
		//Get XPath for Search text box
		String searchXPath = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SEARCH_VAL);

		//Clear Search text box
		driver.findElement(By.xpath("//*[@id='replenishment-list_filter']/label/input")).clear();

		//Read SEARCH_TEXT value from properties file		
		String search_text = "shoes";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_SEARCH_VAL).trim();
		driver.findElement(By.xpath("//*[@id='replenishment-list_filter']/label/input")).sendKeys(search_text);

		if (verifyReplSearchResults()) {	
			generateXML.logVP( "42", "Check if entries corresponding to the search criteria are shown in the table or not", "Correct entries are shown", AppConstants.vPass);	


		} else {	
			generateXML.logVP( "42", "Check if entries corresponding to the search criteria are shown in the table or not", "Correct entries are not shown", AppConstants.vFail);	

		}

	}
	/**
	 * This method is used to check whether MENU_REPLENISHMENT is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_A_9() throws Exception {		

		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.SUGGESTED_ITEMS_LINK);
		driver.findElement(By.xpath("//*[@id='navigation']/li[1]/a/b")).click();
		String selectedText  = driver.findElement(By.className("newheader")).getText();
		selectedText = selectedText.replace("\n", " ").replace("\r", " ");

		if(selectedText.equals(OffersConstants.CONFIG_PARAM_VAL) ) {
			generateXML.logVP("45", "Check whether Suggested Items is shown or not","Suggested Items is shown", AppConstants.vPass);
			generateXML.logVP("46", "Check whether Offers tab -configure parameter is present or not",	"configure parameter is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("45", "Check whether Suggested Items is shown or not","Suggested Items is not shown", AppConstants.vFail);	
			generateXML.logVP("46", "Check whether Offers tab -configure parameter is present or not",	 "configure parameter is not present", AppConstants.vFail);
		}		
		List<WebElement> labelsList=driver.findElements(By.xpath("//*[@class='tablecontainer']//table//tr/*[1]"));

		String[] labels="Weightage of Also Viewed *,Weightage of Similar Products *,Weightage of Top Sellers *,Weightage of Ultimately Bought *".split("\\,");//propsRW.read(OffersConstants.SUGGESTED_ITEMS_LBL).split(",");
		System.out.println("lables size*********"+labels.length);
		int count =0;

		for(WebElement label:labelsList)
		{
			String labelName=label.getText();
			if(labelName.equalsIgnoreCase(labels[0]) || labelName.equalsIgnoreCase(labels[1]) ||labelName.equalsIgnoreCase(labels[2])
					|| labelName.equalsIgnoreCase(labels[3])){

				count++;
			}
		}
		System.out.println("*************"+count);

		if(count==4)
		{
			generateXML.logVP("47", "verify labels in Suggested Items",	"Suggested Items section is displayed with all labels", AppConstants.vPass);				
		}		
		else
		{
			generateXML.logVP("47", "verify labels in Suggested Items",	"Suggested Items section is not displayed with all labels", AppConstants.vFail);				
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.SUGGESTED_ITEMS_UPDT);
		if(driver.findElement(By.xpath("//*[@id='submit']")).isDisplayed()) {
			generateXML.logVP( "55", "Check if  update button is displayed or not", "update button is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "55", "Check if  update button is displayed or not", "update button is not displayed", AppConstants.vFail);		
		}
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "56", "Check if  popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "56", "Check if  popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String update_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(update_msg.equals("Saved Successfully")){	
			generateXML.logVP( "54", "Check if popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "54", "Check if popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();

	}

	/**
	 * This method is used to check whether MENU_REPLENISHMENT is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_B_1() throws Exception {		

		Thread.sleep(2000);
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_LINK);
		driver.findElement(By.xpath("//*[@id='navigation']/li[2]/a/b")).click();
		String selectedText  = driver.findElement(By.className("newheader")).getText();
		selectedText = selectedText.replace("\n", " ").replace("\r", " ");

		if(selectedText.equals("Configure Parameters: Top Picks For You help")){
			generateXML.logVP("57", "Check whether Top picks screen is shown or not","Top picks screen is shown", AppConstants.vPass);
			generateXML.logVP("58", "Check whether Top picks header is present or not",	"Top picks header is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("57", "Check whether Top picks screen is shown or not","Top picks screen is not shown", AppConstants.vFail);	
			generateXML.logVP("58", "Check whether Top picks header is present or not",	 "Top picks header is not present", AppConstants.vFail);
		}		
		List<WebElement> labelsList=driver.findElements(By.xpath("//*[@class='tablecontainer']//table//tr/*[1]"));

		String[] labels="Weightage of Collaborative Filtering *,Weightage of Frequently Bought Together Items *,Weightage of Suggested Items *".split("\\,");//propsRW.read(OffersConstants.TOP_PICKS_LBL).split(",");
		System.out.println("lables size*********"+labels.length);
		int count =0;

		for(WebElement label:labelsList)
		{
			if(label.getText() == null){
				count =3;
				break;
			}
			String labelName=label.getText();
			if(labelName.equalsIgnoreCase(labels[0]) || labelName.equalsIgnoreCase(labels[1]) ||labelName.equalsIgnoreCase(labels[2])){

				count++;
			}
		}
		System.out.println("*************"+count);

		if(count==3)
		{
			generateXML.logVP("59", "verify labels in TOP_PICKS",	"TOP_PICKS section is displayed with all labels", AppConstants.vPass);				
		}		
		else
		{
			generateXML.logVP("59", "verify labels in TOP_PICKS",	"TOP_PICKS section is not displayed with all labels", AppConstants.vFail);				
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_UPDT);
		if(driver.findElement(By.xpath("//*[@id='submit']")).isDisplayed()) {
			generateXML.logVP( "66", "Check if  update button is displayed or not", "update button is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "66", "Check if  update button is displayed or not", "update button is not displayed", AppConstants.vFail);		
		}
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "67", "Check if  popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "67", "Check if  popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String update_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(update_msg.equals("Saved Successfully")){	
			generateXML.logVP( "65", "Check if popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "65", "Check if popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();

	}

	/**
	 * This method is used to check whether MENU_REPLENISHMENT is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_B_2() throws Exception {		

		Thread.sleep(2000);
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_LINK);
		driver.findElement(By.xpath("//*[@id='navigation']/li[3]/a/b")).click();
		String selectedText  = driver.findElement(By.className("newheader")).getText();
		selectedText = selectedText.replace("\n", " ").replace("\r", " ");

		if(selectedText.equals("Configure Parameters: Frequently Bought Together help")){
			generateXML.logVP("68", "Check whether Frequently Bought Together screen is shown or not","Frequently Bought Together screen is shown", AppConstants.vPass);
			generateXML.logVP("69", "Check whether Frequently Bought Together header is present or not",	"Frequently Bought Together header is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("68", "Check whether Frequently Bought Together screen is shown or not","Frequently Bought Together screen is not shown", AppConstants.vFail);	
			generateXML.logVP("69", "Check whether Frequently Bought Together header is present or not",	 "Frequently Bought Together header is not present", AppConstants.vFail);
		}		
		List<WebElement> labelsList=driver.findElements(By.xpath("//*[@class='tablecontainer']//table//tr/*[1]"));

		String[] labels="Bought Together Frequency *,Bought Together Threshold *".split("\\,");//propsRW.read(OffersConstants.TOP_PICKS_LBL).split(",");
		System.out.println("lables size*********"+labels.length);
		int count =0;

		for(WebElement label:labelsList)
		{
			String labelName=label.getText();
			if(labelName.equalsIgnoreCase(labels[0]) || labelName.equalsIgnoreCase(labels[1]) ||labelName.equalsIgnoreCase(labels[2])){

				count++;
			}
		}
		System.out.println("*************"+count);

		if(count==2)
		{
			generateXML.logVP("70", "verify labels in Frequently Bought Together",	"Frequently Bought Together section is displayed with all labels", AppConstants.vPass);				
		}		
		else
		{
			generateXML.logVP("70", "verify labels in Frequently Bought Together",	"Frequently Bought Together section is not displayed with all labels", AppConstants.vFail);				
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_UPDT);
		if(driver.findElement(By.xpath("//*[@id='submit']")).isDisplayed()) {
			generateXML.logVP( "76", "Check if  update button is displayed or not", "update button is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "76", "Check if  update button is displayed or not", "update button is not displayed", AppConstants.vFail);		
		}
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "77", "Check if  popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "77", "Check if  popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String update_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(update_msg.equals("Saved Successfully")){	
			generateXML.logVP( "75", "Check if popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "75", "Check if popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();
	}
	
	
	
	/**
	 * This method is used to check whether MENU_REPLENISHMENT is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_B_3() throws Exception {
		
		Thread.sleep(2000);
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_LINK);
		driver.findElement(By.xpath("//*[@id='navigation']/li[4]/a/b")).click();
		String selectedText  = driver.findElement(By.className("newheader")).getText();
		selectedText = selectedText.replace("\n", " ").replace("\r", " ");

		if(selectedText.equals("Configure Parameters: Viewed Ultimately Bought help")){
			generateXML.logVP("78", "Check whether Viewed Ultimately Bought screen is shown or not","Viewed Ultimately Bought screen is shown", AppConstants.vPass);
			generateXML.logVP("79", "Check whether Viewed Ultimately Bought header is present or not",	"Viewed Ultimately Bought header is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("78", "Check whether Viewed Ultimately Bought screen is shown or not","Viewed Ultimately Bought screen is not shown", AppConstants.vFail);	
			generateXML.logVP("79", "Check whether Viewed Ultimately Bought header is present or not",	 "Viewed Ultimately Bought header is not present", AppConstants.vFail);
		}		
		List<WebElement> labelsList=driver.findElements(By.xpath("//*[@class='tablecontainer']//table//tr/*[1]"));

		String[] labels="Viewed Ultimately Bought Frequency (in Days) *,Viewed Ultimately Bought Threshold *".split("\\,");//propsRW.read(OffersConstants.TOP_PICKS_LBL).split(",");
		System.out.println("lables size*********"+labels.length);
		int count =0;

		for(WebElement label:labelsList)
		{
			String labelName=label.getText();
			if(labelName.equalsIgnoreCase(labels[0]) || labelName.equalsIgnoreCase(labels[1]) ||labelName.equalsIgnoreCase(labels[2])){

				count++;
			}
		}
		System.out.println("*************"+count);

		if(count==2)
		{
			generateXML.logVP("80", "verify labels in Viewed Ultimately Bought",	"Viewed Ultimately Bought section is displayed with all labels", AppConstants.vPass);				
		}		
		else
		{
			generateXML.logVP("80", "verify labels in Viewed Ultimately Bought",	"Viewed Ultimately Bought section is not displayed with all labels", AppConstants.vFail);				
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_UPDT);
		if(driver.findElement(By.xpath("//*[@id='submit']")).isDisplayed()) {
			generateXML.logVP( "86", "Check if  update button is displayed or not", "update button is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "86", "Check if  update button is displayed or not", "update button is not displayed", AppConstants.vFail);		
		}
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "87", "Check if  popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "87", "Check if  popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String update_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(update_msg.equals("Saved Successfully")){	
			generateXML.logVP( "85", "Check if popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "85", "Check if popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();
	}

	

	
	/**
	 * This method is used to check whether MENU_REPLENISHMENT is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_B_4() throws Exception {		

		Thread.sleep(2000);
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_LINK);
		driver.findElement(By.xpath("//*[@id='navigation']/li[5]/a/b")).click();
		String selectedText  = driver.findElement(By.className("newheader")).getText();
		selectedText = selectedText.replace("\n", " ").replace("\r", " ");

		if(selectedText.equals("Configure Parameters: Also Viewed help")){
			generateXML.logVP("88", "Check whether Also Viewed screen is shown or not","Also Viewed screen is shown", AppConstants.vPass);
			generateXML.logVP("89", "Check whether Also Viewed header is present or not",	"Also Viewed header is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("88", "Check whether Also Viewed screen is shown or not","Also Viewed screen is not shown", AppConstants.vFail);	
			generateXML.logVP("89", "Check whether Also Viewed header is present or not",	 "Also Viewed header is not present", AppConstants.vFail);
		}		
		List<WebElement> labelsList=driver.findElements(By.xpath("//*[@class='tablecontainer']//table//tr/*[1]"));

		String[] labels="Boost Limit *,Products Count per User *, Time Threshold (in Days) *".split("\\,");//propsRW.read(OffersConstants.TOP_PICKS_LBL).split(",");
		System.out.println("lables size*********"+labels.length);
		int count =0;

		for(WebElement label:labelsList)
		{
			String labelName=label.getText();
			if(labelName.equalsIgnoreCase(labels[0]) || labelName.equalsIgnoreCase(labels[1]) ||labelName.equalsIgnoreCase(labels[2])){

				count++;
			}
		}
		System.out.println("*************"+count);

		if(count==3)
		{
			generateXML.logVP("90", "verify labels in Also Viewed",	"Also Viewed section is displayed with all labels", AppConstants.vPass);				
		}		
		else
		{
			generateXML.logVP("90", "verify labels in Also Viewed",	"Also Viewed section is not displayed with all labels", AppConstants.vFail);				
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_UPDT);
		if(driver.findElement(By.xpath("//*[@id='submit']")).isDisplayed()) {
			generateXML.logVP( "97", "Check if  update button is displayed or not", "update button is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "97", "Check if  update button is displayed or not", "update button is not displayed", AppConstants.vFail);		
		}
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "98", "Check if  popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "98", "Check if  popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String update_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(update_msg.equals("Saved Successfully")){	
			generateXML.logVP( "96", "Check if popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "96", "Check if popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();
	}
	
	/**
	 * This method is used to check whether MENU_REPLENISHMENT is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_B_5() throws Exception {		

		Thread.sleep(2000);
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_LINK);
		driver.findElement(By.xpath("//*[@id='navigation']/li[6]/a/b")).click();
		String selectedText  = driver.findElement(By.className("newheader")).getText();
		selectedText = selectedText.replace("\n", " ").replace("\r", " ");

		if(selectedText.equals("Configure Parameters: Similar Items help")){
			generateXML.logVP("99", "Check whether Similar Items screen is shown or not","Similar Items screen is shown", AppConstants.vPass);
			generateXML.logVP("100", "Check whether Similar Items header is present or not",	"Similar Items header is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("99", "Check whether Similar Items screen is shown or not","Similar Items screen is not shown", AppConstants.vFail);	
			generateXML.logVP("100", "Check whether Similar Items header is present or not",	 "Similar Items header is not present", AppConstants.vFail);
		}		
		List<WebElement> labelsList=driver.findElements(By.xpath("//*[@class='tablecontainer']//table//tr/*[1]"));

		String[] labels="Maximum Similarity Per Item *,Minimum Number of User Activities *, Maximum Number of User Activities *".split("\\,");//propsRW.read(OffersConstants.TOP_PICKS_LBL).split(",");
		System.out.println("lables size*********"+labels.length);
		int count =0;

		for(WebElement label:labelsList)
		{
			String labelName=label.getText();
			if(labelName.equalsIgnoreCase(labels[0]) || labelName.equalsIgnoreCase(labels[1]) ||labelName.equalsIgnoreCase(labels[2])){

				count++;
			}
		}
		System.out.println("*************"+count);

		if(count==3)
		{
			generateXML.logVP("101", "verify labels in Similar Items",	"Similar Items section is displayed with all labels", AppConstants.vPass);				
		}		
		else
		{
			generateXML.logVP("101", "verify labels in Similar Items",	"Similar Items section is not displayed with all labels", AppConstants.vFail);				
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_UPDT);
		if(driver.findElement(By.xpath("//*[@id='submit']")).isDisplayed()) {
			generateXML.logVP( "108", "Check if  update button is displayed or not", "update button is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "108", "Check if  update button is displayed or not", "update button is not displayed", AppConstants.vFail);		
		}
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "109", "Check if  popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "109", "Check if  popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String update_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(update_msg.equals("Saved Successfully")){	
			generateXML.logVP( "107", "Check if popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "107", "Check if popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();
	}
	
	
	/**
	 * This method is used to check whether MENU_REPLENISHMENT is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_B_6() throws Exception {		

		Thread.sleep(2000);
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_LINK);
		driver.findElement(By.xpath("//*[@id='navigation']/li[7]/a/b")).click();
		String selectedText  = driver.findElement(By.className("newheader")).getText();
		selectedText = selectedText.replace("\n", " ").replace("\r", " ");

		if(selectedText.equals("Configure Parameters: Cluster Recommendation for Category help")){
			generateXML.logVP("110", "Check whether Cluster Recommendation for Category screen is shown or not","Cluster Recommendation for Category screen is shown", AppConstants.vPass);
			generateXML.logVP("111", "Check whether Cluster Recommendation for Category header is present or not",	"Cluster Recommendation for Category header is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("110", "Check whether Cluster Recommendation for Category screen is shown or not","Cluster Recommendation for Category screen is not shown", AppConstants.vFail);	
			generateXML.logVP("111", "Check whether Cluster Recommendation for Category header is present or not",	 "Cluster Recommendation for Category header is not present", AppConstants.vFail);
		}		
		List<WebElement> labelsList=driver.findElements(By.xpath("//*[@class='tablecontainer']//table//tr/*[1]"));

		String[] labels="Weightage of Generic Items *,Weightage of Purchased Items *, Weightage of Viewed Items *".split("\\,");//propsRW.read(OffersConstants.TOP_PICKS_LBL).split(",");
		System.out.println("lables size*********"+labels.length);
		int count =0;

		for(WebElement label:labelsList)
		{
			String labelName=label.getText();
			if(labelName.equalsIgnoreCase(labels[0]) || labelName.equalsIgnoreCase(labels[1]) ||labelName.equalsIgnoreCase(labels[2])){

				count++;
			}
		}
		System.out.println("*************"+count);

		if(count==3)
		{
			generateXML.logVP("112", "verify labels in Cluster Recommendation for Category",	"Cluster Recommendation for Category section is displayed with all labels", AppConstants.vPass);				
		}		
		else
		{
			generateXML.logVP("112", "verify labels in Cluster Recommendation for Category",	"Cluster Recommendation for Category section is not displayed with all labels", AppConstants.vFail);				
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_UPDT);
		if(driver.findElement(By.xpath("//*[@id='submit']")).isDisplayed()) {
			generateXML.logVP( "119", "Check if  update button is displayed or not", "update button is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "119", "Check if  update button is displayed or not", "update button is not displayed", AppConstants.vFail);		
		}
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "120", "Check if  popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "120", "Check if  popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String update_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(update_msg.equals("Saved Successfully")){	
			generateXML.logVP( "118", "Check if popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "118", "Check if popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();
	}
	
	/**
	 * This method is used to check whether MENU_REPLENISHMENT is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_B_7() throws Exception {		

		Thread.sleep(2000);
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();
		String xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_LINK);
		driver.findElement(By.xpath("//*[@id='navigation']/li[8]/a/b")).click();
		String selectedText  = driver.findElement(By.className("newheader")).getText();
		selectedText = selectedText.replace("\n", " ").replace("\r", " ");

		if(selectedText.equals("Configure Parameters: New Product Recommendation help")){
			generateXML.logVP("121", "Check whether New Product Recommendation screen is shown or not","New Product Recommendation screen is shown", AppConstants.vPass);
			generateXML.logVP("122", "Check whether New Product Recommendation header is present or not",	"New Product Recommendation header is present", AppConstants.vPass);				
		} else {
			generateXML.logVP("121", "Check whether New Product Recommendation screen is shown or not","New Product Recommendation screen is not shown", AppConstants.vFail);	
			generateXML.logVP("122", "Check whether New Product Recommendation header is present or not",	 "New Product Recommendation header is not present", AppConstants.vFail);
		}		
		List<WebElement> labelsList=driver.findElements(By.xpath("//*[@class='tablecontainer']//table//tr/*[1]"));

		String[] labels="Brand Boost  *,Number of new Products Limit *, Price Boost *".split("\\,");//propsRW.read(OffersConstants.TOP_PICKS_LBL).split(",");
		System.out.println("lables size*********"+labels.length);
		int count =0;

		for(WebElement label:labelsList)
		{
			String labelName=label.getText();
			if(labelName.equalsIgnoreCase(labels[0]) || labelName.equalsIgnoreCase(labels[1]) ||labelName.equalsIgnoreCase(labels[2])){

				count++;
			}
		}
		System.out.println("*************"+count);

		if(count==3)
		{
			generateXML.logVP("123", "verify labels in New Product Recommendation",	"New Product Recommendation section is displayed with all labels", AppConstants.vPass);				
		}		
		else
		{
			generateXML.logVP("123", "verify labels in New Product Recommendation",	"New Product Recommendation section is not displayed with all labels", AppConstants.vFail);				
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.TOP_PICKS_UPDT);
		if(driver.findElement(By.xpath("//*[@id='submit']")).isDisplayed()) {
			generateXML.logVP( "125", "Check if  update button is displayed or not", "update button is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "125", "Check if  update button is displayed or not", "update button is not displayed", AppConstants.vFail);		
		}
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		xpathExpression = excelRW.readProps(pageName, OffersConstants.DELETE_POPUP);

		if(driver.findElement(By.xpath("html/body/div[4]")).isDisplayed()) {
			generateXML.logVP( "126", "Check if  popup window is displayed or not", "popup window is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "126", "Check if  popup window is displayed or not", "popup window is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName,OffersConstants.DELETE_CONFIRM_MSG);
		String update_msg=driver.findElement(By.xpath("html/body/div[4]/div[1]")).getText();

		if(update_msg.equals("Saved Successfully")){	
			generateXML.logVP( "124", "Check if popup message is displayed or not", "correct popup message is displayed", AppConstants.vPass);	
		} else {	
			generateXML.logVP( "124", "Check if popup message is displayed or not", "correct popup message is not displayed", AppConstants.vFail);		
		}

		xpathExpression = excelRW.readProps(pageName, OffersConstants.OK_CONFIRM);
		driver.findElement(By.xpath("html/body/div[4]/div[2]/a")).click();
	}
	
	
	/**
	 * This method is used to check whether MENU_REPLENISHMENT is selected or not
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_B_8() throws Exception {
		
		String xpathExpressionOfferTab = excelRW.readProps(pageName, OffersConstants.TAB_OFFER);
		driver.findElement(By.xpath(xpathExpressionOfferTab)).click();		
		driver.findElement(By.xpath("//*[@id='navigation']/li[1]/a/b")).click();
		HBaseUtil hutil = new HBaseUtil(); 
		String similarItems = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1006","smw",1);
		String ultimatelyBought = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1006","ubw",1);
		String topSellers = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1006","tsw",1);
		String alsoViewed = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1006","avw",1);
		
		String smw = driver.findElement(By.id("smw")).getAttribute("value");//("//*[@id=\"ModulesContent\"]/div[2]/div[3]/div/form/div[1]/div[2]/div/table/tbody/tr[1]/td[3]/input")).getText();
		
		if(offer){
			generateXML.logVP("48" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed ", AppConstants.vPass);
		}
		
		if(smw.equalsIgnoreCase(String.valueOf(Math.round(Double.parseDouble(similarItems)*100)))){
			generateXML.logVP("49" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Weitage for Similar Items", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("49" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Weitage for Similar Items", AppConstants.vFail);
		}
		
		String ubw = driver.findElement(By.id("ubw")).getAttribute("value");//("//*[@class='tablecontainer']//table/tbody/tr[4]/td[2]/input")).getText();
		
		if(ubw.equalsIgnoreCase(String.valueOf(Math.round(Double.parseDouble(ultimatelyBought)*100)))){
			generateXML.logVP("50" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Weitage for Ultimately Bought Items", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("50" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Weitage for Ultimately Bought Items", AppConstants.vFail);
		}
		
		String tsw = driver.findElement(By.id("tsw")).getAttribute("value");//("//*[@class='tablecontainer']//table/tbody/tr[3]/td[2]/input")).getText();
		
		if(tsw.equalsIgnoreCase(String.valueOf(Math.round(Double.parseDouble(topSellers)*100)))){
			generateXML.logVP("52" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Weitage for Top Sellers Items", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("52" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Weitage for Top Sellers Items", AppConstants.vFail);
		}
		
		String avw = driver.findElement(By.id("avw")).getAttribute("value");
		
		if(avw.equalsIgnoreCase(String.valueOf(Math.round(Double.parseDouble(alsoViewed)*100)))){
			generateXML.logVP("51" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Weitage for Top Sellers Items", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("51" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Weitage for Top Sellers Items", AppConstants.vFail);
		}
		
		driver.findElement(By.xpath("//*[@id='navigation']/li[2]/a/b")).click();		
		String suggestedForYou = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1001","siw",1);
		String frequentlyBought = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1001","fbtw",1);
		String collabFilter = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1001","cfw",1);
		
		String cfw = driver.findElement(By.id("cfw")).getAttribute("value");
		
		if(cfw.equalsIgnoreCase(String.valueOf(Math.round(Double.parseDouble(collabFilter)*100)))){
			generateXML.logVP("61" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Weitage for Collaborative Filtering Items", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("61" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Weitage for Collaborative Filtering Items", AppConstants.vFail);
		}
		
		String siw = driver.findElement(By.id("siw")).getAttribute("value");
		
		if(siw.equalsIgnoreCase(String.valueOf(Math.round(Double.parseDouble(suggestedForYou)*100)))){
			generateXML.logVP("62" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Weitage for Suggested For You Items", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("62" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Weitage for Suggested For You Items", AppConstants.vFail);
		}
		
		String fbtw = driver.findElement(By.id("fbtw")).getAttribute("value");
		
		if(fbtw.equalsIgnoreCase(String.valueOf(Math.round(Double.parseDouble(frequentlyBought)*100)))){
			generateXML.logVP("63" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Weitage for Suggested For You Items", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("63" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Weitage for Suggested For You Items", AppConstants.vFail);
		}
		
		
		driver.findElement(By.xpath("//*[@id='navigation']/li[3]/a/b")).click();		
		String boughtTogetherFreq = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","AHAM003","FB_DATE_FREQUENCY",1);
		String fbthreshold = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","AHAM003","FB_THRESHOLD_COUNT",1);
		
		String btf = driver.findElement(By.id("FB_DATE_FREQUENCY")).getAttribute("value");//By.xpath("//*[@id=\"FB_DATE_FREQUENCY\"]")).getText();
		if(btf.equalsIgnoreCase(boughtTogetherFreq)){
			generateXML.logVP("72" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Bought Together Frequency", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("72" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Bought Together Frequency", AppConstants.vFail);
		}
		
		String ftc = driver.findElement(By.id("FB_THRESHOLD_COUNT")).getAttribute("value");//By.xpath("//*[@id=\"FB_THRESHOLD_COUNT\"]")).getText();
		if(ftc.equalsIgnoreCase(fbthreshold)){
			generateXML.logVP("73" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Bought Together Threshold", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("73" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Bought Together Threshold", AppConstants.vFail);
		}
		
		driver.findElement(By.xpath("//*[@id='navigation']/li[4]/a/b")).click();		
		String vubfreq = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","AHAM004","VUP_DATE_FREQUENCY",1);
		String vuptc = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","AHAM004","VUP_THRESHOLD_COUNT",1);
		
		String vdf = driver.findElement(By.id("VUP_DATE_FREQUENCY")).getAttribute("value");//By.id(id)xpath("//*[@id=\"VUP_DATE_FREQUENCY\"]")).getText();
		if(vdf.equalsIgnoreCase(vubfreq)){
			generateXML.logVP("82" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Viewed Ultimately Bought Together Frequency", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("82" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Viewed Ultimately Bought Together Frequency", AppConstants.vFail);
		}
		
		String vtc = driver.findElement(By.id("VUP_THRESHOLD_COUNT")).getAttribute("value");//By.xpath("//*[@id=\"VUP_THRESHOLD_COUNT\"]")).getText();
		if(vtc.equalsIgnoreCase(vuptc)){
			generateXML.logVP("83" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Viewed Ultimately Bought Together Threshold", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("83" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Viewed Ultimately Bought Together Threshold", AppConstants.vFail);
		}
		
		driver.findElement(By.xpath("//*[@id='navigation']/li[5]/a/b")).click();		
		String timeThreshold = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1007","tt",1);
		String prodcu = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1007","pcu",1);
		String boostVal = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1007","bval",1);
		
		
		String tt = driver.findElement(By.id("tt")).getAttribute("value");//By.xpath("//*[@id=\"tt\"]")).getText();
		if(tt.equalsIgnoreCase(timeThreshold)){
			generateXML.logVP("92" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Time Threshold", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("92" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Time Threshold", AppConstants.vFail);
		}
		
		String pcu = driver.findElement(By.id("pcu")).getAttribute("value");//By.xpath("//*[@id=\"pcu\"]")).getText();
		if(pcu.equalsIgnoreCase(prodcu)){
			generateXML.logVP("93" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Products Count Per User", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("93" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Products Count Per User", AppConstants.vFail);
		
		}
		
		String bval = driver.findElement(By.id("bval")).getAttribute("value");//By.xpath("//*[@id=\"bval\"]")).getText();
		if(bval.equalsIgnoreCase(bval)){
			generateXML.logVP("94" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Boost Value", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("94" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Boost Value", AppConstants.vFail);
		
		}
		
		driver.findElement(By.xpath("//*[@id='navigation']/li[6]/a/b")).click();		
		String maxSim = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1008","m",1);
		String minUA = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1008","mp",1);			
		String maxUA = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1008","mppu",1);
		
		String m = driver.findElement(By.id("m")).getAttribute("value");//By.xpath("//*[@id=\"m\"]")).getText();
		if(m.equalsIgnoreCase(maxSim)){
			generateXML.logVP("103" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Maximum Similarity Per Item", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("103" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Maximum Similarity Per Item", AppConstants.vFail);
		}
		
		String mp = driver.findElement(By.id("mp")).getAttribute("value");//By.xpath("//*[@id=\"mp\"]")).getText();
		if(mp.equalsIgnoreCase(minUA)){
			generateXML.logVP("104" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Minimum Number of User Activities", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("104" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Minimum Number of User Activities", AppConstants.vFail);
		
		}
		
		String mppu = driver.findElement(By.id("mppu")).getAttribute("value");//By.xpath("//*[@id=\"mppu\"]")).getText();
		if(mppu.equalsIgnoreCase(maxUA)){
			generateXML.logVP("105" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Maximum Number of User Activities", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("105" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Maximum Number of User Activities", AppConstants.vFail);
		
		}
		
		driver.findElement(By.xpath("//*[@id='navigation']/li[7]/a/b")).click();		
		String wtPurc = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1005","prw",1);
		String wtView = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1005","vrw",1);
		String wtGen = hutil.getQualifierValue("STRATEGY_CONFIGURATION","PARAMETER_DETAILS","STRAT1005","grw",1);
		
		String prw = driver.findElement(By.id("prw")).getAttribute("value");//By.xpath("//*[@id=\"prw\"]")).getText();
		if(prw.equalsIgnoreCase(String.valueOf(Math.round(Double.parseDouble(wtPurc)*100)))){
			generateXML.logVP("114" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Weigtage of Purchased Items", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("114" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Weigtage of Purchased Items", AppConstants.vFail);
		}
		
		String vrw = driver.findElement(By.id("vrw")).getAttribute("value");//By.xpath("//*[@id=\"vrw\"]")).getText();
		if(vrw.equalsIgnoreCase(String.valueOf(Math.round(Double.parseDouble(wtView)*100)))){
			generateXML.logVP("115" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Weigtage of Viewed Items", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("115" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Weigtage of Viewed Items", AppConstants.vFail);
		
		}
		
		String grw = driver.findElement(By.id("grw")).getAttribute("value");//By.xpath("//*[@id=\"grw\"]")).getText();
		if(grw.equalsIgnoreCase(String.valueOf(Math.round(Double.parseDouble(wtGen)*100)))){
			generateXML.logVP("116" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is displayed in Weigtage of Generic Items", AppConstants.vPass);
		}
		else
		{
			generateXML.logVP("116" ,"This method is used to check if values in Hbase table is same as " +
					"the one displayed on Bussiness console  ",
					"valid data is not displayed in Weigtage of Generic Items", AppConstants.vFail);
		
		}
		
	}
	
	private boolean verifySearchResults() throws InterruptedException {

		String xpathExpression1 = excelRW.readProps(pageName, OffersConstants.SEARCH_RESULT_STR1);
		String result_str1 = driver.findElement(By.xpath(xpathExpression1)).getText();
		String propertyValue1 = propsRW.read(OffersConstants.SEARCH_RESULT_STR1).trim();

		String xpathExpression2 = excelRW.readProps(pageName, OffersConstants.SEARCH_RESULT_STR2);
		String result_str2 = driver.findElement(By.xpath(xpathExpression2)).getText();
		String propertyValue2 = propsRW.read(OffersConstants.SEARCH_RESULT_STR2).trim();

		if(result_str1.equals(propertyValue1) && result_str2.equals(propertyValue2)) {
			return true;
		} else {
			return false;
		}
	}


	private boolean verifyReplSearchResults() throws InterruptedException {

		String xpathExpression1 = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SEARCH_RSLT1);
		String result_str1 = driver.findElement(By.xpath("//*[@id='replenishment-list']/tbody/tr[1]/td[1]/a[1]")).getText();
		String propertyValue1 = "029A0039000# Satin Christening Shoes";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_SEARCH_RSLT1).trim();

		String xpathExpression2 = excelRW.readProps(pageName, OffersConstants.CREATE_REPLENISHMENT_SEARCH_RSLT2);
		String result_str2 = driver.findElement(By.xpath("//*[@id='replenishment-list']/tbody/tr[2]/td[1]/a[1]")).getText();
		String propertyValue2 = "029A0040000# Satin Christening Shoes";//propsRW.read(OffersConstants.CREATE_REPLENISHMENT_SEARCH_RSLT2).trim();

		if(result_str1.equals(propertyValue1) && result_str2.equals(propertyValue2)) {
			return true;
		} else {
			return false;
		}

	}
	/**
	 * After executing each test method, this method
	 * is called
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {

	}

	/**
	 * This method is invoked after all test methods in Offers.java
	 * are executed
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */
	@AfterClass
	public static void tearDownAfterClass() throws TransformerConfigurationException, TransformerException {		

		AppConstants.notRunCount = Integer.parseInt(propsRW.read(AppConstants.TOTAL_VERIFICATION_POINTS).trim())-AppConstants.passCount-AppConstants.failCount;                   		

		//log header report counts in XML file
		generateXML.logHeaderReportCounts();

		//Generate html report using xml created in test method
		//Report should be according to test case name, ex: data.html
		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH+AppConstants.DETAILED_REPORT_XSL;
		String outputHTML = AppConstants.DETAIL_REPORT_FOLDER+AppConstants.FORWARD_SLASH+AppConstants.DATA+AppConstants.DOT_HTML;
		generateReport.generateHTML(AppConstants.XML_FILE_PATH, inputXSL, outputHTML);

		System.out.println("Successfully generated the report");

		//log script in summary report xml file
		generateXML.logScript(AppConstants.LOGIN_SCRIPT_NAME, outputHTML);


		//Reset xml & properties files path to ""	
		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;

		//Set pass, fail and notrun count to zero
		AppConstants.passCount= 0;
		AppConstants.failCount = 0;
		AppConstants.notRunCount = 0;

		//Close the browser
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}

	}

}
