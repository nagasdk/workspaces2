package ocpe.aut.fwk.testScripts;

import static org.junit.Assert.fail;

import java.io.File;
import java.util.concurrent.TimeUnit;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;


/**
 * Login Test Cases 1.1, 1.2, 1.3
 * @author Devalanka_Pavani
 *
 */
@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class Login {

	private static StringBuffer verificationErrors = new StringBuffer();
	private static ExcelUtil excelRW;
	private static PropertiesUtil propsRW;
	private static GenerateXml generateXML;
	private static GenerateHTML generateReport;

	private static String pageName = AppConstants.LOGIN_PAGE;
	int sleepInterval = 2000;	//Sleep interval in milliseconds, 2000 milliseconds, i.e. 2seconds



	private static WebDriver driver;
	static DesiredCapabilities cap = null; static FirefoxBinary ffBinary = null; static FirefoxProfile ffprofile = null;

	private static String userNameXPath;
	private static String passwordXPath;
	private static String loginBtnXPath;


	/**
	 * All the one time set up initializations for the login test script 
	 * are done in this method
	 */
	@BeforeClass
	public static void oneTimeSetUp() {
		// one-time initialization code   
		System.out.println("@BeforeClass - oneTimeSetUp");
		File  pathToFirefoxBinary = new File(AppConstants.PATH_TO_FIREFOX_BINARY);
		ffBinary = new FirefoxBinary(pathToFirefoxBinary);
		ProfilesIni profile = new ProfilesIni();		   		   
		ffprofile = profile.getProfile(AppConstants.FIREFOX_PROFILE_DEFAULT);
		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();		  		  
		proxy.setProxyAutoconfigUrl(AppConstants.PROXY_URL);	
		cap = new DesiredCapabilities();		  
		cap.setCapability(CapabilityType.PROXY, proxy);	

		//Change the xml file path according to name of the script
		AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER+AppConstants.FORWARD_SLASH+AppConstants.LOGIN+AppConstants.DOT_XML;
		/*AppConstants.XML_FILE_PATH = OCPEDriverSuite.xmlFolder+AppConstants.FORWARD_SLASH+AppConstants.LOGIN+AppConstants.DOT_XML;*/
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.LOGIN_PROPERTIES;

		generateXML = new GenerateXml();		
		generateReport = new GenerateHTML();

		//Create a new XML file
		generateXML.createVPXML(AppConstants.LOGIN_SCRIPT_NAME);

		//Util classes that reads the excel sheet and properties files
		excelRW = new ExcelUtil(); 										
		propsRW = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);
		driver = new FirefoxDriver(ffBinary,ffprofile,cap);		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();	
		driver.get(AppConstants.BASE_URL + AppConstants.LOGIN_URL);	

		/*xpathExpression is the value present in column B of 
		  the sheet for the control name "username"
		  Ex: //input[@id='j_username'] 
		 */
		userNameXPath = excelRW.readProps(pageName, AppConstants.USER_NAME);
		passwordXPath = excelRW.readProps(pageName, AppConstants.PASSWORD);
		loginBtnXPath = excelRW.readProps(pageName, AppConstants.LOGIN_SUBMIT);

	}


	/**
	 * All the initializations for each test method 
	 * are done in this method
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {

	}


	/**
	 * This method is used to test login page with invalid username
	 * and valid password and validate whether proper 
	 * error message is being displayed or not
	 * @throws Exception
	 */
	@Test
	public void test_A_1() throws Exception {

		//Clear User Name text box
		driver.findElement(By.xpath(userNameXPath)).clear();

		//wait for 2 secs
		Thread.sleep(sleepInterval);

		//Read INVALID USERNAME value from properties file		
		String userName = propsRW.read(AppConstants.INVALID_USERNAME).trim();
		driver.findElement(By.xpath(userNameXPath)).sendKeys(userName);

		//wait for 2 secs
		Thread.sleep(sleepInterval);


		driver.findElement(By.xpath(passwordXPath)).clear();

		//Read VALID PASSWORD value from properties file
		String password = propsRW.read(AppConstants.VALID_PASSWORD).trim();
		driver.findElement(By.xpath(passwordXPath)).sendKeys(password);


		//Read xpathExpression from Excel file
		driver.findElement(By.xpath(loginBtnXPath)).click();	


		if (verifyErrorMsg(pageName)) {
			/* Set new element tag details */		
			generateXML.logVP( "1.1", "Check if user with invalid Username and valid password is able to login or not", "User is not able to Login and a popup with error message 'User credentials were invalid.' is displayed", AppConstants.vPass);
		
		} else {
			generateXML.logVP("1.1", "Check if user with invalid Username and valid password is able to login or not","User with invalid Username (grt@gmail.com) and valid password (Aham123+) is able to Login Sucessfully",AppConstants.vFail);		
		
		}

		//wait for 2 secs
		Thread.sleep(sleepInterval);		

	}

	/**
	 * This method is used to test login page with valid username
	 * and invalid password validate whether proper 
	 * error message is being displayed or not
	 * @throws Exception
	 */
	@Test
	public void test_A_2() throws Exception {
		/*Clear the User Name textbox*/
		driver.findElement(By.xpath(userNameXPath)).clear();

		/* Get valid username from properties file
		 * ex: rg@gmail.com*/
		String userName = propsRW.read(AppConstants.VALID_USERNAME).trim();
		driver.findElement(By.xpath(userNameXPath)).sendKeys(userName);

		//wait for 2 secs
		Thread.sleep(sleepInterval);

		/* Clear the Password textbox*/	
		driver.findElement(By.xpath(passwordXPath)).clear();

		/* Get invalid password from properties file
		 * ex: ham123*/
		String password = propsRW.read(AppConstants.INVALID_PASSWORD).trim();
		driver.findElement(By.xpath(passwordXPath)).sendKeys(password);

		//wait for 2 secs
		Thread.sleep(sleepInterval);

		/*Click on login button*/
		driver.findElement(By.xpath(loginBtnXPath)).click();

		if (verifyErrorMsg(pageName)) {
			generateXML.logVP( "1.2", "Check if user with valid Username and invalid password is able to login or not", "User is not able to Login and a popup with error message 'User credentials were invalid.' is displayed", AppConstants.vPass);			
	
		} else {		
			generateXML.logVP( "1.2", "Check if user with valid Username and invalid password is able to login or not", "User with valid Username (rg@gmail.com) and invalid password (ham123) is able to Login Sucessfully", AppConstants.vFail);
	
		}

		//wait for 2 secs
		Thread.sleep(sleepInterval);
	}

	/**
	 * This method is used to test login page with invalid username
	 * and invalid password and validate whether proper 
	 * error message is being displayed or not
	 * @throws Exception
	 */
	@Test
	public void test_A_3() throws Exception {
		/*Clear the User Name textbox*/
		driver.findElement(By.xpath(userNameXPath)).clear();

		/* Get invalid username from properties file
		 * ex: grt@gmail.com*/
		String userName = propsRW.read(AppConstants.INVALID_USERNAME).trim();
		driver.findElement(By.xpath(userNameXPath)).sendKeys(userName);

		//wait for 2 secs
		Thread.sleep(sleepInterval);

		/* Clear the Password textbox*/

		driver.findElement(By.xpath(passwordXPath)).clear();

		/* Get invalid password from properties file
		 * ex: ham123*/
		String password = propsRW.read(AppConstants.INVALID_PASSWORD).trim();
		driver.findElement(By.xpath(passwordXPath)).sendKeys(password);


		/*Click on login button*/
		driver.findElement(By.xpath(loginBtnXPath)).click();

		if (verifyErrorMsg(pageName)) {	
			generateXML.logVP( "1.3", "Check if user with invalid Username and invalid password is able to login or not", "User is not able to Login and a popup with error message 'User credentials were invalid.' is displayed", AppConstants.vPass);	
		

		} else {	
			generateXML.logVP( "1.3", "Check if user with invalid Username and invalid password is able to login or not", "User with valid Username (rg@gmail.com) and invalid password (ham123) is able to Login Sucessfully", AppConstants.vFail);	
		
		}

		//wait for 2 secs
		Thread.sleep(sleepInterval);
	}

	/**
	 * This method is used to test login page with valid username
	 * and valid password and validate whether user successfully logged in or not
	 * @throws Exception
	 */
	@Test
	public void test_A_4() throws Exception {

		/*Clear the User Name textbox*/	
		driver.findElement(By.xpath(userNameXPath)).clear();

		//wait for 2 secs
		Thread.sleep(sleepInterval);

		/* Get valid username from properties file
		 * ex: rg@gmail.com*/
		String userName = propsRW.read(AppConstants.VALID_USERNAME).trim();
		driver.findElement(By.xpath(userNameXPath)).sendKeys(userName);


		/* Clear the Password textbox*/	
		driver.findElement(By.xpath(passwordXPath)).clear();

		//wait for 2 secs
		Thread.sleep(sleepInterval);

		/* Get valid password from properties file
		 * ex: Aham123+*/
		String password = propsRW.read(AppConstants.VALID_PASSWORD).trim();
		driver.findElement(By.xpath(passwordXPath)).sendKeys(password);


		/*Click on login button*/
		driver.findElement(By.xpath(loginBtnXPath)).click();

		//Read xpathExpression from Excel file
		String xpathExpression = excelRW.readProps(pageName, AppConstants.WELCOME_MSG);		
		//Welcome message displayed on the page
		String welcomeMessage = driver.findElement(By.xpath(xpathExpression)).getText().trim();

		//welcome message defined in the login.properties file
		userName = propsRW.read(AppConstants.WELCOME_MSG).trim();

		if (welcomeMessage.equals(userName)) {		
			generateXML.logVP( "1.4", "Check if user with valid Username and valid password is able to login or not",	"User is able to Login successfully", 	AppConstants.vPass);		
	
		} else {			
			generateXML.logVP( "1.4", "Check if user with valid Username and valid password is able to login or not",	"User is not able to Login Sucessfully", AppConstants.vFail);	
		
		}

		Thread.sleep(sleepInterval);	
	}


	/**
	 * After clicking on login button, 
	 * error message modal will be displayed with below message
	 * "User credentials were invalid."
	 * Check whether the message is correct or not by fetching
	 * the value from properties file and compare it with the value
	 * that is displayed on the screen
	 * @param pageName
	 * @return boolean
	 * @throws InterruptedException
	 */
	private boolean verifyErrorMsg (String pageName) throws InterruptedException {

		String xpathExpression = excelRW.readProps(pageName,AppConstants.ERROR_MESSAGE);
		String errMsg = driver.findElement(By.xpath(xpathExpression)).getText();

		/*After verification, click on OK button
		 * Pop up will be dismissed */

		Thread.sleep(sleepInterval);
		xpathExpression = excelRW.readProps(pageName, AppConstants.OK_BTN);
		driver.findElement(By.linkText(AppConstants.OK)).click();

		String propertyValue = propsRW.read(AppConstants.INVALID_CREDENTIALS_MSG).trim();

		/* If expected error message and actual error message
		 * are same, then return true
		 * otherwise false 
		 * */
		if(errMsg.equals(propertyValue)) {
			return true;
		} else {
			return false;
		}
	}


	/**
	 * This method is executed after every method annotated with @Test
	 * in Login.java class
	 * @throws Exception
	 */
	@After
	public void tearDown() throws Exception {

	}	

	/**
	 * This method is invoked after all methods annotated with @Test
	 * are executed in Login.java class
	 * Detailed HTML report is generated in this method
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */
	@AfterClass
	public static void tearDownAfterClass() throws TransformerConfigurationException, TransformerException {		

		AppConstants.notRunCount = 	Integer.parseInt(propsRW.read(AppConstants.TOTAL_VERIFICATION_POINTS).trim())-AppConstants.passCount-AppConstants.failCount;		

		//log header report counts in XML file
		generateXML.logHeaderReportCounts();

		//Generate html report using xml created in test method
		//Report should be according to test case name, ex: login.html
		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH+AppConstants.DETAILED_REPORT_XSL;
		String outputHTML = AppConstants.DETAIL_REPORT_FOLDER+AppConstants.FORWARD_SLASH+AppConstants.LOGIN+AppConstants.DOT_HTML;
		generateReport.generateHTML(AppConstants.XML_FILE_PATH, inputXSL, outputHTML);


		System.out.println("Successfully generated the report");

		//log script in summary report xml file
		generateXML.logScript(AppConstants.LOGIN_SCRIPT_NAME, outputHTML);


		//Reset xml & properties files path to ""
		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;
		
		//Set pass, fail and notrun count to zero
		AppConstants.passCount= 0;
		AppConstants.failCount = 0;
		AppConstants.notRunCount = 0;

		//Quit the driver
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!AppConstants.BLANK_STRING.equals(verificationErrorString)) {
			fail(verificationErrorString);
		}

	}


}
