/**
 * 
 */
package ocpe.aut.fwk.testScripts;

import static org.junit.Assert.fail;

import java.io.File;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;

import ocpe.aut.fwk.constants.APITabConstants;
import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.constants.SocialConstants;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.GenerateHTML;
import ocpe.aut.fwk.util.GenerateXml;
import ocpe.aut.fwk.util.HBaseUtil;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;

import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * @author Abhishek_Amarnath
 *
 */
public class Social {

	private static StringBuffer verificationErrors = new StringBuffer();

	private static WebDriver driver;
	static DesiredCapabilities cap = null; static FirefoxBinary ffBinary = null; static FirefoxProfile ffprofile = null;

	private static GenerateXml generateXML;
	private static GenerateHTML generateReport;

	static int pass= 0,fail = 0, notRun = 0;

	private static PropertiesUtil propsRW;
	//private static ExcelUtil excelRW;
	private static String pageName;
	private static HBaseUtil hbaseUtil;

	/**
	 * One time set up for Social.java
	 */
	@BeforeClass
	public static void oneTimeSetUp() {
		// one-time initialization code   
		System.out.println("@BeforeClass - oneTimeSetUp");
		File pathToFirefoxBinary = new File(AppConstants.PATH_TO_FIREFOX_BINARY);
		ffBinary = new FirefoxBinary(pathToFirefoxBinary);
		ProfilesIni profile = new ProfilesIni();		   		   
		ffprofile = profile.getProfile(AppConstants.FIREFOX_PROFILE_DEFAULT);
		org.openqa.selenium.Proxy proxy = new org.openqa.selenium.Proxy();		  		  
		proxy.setProxyAutoconfigUrl(AppConstants.PROXY_URL);	
		cap = new DesiredCapabilities();		  
		cap.setCapability(CapabilityType.PROXY, proxy);				

		driver = new FirefoxDriver(ffBinary,ffprofile,cap);		
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get(AppConstants.BASE_URL + AppConstants.LOGIN_URL);

		generateXML = new GenerateXml();		
		generateReport = new GenerateHTML();		
		//excelRW = new ExcelUtil(); 
		hbaseUtil= new HBaseUtil();

		//Change the xml file path according to name of the script
		AppConstants.XML_FILE_PATH = AppConstants.XML_FOLDER+AppConstants.FORWARD_SLASH+SocialConstants.SOCIAL+AppConstants.DOT_XML;
		AppConstants.PROPERTIES_FILE_PATH = SocialConstants.SOCIAL_PROPERTIES;		

		//Sheet Name of excel from where the xpath values are fetched
		pageName = SocialConstants.SOCIAL_TAB;

		//Create a new XML file
		generateXML.createVPXML(SocialConstants.SOCIAL_SCRIPT_NAME);

		//Login
		/*Firefox browser gets opened with OCPE Login page, provide 
		 * with username rg@gmail.com and click on submit button.*/

		/*Clear the User Name textbox*/
		String xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE, AppConstants.USER_NAME);
		driver.findElement(By.xpath(xpathExpression)).clear();

		propsRW = new PropertiesUtil(AppConstants.LOGIN_PROPERTIES);

		/* Get valid username from properties file
		 * ex: rg@gmail.com*/
		String userName = propsRW.read(AppConstants.VALID_USERNAME).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(userName);


		/* Clear the Password textbox*/
		xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE, AppConstants.PASSWORD);
		driver.findElement(By.xpath(xpathExpression)).clear();

		/* Get valid password from properties file
		 * ex: Aham123+*/
		String password = propsRW.read(AppConstants.VALID_PASSWORD).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(password);


		/*Click on login button*/
		xpathExpression = ExcelUtil.readProps(AppConstants.LOGIN_PAGE, AppConstants.LOGIN_SUBMIT);		
		driver.findElement(By.xpath(xpathExpression)).click();

	}

	/**
	 * This method is invoked after all test methods in Social.java
	 * are executed
	 * @throws TransformerConfigurationException
	 * @throws TransformerException
	 */
	@AfterClass
	public static void tearDownAfterClass() throws TransformerConfigurationException, TransformerException {	

		propsRW=new PropertiesUtil(SocialConstants.SOCIAL_PROPERTIES);


		AppConstants.notRunCount =   Integer.parseInt(propsRW.read(AppConstants.TOTAL_VERIFICATION_POINTS).trim())-AppConstants.passCount-AppConstants.failCount;                   

		//log header report counts in XML file
		generateXML.logHeaderReportCounts();


		//log header report counts in XML file
		//generateXML.logHeaderReportCounts(pass, fail, notRun);
		//Generate html report using xml created in test method
		//Report should be according to test case name, ex: data.html
		String inputXSL = AppConstants.RESOURCES_FOLDER_PATH+AppConstants.DETAILED_REPORT_XSL;
		String outputHTML = AppConstants.DETAIL_REPORT_FOLDER+AppConstants.FORWARD_SLASH+SocialConstants.SOCIAL+AppConstants.DOT_HTML;
		generateReport.generateHTML(AppConstants.XML_FILE_PATH, inputXSL, outputHTML);

		System.out.println("Successfully generated the report");

		//log script in summary report xml file
		//generateXML.logScript(AppConstants.CATALOG_SCRIPT_NAME, outputHTML,  pass, fail, notRun);
		generateXML.logScript(AppConstants.LOGIN_SCRIPT_NAME, outputHTML);

		//Reset xml & properties files path to ""	
		AppConstants.XML_FILE_PATH = AppConstants.BLANK_STRING;
		AppConstants.PROPERTIES_FILE_PATH = AppConstants.BLANK_STRING;

		//Set pass, fail and notrun count to zero
		AppConstants.passCount= 0;
		AppConstants.failCount = 0;
		AppConstants.notRunCount = 0;

		//Close the browser
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	/**
	 * This method is used to verify if user is able to navigate to Social tab after login
	 * Test method
	 * @throws Exception
	 */
	@Test
	public void test_1_A() throws InterruptedException
	{

		Thread.sleep(3000);

		////verify if user is able to navigate to social tab

		driver.findElement(By.linkText(SocialConstants.SOCIAL_TAB_NAME)).click();
		String xpathExpression = ExcelUtil.readProps(pageName, SocialConstants.TAB_SOCIAL);
		String selectedTab  = driver.findElement(By.xpath(xpathExpression)).getText();
		System.out.println("************"+selectedTab);

		if(selectedTab.equals(SocialConstants.SOCIAL_TAB_NAME) ) {
			generateXML.logVP("1", "Check if user is able to navigate to social tab after login","user logs in successfully and navigates to social tab", AppConstants.vPass);				
			pass++;
		} else {
			generateXML.logVP("1", "Check if user is able to navigate to social tab after login","user logs in successfully and unable to navigates to social tab", AppConstants.vFail);		
			fail++;
		}		

	}

	/**
	 * This method is used to verify the UI of social tab
	 * Test method
	 * @throws Exception
	 */

	@Test
	public void test_2_A() throws InterruptedException
	{

		Thread.sleep(3000);

		propsRW = new PropertiesUtil(SocialConstants.SOCIAL_PROPERTIES);

		//verify search section is available or not

		String xpathExpression = ExcelUtil.readProps(pageName, SocialConstants.SEARCHSECTION_TITLE);

		String title= driver.findElement(By.xpath(xpathExpression)).getText();

		if(title.toLowerCase().contains(propsRW.read(SocialConstants.TITLE).toLowerCase()))
		{
			generateXML.logVP("2.1", "Check if search section exists with title containing 'Search by' ",	"search section exists with title containing 'Search by' ", AppConstants.vPass);				
			pass++;
		}

		else
		{
			generateXML.logVP("2.1", "Check if search section exists with title title containing 'Search by' ",	"search section doesnot exist with title containing 'Search by' ", AppConstants.vFail);				
			fail++;
		}

		//verify side menu items as whether it contains facebook association or not

		String leftMenuItem1= driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.LEFTMENUITEM_1))).getText();

		if(leftMenuItem1.equalsIgnoreCase(propsRW.read(SocialConstants.LEFTMENUITEM_1)))
		{
			generateXML.logVP("2.2", "verify if sidemenu items present","sidemenu contains facebook association", AppConstants.vPass);				
			pass++;
		}

		else
		{
			generateXML.logVP("2.2", "verify if sidemenu items present","sidemenu does not contains facebook association", AppConstants.vFail);				
			fail++;
		}



		//verify if facebook association side menu is highlighted or not

		String xpathExpression1 = ExcelUtil.readProps(pageName, SocialConstants.MENU_DEFAULT);
		String selectedMenu  = driver.findElement(By.xpath(xpathExpression1)).getText();

		if(selectedMenu.equals(propsRW.read(SocialConstants.LEFTMENUITEM_1)) ) {
			generateXML.logVP("2.3", "verify if facebook association left menu is highlighted by default or not",	"facebook association left menu is highlighted by default", AppConstants.vPass);				
			pass++;
		} else {
			generateXML.logVP("2.3", "verify if facebook association left menu is highlighted by default or not",	"facebook association left menu is not highlighted by default", AppConstants.vFail);		
			fail++;
		}


		//verify if side menu items are hyper links

		String tagName1=driver.findElement(By.name((SocialConstants.FACEBOOKASSOCIATION))).getTagName();

		if(tagName1.equalsIgnoreCase(SocialConstants.ANCHOR_TAG))
		{
			generateXML.logVP("2.4", "verify if sidemenu items are hyperlinks","sidemenu items are hyperlinks", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("2.4", "verify if sidemenu items are hyperlinks","sidemenu items are not hyperlinks", AppConstants.vFail);				
			fail++;
		}

		//verify if orange color slide is shown on click of the side menu items

		List<WebElement> elements=driver.findElements((By.xpath(ExcelUtil.readProps(pageName, SocialConstants.SLIDECOLOR))));
		int count=0;
		for(int i=0;i<elements.size();i++)
		{
			elements.get(i).click();
			String classArray[]=elements.get(i).getAttribute("class").split(" ");
			for(String classElement:classArray){
				if(classElement.equalsIgnoreCase(SocialConstants.SLIDECOLORCLASS)){
					count++;
					//System.out.println("count = "+count);
				}
			}
			//			if(count==3)break;
		}

		if(count==elements.size())
		{
			generateXML.logVP("2.5", "verify if on click sidemenu items are highlighted in grey with an orange slide next to it","on click side menu items are highlighted in grey with an orange slide next to it", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("2.5", "verify if on click sidemenu items are highlighted in grey with an orange slide next to it","on click side menu items are not highlighted in grey with an orange slide next to it", AppConstants.vFail);				
			fail++;
		}
	}

	/**
	 * This method is used to verify the UI of Facebook Association screen
	 * Test method
	 * @throws Exception
	 */

	@Test
	public void test_3_A() throws InterruptedException
	{

		Thread.sleep(3000);
		propsRW = new PropertiesUtil(SocialConstants.SOCIAL_PROPERTIES);
		//verify search section title
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.LEFTMENUITEM_1))).click();

		String xpathExpression = ExcelUtil.readProps(pageName, SocialConstants.SEARCHSECTION_TITLE);
		String title= driver.findElement(By.xpath(xpathExpression)).getText();

		WebElement searchTitlecss=driver.findElement(By.cssSelector(ExcelUtil.readProps(pageName, SocialConstants.SEARCHTITLECLASS)));
		String fontColor=searchTitlecss.getCssValue(ExcelUtil.readProps(pageName, SocialConstants.COLOR)); //verify font color
		//System.out.println("font color********"+fontColor+"**********");
		String fontWeight=searchTitlecss.getCssValue(ExcelUtil.readProps(pageName, SocialConstants.FONT_WEIGHT));
		//System.out.println("fontWeight********"+fontWeight+"**********");

		if(title.trim().equalsIgnoreCase((propsRW.read(SocialConstants.SEARCH_KEYWORD_TITLE)).trim()))
		{
			generateXML.logVP("3.1", "Check if search section exists with title 'Search by Keyword' title",	"search section exists with title 'Search by Keyword' title", AppConstants.vPass);				
			pass++;
		}

		else
		{
			generateXML.logVP("3.1", "Check if search section exists with title 'Search by Keyword' title",	"search section doesnot exist with title 'Search by Keyword' title", AppConstants.vFail);				
			fail++;
		}

		if( fontColor.equalsIgnoreCase(propsRW.read(SocialConstants.BLACK_COLOR)) && (fontWeight.equalsIgnoreCase(propsRW.read(SocialConstants.BOLD_FONT_WEIGHT)) || (fontWeight.equalsIgnoreCase("bold"))))
		{
			generateXML.logVP("3.2", "Check if search section title 'Search by Keyword' is bold and black",	"search section title 'Search by Keyword' is bold and black", AppConstants.vPass);				
			pass++;
		}

		else
		{
			generateXML.logVP("3.2", "Check if search section title 'Search by Keyword' is bold and black",	"search section title 'Search by Keyword' is not bold and black", AppConstants.vFail);				
			fail++;
		}

		//verify search section elements
		//System.out.println("to chk search elements");
		Boolean result=false;
		WebElement keywordRadio = driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.KEYWORD_RADIO)));//verify Keyword Radio Button
		WebElement categoryRadio = driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.CATEGORY_RADIO))); //verify category radio button
		WebElement searchText = driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.SEARCH_TEXT_BOX))); //verify search text box
		WebElement goBtn = driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.GO_BUTTON))); //verify go button
		//System.out.println("**"+keywordRadio.getTagName()+ "**" +categoryRadio.getTagName());
		if(keywordRadio.getTagName().equalsIgnoreCase("input") && (categoryRadio.getTagName().equalsIgnoreCase("input"))
				&& searchText.getTagName().equalsIgnoreCase("input") && (goBtn.getTagName().equalsIgnoreCase("button"))){
			result = true;
		}

		if(result==true)
		{
			generateXML.logVP("3.3", "verify search section elements",	"search section consists of keyword & category radio buttons, text box and a go button next to it", AppConstants.vPass);				
			pass++;
		}

		else
		{
			generateXML.logVP("3.3", "verify search section elements",	"search section does not consists of keyword & category radio buttons,text box and a go button next to it", AppConstants.vFail);				
			fail++;
		}

		//verify category tree
		WebElement tree =driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.TREE_MENU))); //verify category tree
		//System.out.println("*"+tree.getSize() + " * "+tree.getText() + "*" + tree.getTagName());
		if(tree.getTagName().equalsIgnoreCase("ul")){
			generateXML.logVP("3.4", "verify category tree","category hierarchy is present in tree structure", AppConstants.vPass);				
			pass++;
		}else{
			generateXML.logVP("3.4", "verify category tree","category hierarchy tree is not present", AppConstants.vFail);				
			fail++;
		}
		
		//verify nodes of the category tree
		WebElement treeElement =driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.TREE_ELEMENT)));
		//System.out.println("*"+treeElement.getSize() + " * "+treeElement.getText() + "*" + treeElement.getTagName());
		String tagName1=treeElement.getTagName();

		if(tagName1.equalsIgnoreCase(SocialConstants.ANCHOR_TAG))
		{
			generateXML.logVP("3.5", "verify if nodes of category tree are hyperlink","nodes of category tree are hyperlink", AppConstants.vPass);				
			pass++;
		}
		else
		{
			generateXML.logVP("3.5", "verify if nodes of category tree are hyperlink","nodes of category tree are not hyperlink", AppConstants.vFail);				
			fail++;
		}
		
		String treeElementFontColor=treeElement.getCssValue(ExcelUtil.readProps(pageName, SocialConstants.COLOR)); //verify font color
		//System.out.println("font color********"+treeElementFontColor+"**********");
		if( treeElementFontColor.equalsIgnoreCase(propsRW.read(SocialConstants.NODE_COLOR)))
		{
			generateXML.logVP("3.6", "Check if nodes of category tree are black in color",	"nodes of category tree are black in color", AppConstants.vPass);				
			pass++;
		}

		else
		{
			generateXML.logVP("3.6", "Check if nodes of category tree are black in color",	"nodes of category tree are not black in color", AppConstants.vFail);				
			fail++;
		}
		
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.TREE_ELEMENT))).click();
		System.out.println("tree element clicked");
		
		String treeElementColorAfterClick=treeElement.getCssValue(ExcelUtil.readProps(pageName, SocialConstants.COLOR)); //verify font color after clicking
		System.out.println("font color after click********"+treeElementColorAfterClick+"**********");
		if( treeElementColorAfterClick.equalsIgnoreCase(propsRW.read(SocialConstants.GREEN_COLOR)))
		{
			generateXML.logVP("3.7", "Check if nodes of category tree are green in color after click",	"nodes of category tree are green in color after click", AppConstants.vPass);				
			pass++;
		}

		else
		{
			generateXML.logVP("3.7", "Check if nodes of category tree are green in color after click",	"nodes of category tree are not green in color after click", AppConstants.vFail);				
			fail++;
		}
	}

	/**
	 * This method is used to verify search functionality when a keyword is entered
	 * Test method
	 * @throws Exception
	 */
	
	@Test
	public void test_4_A() throws InterruptedException
	{
		Thread.sleep(3000);
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.LEFTMENUITEM_1))).click();
		//System.out.println("sidemenu clicked");
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.SEARCH_TEXT_BOX))).clear();

		driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.SEARCH_TEXT_BOX))).sendKeys(propsRW.read(SocialConstants.VALID_KEYWORD));
		driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.GO_BUTTON))).click();
		Boolean dataTableExists = false;
		//System.out.println("Go clicked");
		//verify the datatable page exists
		try {
			driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.FB_DATA_TABLE)));
			generateXML.logVP("4.1", "verify whether datatable exists",	"fb pages datatable exists", AppConstants.vPass);				
			pass++;
			dataTableExists = true;
		}
		catch (Exception e) {
			generateXML.logVP("4.1", "verify  whether datatable exists", "fb pages datatable does not exist", AppConstants.vFail);				
			fail++;
			dataTableExists = false;
		}

		if(dataTableExists){
			List<WebElement> columnNames=driver.findElements(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.FB_DATA_TABLE_COLUMNS)));
			// System.out.println("header columns count "+columnNames.size());
			int count=0;
			String colNames = new String();
			for(int i=0;i<columnNames.size();i=i+1){
				String columnName=columnNames.get(i).getText();
				colNames = colNames + columnName;
				count++;
			}
			if(count==4 && (colNames.contains("Facebook Page Name")) && (colNames.contains("Facebook Link"))
					&& (colNames.contains("Likes"))){
				generateXML.logVP("4.2", "verify the columns of datatable","datatable contains Facebook Page Name,Facebook Link and Likes columns", AppConstants.vPass);				
				pass++;
			}
			else{
				generateXML.logVP("4.2", "verify the columns of datatable", "datatable does not contain Facebook Page Name,Facebook Link and Likes columns", AppConstants.vFail);				
				fail++;
			}

			String divText=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.DATA_TABLE_NO_OF_ENTRIES))).getText(); // text saying 'showing  n/n records ' should be displayed.

			if(divText.toLowerCase().contains("showing") && (divText.toLowerCase().contains("entries")))
			{
				generateXML.logVP("4.3", "Verify whether the text saying 'showing  n/n records'","The text saying 'showing  n/n records' is present.", AppConstants.vPass);				
				pass++;
			}
			else
			{
				generateXML.logVP("4.3", "Verify whether the text saying 'showing  n/n records'", "The text saying 'showing  n/n records' is not present.", AppConstants.vFail);		
				fail++;
			}

			List<WebElement> paginationBtns = driver.findElements(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.DATA_TABLE_PAGINATION))); //verify whether pagination exists

			//int cnt=0;
			String paginationBtnNames = new String();
			for(int i=0;i<paginationBtns.size();i=i+1){
				String columnName=paginationBtns.get(i).getText();
				paginationBtnNames = paginationBtnNames + columnName;
				/*System.out.println("tag name = "+paginationBtns.get(i).getTagName());
				   if(paginationBtns.get(i).getTagName().equalsIgnoreCase("a")){
//					   /System.out.println("Success");
					   cnt++;
				   }*/
			}
			//System.out.println("paginationBtnNames : "+paginationBtnNames);
			//System.out.println("cnt = "+cnt);
			if((paginationBtnNames.contains("Previous")) && (paginationBtnNames.contains("Next")))
			{
				generateXML.logVP("4.4", "Verify whether the pagination exsits with Previous and Next buttons","Pagination with Previous and Next buttons is present.", AppConstants.vPass);				
				pass++;
			}
			else
			{
				generateXML.logVP("4.4", "Verify whether the pagination exsits with Previous and Next buttons", "Pagination with Previous and Next buttons is not present.", AppConstants.vFail);		
				fail++;
			}
			
			WebElement cancelBtn= driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.CANCEL_BTN))); // verify whether Cancel Btn is present
			WebElement saveBtn= driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.SAVE_BTN))); // verify whether Save Btn is present
			String cancel = cancelBtn.getText();
			String save = saveBtn.getText();
			System.out.println("colour : "+cancelBtn.getCssValue("color") + "bck grd color : "+cancelBtn.getCssValue("background-color") + "");
			System.out.println("colour : "+saveBtn.getCssValue("color") + "bck grd color : "+saveBtn.getCssValue("background-color") + "");
			if(cancel.equalsIgnoreCase(SocialConstants.CANCEL_TEXT) && save.equalsIgnoreCase(SocialConstants.SAVE_TEXT)
					&& cancelBtn.getCssValue(SocialConstants.COLOR).equalsIgnoreCase(propsRW.read(SocialConstants.ORANGE_TEXT_COLOR))
					&& saveBtn.getCssValue(SocialConstants.COLOR).equalsIgnoreCase(propsRW.read(SocialConstants.ORANGE_TEXT_COLOR))
					&& cancelBtn.getCssValue(SocialConstants.BACKGROUND_COLOR).equalsIgnoreCase(propsRW.read(SocialConstants.BLACK_BACKGROUND_COLOR))
					&& saveBtn.getCssValue(SocialConstants.BACKGROUND_COLOR).equalsIgnoreCase(propsRW.read(SocialConstants.BLACK_BACKGROUND_COLOR))){
				generateXML.logVP("4.5", "Verify whether Cancel and Save buttons are present in black background and orange text","Cancel and Save buttons are present in black background and orange text.", AppConstants.vPass);				
				pass++;
			}
			else
			{
				generateXML.logVP("4.5", "Verify whether Cancel and Save buttons are present in black background and orange text", "Cancel and Save buttons are not present in black background and orange text.", AppConstants.vFail);		
				fail++;
			}
		}
	}
	/**
	 * This method is used to verify search functionality with no keyword entered
	 * @throws Exception
	 */
	
	@Test
	public void test_5_A() throws InterruptedException
	{
		//verify search functionality when category radio button is selected and populating a list
		propsRW=new PropertiesUtil(SocialConstants.SOCIAL_PROPERTIES);
		try
		{
			Thread.sleep(3000);
			driver.findElement(By.linkText(SocialConstants.SOCIAL_TAB_NAME)).click();
			driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.TOOLING_TREEMENU))).click();
			WebElement categoryRadio = driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.CATEGORY_RADIO)));
			WebElement response = driver.findElement(By.xpath(ExcelUtil.readProps(pageName,
					SocialConstants.SEARCH_TEXT_BOX)));
			
			
			if(categoryRadio.isSelected()){
				
			
					generateXML.logVP("6", "verify search functionality when treemenu is clicked category gets auto selected",	"fetched valid response", AppConstants.vPass);				
					pass++;
				}

				else
				{
					generateXML.logVP("6", "verify search functionality when treemenu is clicked category gets auto selected",	"fetched invalid response", AppConstants.vFail);				
					fail++;
				}
			
			if(response.getAttribute("value").equals(propsRW.read(SocialConstants.INP_FIELD_TEXT_VALIDATE))){
				
				generateXML.logVP("7", "verify search functionality when treemenu is clicked input field gets populated",	"fetched valid response", AppConstants.vPass);				
				pass++;
			}else{
				generateXML.logVP("7", "verify search functionality when treemenu is clicked input field gets populated",	"fetched invalid response", AppConstants.vFail);				
				fail++;
			}
				
			WebElement result = driver.findElement(By.xpath(ExcelUtil.readProps(pageName,SocialConstants.TOOLING_RESULT)));
		
			if(result.getText().contains(propsRW.read(SocialConstants.TOOLING_VALID_RESULT))){
				
				generateXML.logVP("8", "verify search functionality when treemenu is clicked result on right",	"fetched valid response", AppConstants.vPass);				
				pass++;
			}else{
				generateXML.logVP("8", "verify search functionality when treemenu is clicked result on right",	"fetched invalid response", AppConstants.vFail);				
				fail++;
			}
			
			

		}
		catch(Exception e)
		{
		
			generateXML.logVP("6", "verify search functionality when treemenu is clicked", "alert is not displayed ", AppConstants.vFail);				
			fail++;
		}
		
	}
	
	/**
	 * This method is used to verify search functionality with no keyword entered
	 * @throws Exception
	 */
	
	@Test
	public void test_6_A() throws InterruptedException
	{
		//verify search functionality when keyword radio button is selected but no keywords entered and clicked on go button
		try
		{
			Thread.sleep(3000);
			driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.LEFTMENUITEM_1))).click();
			//System.out.println("sidemenu clicked");
			driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.SEARCH_TEXT_BOX))).clear();
			driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.GO_BUTTON))).click();

			String errorMessage=driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.ALERT))).getText();

			if(errorMessage.equalsIgnoreCase(propsRW.read(SocialConstants.ERRORMESSAGE_BLANK_KEYWORDS)))
			{
				generateXML.logVP("9", "verify search functionality when no keywords entered and clicked on go button",	"alert is displayed with message 'please enter keywords'", AppConstants.vPass);				
				pass++;
			}

			else
			{
				generateXML.logVP("9", "verify search functionality when no keywords entered and clicked on go button",	"alert is not displayed", AppConstants.vFail);				
				fail++;
			}

			driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.ALERTBUTTON))).click();

		}
		catch(Exception e)
		{
			generateXML.logVP("7", "verify search functionality when no keywords entered and clicked on go button", "alert is not displayed ", AppConstants.vFail);				
			fail++;
		}
		
	}
	
	/**
	 * This method is used to verify search functionality with no keyword entered
	 * @throws Exception
	 */
	
	@Test
	public void test_8_A() throws InterruptedException
	{
		//verify search functionality of cancel button
		propsRW=new PropertiesUtil(SocialConstants.SOCIAL_PROPERTIES);
		try
		{
			Thread.sleep(3000);
			driver.findElement(By.linkText(SocialConstants.SOCIAL_TAB_NAME)).click();
			driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.TOOLING_TREEMENU))).click();
			
			Thread.sleep(3000);
			driver.findElement(By.xpath(ExcelUtil.readProps(pageName, SocialConstants.CANCEL_BTN))).click();
			
			
			WebElement result = driver.findElement(By.xpath(ExcelUtil.readProps(pageName,SocialConstants.FACEBOOK_PAGE_RESULT_DIV)));
		
			if(result.getText().equals("")){
				
				generateXML.logVP("10", "verify social cancel button",	"fetched valid response", AppConstants.vPass);				
				pass++;
			}else{
				
				generateXML.logVP("10", "verify social cancel button",	"fetched invalid response", AppConstants.vFail);				
				fail++;
			}
			
			

		}
		catch(Exception e)
		{
		
			generateXML.logVP("6", "verify search functionality when treemenu is clicked", "alert is not displayed ", AppConstants.vFail);				
			fail++;
		}
		
	}
}
