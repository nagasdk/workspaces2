package ocpe.aut.fwk.practice;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;

import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class TestCase2 {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
   // baseUrl = "http://hydhtc100059d:8080/";
    baseUrl = "http://blrkec242018d:8181/";
    
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testCase2() throws Exception {
    driver.get(baseUrl + "/aham-console-web/login.jsp");
    driver.findElement(By.xpath("//input[@id='j_username']")).clear();
    driver.findElement(By.xpath("//input[@id='j_username']")).sendKeys("rg@gmail.com");
    driver.findElement(By.xpath("//input[@id='login-submit']")).click();
        
    Thread.sleep(2000);
    /// Working //////////////
   driver.findElement(By.cssSelector("a[name=\"activities\"] > b")).click();
   
   Thread.sleep(1000);
   
   WebElement weAnaltyics1 = driver.findElement(By.xpath("//div[@id='analytics1']"));
   WebElement weAnaltyics = driver.findElement(By.xpath("//*[@id='analytics1']//svg/g/g[5]/text"));
   System.out.println("weAnaltyics is "+weAnaltyics);
   
  /* String text = (((weAnaltyics1.findElement(By.tagName("svg"))).
   					   findElement(By.tagName("g"))).
   					   findElement(By.tagName("g"))).getText();    
    System.out.println("Text is "+text);*/
    
    
    //not working....
    /*WebElement we = driver.findElement(By.xpath("/html/body/div[1]/div[1]/div[3]/div[2]/div[3]/div[1]/div[2]/div[2]/div[1]/svg/g/g[1]/title"));  */
    List<WebElement> lstWe = ((weAnaltyics1.findElement(By.tagName("svg"))).findElement(By.tagName("g"))).findElements(By.tagName("g"));
   // List<WebElement> lstSubWe = new ArrayList<WebElement>();
    for (WebElement webElement : lstWe) {
    	//System.out.println("Text Elements are "+(webElement.findElement(By.tagName("title"))/*.get(0))*/.getText()));
    	//System.out.println("Text Elements are "+(webElement.findElement(By.tagName("text[last()]"))/*.get(0))*/.getText()));
    	System.out.println(webElement.getText());
    	
    	
    }
   
   /* String title = we.findElement(By.xpath("/svg/g/g[2]/title")).getText();
    System.out.println("Title = "+title);*/
    
    		
    System.out.println("Done...");
    // WebElement we =  driver.findElement(By.xpath("//[@id='analytics2']/svg/g/g[1]/title"));
    
    /////// Not working //////////////
    // String xpathexp = "//*[local-name()='svg'"+" "+"//*[@*[namespace-uri()='http://www.w3.org/2000/svg']]";
    //WebElement svg = we.findElement(By.xpath(xpathexp));   //we.findElement(By.xpath("//*[local-name()='svg']"));
    //System.out.println("title = "+text);
  //WebElement svg = we.findElement(By.xpath("//*[local-name()='svg' and namespace-uri()='http://www.w3.org/2000/svg']"));

  
    
    			
   // System.out.println("we is "+we.findElement(By.tagName("svg")));
    		//findElement(By.tagName("svg")).findElement(By.tagName("g")).findElement(By.tagName("title"));
    
    
    /*WebElement webElement = driver.findElement(By.id("analytics1")).    		
			findElement(By.tagName("svg")).findElement(By.tagName("g")).findElement(By.tagName("title"));
    System.out.println("webElement.getText() is "+webElement);
	if (webElement.getText().contentEquals("629,015")) {
		System.out.println("Pass");
	}*/
    
    
    //Catalog side menu, Product - Percentile Purchases chart
   /* driver.findElement(By.cssSelector("a[name=\"catalog\"] > b")).click();
    WebElement weAnaltyics1 = driver.findElement(By.xpath("//div[@id='chart']"));
    String text = ((((weAnaltyics1.findElement(By.tagName("svg"))).
    					   findElement(By.tagName("g"))).
    					   findElement(By.tagName("g"))).
    					   findElement(By.tagName("g"))).getText();    
     System.out.println("Text is "+text);*/
    
    
    //Catalog side menu, Product Channel View chart
     /*driver.findElement(By.cssSelector("a[name=\"catalog\"] > b")).click();
     WebElement weAnaltyics1 = driver.findElement(By.xpath("//div[@id='stackedHorizontalChartLegend']"));
     String text = ((weAnaltyics1.findElement(By.tagName("svg"))).
     					   findElement(By.tagName("g"))).getText();    
      System.out.println("Text is "+text);*/
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

 /* private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }*/
}
