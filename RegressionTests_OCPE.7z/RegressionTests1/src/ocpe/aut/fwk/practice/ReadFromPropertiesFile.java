package ocpe.aut.fwk.practice;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ReadFromPropertiesFile {

	private static String propertiesFilePath = "src/com/infy/messageBundle/login.properties";

	public static void main( String[] args )
	{
		Properties prop = new Properties();

		try {
			//load a properties file
			prop.load(new FileInputStream(propertiesFilePath));

			//get the property value and print it out
			System.out.println(prop.getProperty("txtValidUsername"));
			System.out.println(prop.getProperty("txtValidPassword"));
			System.out.println(prop.getProperty("txtInvalidUsername"));
			System.out.println(prop.getProperty("txtInvalidPassword"));

		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}
}
