package ocpe.aut.fwk.practice;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
 
import ocpe.aut.fwk.constants.AppConstants;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
 
public class CopyOfWriteXMLFile {

    public static void main(String[] args) throws Exception {

    	/*newXML();
    	
        DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
        Document document = documentBuilder.parse("D:/login.xml");
        Element root = document.getDocumentElement();

        // Root Element
        Element rootElement = document.getDocumentElement();
        Collection<Server> svr = new ArrayList<Server>();
        svr.add(new Server());

        for (Server i : svr) {
            // server elements
            Element vp = document.createElement("verificationPoint");
            rootElement.appendChild(vp);

            Element testCaseId = document.createElement("testCaseId");
            testCaseId.appendChild(document.createTextNode(i.getName()));
            vp.appendChild(testCaseId);

            Element port = document.createElement("VPName");
            port.appendChild(document.createTextNode(Integer.toString(i.getPort())));
            vp.appendChild(port);

            root.appendChild(vp);
        }

        DOMSource source = new DOMSource(document);

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        StreamResult result = new StreamResult("D:/login.xml");
        transformer.transform(source, result);*/
        
        fetchTagValue();
    }

    public static class Server {
        public String getName() { return "foo"; }
        public Integer getPort() { return 12345; }
    }
    
    public static void newXML() throws ParserConfigurationException, TransformerException {
    	DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
        
        Document document = documentBuilder.newDocument();
        Element rootElement = document.createElement("VerificationPoints");
        document.appendChild(rootElement);
       
        DOMSource source = new DOMSource(document);

        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        StreamResult result = new StreamResult("D:/login.xml");
        transformer.transform(source, result);
    }
    
    private static void fetchTagValue() throws ParserConfigurationException, SAXException, IOException {
    	DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.parse(new File("D:/login.xml"));
        Element rootElement = document.getDocumentElement();
       // String totalTCs = rootElement.getChildNodes().item(0).getChildNodes().item(0).getNodeValue();
   //     String totalTCs = getString(AppConstants.HEADER_ELE_TOTALTCS, rootElement);
        
        int size = document.getElementsByTagName(AppConstants.HEADER_ELE_TOTALTCS).getLength();
        System.out.println("TotalTCs = "+rootElement.getElementsByTagName("VPStatus").getLength());
        
        System.out.println(getString(AppConstants.HEADER_ELE_TOTALTCS, rootElement));
    }
    
    private static int getString(String tagName, Element element) {
    	
    	NodeList list = element.getElementsByTagName(tagName);
		int count = 0;
		for(int loopVar=0; loopVar<list.getLength();loopVar++) {
		//	System.out.println(list.item(loopVar).getTextContent());
			count += Integer.parseInt(list.item(loopVar).getTextContent().trim().toString());
		}		

		return count;
        /*NodeList list = element.getElementsByTagName(tagName);
        if (list != null && list.getLength() > 0) {
            NodeList subList = list.item(0).getChildNodes();

            if (subList != null && subList.getLength() > 0) {
                return subList.item(0).getNodeValue();
            }
        }

        return null;*/
    }

}
