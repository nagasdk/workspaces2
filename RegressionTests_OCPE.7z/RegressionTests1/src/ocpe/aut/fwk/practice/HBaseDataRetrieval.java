package ocpe.aut.fwk.practice;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.Get;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.filter.RegexStringComparator;
import org.apache.hadoop.hbase.filter.RowFilter;
import org.apache.hadoop.hbase.filter.CompareFilter.CompareOp;
import org.apache.hadoop.hbase.util.Bytes;

public class HBaseDataRetrieval {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			Configuration config = HBaseConfiguration.create();
			config.clear();
			config.set("hbase.zookeeper.quorum", "10.68.210.38");
			config.set("hbase.zookeeper.property.clientPort","2181");
			config.set("hbase.master", "10.68.210.38:60010");

//			config.set("hbase.zookeeper.quorum", "10.138.193.10");
//		config.set("hbase.zookeeper.property.clientPort","2181");
//			config.set("hbase.master", "10.138.193.10:60010");

			
			HBaseAdmin.checkHBaseAvailable(config);
			
			HTable table = new HTable(config, "USER_RECENT_ACTIVITY");

			Scan s = new Scan();
			s.addFamily(Bytes.toBytes("USER_ACTIVITY"));
			s.setMaxVersions();
			//s.setStartRow(Bytes.toBytes("12100024"));
			//s.setStopRow(Bytes.toBytes("12100042"));
			RegexStringComparator regexStringComparator = new RegexStringComparator(
					"^(?=[^A-Za-z]+$).*[0-9].*$");
			RowFilter rowFilter = new RowFilter(CompareOp.EQUAL,
					regexStringComparator);
			s.setFilter(rowFilter);
			ResultScanner rs =table.getScanner(s);
			Result r=null;
			BufferedWriter writer = null;
			String st1="";
			String st[]=null;
			String st3[]=null;
			String st2="";
			Date d=new Date();
			Long l=null;
			String s1="";
			String s2="";
	    	DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			
	    	DateFormat dateFormat1 = new SimpleDateFormat("HH:mm:ss");

			
			while((r=rs.next())!=null){
				String key=Bytes.toString(r.getRow());
				//System.out.println("ROW KEY"+key);
				List<KeyValue> list=r.list();
				for(KeyValue kv:list){
					
					
					if("ACTIVITYVALUE_BR".equals(Bytes.toString(kv.getQualifier())))
						
					{
						//System.out.println("timestamp"+kv.getTimestamp());
					   //System.out.println(Bytes.toString(kv.getValue()));
						st1=Bytes.toString(kv.getValue());
						
					   st=st1.split("#",9);
					   if(st[6]!=null&&!"".equals(st[6])){
							if(!(st[6].contains(";")||st[6].contains(")")||st[6].contains(",")||st[6].contains(".")||st[6].contains("-")||st[6].contains("/")||st[6].contains(" "))){
						st3=st[4].split("\\|");
						for(int i=0;i<st3.length;i++){
							l=kv.getTimestamp();
							d.setTime(l);
							s1=dateFormat.format(d);
							s2=dateFormat1.format(d);
						st2= key+","+"Orders"+","+ st[6]+","+st3[i]+","+s1+","+s2;
						}
							}else{
								st3=st[4].split("\\|");
								for(int i=0;i<st3.length;i++){
									l=kv.getTimestamp();
									d.setTime(l);
									s1=dateFormat.format(d);
									s2=dateFormat1.format(d);
								st2= key+","+"Browse"+","+ "0"+","+st3[i]+","+s1+","+s2;
								}
							}
						}else{
							st3=st[4].split("\\|");
							for(int i=0;i<st3.length;i++){
								l=kv.getTimestamp();
								d.setTime(l);
								s1=dateFormat.format(d);
								s2=dateFormat1.format(d);
							st2= key+","+"Browse"+","+ "0"+","+st3[i]+","+s1+","+s2;
							}
						}
					   System.out.println(st2);
					   
					    
//					        writer = new BufferedWriter(new FileWriter("D:\\infylabs\\1"));
//					        writer.write(st2);

					
					}
					
				}
			}
			}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
