package ocpe.aut.fwk.practice;


import java.util.List;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.KeyValue;
import org.apache.hadoop.hbase.client.HBaseAdmin;
import org.apache.hadoop.hbase.client.HTable;
import org.apache.hadoop.hbase.client.Result;
import org.apache.hadoop.hbase.client.ResultScanner;
import org.apache.hadoop.hbase.client.Scan;
import org.apache.hadoop.hbase.util.Bytes;

public class ActivitiesHBaseChartValues {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
	
		try {
			Configuration config = HBaseConfiguration.create();
			config.clear();
			config.set("hbase.zookeeper.quorum", "10.68.210.38");
			config.set("hbase.zookeeper.property.clientPort","2181");
			config.set("hbase.master", "10.68.210.38:60010");

//			config.set("hbase.zookeeper.quorum", "10.138.193.10");
//		config.set("hbase.zookeeper.property.clientPort","2181");
//			config.set("hbase.master", "10.138.193.10:60010");

			
			HBaseAdmin.checkHBaseAvailable(config);
			
			HTable table = new HTable(config, "AHAM_DASHBOARD");

			Scan s = new Scan();
			s.addFamily(Bytes.toBytes("DATA"));
			s.setMaxVersions(1); // set max version to 1 means scan for col family of latest timestamp

			ResultScanner rs =table.getScanner(s);
			Result r=null;
			
			while((r=rs.next())!=null){
				String key=Bytes.toString(r.getRow());
				//System.out.println("ROW KEY"+key);
			
				if("ACTIVITIES".equals(key)) {
					System.out.println("into sysout statement Pavs....."+ key);
				List<KeyValue> list=r.list();
				for(KeyValue kv:list){			
					
			
						System.out.println("into kv qualifier sysout ....."+ Bytes.toString(kv.getQualifier()));
					//	if("SEARCH".equals(Bytes.toString(kv.getQualifier()))) {
							System.out.println("into kv value sysout ....."+ Bytes.toString(kv.getValue()));
					//	}
						
					
					
				}
			}
				
			}
			}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
