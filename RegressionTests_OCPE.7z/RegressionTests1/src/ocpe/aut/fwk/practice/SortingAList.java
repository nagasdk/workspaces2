package ocpe.aut.fwk.practice;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class SortingAList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

			/* Create a sorted list with actual list */
			List<String> sortedList = new ArrayList<String>();
			sortedList.add("app");
			sortedList.add("boolean");
			sortedList.add("zookeeper");
		
			/**
			 * this is 1 way, see below for another way
			 */
			/* Check the sort order (whether it is ascending or desecending) and sort the
			 * list accordingly*/
			String sortOrder= "ascending";
			//String sortOrder= "descending";
			if(sortOrder.equals("ascending")) {
			Collections.sort(sortedList, new Comparator <String>() {
				
			    @Override
			    public int compare(String one, String two) {
			        return one.compareTo(two);
			    }
			});
			} else {
				Collections.sort(sortedList, new Comparator <String>() {
				    @Override
				    public int compare(String one, String two) {
				        return two.compareTo(one);
				    }
				});
			}
			
			for(String s : sortedList) {
				System.out.println(s);
			}
			
			/**
			 * this is another way
			 */
			/* Check the sort order (whether it is ascending or desecending) and sort the
			 * list accordingly*/
			if(sortOrder.equals(sortOrder.equals("ascending"))) {
				Collections.sort(sortedList);
			} else {
				// create comparator for reverse order i.e. descending order
				Comparator<String> comparator = Collections.reverseOrder(); 
				// sort the list
				Collections.sort(sortedList, comparator); 
			}

			for(String s : sortedList) {
				System.out.println(s);
			}
	}

}
