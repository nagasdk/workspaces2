package ocpe.aut.fwk.practice;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import ocpe.aut.fwk.util.LogXMLResult;
import ocpe.aut.fwk.util.CreateXML_Root;
 
public class JAXBExample {
	public static void main(String[] args) {
 
		LogXMLResult vpVO1 = new LogXMLResult();
	  vpVO1.setTestCaseId("1.3");
	  vpVO1.setVPName("Check if user with invalid Username and valid password is able to login or not");
	  vpVO1.setVPResult("User is not able to Login and a popup with error message 'User credentials were invalid.' is displayed");
	  vpVO1.setVPStatus("PASS");
	  
	  LogXMLResult vpVO2 = new LogXMLResult();
	  vpVO2.setTestCaseId("1.4");
	  vpVO2.setVPName("Check if user with valid Username and valid password is able to login or not");
	  vpVO2.setVPResult("User is able to Login successfully");
	  vpVO2.setVPStatus("PASS");
	  
	  List<LogXMLResult> listOfElements = new ArrayList<LogXMLResult>();
	  listOfElements.add(vpVO1);
	  listOfElements.add(vpVO2);
	  
	  CreateXML_Root rootVO = new CreateXML_Root();
/*	rootVO.setElementVO(listOfElements);*/  ///////////////////////////commented for time being
	  
 
	  try {
 
		File file = new File("src/ocpe/aut/fwk/resources/VerificationPoints.xml");
		JAXBContext jaxbContext = JAXBContext.newInstance(CreateXML_Root.class);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
 
		// output pretty printed
		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
 
		jaxbMarshaller.marshal(rootVO, file);
	//	jaxbMarshaller.marshal(rootVO, System.out);
 
	      } catch (JAXBException e) {
		e.printStackTrace();
	      }
 
	}
}