package ocpe.aut.fwk.practice;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class TestScriptUsingChrome{


	private WebDriver driver;
	private String baseUrl;
	private String loginUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	ExcelUtil readExcelSheetUtil;
	//Sleep interval in milliseconds, 2000 milliseconds, i.e. 2seconds
	int sleepInterval = 2000;
	
	
	@Before
	public void setUp() throws Exception {
		driver = new ChromeDriver();
		baseUrl = AppConstants.BASE_URL;
		loginUrl = AppConstants.LOGIN_URL;
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testValidUsernameAndPassword() throws Exception {
		
		driver.get(baseUrl + loginUrl);

		//Util class that reads the excel sheet
		readExcelSheetUtil = new ExcelUtil();


		//Sheet Name from where the values are fetched
		String pageName = AppConstants.LOGIN_PAGE;

		//key is the value present in column A of the sheet
		String cntrlName=AppConstants.USER_NAME;

		//xpathExpression is the value present in column B of the sheet for the above key
		/* Ex: */
		String xpathExpression = readExcelSheetUtil.readProps(pageName, cntrlName);

		
		//wait for 2 secs
		Thread.sleep(sleepInterval);


		driver.findElement(By.xpath(xpathExpression)).clear();
		
		//wait for 2 secs
		Thread.sleep(sleepInterval);
		
		//Read value from properties file
		PropertiesUtil readWritePropertiesFile = new PropertiesUtil("src/ocpe/aut/fwk/resources/login.properties");
		String propertyValue = readWritePropertiesFile.read(AppConstants.VALID_USERNAME).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(propertyValue);

		//wait for 2 secs
		Thread.sleep(sleepInterval);
		
		
		cntrlName=AppConstants.PASSWORD;
		xpathExpression = readExcelSheetUtil.readProps(pageName, cntrlName);
		driver.findElement(By.xpath(xpathExpression)).clear();
		
		//wait for 2 secs
		Thread.sleep(sleepInterval);
		
		//Read value from properties file
		propertyValue = readWritePropertiesFile.read(AppConstants.VALID_PASSWORD).trim();
		driver.findElement(By.xpath(xpathExpression)).sendKeys(propertyValue);

		//Read xpathExpression from Excel file
		cntrlName = AppConstants.LOGIN_SUBMIT;
		xpathExpression = readExcelSheetUtil.readProps(pageName, cntrlName);		
		driver.findElement(By.xpath(xpathExpression)).click();

		//wait for 2 secs
		Thread.sleep(sleepInterval);		
		
		
		//Read xpathExpression from Excel file
		xpathExpression = readExcelSheetUtil.readProps(pageName, AppConstants.WELCOME_MSG);		
		//Welcome message displayed on the page
		String welcomeMessage = driver.findElement(By.xpath(xpathExpression)).getText().trim();
		
		//welcome message defined in the login.properties file
		propertyValue = readWritePropertiesFile.read(AppConstants.WELCOME_MSG).trim();
		
			
		if(welcomeMessage.equals(propertyValue)) {
			System.out.println(AppConstants.vPass);
		} else {
			System.out.println(AppConstants.vFail);
		}
		
		//wait for 3 secs
		Thread.sleep(3000);	
	}

	
	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!AppConstants.BLANK_STRING.equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}	


}