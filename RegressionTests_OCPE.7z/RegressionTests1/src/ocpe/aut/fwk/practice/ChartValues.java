package ocpe.aut.fwk.practice;

//imported classes
import static org.junit.Assert.fail;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;

import com.thoughtworks.selenium.DefaultSelenium;

public class ChartValues {
	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();

	@Before
	public void setUp() throws Exception {
		//FirefoxProfile profile = new FirefoxProfile();
		//profile.setPreference("webdriver.log.file", "/PavsTmp/firefox_console"); 
		driver = new FirefoxDriver();
		//Base URL
		baseUrl = "http://blrkec241952d:8282/";    
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		
	}

	@Test
	public void testCase(WebDriver driver) throws Exception {

		//Login
		/*Firefox browser gets opened with OCPE Login page, provide 
		 * with username rg@gmail.com and click on submit button.
		 * After login, Data tab selected with it's first side menu highlighted */
		/*this.driver = driver;
		baseUrl = "http://blrkec241952d:8282/";    
		driver.get(baseUrl + "/aham-console-web/login.jsp");
		driver.findElement(By.xpath("//input[@id='j_username']")).clear();
		driver.findElement(By.xpath("//input[@id='j_username']")).sendKeys("rg@gmail.com");
		driver.findElement(By.xpath("//input[@id='login-submit']")).click();  */

		//wait for 4 secs
		Thread.sleep(4000);

		//Click on Catalog side menu of Data tab
		driver.findElement(By.cssSelector("a[name=\"catalog\"] > b")).click();

		//Catalog side menu, Product Channel View chart     --- Stacked horizontal Bar Chart
		WebElement stackedHorizonLegend = driver.findElement(By.xpath("//div[@id='stackedHorizontalChartLegend']"));
		String stackedHorizonLegendText = ((stackedHorizonLegend.findElement(By.tagName("svg"))).
				findElement(By.tagName("g"))).getText();    
		System.out.println("stackedHorizonLegendText is "+stackedHorizonLegendText+"\n");

		

		//Catalog side menu, Product - Percentile Purchases chart   -- Area Chart
		//Legend orange value
		WebElement areaChartLegend = driver.findElement(By.xpath("//div[@id='areaChartLegend']"));
		String areaChartLegendText = ((areaChartLegend.findElement(By.tagName("svg"))).
				findElement(By.tagName("g"))).getText();  		
		System.out.println("------"+areaChartLegendText+"---------");
		
		WebElement chart = driver.findElement(By.xpath("//div[@id='chart']"));		
		//No.of Activities -- Orange colored graph
		List<WebElement> lstofActivities = ((chart.findElement(By.tagName("svg"))).findElements(By.tagName("circle")));
		for (WebElement webElement : lstofActivities) {		    	
			System.out.println("Orange values = "+webElement.getText());		    	
		}
		
		//One line gap
		System.out.println("\n");
		
		//Legend green value
		WebElement areaChartLegend1 = driver.findElement(By.xpath("//div[@id='areaChartLegend']"));
		String areaChartLegendText1 = ((areaChartLegend1.findElement(By.tagName("svg"))).
				findElements(By.tagName("g"))).get(1).getText();  		
		System.out.println("------"+areaChartLegendText1+"---------");

		//No.of Purchases -- Green colored graph		
		List<WebElement> lstChart = ((chart.findElement(By.tagName("svg"))).findElements(By.tagName("rect")));
		for (WebElement webElement : lstChart) {		    	
			System.out.println("Green values = "+webElement.getText());		    	
		}


		/*String chartValue = ((((chart.findElement(By.tagName("svg"))).
				findElement(By.tagName("g"))).
				findElement(By.tagName("g"))).
				findElement(By.tagName("g"))).getText();    
		System.out.println("Text is "+chartValue+"\n");*/

		//One line gap
		System.out.println("\n");

		//wait for 4 secs
		Thread.sleep(4000);


		//Click on Activities side menu of Data tab
		driver.findElement(By.cssSelector("a[name=\"activities\"] > b")).click();

		//Activities side menu, Activity Distribution: By Activity Type    -- Pie Chart
		WebElement weAnaltyics1 = driver.findElement(By.xpath("//div[@id='analytics1']"));

		//Values of all sectors in pie chart
		List<WebElement> lstWe = ((weAnaltyics1.findElement(By.tagName("svg"))).findElement(By.tagName("g"))).findElements(By.tagName("g"));
		for (WebElement webElement : lstWe) {		    	
			System.out.println(webElement.getText());		    	
		}

		//Value of a single sector in pie chart
		/*String text = (((weAnaltyics1.findElement(By.tagName("svg"))).
				findElement(By.tagName("g"))).
				findElement(By.tagName("g"))).getText();    
		System.out.println("Text is "+text);*/

		//wait for 4 secs
		Thread.sleep(4000);
		
		
	}


	@After
	public void tearDown() throws Exception {
		//Close the browser
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}


}
