package ocpe.aut.fwk.practice;

import java.io.File;
import java.io.FileInputStream;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


public class ReadFromExcel {

	public static void main(String[] args) 
	{
		try
		{
			FileInputStream file = new FileInputStream(new File("D:\\xpathExpressions.xlsx"));

			//Create Workbook instance holding reference to .xlsx file
			XSSFWorkbook workbook = new XSSFWorkbook(file);

			//Get first/desired sheet from the workbook
			XSSFSheet sheet = workbook.getSheet("LoginPage");

			/*//Iterate through each rows one by one
			Iterator<Row> rowIterator = sheet.iterator();
			while (rowIterator.hasNext()) 
			{
				Row row = rowIterator.next();
				//For each row, iterate through all the columns
				Iterator<Cell> cellIterator = row.cellIterator();
				
				while (cellIterator.hasNext()) 
				{
					Cell cell = cellIterator.next();
					//Check the cell type and format accordingly
					switch (cell.getCellType()) 
					{
						case Cell.CELL_TYPE_NUMERIC:
							System.out.print(cell.getNumericCellValue() + "\t");
							break;
						case Cell.CELL_TYPE_STRING:
							System.out.print(cell.getStringCellValue() + "\t");
							break;
					}
				}
				System.out.println("");
			}*/
			
			/* Fetch the row number which contains the key */
			int rowNumber = 0;			
			for (Row row : sheet) {
		        for (Cell cell : row) {
		            if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
		                if (cell.getRichStringCellValue().getString().trim().equals("username")) {
		                	rowNumber = row.getRowNum();  
		                	break;
		                }
		            }
		        }
		    } 
			
			/* Get the row, it's 2nd column value */
			XSSFRow row = sheet.getRow(rowNumber);
			XSSFCell cell = row.getCell(1);
			String value = cell.getStringCellValue().trim().toString();	
			System.out.println(value);
		    
			file.close();
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
	}
}

