package ocpe.aut.fwk.practice;

import java.io.File;

public class CreateDirectory {

	public static void main(String args[])
	{ 
		//String path = System.getProperty("user.home");
		String reportsDirectory = "D:\\Reports";
		System.out.println("Path is "+reportsDirectory);
		File dir=new File(reportsDirectory+"/Detailed Reports");
		if(dir.exists()){
			System.out.println("A folder with name 'new folder' is already exist in the path "+reportsDirectory);
		}else{
			System.out.println("folder created");
			dir.mkdir();
		}		

			boolean deleted=false;
			String folderPath = "D:\\Reports"+"/test";
			File directory = new File(folderPath);		

			/*If the directory (i.i. folder) already exists, no need to create a new directory (i.e. folder)
			 * otherwise a new directory (i.e. folder) is created
			 * */
			if(directory.exists()){
				deleted = directory.delete();
				System.out.println("Directory "+folderPath+" deleted "+deleted);
			}else{
				System.out.println("If directory does not exists, then no need of delete");
			}
			
		}
		

}

