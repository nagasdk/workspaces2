package ocpe.aut.fwk.practice;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import ocpe.aut.fwk.util.ExcelUtil;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class InvalidUsername {
	private WebDriver driver;
	private String baseUrl;
	private StringBuffer verificationErrors = new StringBuffer();
	ExcelUtil readExcelSheetUtil;
	@Before
	public void setUp() throws Exception {
		driver = new FirefoxDriver();
		baseUrl = "http://blrkec241952d:8282/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Test
	public void testInvalidUsername() throws Exception {
		driver.get(baseUrl + "/aham-console-web/login.jsp");

		//Util class that reads the excel sheet
		readExcelSheetUtil = new ExcelUtil();

		//Excel sheet workbook absolute path
		String workBookPath = "D:\\xpathExpressions.xlsx";

		//Sheet Name from where the values are fetched
		String sheetName = "LoginPage";

		//key is the value present in column A of the sheet
		String key="username";

		//xpathExpression is the value present in column B of the sheet for the above key
		/* Ex: */
		String xpathExpression = readExcelSheetUtil.readProps(sheetName, key);

		driver.findElement(By.xpath(xpathExpression)).clear();
		driver.findElement(By.xpath(xpathExpression)).sendKeys("rg1@gmail.com");
		
        key="loginSubmit";
		xpathExpression = readExcelSheetUtil.readProps(sheetName, key);
		driver.findElement(By.xpath(xpathExpression)).click();


		key="errorMessage";
		xpathExpression = readExcelSheetUtil.readProps(sheetName, key);
		String errMsg = driver.findElement(By.xpath(xpathExpression)).getText();
		
		System.out.println("errMsg is "+errMsg);
		
		
		key="okBtn";
		xpathExpression = readExcelSheetUtil.readProps(sheetName, key);
		driver.findElement(By.linkText("OK")).click();
		
			
		//wait for 10 secs
		Thread.sleep(5000);


		key="username";
		xpathExpression = readExcelSheetUtil.readProps(sheetName, key);
		driver.findElement(By.xpath(xpathExpression)).clear();
		//wait for 5 secs
		Thread.sleep(5000);
		driver.findElement(By.xpath(xpathExpression)).sendKeys("rg@gmail.com");

		//wait for 5 secs
		Thread.sleep(5000);
		key="password";
		xpathExpression = readExcelSheetUtil.readProps(sheetName, key);
		driver.findElement(By.xpath(xpathExpression)).clear();
		//wait for 5 secs
		Thread.sleep(5000);
		driver.findElement(By.xpath(xpathExpression)).sendKeys("trewr");

		key="loginSubmit";
		xpathExpression = readExcelSheetUtil.readProps(sheetName, key);
		driver.findElement(By.xpath(xpathExpression)).click();

		if (isAlertPresent()) {
			Alert alert = driver.switchTo().alert();
			//dismiss the alert
			alert.accept();
		}

	}

	/*@Test
  public void testInvalidPassword() throws Exception {
    driver.get(baseUrl + "/aham-console-web/login.jsp?error=true");
    driver.findElement(By.xpath("//input[@id='j_username']")).clear();
    driver.findElement(By.xpath("//input[@id='j_username']")).sendKeys("rg@gmail.com");

    driver.findElement(By.xpath("//input[@id='j_password']")).clear();
    driver.findElement(By.xpath("//input[@id='j_password']")).sendKeys("trewr");
    driver.findElement(By.xpath("//input[@id='login-submit']")).click();

    //wait for 5 secs
  	Thread.sleep(5000);
  }*/

	@After
	public void tearDown() throws Exception {
		driver.quit();
		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	private boolean isAlertPresent() {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

}
