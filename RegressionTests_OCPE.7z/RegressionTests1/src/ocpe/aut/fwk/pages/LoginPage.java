/**
 * 
 */
package ocpe.aut.fwk.pages;

import static org.junit.Assert.assertTrue;
import static ocpe.aut.fwk.constants.AppConstants.*;
import ocpe.aut.fwk.util.ExcelUtil;
import ocpe.aut.fwk.util.PropertiesUtil;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.LoadableComponent;

/**
 * @author arindam_r
 * 
 */
public class LoginPage extends LoadableComponent<LoginPage> {

	private final WebDriver driver;

	private WebElement userNameElement;

	private WebElement passwordElement;

	private WebElement loginBtnElement;

	private WebElement forgotPwdLnkElement;

	private WebElement captchaElement;

	private int loginCount = 1;

	private static String pageName = LOGIN_PAGE;
	
	private long sleepInterval = 1000;

	private PropertiesUtil propertiesUtil;

	public LoginPage(WebDriver driver) {
		this.driver = driver;
		propertiesUtil = new PropertiesUtil(LOGIN_PROPERTIES);
	}

	@Override
	protected void isLoaded() throws Error {
		String url = driver.getCurrentUrl();
		assertTrue("Not on the login page: " + url, url.endsWith("login.jsp"));
	}

	@Override
	protected void load() {
		driver.get(BASE_URL + LOGIN_URL);
		initElements();
	}

	private LoginPage reinitializePageElements() {
		initElements();
		return this;
	}

	private void initElements() {
		userNameElement = driver.findElement(By.xpath(ExcelUtil.readProps(
				pageName, USER_NAME)));
		passwordElement = driver.findElement(By.xpath(ExcelUtil.readProps(
				pageName, PASSWORD)));
		loginBtnElement = driver.findElement(By.xpath(ExcelUtil.readProps(
				pageName, LOGIN_SUBMIT)));
		forgotPwdLnkElement = driver.findElement(By.xpath(ExcelUtil.readProps(
				pageName, FORGOT_PASSWORD_LINK)));
	}

	private void initCaptcha() {
		if (loginCount > 2) {
			captchaElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, USER_NAME)));
		}
		loginCount++;
	}
	
	private void sleep(){
		try {
			Thread.sleep(sleepInterval);
		} catch (InterruptedException e) {
			throw new RuntimeException(e);
		}
	}

	public LoginPage typeUserName(String userName) {
		userNameElement.clear();
		userNameElement.sendKeys(userName);
		return this;
	}

	public LoginPage typePassword(String password) {
		passwordElement.clear();
		passwordElement.sendKeys(password);
		return this;
	}

	public boolean captchaAppeared() {
		return captchaElement != null;
	}

	public LoginPage typeCaptcha(String captcha) {
		captchaElement.clear();
		captchaElement.sendKeys(captcha);
		return this;
	}

	public HomePage loginExpectingSuccess() {
		loginBtnElement.click();
		sleep();
		return new HomePage(driver, this).get();
	}

	public ErrorMessageDiv loginExpectingFailure() {
		loginBtnElement.click();
		sleep();
		initCaptcha();
		return new ErrorMessageDiv(driver);
	}

	public LoginPage loginVerficationFailure() {
		loginBtnElement.click();
		sleep();
		return this;
	}

	public String getUserNameCss(String property) {
		return userNameElement.getCssValue(property);
	}

	public String getPasswordCss(String property) {
		return passwordElement.getCssValue(property);
	}

	public ForgotPasswordDiv forgotPassword() {
		forgotPwdLnkElement.click();
		sleep();
		return new ForgotPasswordDiv(driver);
	}

	public class ErrorMessageDiv {

		private final WebDriver driver;

		private WebElement messageElement, okBtnElement;

		private ErrorMessageDiv(WebDriver driver) {
			this.driver = driver;
			messageElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, ERROR_MESSAGE)));
			okBtnElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, OK_BTN)));
		}

		public String readErrorMessage() {
			return messageElement.getText();
		}

		public LoginPage clickOKButton() {
			okBtnElement.click();
			sleep();
			return LoginPage.this.reinitializePageElements();
		}
	}

	public class ForgotPasswordDiv {

		private final WebDriver driver;

		private WebElement firstNameElement, lastNameElement, emailElement,
				captchaElement, submitButtonElement, cancelButtonElement,
				closeButtonElement;

		private ForgotPasswordDiv(WebDriver webDriver) {
			this.driver = webDriver;
			initElements();
		}

		private void initElements() {
			firstNameElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, FIRST_NAME)));
			lastNameElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, LAST_NAME)));
			emailElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, EMAIL)));
			captchaElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, CAPTCHA)));
			submitButtonElement = driver.findElement(By.xpath(ExcelUtil
					.readProps(pageName, FP_SUBMIT)));
			cancelButtonElement = driver.findElement(By.xpath(ExcelUtil
					.readProps(pageName, FP_CANCEL)));
			closeButtonElement = driver.findElement(By.xpath(ExcelUtil
					.readProps(pageName, FP_CLOSE)));
		}

		public boolean elementsInitialized() {
			if (firstNameElement != null && lastNameElement != null
					&& emailElement != null && this.captchaElement != null
					&& submitButtonElement != null
					&& cancelButtonElement != null
					&& closeButtonElement != null) {
				return true;
			}
			return false;
		}

		private ForgotPasswordDiv reInitializeDivElements() {
			initElements();
			return this;
		}

		public ForgotPasswordDiv typeFirstName(String firstName) {
			firstNameElement.sendKeys(firstName);
			return this;
		}

		public ForgotPasswordDiv typeLastName(String lastName) {
			lastNameElement.sendKeys(lastName);
			return this;
		}

		public ForgotPasswordDiv typeEmail(String email) {
			emailElement.sendKeys(email);
			return this;
		}

		public ForgotPasswordDiv typeCaptcha(String captcha) {
			captchaElement.sendKeys(captcha);
			return this;
		}

		public FPErrorMessageDiv clickSubmitButton() {
			submitButtonElement.click();
			sleep();
			return new FPErrorMessageDiv(driver);
		}

		public LoginPage clickCancelButton() {
			cancelButtonElement.click();
			sleep();
			return LoginPage.this.reinitializePageElements();
		}

		public LoginPage clickCloseButton() {
			closeButtonElement.click();
			sleep();
			return LoginPage.this.reinitializePageElements();
		}

		public class FPErrorMessageDiv {

			private final WebDriver driver;

			private WebElement messageElement, okBtnElement;

			public FPErrorMessageDiv(WebDriver driver) {
				this.driver = driver;
				initElements();
			}

			private void initElements() {
				messageElement = driver.findElement(By.xpath(ExcelUtil
						.readProps(pageName, FP_ERR_MSG)));
				okBtnElement = driver.findElement(By.xpath(ExcelUtil.readProps(
						pageName, FP_OK_BTN)));
			}

			public String readErrorMessage() {
				return messageElement.getText();
			}

			public ForgotPasswordDiv clickOKButton() {
				okBtnElement.click();
				sleep();
				return ForgotPasswordDiv.this.reInitializeDivElements();
			}
		}
	}

	public void performLogin() {
		this.typeUserName(propertiesUtil.read(VALID_USERNAME)).typePassword(
				propertiesUtil.read(VALID_PASSWORD));
		loginBtnElement.click();
		sleep();
	}
}
