/**
 * 
 */
package ocpe.aut.fwk.pages;

import static org.junit.Assert.assertTrue;
import ocpe.aut.fwk.constants.AppConstants;
import ocpe.aut.fwk.util.ExcelUtil;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.LoadableComponent;

/**
 * @author arindam_r
 * 
 */
public class HomePage extends LoadableComponent<HomePage> {

	private final WebDriver driver;
	private final LoadableComponent<?> parent;

	private static String pageName = AppConstants.LOGIN_PAGE;

	private WebElement welcomeMessageElement, changePasswordElement,
			updateProfileElement, logoutElement;

	public HomePage(WebDriver driver, LoadableComponent<?> parent) {
		this.driver = driver;
		this.parent = parent;
		initElements();
	}

	@Override
	protected void isLoaded() throws Error {
		String url = driver.getCurrentUrl();
		assertTrue("Not on the home page: " + url, url.contains("/index.html"));
	}

	@Override
	protected void load() {
		parent.get();
		((LoginPage) parent).performLogin();
		driver.get(AppConstants.BASE_URL + AppConstants.HOME_URL);
		initElements();
	}

	private void initElements() {
		welcomeMessageElement = driver.findElement(By.xpath(ExcelUtil
				.readProps(pageName, AppConstants.WELCOME_MSG)));
		changePasswordElement = driver.findElement(By.xpath(ExcelUtil
				.readProps(pageName, AppConstants.CHANGE_PWD)));
		updateProfileElement = driver.findElement(By.xpath(ExcelUtil.readProps(
				pageName, AppConstants.UPDATE_PROFILE)));
		logoutElement = driver.findElement(By.xpath(ExcelUtil.readProps(
				pageName, AppConstants.LOGOUT)));
	}

	public ChangePasswordDiv changePassword() {
		changePasswordElement.click();
		return new ChangePasswordDiv();
	}

	public UpdateProfileDiv updateProfile() {
		updateProfileElement.click();
		return new UpdateProfileDiv();
	}

	public LoginPage logout() {
		logoutElement.click();
		return new LoginPage(driver);
	}

	public String readWelcomeMessage() {
		return welcomeMessageElement.getText();
	}

	/**
	 * @author arindam_r
	 * 
	 */
	public class ChangePasswordDiv {

		private WebElement oldPwdElement, newPwdElement, reTypePwdElement,
				captchaElement, cancelBtnElement, updateBtnElement,
				closeBtnElement;

		private ChangePasswordDiv() {
			initElements();
		}

		private void initElements() {
			oldPwdElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.RP_OLD_PWD)));
			newPwdElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.RP_NEW_PWD)));
			reTypePwdElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.RP_RETYPE_PWD)));
			captchaElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.RP_CAPTCHA)));
			cancelBtnElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.RP_CANCEL)));
			updateBtnElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.RP_UPDATE)));
			closeBtnElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.RP_CLOSE_BTN)));
		}

		public ChangePasswordDiv typeOldPassword(String oldPassword) {
			oldPwdElement.sendKeys(oldPassword);
			return this;
		}

		public ChangePasswordDiv typeNewPassword(String newPassword) {
			newPwdElement.sendKeys(newPassword);
			return this;
		}

		public ChangePasswordDiv reTypeNewPassword(String newPassword) {
			reTypePwdElement.sendKeys(newPassword);
			return this;
		}

		public ChangePasswordDiv typeCaptcha(String captcha) {
			captchaElement.sendKeys(captcha);
			return this;
		}

		public HomePage clickCancel() {
			cancelBtnElement.click();
			return HomePage.this;
		}

		public HomePage clickClose() {
			closeBtnElement.click();
			return HomePage.this;
		}

		public RPErrorMessageDiv clickUpdateExpectingFailure() {
			updateBtnElement.click();
			return new RPErrorMessageDiv();
		}

		public class RPErrorMessageDiv {

			WebElement errorMessageElement, okBtnElement;

			private RPErrorMessageDiv() {
				errorMessageElement = driver.findElement(By.xpath(ExcelUtil
						.readProps(pageName, AppConstants.RP_ERR_MSG)));
				okBtnElement = driver.findElement(By.xpath(ExcelUtil.readProps(
						pageName, AppConstants.RP_OK_BTN)));
			}

			public String readErrorMessage() {
				return errorMessageElement.getText();
			}

			public ChangePasswordDiv clickOKButton() {
				okBtnElement.click();
				return ChangePasswordDiv.this;
			}
		}
	}

	public class UpdateProfileDiv {

		private WebElement userNameElement, firstNameElement, lastNameElement,
				emailElement, roleElement, statusElement, phoneElement,
				mobileElement, cancelBtnElement, updateBtnElement,
				closeBtnElement;

		private UpdateProfileDiv() {
			initElements();
		}

		private void initElements() {
			userNameElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.UP_USER_NAME)));
			firstNameElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.UP_FIRST_NAME)));
			lastNameElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.UP_LAST_NAME)));
			emailElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.UP_EMAIL)));
			roleElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.UP_ROLE)));
			statusElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.UP_STATUS)));
			phoneElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.UP_PHONE)));
			mobileElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.UP_MOBILE)));
			cancelBtnElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.UP_CANCEL)));
			updateBtnElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.UP_UPDATE)));
			closeBtnElement = driver.findElement(By.xpath(ExcelUtil.readProps(
					pageName, AppConstants.UP_CLOSE)));
		}

		public String readUserName() {
			return userNameElement.getText();
		}

		public UpdateProfileDiv typeFirstName(String firstName) {
			firstNameElement.sendKeys(firstName);
			return this;
		}

		public UpdateProfileDiv typeLastName(String lastName) {
			lastNameElement.sendKeys(lastName);
			return this;
		}

		public UpdateProfileDiv typeEmail(String email) {
			emailElement.sendKeys(email);
			return this;
		}

		public String readRole() {
			return roleElement.getText();
		}

		public String readStatus() {
			return statusElement.getText();
		}

		public UpdateProfileDiv typePhone(String phone) {
			phoneElement.sendKeys(phone);
			return this;
		}

		public UpdateProfileDiv typeMobile(String mobile) {
			mobileElement.sendKeys(mobile);
			return this;
		}

		public HomePage clickCancel() {
			cancelBtnElement.click();
			return HomePage.this;
		}

		public HomePage clickClose() {
			closeBtnElement.click();
			return HomePage.this;
		}

		public UpdateProfileDiv clickUpdateExpectingFailure() {
			updateBtnElement.click();
			return this;
		}

		public HomePage clickUpdateExpectingSuccess() {
			updateBtnElement.click();
			return HomePage.this;
		}
	}

}
