package utils;

//Import required classes
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Properties;

/**
 * This class has methods to read or write from .properties file
 * @author Nagaraju Kura
 *
 */
public class PropertiesUtil {
	
	/**
	 * Path of .properties file
	 */
	private String propertiesFilePath;

	/**
	 * Constructor which takes .properties file path as input
	 * @param propertiesFilePath
	 */
	public PropertiesUtil(String propertiesFilePath) {
		this.propertiesFilePath = propertiesFilePath;
	}
	
	/**
	 * This method is used to write a map of values into
	 * .properties file
	 * @param map
	 */
	public void write(HashMap<String, String> map) {

		Properties prop = new Properties();

		try {
			//Iterate the HashMap
			for (Entry<String, String> entry : map.entrySet()) {
				//set the properties value
				prop.setProperty(entry.getKey().toString(), entry.getValue().toString());
			}


			//save properties to required folder
			prop.store(new FileOutputStream(propertiesFilePath), null);

			System.out.println("successfully written to properties file");

		} catch (IOException ex) {
			//Print the stacktrace
			ex.printStackTrace();
		}
	}

	/**
	 * This method reads the key from .properties file and returns it's value
	 * @param key
	 * @return value
	 */
	public String read(String key) {

		Properties prop = new Properties();

		try {
			//load a properties file
			prop.load(new FileInputStream(propertiesFilePath));


		}
		catch (IOException ex) {
			ex.printStackTrace();
		}
		
		//get the property value and return it
		return prop.getProperty(key).toString();

	}
	
}



