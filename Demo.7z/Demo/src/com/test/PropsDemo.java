package com.test;



/*import org.junit.Test;
import org.junit.BeforeClass;*/

import org.junit.BeforeClass;
import org.junit.Test;

import utils.PropertiesUtil;



public class PropsDemo{
	
/*	private static PropertiesUtil props ;
	
	public static void main (String[] args){
			
		props = new PropertiesUtil("src/resources/practise1.properties");
		
		System.out.println(props.read("surname"));
	}
	*/
	
	
	
	private static PropertiesUtil props ;
	
	@BeforeClass
    public static void initiliaxation(){
		props = new PropertiesUtil("src/resources/practise1.properties");
	}
	
	

	
	@Test
	public void test() {
		System.out.println(props.read("surname"));		
		
	}

}
