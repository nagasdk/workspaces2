package com.constants;


public class GenericConstants {
	
	public static final String WORKBOOK_PATH = "src/resources/OR.xlsx";
	public static String txtUserName="username";
	public static String txtPassWord="password";
	
	public static String LoginPage="Login";
	public static String USER_TEXTBOX="logintext_xpath";
	public static String PWD_TEXTBOX="pwd_xpath";
	
	public static String LOC_XPATH="xpath";
	public static String LOC_linkname="linkname";
	public static String LOC_ID="id";
	public static String LOC_css="css";
	

}
